/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.dataframe;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 10, 2019 2:41:59 PM
 * @Description
 *              <p>
 *              运行数据帧
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 10, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class RunDataFrame implements IDataFrame {

	private int id;

	private int type;

	private DataFrameD1 dataFrameD1;

	private DataFrameD2 dataFrameD2;

	private DataFrameD3 dataFrameD3;

	private DataFrameD4 dataFrameD4;

	@Override
	public int getID() {
		return id;
	}

	@Override
	public int getType() {
		return type;
	}

	public DataFrameD1 getDataFrameD1() {
		if (dataFrameD1 == null) {
			dataFrameD1 = new DataFrameD1();
		}
		return dataFrameD1;
	}

	public void setDataFrameD1(DataFrameD1 dataFrameD1) {
		this.dataFrameD1 = dataFrameD1;
	}

	public DataFrameD2 getDataFrameD2() {
		if (dataFrameD2 == null) {
			dataFrameD2 = new DataFrameD2();
		}
		return dataFrameD2;
	}

	public void setDataFrameD2(DataFrameD2 dataFrameD2) {
		this.dataFrameD2 = dataFrameD2;
	}

	public DataFrameD3 getDataFrameD3() {
		if (dataFrameD3 == null) {
			dataFrameD3 = new DataFrameD3();
		}
		return dataFrameD3;
	}

	public void setDataFrameD3(DataFrameD3 dataFrameD3) {
		this.dataFrameD3 = dataFrameD3;
	}

	public DataFrameD4 getDataFrameD4() {
		if (dataFrameD4 == null) {
			dataFrameD4 = new DataFrameD4();
		}
		return dataFrameD4;
	}

	public void setDataFrameD4(DataFrameD4 dataFrameD4) {
		this.dataFrameD4 = dataFrameD4;
	}

	@Override
	public void setID(int id) {
		this.id = id;
	}

	@Override
	public void setType(int type) {
		this.type = type;
	}

}
