package com.hirain.phm.bd.store.file;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(2)
public class FilepathInitialize implements ApplicationRunner {

	@Autowired
	private StoreProperties properties;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		File root = new File(properties.getRoot());
		if (!root.exists()) {
			root.mkdirs();
		}
		File container = new File(root, properties.getFolder());
		if (!container.exists()) {
			container.mkdirs();
		}
	}

}
