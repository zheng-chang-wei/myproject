package com.hirain.phm.bode.ui.monitor.figure.door;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.LineBorder;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;

import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;

public class DoorSheetFigure extends Figure implements StatusListener, IFigureMove {

	private final int width = 100, height = 225;

	private final int side;

	private final RoundRectangleFigure rectangleFigure = new RoundRectangleFigure();

	private final RectangleFigure windowFigure = new RectangleFigure();

	private final BottomFigure bf = new BottomFigure();

	private final RectangleFigure r_bottom_1 = new RectangleFigure();

	private final RectangleFigure r_bottom_2 = new RectangleFigure();

	private final RectangleFigure handle = new RectangleFigure();

	private int step;

	public DoorSheetFigure(int side) {
		this.side = side;
		setLayoutManager(new XYLayout());
		this.setOpaque(false);
		createFigure(side);
		setBackgroundColor(CarriageConstants.color_light_gray);
	}

	private void createFigure(int side) {
		add(rectangleFigure, new Rectangle(width, 0, width, height));
		rectangleFigure.setOpaque(true);
		windowFigure.setBorder(new LineBorder(2));
		if (side == DoorContent.LEFT) {
			add(rectangleFigure, new Rectangle(width, 0, width, height));

			add(handle, new Rectangle(width * 2 - 10, height / 2 - 5, 6, 12));

			add(windowFigure, new Rectangle(width * 5 / 4, 30, width * 3 / 5, height / 2));

			add(bf, new Rectangle(width, height - 30, width, 12));

			add(r_bottom_1, new Rectangle(width + 12, height - 27, 15, 6));

			add(r_bottom_2, new Rectangle(width * 2 - 22, height - 11, 15, 6));
			initPosition = leftArray;
		} else {
			add(rectangleFigure, new Rectangle(0, 0, width, height));

			add(handle, new Rectangle(4, height / 2 - 5, 6, 12));

			add(windowFigure, new Rectangle(width * 3 / 20, 30, width * 3 / 5, height / 2));

			add(bf, new Rectangle(0, height - 30, width, 12));

			add(r_bottom_1, new Rectangle(width - 26, height - 27, 15, 6));

			add(r_bottom_2, new Rectangle(7, height - 11, 15, 6));
			initPosition = rightArray;
		}
	}

	@Override
	public void update(int operation, int step) {
		this.step = step;
		if (side == DoorContent.LEFT) {
			// if (operation == DoorContent.OPEN_OPERATION) {
			moveToLeft();
			// } else if (operation == DoorContent.CLOSE_OPERATION) {
			// moveToRight();
			// }
		} else {
			// if (operation == DoorContent.OPEN_OPERATION) {
			moveToRight();
			// } else if (operation == DoorContent.CLOSE_OPERATION) {
			// moveToLeft();
			// }
		}
	}

	private int[] leftArray = { width, width * 2 - 10, width * 5 / 4, width, width + 12, width * 2 - 22 };

	private int[] rightArray = { 200 + 0, 200 + 4, 200 + width * 3 / 20, 200 + 0, 200 + width - 26, 200 + 7 };

	private int[] initPosition;

	@Override
	public void moveToRight() {
		rectangleFigure.getBounds().x = initPosition[0] + step;
		handle.getBounds().x = initPosition[1] + step;
		windowFigure.getBounds().x = initPosition[2] + step;
		bf.getBounds().x = initPosition[3] + step;
		r_bottom_1.getBounds().x = initPosition[4] + step;
		r_bottom_2.getBounds().x = initPosition[5] + step;
	}

	@Override
	public void moveToLeft() {
		rectangleFigure.getBounds().x = initPosition[0] - step;
		handle.getBounds().x = initPosition[1] - step;
		windowFigure.getBounds().x = initPosition[2] - step;
		bf.getBounds().x = initPosition[3] - step;
		r_bottom_1.getBounds().x = initPosition[4] - step;
		r_bottom_2.getBounds().x = initPosition[5] - step;
	}

	@Override
	public void reset() {
	}
}
