package com.hirain.phm.bode.server.mqtt;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Test;

public class TestSSLConnectin {

	private final String password = "123456";

	private static final String HOST = "ssl://10.40.2.34:8883";

	private static final String TOPIC = "hello";

	@Test
	public void test() throws Exception {
		final MqttConnection client = new MqttConnectionImpl(HOST, "test", new MqttHandler("test"));
		client.connect("F:\\ssl\\ca.crt", "F:\\ssl\\client.crt", "F:\\ssl\\client.key", password);
		client.subscribe(TOPIC);
		client.send(TOPIC, "Hello World".getBytes(), 1, false);

		TimeUnit.SECONDS.sleep(2);

		client.disconnect();
	}

	@Test
	public void testRead() throws IOException {
		final File file = new File("F:\\apache-apollo-1.7.1-windows-distro\\apache-apollo-1.7.1\\client.key");
		System.out.println(file.exists());
		FileUtils.readFileToByteArray(file);
	}
}
