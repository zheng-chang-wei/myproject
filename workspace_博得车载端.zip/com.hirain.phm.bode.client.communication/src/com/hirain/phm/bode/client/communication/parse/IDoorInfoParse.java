/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.parse;

import com.hirain.phm.bode.core.dataframe.DoorStatus;
import com.hirain.phm.bode.core.dataframe.IDataFrame;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 29, 2019 2:53:48 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 29, 2019 zepei.tao@hirain.com 1.0 create file
 */
public interface IDoorInfoParse {

	/**
	 * 分发实时数据（用来画曲线）
	 * 
	 * @param carNo
	 * @param doorNo
	 */
	void postRealTimeData(IDataFrame dataFrame);

	/**
	 * 分发门状态数据，用来刷新上方的车厢门状态
	 */
	void postDoorStatusData(DoorStatus doorStatus);

}
