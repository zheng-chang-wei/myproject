package com.hirain.phm.bode.server.log;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.hirain.phm.bode.server.db.DBService;

public class LogService {

	static Logger logger = Logger.getLogger(LogService.class);

	private static LogService instance = new LogService();

	private final String FILE_SEPARATOR = File.separator;

	public final String LOG_ROOT = System.getProperty("user.dir") + FILE_SEPARATOR + "log" + FILE_SEPARATOR;

	private static DateTimeFormatter pattern = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	private LocalDate date;

	private File file;

	private LogService() {
	}

	public static LogService instance() {
		return instance;
	}

	public void log(String username, String operation) {
		checkFile();
		if (file != null) {
			final LocalDateTime time = LocalDateTime.now();
			final String line = String.format("[%s] : %s - %s\r\n", time.format(pattern), username, operation);
			try {
				FileUtils.writeStringToFile(file, line, Charset.forName("UTF-8"), true);
			} catch (final IOException e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	public void log(LogEvent event) {
		checkFile();
		if (file != null) {
			final LocalDateTime time = LocalDateTime.now();
			final String line = String.format("[%s] %s\r\n", time.format(pattern), event.toString());
			try {
				FileUtils.writeStringToFile(file, line, Charset.defaultCharset(), true);
			} catch (final IOException e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	private void checkFile() {
		final LocalDate now = LocalDate.now();
		if (date == null || date.isBefore(now)) {
			date = now;
			final String filepath = filepath(date);
			final File folder = new File(LOG_ROOT + date.getYear());
			folder.mkdirs();
			file = new File(LOG_ROOT + filepath);
			if (!file.exists()) {
				try {
					insertLogRecord(date, filepath);
					file.createNewFile();
				} catch (final Exception e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
	}

	private void insertLogRecord(LocalDate date, String filepath) {
		final String day = date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		final SqlSession session = DBService.getInstance().getSession(true);
		final LogRecordMapper mapper = session.getMapper(LogRecordMapper.class);
		LogRecord record = mapper.selectByPrimaryKey(day);
		if (record == null) {
			record = new LogRecord();
			record.setDay(day);
			record.setFilepath(filepath);
			mapper.insert(record);
		}
	}

	private String filepath(LocalDate now) {
		return now.getYear() + FILE_SEPARATOR + "SysLog-" + now.format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".log";
	}
}
