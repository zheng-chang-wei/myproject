package com.hirain.phm.bode.server.fault;

import com.hirain.phm.bode.server.message.PreProcessor;
import com.hirain.phm.bode.server.server.ServerService;
import com.hirain.phm.bode.server.store.StoreService;

public class ServerFaultMock {

	private PreProcessor processor;

	private FaultService faultService;

	public void start() {
		processor = new PreProcessor();
		processor.init();

		faultService = new FaultService(processor);
		faultService.init();

		final StoreService storeService = new StoreService(processor);
		storeService.init();

		final ServerService serverService = new ServerService();
		serverService.init();

	}
}
