package com.hirain.phm.bode.server.bus;

import com.google.common.eventbus.EventBus;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年1月4日 下午2:42:46
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月4日 jianwen.xin@hirain.com 1.0 create file
 */
public class InnerEventBus {

	private static InnerEventBus instance = new InnerEventBus();

	private final EventBus bus;

	private InnerEventBus() {
		bus = new EventBus("Inner bus");
	}

	public static InnerEventBus getInstance() {
		return instance;
	}

	/**
	 * register bus
	 * 
	 * @param object
	 */
	public void register(Object object) {
		bus.register(object);
	}

	/**
	 * @param object
	 */
	public void unregister(Object object) {
		bus.unregister(object);
	}

	/**
	 * post event
	 * 
	 * @param object
	 */
	public void post(Object object) {
		bus.post(object);
	}
}
