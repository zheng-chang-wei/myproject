package com.hirain.phm.bd.mock;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.kafka.core.KafkaTemplate;

import com.hirain.phm.bd.common.ZipUtil;
import com.hirain.phm.bd.common.serialize.JsonUtil;
import com.hirain.phm.bd.message.CarriagePacket;
import com.hirain.phm.bd.message.CommonMessage;
import com.hirain.phm.bd.message.DoorPacket;
import com.hirain.phm.bd.message.TrainPacket;
import com.hirain.phm.bd.message.decode.DecodePacket;
import com.hirain.phm.bd.message.decode.KeyValueDecoder;
import com.hirain.phm.bd.message.decode.RunDataFrame;
import com.hirain.phm.bd.message.train.RegisterMessage;

@SpringBootApplication
public class MockApplication {

	private static KafkaTemplate<String, Object> kafkaTemplate;

	private static KeyValueDecoder decoder;

	private static Properties properties;

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(MockApplication.class, args);
		kafkaTemplate = context.getBean(KafkaTemplate.class);
		properties = context.getBean(Properties.class);
		System.out.println(properties.original);
		register();
		while (true) {
			send();
		}
	}

	/**
	 * 
	 */
	public static void send() {
		decoder = new KeyValueDecoder();
		InputStreamReader reader = null;
		BufferedReader br = null;
		try {
			ClassLoader loader = MockApplication.class.getClassLoader();
			InputStream inputStream = loader.getResourceAsStream("phm_data2.txt");
			reader = new InputStreamReader(inputStream);
			br = new BufferedReader(reader);
			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				byte[] bs = getBytes(line);

				if (properties.original) {
					sendOriginal(bs);
				} else {
					sendDecode(bs);
				}
				TimeUnit.MILLISECONDS.sleep(800);
			}
		} catch (Exception e) {
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (final IOException e) {
					e.printStackTrace();
				}
			}
			if (reader != null) {
				try {
					reader.close();
				} catch (final IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * @param line
	 * @return
	 */
	private static byte[] getBytes(String line) {
		byte[] bs = new byte[32];
		if (line != null) {
			int index = 0;
			for (int i = 0; i < line.length() - 1; i = i + 2) {
				String sub = line.substring(i, i + 2);
				int v = Integer.parseInt(sub, 16);
				bs[index++] = (byte) v;
			}
		}
		return addTimestamp(bs);
	}

	private static byte[] addTimestamp(byte[] data) {
		final LocalDateTime dateTime = LocalDateTime.now();
		data[21] = (byte) dateTime.getDayOfMonth();
		data[22] = (byte) dateTime.getHour();
		data[23] = (byte) dateTime.getMinute();
		data[25] = (byte) dateTime.getSecond();
		// final ByteBuffer buffer = ByteBuffer.allocate(2);
		// buffer.order(ByteOrder.LITTLE_ENDIAN).putShort((short) (dateTime.getNano() / 1000000));
		// buffer.flip();
		// data[26] = buffer.get();
		// data[27] = buffer.get();
		return data;
	}

	/**
	 */
	private static void register() {
		RegisterMessage message = new RegisterMessage();
		message.setCity("北京");
		message.setLine("01");
		message.setTrain("02");
		message.setMac1("60-14-B3-7D-C1-B5");
		message.setMac2("54-EE-75-DD-53-40");
		message.setSsl(false);
		message.setSid(0x01);
		String string = JsonUtil.toString(message);
		kafkaTemplate.send("train-ground", string.getBytes());
	}

	public static void sendDecode(byte[] bs) {
		bs[12] = 0x18;
		CommonMessage message = new CommonMessage();
		message.setDatas(bs);
		message.setMilli(0);
		message.setYear(2019);
		message.setMonth(7);
		RunDataFrame frame = decoder.decode(message);
		DecodePacket packet = new DecodePacket(0x21, "北京", "01");
		List<RunDataFrame> frames = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			frames.add(frame);
		}
		packet.setFrames(frames);
		packet.setKeys(KeyValueDecoder.keys);
		String string = JsonUtil.toString(packet);
		kafkaTemplate.send("decode-realtime-beijing-01", "beijing-01-02", string.getBytes(Charset.forName("utf-8")));
	}

	public static void sendOriginal(byte[] bs) {
		TrainPacket packet = create(bs);
		String string = JsonUtil.toString(packet);
		byte[] payload = ZipUtil.compress(string.getBytes(Charset.forName("utf-8")));
		kafkaTemplate.send("test-beijing-01", "beijing-01-02", payload);
	}

	public static TrainPacket create(byte[] bs) {
		TrainPacket packet = new TrainPacket();
		List<CarriagePacket> children = new ArrayList<>(2);
		for (int i = 0; i < 2; i++) {
			CarriagePacket carriagePacket = new CarriagePacket();
			List<DoorPacket> packets = new ArrayList<>(2);
			for (int j = 0; j < 2; j++) {
				DoorPacket doorPacket = new DoorPacket();
				List<CommonMessage> list = new ArrayList<>();
				for (int l = 0; l < 16; l++) {
					CommonMessage message = new CommonMessage();
					message.setDatas(bs);
					message.setYear(2019);
					message.setMonth(7);
					message.setMilli(100);
					list.add(message);
				}
				doorPacket.setDoorId(i);
				doorPacket.setMessages(list);
				packets.add(doorPacket);
			}
			carriagePacket.setCarriageId(i);
			carriagePacket.setPackets(packets);
			children.add(carriagePacket);
		}
		packet.setPackets(children);
		packet.setCity("北京");
		packet.setLine("01");
		packet.setTrain("02");
		packet.setIndex(1);
		return packet;
	}

}
