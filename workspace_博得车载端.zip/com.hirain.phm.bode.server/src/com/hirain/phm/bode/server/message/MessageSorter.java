package com.hirain.phm.bode.server.message;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

import com.hirain.phm.bode.core.IDoor;

class MessageSorter {

	private final BlockingQueue<DoorMessage> workQueue = new LinkedBlockingQueue<>();

	private final Map<Integer, List<DoorMessage>> cache = new HashMap<>();

	private final Map<Integer, TimestampHandler> handlerMap = new HashMap<>();

	private final int carriageId;

	private ExecutorService executor;

	private final Comparator<DoorMessage> comparator = (o1, o2) -> {
		return o1.getTimestamp().compareTo(o2.getTimestamp());
	};

	private final PreProcessor processor;

	private final AtomicBoolean stopped = new AtomicBoolean(false);

	public MessageSorter(PreProcessor processor, int carriageId, List<IDoor> doors) {
		this.processor = processor;
		this.carriageId = carriageId;
		if (doors != null) {
			for (final IDoor door : doors) {
				cache.put(door.getAddr(), new CopyOnWriteArrayList<>());
				handlerMap.put(door.getAddr(), new TimestampHandler());
			}
		}
	}

	public void work() {
		executor = Executors.newSingleThreadExecutor(r -> new Thread(r, "message sorter-" + carriageId));
		executor.submit(() -> {
			while (true) {
				if (stopped.get() && workQueue.isEmpty()) {
					break;
				}
				try {
					final DoorMessage doorMessage = workQueue.take();
					final List<DoorMessage> list = cache.getOrDefault(doorMessage.getDoorId(), new CopyOnWriteArrayList<>());
					list.add(doorMessage);
					if (list.size() >= 16) {
						Collections.sort(list, comparator);
						final List<DoorMessage> out = new ArrayList<>(list);
						final List<DoorMessage> subList = out.subList(0, 8);
						final List<DoorMessage> results = addMilli(subList, doorMessage.getDoorId());
						if (!results.isEmpty()) {
							processor.post(results);
						}
						list.clear();
						list.addAll(out.subList(8, out.size()));
					}
					cache.put(doorMessage.getDoorId(), list);
				} catch (final InterruptedException e) {
					PreProcessor.logger.error(e.getMessage(), e);
				}
			}
		});
	}

	private List<DoorMessage> addMilli(List<DoorMessage> subList, Integer doorId) {
		final TimestampHandler handler = handlerMap.get(doorId);
		final List<DoorMessage> results = new ArrayList<>();
		for (final DoorMessage message : subList) {
			final int milli = handler.nextMilli(message.getTimestamp(), message.getDatas()[0]);
			if (milli != -1) {
				final long time = message.getTimestamp().getTime();
				final Date date = new Date(time + milli);
				message.setTimestamp(date);
				message.setMilli(milli);
				results.add(message);
			}
		}
		return results;
	}

	public void stop() {
		stopped.set(true);
		if (executor != null) {
			executor.shutdown();
			executor = null;
		}
	}

	public void push(DoorMessage message) {
		try {
			workQueue.put(message);
		} catch (final InterruptedException e) {
			PreProcessor.logger.error(e.getMessage(), e);
		}
	}

}
