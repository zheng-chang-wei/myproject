/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.ground.train.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hirain.phm.bd.ground.common.service.BaseService;
import com.hirain.phm.bd.ground.train.dao.TrainMapper;
import com.hirain.phm.bd.ground.train.domain.Train;
import com.hirain.phm.bd.ground.train.param.TrainCountResponse;
import com.hirain.phm.bd.ground.train.param.TrainParam;
import com.hirain.phm.bd.ground.train.param.TrainParamHeader;
import com.hirain.phm.bd.ground.train.service.TrainService;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Apr 25, 2019 4:33:02 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Apr 25, 2019 zepei.tao@hirain.com 1.0 create file
 */
@Service
public class TrainServiceImpl extends BaseService<Train> implements TrainService {

	@Autowired
	private TrainMapper mapper;

	/**
	 * @see com.hirain.phm.bd.ground.train.service.TrainService.service.ITrainService#insertTrain(com.hirain.phm.bd.ground.db.model.LineRecord)
	 */
	@Override
	public void insertTrain(Train train) {
		mapper.insert(train);

	}

	/**
	 * @see com.hirain.phm.bd.ground.train.service.TrainService#findTrainsByParams(com.hirain.phm.bd.ground.train.param.TrainParam)
	 */
	@Override
	public List<TrainParam> findTrainsByParams(TrainParam trainParms) {
		return mapper.findTrainsByParams(trainParms);
	}

	@Override
	public List<Train> findTrains(TrainParamHeader trainParms) {
		return mapper.findTrains(trainParms);
	}

	@Override
	public List<Train> findTrainParamHeaderByUserId(Long userId) {
		return mapper.findTrainsByUserId(userId);
	}

	/**
	 * @see com.hirain.phm.bd.ground.train.service.TrainService#select(java.lang.String, java.lang.String)
	 */
	@Override
	public Train select(String project, String train) {
		return mapper.selectByProjectAndNo(project, train);
	}

	/**
	 * @see com.hirain.phm.bd.ground.train.service.TrainService#selectByCityAndLine(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Train> selectByCityAndLine(String city, String line) {
		return mapper.selectByCityAndLine(city, line);
	}

	/**
	 * @see com.hirain.phm.bd.ground.train.service.TrainService#selectByProject(java.lang.String)
	 */
	@Override
	public List<Train> selectByProject(String project) {
		return mapper.selectByProject(project);
	}

	/**
	 * @see com.hirain.phm.bd.ground.train.service.TrainService#countOnline()
	 */
	@Override
	public int countOnline() {
		Train record = new Train();
		record.setTrainOnline(true);
		return mapper.selectCount(record);
	}

	/**
	 * @see com.hirain.phm.bd.ground.train.service.TrainService#countAll()
	 */
	@Override
	public int countAll() {
		return mapper.selectCount(new Train());
	}

	/**
	 * @see com.hirain.phm.bd.ground.train.service.TrainService#countOnlineDoor()
	 */
	@Override
	public int countOnlineDoor() {
		return mapper.selectCountOfOnlineDoor();
	}

	/**
	 * @see com.hirain.phm.bd.ground.train.service.TrainService#countTrain()
	 */
	@Override
	public TrainCountResponse countTrain() {
		TrainCountResponse response = new TrainCountResponse();
		response.setTotal(countAll());
		response.setOnline(countOnline());
		response.setOnlineDoor(countOnlineDoor());
		return response;
	}
}
