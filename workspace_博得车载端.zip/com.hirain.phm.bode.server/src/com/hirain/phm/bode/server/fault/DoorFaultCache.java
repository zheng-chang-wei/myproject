package com.hirain.phm.bode.server.fault;

class DoorFaultCache {

	private FaultRecord record;

	private int action;

	private int count = 0;

	public DoorFaultCache(FaultRecord record, int action) {
		this.record = record;
		this.action = action;
	}

	public void setRecord(FaultRecord record) {
		this.record = record;
	}

	public FaultRecord getRecord() {
		return record;
	}

	public int getAction() {
		return action;
	}

	public void setAction(int action) {
		this.action = action;
	}

	public int increaseAndGet() {
		count++;
		return count;
	}
}
