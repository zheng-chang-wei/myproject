package com.hirain.phm.bd.store.original;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OriginalStoreAppApplicationTests {

	@Test
	public void contextLoads() {
	}

}
