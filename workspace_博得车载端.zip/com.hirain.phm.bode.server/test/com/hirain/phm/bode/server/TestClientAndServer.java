package com.hirain.phm.bode.server;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.util.SystemInfoUtil;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.config.ConfigurationService;
import com.hirain.phm.bode.server.server.ServerConstant;

public class TestClientAndServer {

	private static InetSocketAddress serverAddr = new InetSocketAddress(TestConstant.LOCALHOST, 17257);

	private static InetSocketAddress heartAddr = new InetSocketAddress(TestConstant.LOCALHOST, 17258);

	private DatagramSocket client;

	public void setUp() {
		final ServerMock mock = new ServerMock();
		mock.start();
	}

	@Test
	public void testSetting() throws Exception {
		setUp();
		DatagramSocket client = null;
		DatagramSocket mdcu = null;
		try {
			client = new DatagramSocket(17229);

			final ITrain train = ConfigurationService.getInstance().getTrain();
			train.setCityName("bj");
			final byte[] bs = SystemInfoUtil.convertSystemInfo2XmlBytes(train);
			final ByteBuffer buffer = ByteBuffer.allocate(3 + bs.length);
			buffer.put((byte) 0x03);
			buffer.putShort((short) bs.length);
			buffer.put(bs);
			final DatagramPacket send = new DatagramPacket(buffer.array(), 3 + bs.length);
			send.setSocketAddress(serverAddr);

			mdcu = new DatagramSocket(ServerConstant.TO_MDCU_PORT);

			client.send(send);

			final DatagramPacket ok = new DatagramPacket(new byte[100], 100);
			mdcu.receive(ok);
			final DatagramPacket receive = new DatagramPacket(new byte[4], 4);
			client.receive(receive);

			final byte[] bs2 = receive.getData();
			assertEquals(0x13, bs2[0]);
			assertEquals(0, bs2[3]);

			final String result = new String(ok.getData()).trim();
			assertEquals("ok", result);

		} finally {
			if (client != null) {
				client.close();
			}
			if (mdcu != null) {
				mdcu.close();
			}
		}
	}

	@Test
	public void testMessage() throws IOException, InterruptedException {
		setUp();
		final MDCUMock mdcuMock = new MDCUMock();
		client = null;
		try {
			mdcuMock.start(true);
			client = new DatagramSocket(17229);
			TestConstant.login1(client);
			final ExecutorService executor = Executors.newSingleThreadExecutor();
			executor.submit(() -> {
				DatagramPacket packet;
				final byte[] buf = new byte[] { (byte) 0xAA, 0, 1, 0 };
				while (true) {
					packet = new DatagramPacket(buf, 4);
					packet.setSocketAddress(heartAddr);
					client.send(packet);
					TimeUnit.SECONDS.sleep(3);
				}
			});
			final ByteBuffer buffer = ByteBuffer.allocate(5);
			buffer.put((byte) 0x04);
			buffer.putShort((short) 2);
			buffer.put((byte) 2);
			buffer.put((byte) 1);

			final DatagramPacket packet = new DatagramPacket(buffer.array(), 5);
			packet.setSocketAddress(serverAddr);
			client.send(packet);

			final ITrain train = ConfigurationService.getInstance().getTrain();
			if (train != null) {
				InnerEventBus.getInstance().post(new ConfigEvent(train, null));
			} else {
				return;
			}

			int index = 0;
			while (index < 15) {
				final DatagramPacket packet2 = new DatagramPacket(new byte[35], 35);
				client.receive(packet2);
				final byte[] data = packet2.getData();
				if (data[0] == 0x14) {
					System.out.println(convertBytes2Line(data));
					index++;
				}
			}

		} finally {
			if (client != null) {
				client.close();
			}
			mdcuMock.stop();
		}
	}

	public String convertBytes2Line(byte[] bs) {
		final StringBuilder sb = new StringBuilder();
		for (int i = 3; i < bs.length; i++) {
			final byte b = bs[i];
			final String hex = Integer.toHexString(b & 0xff);
			if (hex.length() < 2) {
				sb.append("0");
			}
			sb.append(hex.toUpperCase()).append(" ");
		}
		return sb.toString();
	}

}
