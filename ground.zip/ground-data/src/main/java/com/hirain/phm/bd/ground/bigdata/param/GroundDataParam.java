package com.hirain.phm.bd.ground.bigdata.param;

import lombok.Data;

@Data
public class GroundDataParam {

	private String project;

	private String train;
}
