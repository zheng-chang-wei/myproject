package com.hirain.phm.bode.server.client;

public class ClientConstants {

	/** ------------ port---------------- **/

	public static final int LOCAL_CLIENT_PORT = 17257;

	public static final int LOCAL_HEART_PORT = 17258;

	public static final int LOCAL_UPLOAD_PORT = 17259;

	/** ------------ command id---------------- **/

	public static final int SYSTEM_CONFIG_QUERY = 0x01;

	public static final int STORAGE_SPACE_QUERY = 0x02;

	public static final int SYSTEM_CONFIG_UPDATE = 0x03;

	public static final int SPECIFY_DOOR_QUERY = 0x04;

	public static final int DEBUG_COMMAND_ID = 0x06;

	public static final int LOGIN_COMMAND_ID = 0x07;

	public static final int LOGOUT_COMMAND_ID = 0x08;

	public static final int DATA_QUERY_ID = 0x09;

	public static final int DATA_REPLAY_ID = 0x0a;

	public static final int DATA_STATISTICS_ID = 0x0b;

	public static final int DATA_DOWNLOAD_ID = 0x0c;

	/** ------------------response id-------------------- **/

	public static final int SYSTEM_CONFIG_RESPONSE = 0x11;

	public static final int STORAGE_SPACE_RESPONSE = 0x12;

	public static final int SYSTEM_CONFIG_CONFIRM = 0x13;

	public static final int SPECIFY_DOOR_RESPONSE = 0x14;

	public static final int DEBUG_CONFIRM_ID = 0x16;

	public static final int LOGIN_CONFIRM_ID = 0x17;

	public static final int LOGOUT_CONFIRM_ID = 0x18;

	public static final int DATA_QUERY_RESPONSE = 0x19;

	public static final int DATA_DOWNLOAD_RESPONSE = 0x1a;

	public static final int DATA_STATISTICS_RESPONSE = 0x1b;

	/** ----------------------sid-------------------- **/

	public static final byte COMMON_TAG = 1;

	public static final byte FAULT_TAG = 2;

	public static final byte FAULT_LIST = 3;

	public static final byte LOG_TAG = 5;

	public static final byte EOF = 2;

}
