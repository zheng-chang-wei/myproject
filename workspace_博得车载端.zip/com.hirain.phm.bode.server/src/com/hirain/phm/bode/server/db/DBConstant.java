package com.hirain.phm.bode.server.db;

public class DBConstant {

	public static String MESSAGE_TABLE_SUFFIX = "message";

	public static String RECORD_TABLE_SUFFIX = "record";

	public static String FAULT_MESSAGE_TABLE = "t_fault_message";

	public static String FAULT_RECORD_TABLE = "t_fault_record";

}
