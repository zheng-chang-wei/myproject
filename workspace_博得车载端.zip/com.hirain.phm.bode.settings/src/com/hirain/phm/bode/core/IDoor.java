/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 3:39:19 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
public interface IDoor {

	void setAddr(int addr);

	int getAddr();
}
