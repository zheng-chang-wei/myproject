package com.hirain.phm.bode.ui.monitor.model;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.swt.graphics.Color;

public enum DoorStateEnum {
	// 门完全关闭
	door_close(0, ColorConstants.green, "门完全关闭"),
	// 门完全打开
	door_open(1, ColorConstants.yellow, "门完全打开"),
	// 开门过程中
	door_openning(2, new Color(null, 204, 102, 204), "开门过程中"),
	// 关门过程中
	door_closing(3, ColorConstants.blue, "关门过程中"),
	// 通讯故障
	communication_malfunction(4, ColorConstants.black, "通讯故障   "),
	// 门故障
	door_malfunction(5, ColorConstants.red, "门故障       "),
	// 隔离
	isolation(6, ColorConstants.red, "隔离       "),
	// 紧急解锁
	emergency_unlock(7, ColorConstants.red, "紧急解锁"),
	// 防挤压
	anti_crush(8, ColorConstants.red, "防挤压   ");

	private int code;

	private Color color;

	private String lable;

	DoorStateEnum(int code, Color color, String lable) {
		this.code = code;
		this.color = color;
		this.lable = lable;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public String getLable() {
		return lable;
	}

	public void setLable(String lable) {
		this.lable = lable;
	}

}
