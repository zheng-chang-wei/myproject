package com.hirain.phm.bode.ui.util;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.nebula.visualization.xygraph.util.XYGraphMediaFactory;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import com.hirain.phm.bode.core.dataframe.DataFrameD1;
import com.hirain.phm.bode.core.dataframe.DataFrameD2;
import com.hirain.phm.bode.core.dataframe.DataFrameD3;
import com.hirain.phm.bode.core.dataframe.DataFrameD4;
import com.hirain.phm.bode.core.dataframe.DoorStatus;
import com.hirain.phm.bode.core.dataframe.IDataFrame;
import com.hirain.phm.bode.core.dataframe.RunDataFrame;
import com.hirain.phm.bode.core.util.DataFrameDecoder;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;
import com.hirain.phm.bode.ui.monitor.model.Position;
import com.hirain.phm.bode.ui.monitor.model.XYGraphViewer;
import com.hirain.phm.bode.ui.monitor.model.XYSeries;
import com.hirain.phm.bode.ui.monitor.provider.TableViewerContentProvider;
import com.hirain.phm.bode.ui.monitor.provider.TableViewerLabelProvider;
import com.hirain.phm.bode.ui.monitor.utils.Util;

public class PlotUtil {

	/**
	 * 车辆信号名称
	 */
	private String[] carSignal;

	/**
	 * 输入信号名称
	 */
	private String[] inputSignal;

	/**
	 * 输出信号名称
	 */
	private String[] outputSignal;

	/**
	 * 电机与指令信号名称
	 */
	private String[] electromechanicalSignal;

	// private Map<String, List<Position>> dataCacheMap = new LinkedHashMap<>();

	private List<List<String>> signalLists;

	private List<String[]> signalAttrList = new ArrayList<>();

	private List<List<List<Position>>> tableList = new ArrayList<>();

	private List<TableItem> tableItems = new ArrayList<>();

	private List<XYGraphViewer> graphViewerList = new ArrayList<>();

	private List<CheckboxTableViewer> checkboxTableViewerList = new ArrayList<>();

	private List<Button> buttonSelectAllList = new ArrayList<>();

	private String configFilePath = System.getProperty("user.dir") + "\\signal.ini";

	public void createPlotArea(Composite coreComposite) {
		readIni();
		Composite composite = new Composite(coreComposite, SWT.NONE);
		composite.setLayout(new GridLayout(4, false));
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		// linkToScroll(composite);
		createDeviceTableViewer(composite, "车\r\n辆\r\n信\r\n号", signalLists.get(0));
		createAPlot(composite);
		createDeviceTableViewer(composite, "车\r\n辆\r\n信\r\n号", signalLists.get(0));
		createAPlot(composite);
		createDeviceTableViewer(composite, "输\r\n入\r\n输\r\n出\r\n信\r\n号", signalLists.get(1));
		createAPlot(composite);
		createDeviceTableViewer(composite, "输\r\n入\r\n输\r\n出\r\n信\r\n号", signalLists.get(1));
		createAPlot(composite);
		createDeviceTableViewer(composite, "电\r\n机\r\n与\r\n指\r\n令\r\n信\r\n号", signalLists.get(2));
		createAPlot(composite);
		createDeviceTableViewer(composite, "电\r\n机\r\n与\r\n指\r\n令\r\n信\r\n号", signalLists.get(2));
		createAPlot(composite);

		initSignalAttrList();
		initPositions();
	}

	private void initSignalAttrList() {
		signalAttrList.add(CarriageConstants.carSignalAttrs);
		signalAttrList.add(CarriageConstants.inputAndOutputSignaleAttrs);
		signalAttrList.add(CarriageConstants.electromechanicalSignalAttrs);
	}

	private void initPositions() {
		for (String[] signalAttrs : signalAttrList) {
			// 每一个表格一个tableAttrsList，里面存放每个属性的所有点
			List<List<Position>> tableAttrsList = new ArrayList<>();
			for (int i = 0; i < signalAttrs.length; i++) {
				List<Position> positions = new ArrayList<>();
				tableAttrsList.add(positions);
			}
			tableList.add(tableAttrsList);
		}
	}

	private void createDeviceTableViewer(Composite parent, String title, List<String> input) {
		Composite composite = new Composite(parent, SWT.None);
		composite.setLayout(new GridLayout(2, false));
		GridData gridData = new GridData(SWT.FILL, SWT.FILL, false, false);
		composite.setLayoutData(gridData);
		composite.setBackground(new Color(null, 215, 215, 215));

		Composite compositeTitle = new Composite(composite, SWT.NONE);
		compositeTitle.setLayout(new GridLayout());
		compositeTitle.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, true, 1, 2));
		compositeTitle.setBackground(new Color(null, 215, 215, 215));
		Label labTitle = new Label(compositeTitle, SWT.VERTICAL);
		labTitle.setText(title);
		labTitle.setBackground(new Color(null, 215, 215, 215));
		labTitle.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, true));

		TableViewer tableViewerDevice = new TableViewer(composite, SWT.BORDER | SWT.CHECK | SWT.FULL_SELECTION | SWT.MULTI | SWT.V_SCROLL);
		final Table table = tableViewerDevice.getTable();
		table.setLinesVisible(true);
		CheckboxTableViewer checkboxTableViewerDevice = new CheckboxTableViewer(table);
		TableLayout layoutDevice = new TableLayout();
		table.setLayout(layoutDevice);
		GridData layoutData = new GridData(SWT.FILL, SWT.FILL, false, false);
		layoutData.heightHint = 230;
		layoutData.widthHint = 150;
		table.setLayoutData(layoutData);

		layoutDevice.addColumnData(new ColumnWeightData(3));
		new TableColumn(table, SWT.None);
		layoutDevice.addColumnData(new ColumnWeightData(1));
		new TableColumn(table, SWT.None);
		checkboxTableViewerDevice.setContentProvider(new TableViewerContentProvider());
		checkboxTableViewerDevice.setLabelProvider(new TableViewerLabelProvider());
		checkboxTableViewerDevice.setInput(input);
		checkboxTableViewerList.add(checkboxTableViewerDevice);

		Composite compositeSelectAll = new Composite(composite, SWT.BORDER);
		compositeSelectAll.setLayout(new GridLayout());
		compositeSelectAll.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false));
		compositeSelectAll.setBackground(new Color(null, 215, 215, 215));
		Button btnSelectAll = new Button(compositeSelectAll, SWT.None);
		btnSelectAll.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		btnSelectAll.setText("全选");
		btnSelectAll.setBackground(new Color(null, 215, 215, 215));
		buttonSelectAllList.add(btnSelectAll);
		btnSelectAll.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			String text = btnSelectAll.getText();
			int index = checkboxTableViewerList.indexOf(checkboxTableViewerDevice);
			XYGraphViewer xyGraphViewer = graphViewerList.get(index);
			if (text.equals("全选")) {
				btnSelectAll.setText("清除");
				for (int i = 0; i < input.size(); i++) {
					if (!checkboxTableViewerDevice.getChecked(table.getItem(i).getText())) {
						List<Position> positions = tableList.get(index / 2).get(i);
						Color color = XYGraphMediaFactory.getInstance().getColor(CarriageConstants.DEFAULT_TRACES_COLOR[i % 12]);
						table.getItem(i).setBackground(1, color);
						xyGraphViewer.setInput(Util.getData(input.get(i), positions, color));
						tableItems.add(table.getItem(i));
					}
				}
				checkboxTableViewerDevice.setAllChecked(true);
			} else {
				checkboxTableViewerDevice.setAllChecked(false);
				btnSelectAll.setText("全选");
				xyGraphViewer.clearTrace();
				for (int i = 0; i < input.size(); i++) {
					table.getItem(i).setBackground(1, ColorConstants.white);
					tableItems.remove(table.getItem(i));
				}
			}
		}));
		// TODO 勾选
		checkboxTableViewerDevice.addCheckStateListener(event -> {
			checkAllChanged(checkboxTableViewerDevice, input, btnSelectAll);
			String element = (String) event.getElement();
			boolean checked = event.getChecked();
			int index = checkboxTableViewerList.indexOf(checkboxTableViewerDevice);
			// table第几个元素被选中
			int elementCheckedIndex = input.indexOf(element);
			TableItem item = table.getItem(elementCheckedIndex);
			XYGraphViewer xyGraphViewer = graphViewerList.get(index);
			if (checked) {
				tableItems.add(item);
				List<Position> positions = tableList.get(index / 2).get(elementCheckedIndex);
				Color color = XYGraphMediaFactory.getInstance().getColor(CarriageConstants.DEFAULT_TRACES_COLOR[elementCheckedIndex % 12]);
				item.setBackground(1, color);
				List<XYSeries> data = Util.getData(element, positions, color);
				xyGraphViewer.setInput(data);
			} else {
				xyGraphViewer.removeTrace(element);
				item.setBackground(1, ColorConstants.white);
				tableItems.remove(item);
			}

		});
	}

	public void createAPlot(final Composite bottom) {
		XYGraphViewer graphViewerA = new XYGraphViewer(bottom);
		graphViewerA.setToolbarEnable(true);
		graphViewerList.add(graphViewerA);
		final GridData layoutData = new GridData(GridData.FILL_HORIZONTAL);
		graphViewerA.getContent().setLayoutData(layoutData);

	}

	private void readIni() {
		final Properties properties = Util.getProperties(configFilePath);
		for (final Map.Entry<Object, Object> propertie : properties.entrySet()) {
			String key = (String) propertie.getKey();
			String value = (String) propertie.getValue();
			switch (key) {
			case "车厢信号":
				carSignal = value.split(StringUtil.COMMA);
				break;
			case "输入信号":
				inputSignal = value.split(StringUtil.COMMA);
				break;
			case "输出信号":
				outputSignal = value.split(StringUtil.COMMA);
				break;
			case "电机与指令信号":
				electromechanicalSignal = value.split(StringUtil.COMMA);
				break;
			default:
				break;
			}
		}
		signalLists = new ArrayList<>();
		signalLists.add(Util.string2List(carSignal));
		List<String> inputAndOutputSignals = new ArrayList<>();
		inputAndOutputSignals.addAll(Util.string2List(inputSignal));
		inputAndOutputSignals.addAll(Util.string2List(outputSignal));
		signalLists.add(inputAndOutputSignals);
		signalLists.add(Util.string2List(electromechanicalSignal));
	}

	public void decodeResultMessage(byte[] messageData) {
		List<byte[]> messages = getMessages(messageData);
		// System.err.println(messages.size());
		for (byte[] datas : messages) {
			ByteBuffer buffer = ByteBuffer.wrap(datas);
			byte[] source = new byte[32];
			buffer.get(source);
			short milli = buffer.getShort();
			Map<IDataFrame, DoorStatus> map = new DataFrameDecoder().convertBytes2DataFrame(source);
			RunDataFrame runDataFrame = null;
			for (IDataFrame key : map.keySet()) {
				runDataFrame = (RunDataFrame) key;
			}
			DataFrameD1 dataFrameD1 = runDataFrame.getDataFrameD1();
			DataFrameD2 dataFrameD2 = runDataFrame.getDataFrameD2();
			DataFrameD3 dataFrameD3 = runDataFrame.getDataFrameD3();
			DataFrameD4 dataFrameD4 = runDataFrame.getDataFrameD4();
			dataFrameD4.setMillisecond(milli);
			long millis = Util.getCurrentTimeMillis(dataFrameD3, dataFrameD4);

			for (int i = 0; i < signalAttrList.size(); i++) {
				String[] signalAttrs = signalAttrList.get(i);
				// 获取第i个表格
				List<List<Position>> tablePositions = tableList.get(i);
				for (int j = 0; j < signalAttrs.length; j++) {
					// 获取第i个表格的第j条曲线包含的点
					List<Position> positions = tablePositions.get(j);
					// Object currentValue = Util.getValue(dataFrameList, signalAttrs[j]);
					Object currentValue = null;
					switch (i) {
					case 0:
						if (j == 24) {
							currentValue = dataFrameD3.getCloseDoorTime();
						} else {
							currentValue = Util.getValueByAttr(dataFrameD1, signalAttrs[j]);
						}
						if (currentValue == null) {
							currentValue = Util.getValueByAttr(dataFrameD2, signalAttrs[j]);
						}
						break;
					case 1:
						currentValue = Util.getValueByAttr(dataFrameD1, signalAttrs[j]);
						break;
					case 2:
						currentValue = Util.getValueByAttr(dataFrameD2, signalAttrs[j]);
						if (currentValue == null) {
							currentValue = Util.getValueByAttr(dataFrameD3, signalAttrs[j]);
						}
						break;
					default:
						break;
					}
					Position position = null;
					if (currentValue instanceof Boolean) {
						boolean value = (boolean) currentValue;
						position = new Position(millis, value ? 1 : 0);
					} else {
						position = new Position(millis, Double.valueOf(String.valueOf(currentValue)));
					}
					positions.add(position);
				}
			}
			// int size = tableList.get(0).get(0).size();
			// System.out.println(size);
		}
	}

	public void clearXYGraphViewer() {
		for (List<List<Position>> pLists : tableList) {
			for (List<Position> list : pLists) {
				list.clear();
			}
		}
		for (TableItem item : tableItems) {
			item.setBackground(1, ColorConstants.white);
		}
		for (XYGraphViewer xYGraphViewer : graphViewerList) {
			xYGraphViewer.clearTrace();
		}
		for (CheckboxTableViewer checkboxTableViewer : checkboxTableViewerList) {
			checkboxTableViewer.setAllChecked(false);
		}
		for (Button button : buttonSelectAllList) {
			button.setText("全选");
		}
	}

	public List<byte[]> getMessages(byte[] data) {
		List<byte[]> messages = new ArrayList<>();
		ByteBuffer buffer = ByteBuffer.wrap(data);
		buffer.get();
		int num = Short.toUnsignedInt(buffer.getShort());
		for (int i = 0; i < num; i++) {
			byte[] datas = new byte[32 + 2];
			buffer.get(datas);
			messages.add(datas);
		}
		return messages;

	}

	public static void checkAllChanged(CheckboxTableViewer checkboxTableViewerDevice, List<String> input, Button btnSelectAll) {
		if (checkboxTableViewerDevice.getCheckedElements().length < input.size()) {
			btnSelectAll.setText("全选");
		} else {
			btnSelectAll.setText("清除");
		}
	}
}
