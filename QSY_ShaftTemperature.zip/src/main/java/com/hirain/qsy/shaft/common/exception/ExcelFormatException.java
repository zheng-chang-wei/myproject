package com.hirain.qsy.shaft.common.exception;

public class ExcelFormatException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8393981291913827910L;

	public ExcelFormatException(String message) {
		super(message);
	}

}
