package com.hirain.phm.bode.server.ground.sender;

import com.hirain.phm.bode.server.mqtt.MqttPublisher;

import lombok.Setter;

public class RealtimeMessageSender {

	@Setter
	private MqttPublisher publisher;

	@Setter
	private String topic;

	public void send(byte[] payload) {
		if (publisher != null && publisher.isConnected()) {
			publisher.sendAsync(topic, payload);
			System.out.println("realtime:" + payload.length);
		}
	}
}
