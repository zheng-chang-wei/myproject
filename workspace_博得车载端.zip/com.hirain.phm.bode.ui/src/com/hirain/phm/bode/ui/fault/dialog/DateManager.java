package com.hirain.phm.bode.ui.fault.dialog;

public class DateManager {

	private static Date dateStart = null;

	private static Date dateEnd = null;

	private DateManager() {

	}

	public static Date getDateStart() {
		if (dateStart == null) {
			dateStart = new Date();
		}
		return dateStart;
	}

	public static Date getDateEnd() {
		if (dateEnd == null) {
			dateEnd = new Date();
		}
		return dateEnd;
	}
}
