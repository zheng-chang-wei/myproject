package com.hirain.phm.bd.ground.authority.service.impl;

import org.springframework.stereotype.Service;

import com.hirain.phm.bd.ground.authority.domain.RepairRole;
import com.hirain.phm.bd.ground.authority.service.ApprovalRoleService;
import com.hirain.phm.bd.ground.common.service.BaseService;

@Service
public class ApprovalRoleServiceImpl extends BaseService<RepairRole> implements ApprovalRoleService {


}
