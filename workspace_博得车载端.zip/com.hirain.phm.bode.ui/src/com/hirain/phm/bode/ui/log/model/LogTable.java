package com.hirain.phm.bode.ui.log.model;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年2月22日 下午3:53:12
 * @Description
 *              <p>
 *              表格中的日志条目
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年2月22日 changwei.zheng@hirain.com 1.0 create file
 */
public class LogTable {

	private String logTime;

	private String logName;

	public String getLogTime() {
		return logTime;
	}

	public void setLogTime(String logTime) {
		this.logTime = logTime;
	}

	public String getLogName() {
		return logName;
	}

	public void setLogName(String logName) {
		this.logName = logName;
	}

}
