package com.hirain.phm.bode.ui.monitor.figure.carriage;

import java.util.List;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.MouseEvent;
import org.eclipse.draw2d.MouseListener;
import org.eclipse.draw2d.MouseMotionListener;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.monitor.listener.HandlerDoorCheckedManager;
import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created Jan 4, 2019 6:51:36 PM
 * @Description
 *              <p>
 *              车厢
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 4, 2019 changwei.zheng@hirain.com 1.0 create file
 */
public class CarriageFigure extends CommonCarriageFigure {

	/**
	 * 一节车厢的宽度
	 */
	private int carriageWidth = 0;

	/**
	 * 车厢的高度
	 */
	private int carriageHeight = 0;

	private final int spacing = CarriageConstants.carriageHorizontalSpacing + CarriageConstants.doorWidth;

	private ButtonFigure mdcuButtonFigure;

	public CarriageFigure(ICar carriage, boolean isConfig, boolean isTop) {
		super(carriage, isConfig);
		List<IDoor> door = carriage.getDoors();
		int doorCount = door.size();
		RectangleFigure rectangleFigure = new RectangleFigure();
		carriageWidth = spacing * 12 / 2 + CarriageConstants.carriageHorizontalSpacing;
		int startWidth = (carriageWidth + 5 - 30 * doorCount / 2) / 2;
		add(rectangleFigure, new Rectangle(0, 0, carriageWidth, CarriageConstants.carriageHeight));
		add(label, new Rectangle(0, 0, carriageWidth, CarriageConstants.carriageHeight));
		int doorIndex = 0;
		for (int i = 0; i < doorCount / 2; i++) {
			if (isTop) {
				doorIndex = 2 * (i + 1);
			} else {
				doorIndex = 2 * (doorCount / 2 - i - 1) + 1;
			}
			final DoorFigure doorFigure = new DoorFigure(doorIndex + "", isConfig);
			doorFigureMap.put(carriage.getIndex() + StringUtil.UNDER_LINE + doorFigure.getName(), doorFigure);

			add(doorFigure, new Rectangle(startWidth + spacing * i, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
		}
		for (int i = 0; i < doorCount / 2; i++) {
			if (isTop) {
				doorIndex = 2 * i + 1;
			} else {
				doorIndex = 2 * (doorCount / 2 - i);
			}
			final DoorFigure doorFigure = new DoorFigure(doorIndex + "", isConfig);
			doorFigureMap.put(carriage.getIndex() + StringUtil.UNDER_LINE + doorFigure.getName(), doorFigure);
			add(doorFigure, new Rectangle(startWidth + spacing * i, CarriageConstants.carriageHeight - CarriageConstants.doorWidth,
					CarriageConstants.doorWidth, CarriageConstants.doorWidth));
		}
		if (isConfig) {
			// setBackgroundColor(CarriageConstants.color_gray);
			carriageHeight = CarriageConstants.carriageHeight + CarriageConstants.buttonSpacing + CarriageConstants.doorWidth;
			mdcuButtonFigure = new ButtonFigure();
			add(mdcuButtonFigure,
					new Rectangle((carriageWidth - CarriageConstants.buttonWidth) / 2,
							CarriageConstants.carriageHeight + CarriageConstants.carriageHorizontalSpacing * 2, CarriageConstants.buttonWidth,
							CarriageConstants.doorWidth));
			rectangleFigure.addMouseListener(new MouseListener() {

				@Override
				public void mouseDoubleClicked(MouseEvent arg0) {

				}

				@Override
				public void mousePressed(MouseEvent arg0) {
					if (isConfig) {
						HandlerDoorCheckedManager.getInstatnce().carChecked(carriage);
						setLabelText(carriage.getName());
					}
				}

				@Override
				public void mouseReleased(MouseEvent arg0) {

				}
			});

		}
		addListener();
	}

	@Override
	protected void addListener() {
		super.addListener();
		if (mdcuButtonFigure != null) {
			mdcuButtonFigure.addMouseListener(new MouseListener() {

				@Override
				public void mousePressed(MouseEvent me) {
					HandlerDoorCheckedManager.getInstatnce().mdcuChecked(car);
				}

				@Override
				public void mouseReleased(MouseEvent me) {

				}

				@Override
				public void mouseDoubleClicked(MouseEvent me) {

				}
			});
			mdcuButtonFigure.addMouseMotionListener(new MouseMotionListener() {

				@Override
				public void mouseMoved(MouseEvent me) {

				}

				@Override
				public void mouseHover(MouseEvent me) {

				}

				@Override
				public void mouseExited(MouseEvent me) {
					mdcuButtonFigure.setBackgroundColor(CarriageConstants.color_light_gray);
					Display.getDefault().getActiveShell().setCursor(null);
				}

				@Override
				public void mouseEntered(MouseEvent me) {
					mdcuButtonFigure.setBackgroundColor(ColorConstants.gray);
					Display.getDefault().getActiveShell().setCursor(Display.getDefault().getSystemCursor(SWT.CURSOR_HAND));
				}

				@Override
				public void mouseDragged(MouseEvent me) {

				}
			});
		}
	}

	/**
	 * 获取一节车厢的宽度
	 */
	@Override
	public int getCarriageWidth() {
		return carriageWidth;
	}

	public int getCarriageHeight() {
		return carriageHeight;
	}

}
