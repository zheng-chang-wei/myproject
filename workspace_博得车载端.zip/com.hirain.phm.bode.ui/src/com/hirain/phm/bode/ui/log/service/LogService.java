package com.hirain.phm.bode.ui.log.service;

import com.hirain.phm.bode.ui.log.model.LogQueryCondition;
import com.hirain.phm.bode.ui.log.model.LogTable;

public interface LogService {

	void selectByPage(LogQueryCondition queryCondition, int pageNum, int pageSize);

	void selectCount(LogQueryCondition queryCondition);

	void download(LogTable logTable);
}
