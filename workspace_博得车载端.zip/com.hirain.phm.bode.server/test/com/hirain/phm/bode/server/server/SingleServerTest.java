package com.hirain.phm.bode.server.server;

import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.config.ConfigurationService;
import com.hirain.phm.bode.server.message.PreProcessor;
import com.hirain.phm.bode.server.store.StoreService;

public class SingleServerTest {

	public static void main(String[] args) {
		final SingleServerService server = new SingleServerService();
		server.init();

		// final GroundService ground = new GroundService();
		// ground.init();

		final PreProcessor processor = new PreProcessor();
		processor.init();

		final StoreService storeService = new StoreService(processor);
		storeService.init();

		final ITrain train = ConfigurationService.getInstance().getTrain();
		InnerEventBus.getInstance().post(new ConfigEvent(train, null));
	}
}
