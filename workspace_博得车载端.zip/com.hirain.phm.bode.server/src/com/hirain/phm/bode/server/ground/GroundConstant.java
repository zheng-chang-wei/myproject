package com.hirain.phm.bode.server.ground;

import com.hirain.phm.bode.server.PrefsUtil;

public class GroundConstant {

	/*-----------------------sid------------------------*/
	public static final int REGISTER_RESPONSE_ID = 0x11;

	public static final int DATA_DELETE_COMMOND = 0x15;

	public static final int USERLIST_UPDATE_COMMAND = 0x16;

	public static final int USERLIST_UPDATE_RESPONSE = 0x06;

	public static final int TRAINSTATE_UPDATE_COMMAND = 0x19;

	public static final int FAULT_UPLOAD_COMMAND = 0x03;

	public static final int ON_OFF_ID = 0x08;

	public static final int GROUND_ONOFF_ID = 0x18;

	/*--------------------------state--------------------*/
	public static final int TRAIN_ACTIVATE = 1;

	public static final int TRAIN_DISCONNECT = 2;

	public static final int TRAIN_DEACTIVATE = 3;

	/*-------------------------topic----------------------*/
	public static final String TRAIN_TO_GROUND = "train-ground";

	public static final String REGISTER_TOPIC = "train/register";

	public static final String MQTT_HOST_URL;

	public static final String MQTT_SSL_URL;

	static {
		MQTT_HOST_URL = PrefsUtil.instance().getValue("mqtt.tcp.url");
		MQTT_SSL_URL = PrefsUtil.instance().getValue("mqtt.ssl.url");
	}
}
