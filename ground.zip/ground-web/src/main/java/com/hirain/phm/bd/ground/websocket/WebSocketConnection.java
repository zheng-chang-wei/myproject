/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.ground.websocket;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import com.hirain.phm.bd.common.serialize.JsonUtil;
import com.hirain.phm.bd.ground.realtime.domain.MonitorOption;
import com.hirain.phm.bd.ground.realtime.service.IOptionTextService;
import com.hirain.phm.bd.message.decode.DecodePacket;
import com.hirain.phm.bd.message.decode.RunDataFrame;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年5月15日 上午10:02:14
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年5月15日 jianwen.xin@hirain.com 1.0 create file
 */
@Component
@ServerEndpoint(value = "/websocket")
public class WebSocketConnection {

	static private IOptionTextService textService;

	private MonitorOption monitorOption;

	private Session session;

	private String[] states = { "隔离", "紧急解锁", "门故障", "防挤压", "门完全打开", "关门过程中", "开门过程中", "门完全关闭" };

	@Autowired
	public void setTextService(IOptionTextService textService) {
		WebSocketConnection.textService = textService;
	}

	@OnOpen
	public void onOpen(Session session) {
		this.session = session;
		WebSocketServer.addConnection(textService.getKey(monitorOption), this);
		sendMessage(WebSocketServer.getFaultPacketsAsString());
	}

	@OnClose
	public void onClose() {
		WebSocketServer.removeConnection(textService.getKey(monitorOption), this);
	}

	@OnMessage
	public void onMessage(String message, Session session) {
		System.err.println("receive:" + message);
		MonitorOption newOption = null;
		try {
			newOption = JsonUtil.fromString(message, MonitorOption.class);
		} catch (Exception e) {
			e.printStackTrace();
			return;
		} finally {
		}
		if (newOption.equals(monitorOption)) {
			return;
		}
		String key = textService.getKey(monitorOption);
		String newKey = textService.getKey(newOption);
		if (!key.equals(newKey)) {
			System.err.println(key + "   " + newKey);
			WebSocketServer.removeConnection(key, this);
			WebSocketServer.addConnection(newKey, this);
		}
		monitorOption = newOption;
		mockMessage(key);

	}

	private void mockMessage(String message) {
		if (!message.contains("null")) {
			return;
		}
		while (true) {
			DecodePacket packet = new DecodePacket(1, "", "");
			File file;
			try {
				file = ResourceUtils.getFile("classpath:key.txt");
				List<String> keys = FileUtils.readLines(file, "utf-8");
				List<RunDataFrame> frames = new ArrayList<>();
				for (int i = 1; i < 7; i++) {
					for (int j = 1; j < 11; j++) {

						RunDataFrame runDataFrame = new RunDataFrame();
						frames.add(runDataFrame);
						List<String> values = new ArrayList<>();
						for (String keyy : keys) {
							if (keyy.equals("车厢号")) {
								values.add(i + "");
							} else if (keyy.equals("门地址")) {
								values.add(j + "");
							} else if (keyy.equals("车门状态")) {
								values.add(states[new Random().nextInt(states.length)]);
							} else if (keyy.equals("时间")) {
								values.add(new Date().toLocaleString());
							} else if (keyy.equals("门隔离")) {
								values.add("" + new Random().nextInt(2));
							} else {
								values.add("" + new Random().nextInt(2));
							}
						}
						runDataFrame.setValues(values);
					}
				}
				packet.setFrames(frames);
				packet.setKeys(keys);
				String message2 = JsonUtil.toString(new WebsocketPacket(packet));
				// System.out.println(message);
				sendMessage(message2);
				TimeUnit.MILLISECONDS.sleep(1000);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	@OnError
	public void onError(Session session, Throwable e) {
		System.out.println("error");
		e.printStackTrace();
	}

	public boolean follows(DecodePacket packet) {
		if (textService.getKey(packet).equals(textService.getKey(monitorOption))) {
			return true;
		} else {
			return false;
		}
	}

	public void sendMessage(String message) {
		if (session.isOpen()) {
			// 非阻塞发送，需要后续观察，tomcat有bug，导致非阻塞发送并非线程安全
			synchronized (session) {
				try {
					session.getBasicRemote().sendText(message);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			// 阻塞发送
			// try {
			// session.getBasicRemote().sendText(message);
			// } catch (Exception e) {
			// log.error(e.getMessage(), e);
			// }
		}
	}

}
