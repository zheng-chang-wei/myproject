package com.hirain.phm.bode.server.message;

import java.util.List;

import com.hirain.phm.bode.server.rbac.impl.UserOperation;

public class UserOperations {

	private List<UserOperation> operations;

	public List<UserOperation> getOperations() {
		return operations;
	}

	public void setOperations(List<UserOperation> operations) {
		this.operations = operations;
	}
}
