package com.hirain.phm.bode.client.communication.service;

public class ServiceConstant {

	public static final byte[] EMPTY_DATA = new byte[] { 0 };

	/**
	 * 客户端的发送端口
	 */
	public static final int LOCAL_PORT = 17000;

	/**
	 * 客户端-服务端 指令通信端口
	 */
	public static final int HOST_PORT = 17257;

	/**
	 * 客户端-服务端 心跳指令端口
	 */
	public static final int HEART_PORT = 17258;

	/**
	 * 心跳检测PID
	 */
	public static final byte PID_HEART_INQUIRY = (byte) 0XAA;

	/**
	 * 心跳检测确认PID
	 */
	public static final byte PID_HEART_INQUIRY_ACK = (byte) 0XBB;

	/**
	 * 系统信息查询
	 */
	public static final byte PID_SYSTEMINFO_INQUIRY = 0x01;

	/**
	 * 系统信息查询回复
	 */
	public static final byte PID_SYSTEMINFO_INQUIRY_ACK = 0x11;

	/**
	 * 存储空间查询
	 */
	public static final byte PID_SPACE_INQUIRY = 0x02;

	/**
	 * 存储空间查询回复
	 */
	public static final byte PID_SPACE_INQUIRY_ACK = 0x12;

	/**
	 * 系统信息配置下发
	 */
	public static final byte PID_SYSTEMINFO_CONFIG = 0x03;

	/**
	 * 系统信息配置下发 回复
	 */
	public static final byte PID_SYSTEMINFO_CONFIG_ACK = 0x13;

	public static final byte PID_DOORINFO_INQUIRY_ACK = 0x14;

	/**
	 * 下载操作通知
	 */
	public static final byte PID_DOWNLOAD = 0x05;

	/**
	 * 下载操作通知回复
	 */
	public static final byte PID_DOWNLOAD_ACK = 0x15;

	/**
	 * 调试模式通知
	 */
	public static final byte PID_DEBUGMODE = (byte) 0x06;

	/**
	 * 调试模式通知回复
	 */
	public static final byte PID_DEBUGMODE_ACK = (byte) 0x16;

	/**
	 * 登录指令
	 */
	public static final byte PID_LOGIN = (byte) 0x07;

	/**
	 * 登录指令回复
	 */
	public static final byte PID_LOGIN_ACK = (byte) 0x17;

	/**
	 * 登出指令
	 */
	public static final byte PID_LOGOUT = (byte) 0x08;

	/**
	 * 登出指令回复
	 */
	public static final byte PID_LOGOUT_ACK = (byte) 0x18;

	/**
	 * 数据查询指令
	 */
	public static final byte PID_DATA_QUERY = (byte) 0x09;

	/**
	 * 数据查询指令回复
	 */
	public static final byte PID_DATA_QUERY_ACK = (byte) 0x19;

	/**
	 * 数据回放指令
	 */
	public static final byte PID_DATA_DOWNLOAD = (byte) 0x0a;

	/**
	 * 数据回放指令回复
	 */
	public static final byte PID_DATA_DOWNLOAD_ACK = (byte) 0x1a;

	/**
	 * 数据统计指令
	 */
	public static final byte PID_DATA_COUNT = (byte) 0x0b;

	/**
	 * 数据统计指令回复
	 */
	public static final byte PID_DATA_COUNT_ACK = (byte) 0x1b;

	/**
	 * 数据下载指令回复
	 */
	public static final byte DATA_DOWNLOAD_ID = (byte) 0x0c;

	/** ----------------------sid-------------------- **/
	/**
	 * 查询报文记录sid
	 */
	public static final byte COMMON_TAG = 1;

	/**
	 * 查询故障记录sid
	 */
	public static final byte FAULT_RECORD_SID = 2;

	/**
	 * 查询故障列表sid
	 */
	public static final byte FAULT_SID = 3;

	/**
	 * 报文记录统计查询sid
	 */
	public static final byte MESSAGE_COUNT_SID = 1;

	/**
	 * 故障记录统计查询sid
	 */
	public static final byte FAULT_RECORD_COUNT_SID = 2;

	/**
	 * 报文数据下载sid
	 */
	public static final byte MESSAGE_DOWNLOAD_SID = 1;

	/**
	 * 故障数据下载sid
	 */
	public static final byte FAULT_RECORD_DOWNLOAD_SID = 2;

	/**
	 * 报文数据下载完成sid
	 */
	public static final byte MESSAGE_DOWNLOAD_COMPLETE_SID = 3;

	/**
	 * 故障数据下载完成sid
	 */
	public static final byte FAULT_DOWNLOAD_COMPLETE_SID = 4;

	/**
	 * 日志相关指令
	 */
	public static final byte LOG_SID = 5;

	/**
	 * 日志数据下载完成sid
	 */
	public static final byte LOG_DOWNLOAD_COMPLETE_SID = 6;

}
