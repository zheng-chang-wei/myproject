package com.hirain.phm.bode.server.ground;

import java.nio.charset.Charset;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.eclipse.paho.client.mqttv3.MqttException;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bd.message.ground.DeleteTrainDataMessage;
import com.hirain.phm.bd.message.ground.RegisterResponse;
import com.hirain.phm.bd.message.ground.TrainStateMessage;
import com.hirain.phm.bd.message.ground.UserUpdateResponse;
import com.hirain.phm.bd.message.train.LifeMessage;
import com.hirain.phm.bd.message.train.RegisterMessage;
import com.hirain.phm.bd.message.train.StorageMessage;
import com.hirain.phm.bd.message.train.TrainConfigMessage;
import com.hirain.phm.bd.message.train.WillMessage;
import com.hirain.phm.bode.core.IServer;
import com.hirain.phm.bode.core.IServerIp;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.impl.ServerIpType;
import com.hirain.phm.bode.core.util.SystemInfoUtil;
import com.hirain.phm.bode.server.PrefsUtil;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.DebugEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.bus.MacEvent;
import com.hirain.phm.bode.server.bus.MacResultEvent;
import com.hirain.phm.bode.server.bus.MessageListEvent;
import com.hirain.phm.bode.server.bus.SendEvent;
import com.hirain.phm.bode.server.bus.StorageEvent;
import com.hirain.phm.bode.server.db.DBManageService;
import com.hirain.phm.bode.server.fault.FaultRecord;
import com.hirain.phm.bode.server.ground.sender.FaultSender;
import com.hirain.phm.bode.server.ground.sender.MessagePrepareProcessor;
import com.hirain.phm.bode.server.life.LifeMessagePackage;
import com.hirain.phm.bode.server.message.IPreProcessor;
import com.hirain.phm.bode.server.message.UserOperations;
import com.hirain.phm.bode.server.mqtt.MqttConnection;
import com.hirain.phm.bode.server.mqtt.MqttConnectionImpl;
import com.hirain.phm.bode.server.mqtt.SslUtil;
import com.hirain.phm.bode.server.rbac.impl.UserService;
import com.hirain.phm.bode.server.server.ServerConstant;

public class GroundService {

	static Logger logger = Logger.getLogger(GroundService.class);

	private String city;

	private String line;

	private String train;

	private String mac1;

	private String mac2;

	private MqttConnection encryptedConnection;

	private MqttConnection messageConnection;

	private boolean debug = false;

	private MessagePrepareProcessor prepareProcessor;

	private final FaultSender fSender = new FaultSender();

	private String sslClient;

	private String messageClient;

	private ExecutorService executorService;

	private int state;

	private IPreProcessor processor;

	public GroundService() {

	}

	public GroundService(IPreProcessor processor) {
		this.processor = processor;
	}

	public void init() {
		final String[] mac = PrefsUtil.instance().getMac();
		if (mac == null || mac.length < 1) {
			mac1 = Utils.mac();
			PrefsUtil.instance().update("mac1", mac1);
		} else {
			mac1 = mac[0];
		}
		logger.info("mac1:" + mac1);
		state = PrefsUtil.instance().getState();
		executorService = Executors.newFixedThreadPool(5);
		InnerEventBus.getInstance().register(this);
		processor.register(this);
		prepareProcessor = new MessagePrepareProcessor();
		prepareProcessor.start();
		fSender.start();
	}

	@Subscribe
	public void on(ConfigEvent event) {
		final ITrain config = event.getTrain();
		final String cityName = config.getCityName();
		final Integer lineName = config.getLineName();
		final String trainNo = config.getTrainNo();
		if (configChanged(cityName, String.valueOf(lineName), trainNo)) {
			city = cityName;
			line = String.valueOf(lineName);
			train = trainNo;
			fSender.update(city, line, train);
			int index = 0;
			final List<IServer> servers = config.getServers();
			final List<String> locahosts = Utils.locahosts();
			for (int i = 0; i < servers.size(); i++) {
				final IServer server = servers.get(i);
				final List<IServerIp> list = server.getServesIps();
				for (final IServerIp sIP : list) {
					if (sIP.getType().equals(ServerIpType.Type1)) {
						final String ip = sIP.getIp();
						if (locahosts.contains(ip)) {
							index = i;
						}
					}
				}
			}
			register(config);
			prepareProcessor.set(index);
			prepareProcessor.set(city, line, train);
		} else {
			uploadConfig(config);
		}
	}

	@Subscribe
	public void on(MacEvent event) {
		mac2 = event.getMac();
		PrefsUtil.instance().update("mac2", mac2);
		final SendEvent sendEvent = new SendEvent();
		sendEvent.setPid((byte) ServerConstant.REPLY_MAC_ID);
		sendEvent.setDatas(mac1.getBytes());
		InnerEventBus.getInstance().post(sendEvent);
	}

	@Subscribe
	public void on(MessageListEvent event) {
		if (state == GroundConstant.TRAIN_ACTIVATE) {
			prepareProcessor.add(event.getMessages(), debug);
		}
	}

	@Subscribe
	public void on(FaultRecord record) {
		if (state == GroundConstant.TRAIN_ACTIVATE) {
			fSender.add(record);
		}
	}

	@Subscribe
	public void on(DebugEvent event) {
		debug = event.isDebug();
	}

	/**
	 * 向地面发送存储报文
	 */
	@Subscribe
	public void on(StorageEvent event) {
		if (state == GroundConstant.TRAIN_ACTIVATE) {
			final StorageMessage message = new StorageMessage();
			message.setSid(0x02);
			message.setCity(city);
			message.setLine(line);
			message.setTrain(train);
			message.setTotal(event.getTotal());
			message.setUsed(event.getUsed());
			message.setFaultSpace(event.getFaultSpace());
			final String json = Utils.toJsonString(message);
			if (encryptedConnection != null && encryptedConnection.isConnected()) {
				try {
					encryptedConnection.send(GroundConstant.TRAIN_TO_GROUND, json.getBytes(), 1, false);
				} catch (final Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Subscribe
	public void on(DeleteTrainDataMessage message) {
		final String DataType = message.getDataType();
		final Date cutTime = message.getCutTime();
		if (DataType == null) {
			DBManageService.getInstance().deleteDataBeforeDay(cutTime);
		} else if (DataType.equals("Common")) {
			DBManageService.getInstance().deleteCommonDataBeforeDay(cutTime);
		} else if (DataType.equals("Fault")) {
			DBManageService.getInstance().deleteFaultDataBeforDay(cutTime);
		} else {
			DBManageService.getInstance().deleteDataBeforeDay(cutTime);
		}

	}

	/**
	 * 向地面发送寿命报文
	 */
	@Subscribe
	public void on(LifeMessagePackage messagePackage) {
		for (final LifeMessage lifeMessage : messagePackage.getLifeMessages()) {
			final String json = Utils.toJsonString(lifeMessage);
			if (encryptedConnection != null && encryptedConnection.isConnected()) {
				try {
					encryptedConnection.send(GroundConstant.TRAIN_TO_GROUND, json.getBytes(), 1, false);
				} catch (final Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void post(int sid, String json) {
		switch (sid) {
		case GroundConstant.TRAINSTATE_UPDATE_COMMAND:
			executorService.submit(() -> {
				final TrainStateMessage stateMessage = Utils.fromJsonString(json, TrainStateMessage.class);
				handleState(stateMessage.getState());
			});
			break;
		case GroundConstant.USERLIST_UPDATE_COMMAND:
			executorService.submit(() -> {
				final UserOperations operations = Utils.fromJsonString(json, UserOperations.class);
				final int result = UserService.getInstance().update(operations.getOperations());
				final UserUpdateResponse response = new UserUpdateResponse();
				response.setCity(city);
				response.setLine(line);
				response.setTrain(train);
				response.setSid(GroundConstant.USERLIST_UPDATE_RESPONSE);
				response.setSuccess(result == 0);
				response.setError(result);
				final String resultJson = Utils.toJsonString(response);
				try {
					encryptedConnection.send(GroundConstant.TRAIN_TO_GROUND, resultJson.getBytes(), 1, false);
				} catch (final Exception e) {
					e.printStackTrace();
				}
			});
			break;
		case GroundConstant.GROUND_ONOFF_ID:
			executorService.submit(() -> {
				final WillMessage willMessage = Utils.fromJsonString(json, WillMessage.class);
				final boolean on = willMessage.getOn();
				if (on) {
					logger.info("地面端上线了");
				} else {
					logger.info("地面端下线了");
					registerToGround();
				}
			});
		default:
			break;
		}
	}

	public void reconnected(String clientId) {
		if (clientId.equals(sslClient)) {
			fSender.reconnected();
		}
	}

	private boolean configChanged(String cityName, String lineName, String car) {
		if (!cityName.equals(city)) {
			return true;
		}
		if (!lineName.equals(line)) {
			return true;
		}
		if (!car.equals(train)) {
			return true;
		}
		return false;
	}

	private void register(ITrain config) {
		executorService.submit(() -> {
			mac2 = getMac2();
			registerToGround();
			createSslConnection(PrefsUtil.instance().getPassword());
			uploadConfig(config);
		});
	}

	private String getMac2() {
		final String[] macs = PrefsUtil.instance().getMac();
		if (macs.length < 2) {
			while (true) {
				final SyncSubscriber<MacResultEvent> subscriber = new SyncSubscriber<MacResultEvent>() {

					@Subscribe
					public void on(MacResultEvent event) {
						System.out.println(event);
						setResponse(event);
					}
				};
				InnerEventBus.getInstance().register(subscriber);
				InnerEventBus.getInstance().post(new SendEvent((byte) ServerConstant.ASK_MAC_ID, mac1.getBytes()));
				try {
					final MacResultEvent event = subscriber.get(1, TimeUnit.SECONDS);
					InnerEventBus.getInstance().unregister(subscriber);
					if (event != null) {
						mac2 = new String(event.getMac());
						PrefsUtil.instance().update("mac2", mac2);
						break;
					}
				} catch (final InterruptedException e) {
				}
				try {
					TimeUnit.MILLISECONDS.sleep(1000);
				} catch (final InterruptedException e) {
				}
			}
		} else {
			mac2 = macs[1];
		}
		return mac2;
	}

	private void registerToGround() {
		final String clientId = city + line + train + "-register";
		final MqttConnection connection = new MqttConnectionImpl(GroundConstant.MQTT_HOST_URL, clientId, new CommonMqttCallback(clientId, this));
		connect(connection);
		try {
			final String topic = "ca/" + city + "/" + line + "/" + train;
			System.out.println("register topic:" + topic);
			connection.subscribe(topic);
		} catch (final MqttException e) {
			e.printStackTrace();
		}
		continueRegister(connection);
		if (connection.isConnected()) {
			try {
				connection.disconnect();
			} catch (final MqttException e) {
			}
		}
	}

	private void uploadConfig(final ITrain config) {
		if (encryptedConnection != null && encryptedConnection.isConnected()) {
			try {
				final TrainConfigMessage message = new TrainConfigMessage();
				message.setSid(0x04);
				message.setCity(city);
				message.setLine(line);
				message.setTrain(train);
				message.setSetting(SystemInfoUtil.convertSystemInfo2XmlBytes(config));
				final String json = Utils.toJsonString(message);
				encryptedConnection.send(GroundConstant.TRAIN_TO_GROUND, json.getBytes(), 1, false);
				logger.info("upload system configuration");
			} catch (final Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	private void continueRegister(final MqttConnection connection) {
		while (true) {
			final RegisterMessage message = new RegisterMessage();
			message.setCity(city);
			message.setLine(line);
			message.setTrain(train);
			message.setMac1(mac1);
			message.setMac2(mac2);
			message.setState(state);
			message.setSid(0x01);
			final boolean needSSL = !GroundUtils.validateSSLCondition();
			message.setSsl(needSSL);
			final String json = Utils.toJsonString(message);
			System.out.println(json);
			final SyncSubscriber<RegisterResponse> subscriber = new SyncSubscriber<RegisterResponse>() {

				@Subscribe
				public void on(RegisterResponse response) {
					setResponse(response);
				}
			};
			InnerEventBus.getInstance().register(subscriber);
			try {
				connection.send(GroundConstant.REGISTER_TOPIC, json.getBytes(Charset.forName("utf-8")), 1, false);
				System.out.println("register message send");
				final RegisterResponse response = subscriber.get(30, TimeUnit.SECONDS);
				InnerEventBus.getInstance().unregister(subscriber);
				if (response != null && response.isSuccess()) {
					if (needSSL) {
						SslUtil.update("ca.crt", response.getCaCert());
						SslUtil.update("client.crt", response.getCert());
						SslUtil.update("client.key", response.getKey());
						final String password = response.getPassword();
						PrefsUtil.instance().update("password", password);
					}
					handleState(response.getState());
					logger.info("register success");
					return;
				}
			} catch (final Exception e) {
				logger.error(e.getMessage(), e);
			}
			try {
				TimeUnit.SECONDS.sleep(1);
			} catch (final InterruptedException e) {
			}
		}
	}

	private void createSslConnection(String password) {
		sslClient = city + line + train + "ssl";
		final MqttConnection sslConnection = new MqttConnectionImpl(GroundConstant.MQTT_SSL_URL, sslClient, new CommonMqttCallback(sslClient, this));
		final WillMessage willMessage = new WillMessage();
		willMessage.setSid(GroundConstant.ON_OFF_ID);
		willMessage.setCity(city);
		willMessage.setLine(line);
		willMessage.setTrain(train);
		willMessage.setOn(false);
		final String json = Utils.toJsonString(willMessage);
		((MqttConnectionImpl) sslConnection).setWill(json.getBytes());
		encryptedConnection = sslConnection;
		if (GroundConstant.MQTT_SSL_URL.startsWith("ssl")) {
			connect(sslConnection, password);
		} else {
			connect(sslConnection);
		}
		try {
			sslConnection.subscribe("response/" + city + "/" + line + "/" + train);
			sslConnection.subscribe("ground-train");
		} catch (final Exception e) {
		}
		willMessage.setOn(true);
		final String on = Utils.toJsonString(willMessage);
		try {
			logger.info("train online");
			sslConnection.send(GroundConstant.TRAIN_TO_GROUND, on.getBytes());
		} catch (final Exception e) {
		}
		fSender.setPublisher(encryptedConnection);
		fSender.setTopic(GroundConstant.TRAIN_TO_GROUND);
	}

	/**
	 * 处理车载端状态
	 * 
	 * @param state
	 */
	private void handleState(int oldState) {
		if (state == oldState) {
			if (state == GroundConstant.TRAIN_ACTIVATE) {
				if (messageConnection == null || !messageConnection.isConnected()) {
					createMessageConnection(PrefsUtil.instance().getPassword());
				}
			}
			return;
		}
		if (state == GroundConstant.TRAIN_ACTIVATE && oldState != GroundConstant.TRAIN_ACTIVATE) {
			prepareProcessor.stop();
			fSender.stop();
			if (messageConnection != null && messageConnection.isConnected()) {
				try {
					messageConnection.disconnect();
				} catch (final MqttException e) {
				}
			}
		} else if (state != GroundConstant.TRAIN_ACTIVATE && oldState == GroundConstant.TRAIN_ACTIVATE) {
			if (messageConnection == null || !messageConnection.isConnected()) {
				createMessageConnection(PrefsUtil.instance().getPassword());
			}
			prepareProcessor.start();
			fSender.start();
		}
		state = oldState;
	}

	private void createMessageConnection(String password) {
		messageClient = city + line + train + "message";
		final MqttConnection connection = new MqttConnectionImpl(GroundConstant.MQTT_SSL_URL, messageClient, new MessageMqttCallback(messageClient));
		messageConnection = connection;
		if (GroundConstant.MQTT_SSL_URL.startsWith("ssl")) {
			connect(connection, password);
		} else {
			connect(connection);
		}
		prepareProcessor.setPublisher(messageConnection);
	}

	private void connect(MqttConnection connection) {
		while (true) {
			try {
				connection.connect();
				return;
			} catch (final Exception e) {
				e.printStackTrace();
			}
			try {
				TimeUnit.SECONDS.sleep(1);
			} catch (final InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void connect(MqttConnection connection, String password) {
		final String folder = SslUtil.SSL_ROOT;
		while (true) {
			try {
				connection.connect(folder + "ca.crt", folder + "client.crt", folder + "client.key", password);
				return;
			} catch (final Exception e) {
			}
			try {
				TimeUnit.SECONDS.sleep(1);
			} catch (final InterruptedException e) {
			}
		}
	}
}
