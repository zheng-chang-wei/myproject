package com.hirain.phm.bode.server.db.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface FaultMgrMapper {

	int addPartitionsToFaultRecord(List<Long> partitions);

	int deleteFaultRecordsBeforeDay(@Param("day") String day);

	int addPartitionsToFaultMessage(List<String> partitions);

	int dropPartitionFromFaultMessge(@Param("day") String day);

	int deleteFaultMessagesBeforeDay(@Param("day") String day);

	int createPartitions(List<String> partitions);

	long countFaultRecord();
}
