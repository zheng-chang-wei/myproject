package com.hirain.phm.bode.core;

import java.util.List;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 3:38:20 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
public interface ICar {

	void setIndex(int index);

	int getIndex();

	void setType(byte type);

	byte getType();

	void setName(String name);

	String getName();

	List<IMdcu> getMdcus();

	List<IDoor> getDoors();

	void setMdcus(List<IMdcu> mdcus);

	void setDoors(List<IDoor> doors);
}
