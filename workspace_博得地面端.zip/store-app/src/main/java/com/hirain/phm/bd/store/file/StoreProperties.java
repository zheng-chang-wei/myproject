/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.store.file;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年5月20日 下午5:07:05
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年5月20日 jianwen.xin@hirain.com 1.0 create file
 */
@Component
@Getter
public class StoreProperties {

	@Value("${store.file.root}")
	public String root;

	@Value("${store.file.container}")
	public String folder;

	@Value("${store.file.extension}")
	public String extension;

	@Value("${store.hdfs.root}")
	public String hdfsRoot;
}
