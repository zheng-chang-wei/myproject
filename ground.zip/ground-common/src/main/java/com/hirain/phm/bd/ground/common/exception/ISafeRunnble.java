package com.hirain.phm.bd.ground.common.exception;

@FunctionalInterface
public interface ISafeRunnble<T> {

	T run();
}
