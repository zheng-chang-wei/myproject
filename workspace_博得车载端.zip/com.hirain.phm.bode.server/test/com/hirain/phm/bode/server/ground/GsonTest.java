package com.hirain.phm.bode.server.ground;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.hirain.phm.bd.message.CarriagePacket;
import com.hirain.phm.bd.message.CommonMessage;
import com.hirain.phm.bd.message.DoorPacket;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.message.DoorMessage;

public class GsonTest {

	@Test
	public void test() {
		final CommonMessage commonMessage = new CommonMessage(new byte[] { 1, 2, 3, 4, 5 }, true);
		final DoorMessage doorMessage = new DoorMessage();
		doorMessage.setCarriageId(1);
		doorMessage.setDoorId(1);
		doorMessage.setDatas(new byte[] { 1, 2, 3, 4, 5 });
		doorMessage.setTimestamp(new Date());
		final String json = Utils.toJsonString(commonMessage);
		System.out.println(json);
	}

	@Test
	public void testMap() {
		final CommonMessage commonMessage = new CommonMessage(new byte[] { 1, 2, 3, 4, 5 }, true);
		final Map<String, Object> map = new HashMap<>();
		map.put("carriageId", 1);
		map.put("doorId", 1);
		map.put("messages", commonMessage);
		final String json = Utils.toJsonString(map);
		System.out.println(json);

		final HashMap<?, ?> map2 = Utils.fromJsonString(json, HashMap.class);
		for (final Object key : map2.keySet()) {
			System.out.println(key + ":" + map2.get(key) + "   " + map2.get(key).getClass());
		}
	}

	@Test
	public void testExpose() {
		final CommonMessage commonMessage = new CommonMessage(new byte[] { 1, 2, 3, 4, 5 }, true);
		final DoorPacket packet = new DoorPacket(1, Arrays.asList(commonMessage));
		final CarriagePacket carriagePacket = new CarriagePacket(1, Arrays.asList(packet));
		final String json = Utils.toJsonString(Arrays.asList(carriagePacket));
		System.out.println(json);
	}

}
