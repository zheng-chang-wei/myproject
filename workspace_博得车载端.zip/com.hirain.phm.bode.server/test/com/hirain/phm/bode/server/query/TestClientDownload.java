package com.hirain.phm.bode.server.query;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;

import org.junit.Test;

import com.hirain.phm.bode.server.TestConstant;
import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ServerClientMock;

public class TestClientDownload {

	private static InetSocketAddress address = new InetSocketAddress(TestConstant.LOCALHOST, 17257);

	public static void setUp() {
		final ServerClientMock mock = new ServerClientMock();
		mock.start();
	}

	@Test
	public void testCommon() throws IOException {
		setUp();
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			TestConstant.login1(client);
			final String sql = "select datas from t_carriage2_message where door_id=1";
			final byte[] bs = sql.getBytes();
			final ByteBuffer buffer = ByteBuffer.allocate(bs.length + 15 + 3);
			buffer.put((byte) ClientConstants.DATA_DOWNLOAD_ID);
			buffer.putShort((short) (bs.length + 15));
			buffer.put(ClientConstants.COMMON_TAG);
			buffer.put((byte) 2);
			buffer.put((byte) 1);
			final byte[] time = new byte[] { 19, 02, 15, 16, 18, 00, 19, 02, 15, 16, 18, 10 };
			buffer.put(time);
			buffer.put(bs);
			send(client, buffer.array(), address);
			process(ClientConstants.COMMON_TAG, client);
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	@Test
	public void testFault() throws IOException {
		setUp();
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			TestConstant.login1(client);
			final String sql = "select datas from t_fault_message where door_id=1 and carriage_id=2";
			final byte[] bs = sql.getBytes();
			final ByteBuffer buffer = ByteBuffer.allocate(bs.length + 13 + 3);
			buffer.put((byte) ClientConstants.DATA_DOWNLOAD_ID);
			buffer.putShort((short) (bs.length + 13));
			buffer.put(ClientConstants.FAULT_TAG);
			buffer.put((byte) 2);
			buffer.put((byte) 1);
			buffer.putInt(7);
			final byte[] time = new byte[] { 19, 02, 15, 16, 18, 00 };
			buffer.put(time);
			buffer.put(bs);
			send(client, buffer.array(), address);
			process(ClientConstants.FAULT_TAG, client);
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	private void process(byte tag, DatagramSocket client) throws IOException {
		while (true) {
			final DatagramPacket receive = new DatagramPacket(new byte[65535], 65535);
			client.receive(receive);
			final byte[] data = receive.getData();
			final ByteBuffer bf = ByteBuffer.wrap(data);
			assertEquals(0x1a, bf.get());
			final int length = Short.toUnsignedInt(bf.getShort());
			final byte type = bf.get();
			if (type == tag + ClientConstants.EOF) {
				assertEquals(1, length);
				System.out.println(type);
				break;
			} else {
				assertEquals(tag, type);
				final int num = Short.toUnsignedInt(bf.getShort());
				assertEquals(num * 32 + 3, length);
				for (int i = 0; i < num; i++) {
					final byte[] b = new byte[32];
					bf.get(b);
					System.out.println(convertBytes2Line(b));
				}
				System.out.println();
			}
		}
	}

	public String convertBytes2Line(byte[] bs) {
		final StringBuilder sb = new StringBuilder();
		for (int i = 0; i < bs.length; i++) {
			final byte b = bs[i];
			final String hex = Integer.toHexString(b & 0xff);
			if (hex.length() < 2) {
				sb.append("0");
			}
			sb.append(hex.toUpperCase()).append(" ");
		}
		return sb.toString();
	}

	public void send(DatagramSocket socket, byte[] data, InetSocketAddress address) throws IOException {
		final DatagramPacket send = new DatagramPacket(data, data.length, address);
		socket.send(send);
	}
}
