package com.hirain.phm.bode.server.server;

import java.net.InetSocketAddress;
import java.util.Arrays;

import com.hirain.phm.bode.server.comm.IConnection;
import com.hirain.phm.bode.server.comm.IConnectionFactory;
import com.hirain.phm.bode.server.comm.IPost;
import com.hirain.phm.bode.server.comm.impl.UDPConnection;
import com.hirain.phm.bode.server.comm.impl.UDPConnectionEncoder;

class ServerConnectionFactory implements IConnectionFactory {

	private final IPost poster;

	public ServerConnectionFactory(IPost poster) {
		this.poster = poster;
	}

	@Override
	public IConnection create(InetSocketAddress addr) {
		if (addr.getPort() == ServerConstant.LOCAL_MDCU_PORT) {
			IConnection connection = new UDPConnection(addr, Arrays.asList(new MDCUMessageCodec(), new ServerHandler(poster)));
			return connection;
		} else {
			IConnection connection = new UDPConnection(addr,
					Arrays.asList(new CommandMessageDecoder(), new UDPConnectionEncoder(), new ServerHandler(poster)));
			return connection;
		}
	}

}
