package com.hirain.phm.bode.ui.monitor.listener;

import java.util.ArrayList;
import java.util.List;

public class HandlerDoorDestroyManager {

	private final List<DoorDestroyListener> listeners = new ArrayList<DoorDestroyListener>();

	private static HandlerDoorDestroyManager instance = null;

	private HandlerDoorDestroyManager() {

	}

	public static HandlerDoorDestroyManager getInstatnce() {
		if (instance == null) {
			instance = new HandlerDoorDestroyManager();
		}
		return instance;
	}

	public void add(DoorDestroyListener listener) {
		// listeners.removeAll(listeners);
		listeners.add(listener);
	}

	public void remove() {
		listeners.clear();
	}

	public void distroy() {
		for (DoorDestroyListener listener : listeners) {
			listener.distroy();
		}
	}

}
