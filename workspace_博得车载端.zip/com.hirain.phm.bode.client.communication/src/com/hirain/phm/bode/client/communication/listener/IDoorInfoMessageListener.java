/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.listener;

import com.hirain.phm.bode.client.communication.message.DoorInfoMessage;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 25, 2019 11:26:08 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 25, 2019 zepei.tao@hirain.com 1.0 create file
 */
public interface IDoorInfoMessageListener {

	public void receive(DoorInfoMessage message);

}
