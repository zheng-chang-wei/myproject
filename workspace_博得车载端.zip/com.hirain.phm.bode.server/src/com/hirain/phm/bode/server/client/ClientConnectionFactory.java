package com.hirain.phm.bode.server.client;

import java.net.InetSocketAddress;
import java.util.Arrays;

import com.hirain.phm.bode.server.comm.IConnection;
import com.hirain.phm.bode.server.comm.IConnectionFactory;
import com.hirain.phm.bode.server.comm.impl.UDPConnection;
import com.hirain.phm.bode.server.comm.impl.UDPConnectionEncoder;

class ClientConnectionFactory implements IConnectionFactory {

	private final IHeartPost poster;

	public ClientConnectionFactory(IHeartPost poster) {
		this.poster = poster;
	}

	@Override
	public IConnection create(InetSocketAddress addrs) {
		int port = addrs.getPort();
		if (port == ClientConstants.LOCAL_HEART_PORT) {
			return new UDPConnection(addrs, Arrays.asList(new ClientMessageDecoder(), new ClientHeartHandler(poster)));
		} else {
			return new UDPConnection(addrs, Arrays.asList(new ClientMessageDecoder(), new UDPConnectionEncoder(), new ClientHandler(poster)));
		}
	}

}
