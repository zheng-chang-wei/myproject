package com.hirain.phm.bode.ui.datamanager.provider;

import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.swt.graphics.Image;

import com.hirain.phm.bode.core.message.MessageRecord;

public class TableViewerLabelProvider implements ITableLabelProvider {

	@Override
	public void addListener(ILabelProviderListener listener) {

	}

	@Override
	public void dispose() {

	}

	@Override
	public boolean isLabelProperty(Object element, String property) {
		return false;
	}

	@Override
	public void removeListener(ILabelProviderListener listener) {

	}

	@Override
	public Image getColumnImage(Object element, int columnIndex) {
		return null;
	}

	@Override
	public String getColumnText(Object element, int columnIndex) {
		if (element instanceof MessageRecord) {
			MessageRecord messageRecord = (MessageRecord) element;
			if (messageRecord.isValid()) {
				switch (columnIndex) {
				case 0:
					return messageRecord.getStartTime();
				case 1:
					return messageRecord.getEndTime();
				case 2:
					return messageRecord.getCarriageId() + "";
				case 3:
					return messageRecord.getDoorId() + "";
				case 4:
					return messageRecord.getDebug();
				default:
					break;
				}
			} else {
				switch (columnIndex) {
				case 0:
					return "数据库中没有符合条件的记录";
				case 1:
					return "";
				case 2:
					return "";
				case 3:
					return "";
				case 4:
					return "";
				default:
					break;
				}
			}
		}
		return "";
	}
}
