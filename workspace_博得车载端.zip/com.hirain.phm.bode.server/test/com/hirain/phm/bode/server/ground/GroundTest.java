package com.hirain.phm.bode.server.ground;

import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.config.ConfigurationService;
import com.hirain.phm.bode.server.log.LogEvent;
import com.hirain.phm.bode.server.log.LogService;
import com.hirain.phm.bode.server.message.PreProcessor;
import com.hirain.phm.bode.server.server.AbstractServerService;
import com.hirain.phm.bode.server.server.SingleServerService;

public class GroundTest {

	public static void main(String[] args) {
		final AbstractServerService serverService = new SingleServerService();
		serverService.init();

		final PreProcessor processor = new PreProcessor();
		processor.init();

		final GroundService service = new GroundService(processor);
		service.init();
		final ITrain train = ConfigurationService.getInstance().getTrain();
		if (train != null && Utils.validateSetting(train) == 0) {
			LogService.instance().log(LogEvent.ofTrain(train));
			InnerEventBus.getInstance().post(new ConfigEvent(train, null));
		}
	}
}
