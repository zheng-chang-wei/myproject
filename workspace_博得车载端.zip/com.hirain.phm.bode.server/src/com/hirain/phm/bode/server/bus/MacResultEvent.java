package com.hirain.phm.bode.server.bus;

import lombok.ToString;

@ToString
public class MacResultEvent {

	private byte[] mac;

	public MacResultEvent(byte[] datas) {
		// final ByteBuffer buffer = ByteBuffer.wrap(datas);
		// mac = new byte[6];
		// buffer.get(mac);
		mac = datas;
	}

	public byte[] getMac() {
		return mac;
	}

	public void setMac(byte[] mac) {
		this.mac = mac;
	}

}
