package com.hirain.phm.bode.ui.monitor.figure.door;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.swt.SWT;

public class RoundRectangleFigure extends Figure {

	public RoundRectangleFigure() {
	}

	@Override
	public void paintFigure(Graphics g) {
		Rectangle r = bounds;

		g.drawArc(r.x, r.y, 30, 30, 90, 90);
		g.drawLine(r.x + 13, r.y, r.x + r.width - 13, r.y);

		g.drawArc(r.x + r.width - 30, r.y, 30, 30, 0, 90);
		g.drawLine(r.x + r.width - 1, r.y + 13, r.x + r.width - 1, r.y + r.height - 13);

		g.drawArc(r.x + r.width - 30, r.y + r.height - 30, 30, 30, 270, 90);
		g.drawLine(r.x + 13, r.y + r.height - 1, r.x + r.width - 13, r.y + r.height - 1);

		g.drawArc(r.x, r.y + r.height - 30, 30, 30, 180, 90);
		g.drawLine(r.x, r.y + 13, r.x, r.y + r.height - 13);

		g.setAntialias(SWT.ON);
	}

}
