package com.hirain.phm.bode.server.ground.sender;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.hirain.phm.bd.message.CommonMessage;
import com.hirain.phm.bode.server.message.DoorMessage;

public class DoorCache {

	private final Queue<CommonMessage> queue = new ConcurrentLinkedQueue<>();

	// private static Comparator<CommonMessage> comparator = (o1, o2) -> o1.getMessage().getTimestamp().compareTo(o2.getMessage().getTimestamp());

	public DoorCache() {
	}

	public void add(CommonMessage message) {
		queue.offer(message);
	}

	public void add(List<DoorMessage> messages, boolean debug) {
		for (final DoorMessage message : messages) {
			final CommonMessage msg = new CommonMessage(message.getDatas(), debug);
			msg.setMilli(message.getMilli());
			final Date timestamp = message.getTimestamp();
			final Calendar calendar = Calendar.getInstance();
			calendar.setTime(timestamp);
			msg.setYear(calendar.get(Calendar.YEAR));
			msg.setMonth(calendar.get(Calendar.MONTH) + 1);
			queue.offer(msg);
		}
	}

	@SuppressWarnings("unused")
	private void addMilli(CommonMessage msg) {
		final ByteBuffer buffer = ByteBuffer.wrap(msg.getDatas());
		buffer.putShort(26, (short) msg.getMilli());
		msg.setDatas(buffer.array());
	}

	public List<CommonMessage> get(int count) {
		final List<CommonMessage> list = new ArrayList<>();
		for (int i = 0; i < count; i++) {
			final CommonMessage message = queue.poll();
			if (message == null) {
				break;
			}
			list.add(message);
		}
		// Collections.sort(list, comparator);
		return list;
	}

}
