package com.hirain.phm.bode.ui.fault.service.impl;

import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.core.fault.FaultRecord;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.fault.service.FaultRecordService;

public class FaultRecordServiceImpl implements FaultRecordService {

	private static FaultRecordServiceImpl singleton = null;

	private FaultRecordServiceImpl() {
	}

	public static FaultRecordServiceImpl getInstance() {
		if (singleton == null) {
			singleton = new FaultRecordServiceImpl();
		}
		return singleton;
	}

	@Override
	public void selectByPage(FaultRecord faultQuery, int pageNum, int pageSize) {
		StringBuilder sql = new StringBuilder("select * from t_fault_record where ");
		String carriageId = faultQuery.getCarriageId();
		sql.append("carriage_id=" + carriageId);
		String doorId = faultQuery.getDoorId();
		sql.append(" and door_id=" + doorId);
		String faultId = faultQuery.getFaultId();
		if (faultId != null) {
			sql.append(" and fault_id=" + faultId);
		}
		String start = faultQuery.getStartTime();
		if (start != null) {
			sql.append(" and timestamp>='" + start + "'");
		}
		String end = faultQuery.getEndTime();
		if (end != null) {
			sql.append(" and timestamp<='" + end + "'");
		}
		Boolean debug = faultQuery.getDebug();
		if (debug != null) {
			sql.append(" and debug=" + (debug ? 1 : 0));
		}
		sql.append(" order by id desc limit " + (pageNum - 1) * pageSize + "," + pageSize);
		System.err.println(sql);

		try {
			CommunicationService.getInstance().select(ServiceConstant.PID_DATA_QUERY, ServiceConstant.FAULT_RECORD_SID, sql.toString());
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}

	@Override
	public void selectCount(FaultRecord faultQuery) {
		StringBuilder sql = new StringBuilder("select count(id) from t_fault_record where ");
		String carriageId = faultQuery.getCarriageId();
		sql.append("carriage_id=" + carriageId);
		String doorId = faultQuery.getDoorId();
		if (doorId != null) {
			sql.append(" and door_id=" + doorId);
		}
		String faultId = faultQuery.getFaultId();
		if (faultId != null) {
			sql.append(" and fault_id=" + faultId);
		}
		String start = faultQuery.getStartTime();
		if (start != null) {
			sql.append(" and timestamp>='" + start + "'");
		}
		String end = faultQuery.getEndTime();
		if (end != null) {
			sql.append(" and timestamp<='" + end + "'");
		}
		Boolean debug = faultQuery.getDebug();
		if (debug != null) {
			sql.append(" and debug=" + (debug ? 1 : 0));
		}
		try {
			CommunicationService.getInstance().select(ServiceConstant.PID_DATA_COUNT, ServiceConstant.FAULT_RECORD_COUNT_SID, sql.toString());
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}

}
