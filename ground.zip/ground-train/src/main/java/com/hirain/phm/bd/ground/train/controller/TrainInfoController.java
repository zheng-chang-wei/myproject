package com.hirain.phm.bd.ground.train.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hirain.phm.bd.common.serialize.JsonUtil;
import com.hirain.phm.bd.ground.common.exception.SafeRunner;
import com.hirain.phm.bd.ground.common.model.ResponseBo;
import com.hirain.phm.bd.ground.train.domain.Train;
import com.hirain.phm.bd.ground.train.param.TrainParamHeader;
import com.hirain.phm.bd.ground.train.service.ProjectService;
import com.hirain.phm.bd.ground.train.service.TrainService;
import com.hirain.phm.bode.core.util.SystemInfoUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/train")
@Slf4j
public class TrainInfoController {

	@Autowired
	private TrainService trainService;

	@Autowired
	private ProjectService projectService;

	@GetMapping("/projects")
	public ResponseBo getAllsProjects() {
		return SafeRunner.getResponse(() -> ResponseBo.ok(projectService.selectAll()), "获取项目失败");
	}

	@GetMapping("/project/trains")
	public ResponseBo getTrainsByProject(String project) {
		return SafeRunner.getResponse(() -> ResponseBo.ok(trainService.selectByProject(project)), "获取车辆信息失败");
	}

	@GetMapping("/getTrainConfigInfo")
	public ResponseBo getTrainConfigInfo(TrainParamHeader trainParams) {
		Train train = trainService.select(trainParams.getProject(), trainParams.getTrainNo());
		String configInfo = null;
		if (train != null) {
			configInfo = train.getConfigInfo();
		}
		if (configInfo == null) {
			return ResponseBo.error("列车配置信息不存在");
		} else {
			try {
				return ResponseBo.ok(JsonUtil.toString(SystemInfoUtil.convertXmlBytes2SystemInfo(configInfo.getBytes())));
			} catch (Exception e) {
				log.error("获取车辆配置信息失败", e);
				return ResponseBo.error("列车配置信息异常");
			}
		}
	}

	@GetMapping("/dashboard")
	public ResponseBo countTrain() {
		return SafeRunner.run(() -> ResponseBo.ok(trainService.countTrain()), ResponseBo.error("查询失败"));
	}

}
