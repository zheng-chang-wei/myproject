package com.hirain.phm.bode.server;

import java.io.File;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.util.SystemInfoUtil;

public class Utils {

	public static List<String> locahosts() {
		final List<String> ips = new ArrayList<>();
		try {
			final Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
			while (interfaces.hasMoreElements()) {
				final NetworkInterface inf = interfaces.nextElement();
				final Enumeration<InetAddress> inetAddresses = inf.getInetAddresses();
				while (inetAddresses.hasMoreElements()) {
					final InetAddress element = inetAddresses.nextElement();
					if (element != null && element instanceof Inet4Address) {
						if (element.isLoopbackAddress()) {
							continue;
						}
						ips.add(element.getHostAddress());
					}
				}
			}
		} catch (final SocketException e) {
			e.printStackTrace();
		}
		return ips;
	}

	public static String mac() {
		try {
			final Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
			while (interfaces.hasMoreElements()) {
				final NetworkInterface inf = interfaces.nextElement();
				final Enumeration<InetAddress> inetAddresses = inf.getInetAddresses();
				while (inetAddresses.hasMoreElements()) {
					final InetAddress element = inetAddresses.nextElement();
					if (element != null && element instanceof Inet4Address) {
						if (element.isLoopbackAddress()) {
							continue;
						}
						final byte[] mac = NetworkInterface.getByInetAddress(element).getHardwareAddress();
						return mac2Str(mac);
					}
				}
			}

		} catch (final SocketException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static byte validateSetting(ITrain train) {
		try {
			SystemInfoUtil.vaildModel(train);
			return 0;
		} catch (final Exception e) {
			e.printStackTrace();
			return 1;
		}
	}

	public static String toJsonString(Object object) {
		final Gson gson = new Gson();
		return gson.toJson(object);
	}

	public static String toJsonStringWithExpose(Object object) {
		final Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		return gson.toJson(object);
	}

	public static <T> T fromJsonString(String str, Class<T> clz) {
		final Gson gson = new Gson();
		return gson.fromJson(str, clz);
	}

	public static String mac2Str(byte[] mac) {
		final StringBuilder sb = new StringBuilder();
		for (int i = 0; i < mac.length; i++) {
			if (i > 0) {
				sb.append("-");
			}

			final String hex = Integer.toHexString(Byte.toUnsignedInt(mac[i]));
			if (hex.length() < 2) {
				sb.append("0");
			}
			sb.append(hex);
		}
		return sb.toString();
	}

	/**
	 * 总空间大小判定
	 * 
	 * @return
	 */
	public static double getTotalSpace() {
		final File[] roots = File.listRoots();
		long total = 0l;
		for (final File root : roots) {
			total += root.getTotalSpace();
		}
		return total / 1024 / 1024;
	}
}
