package com.hirain.phm.bode.server.comm.impl;

import java.net.InetSocketAddress;

import com.hirain.phm.bode.server.comm.ICommunication;
import com.hirain.phm.bode.server.comm.IConnectionFactory;
import com.hirain.phm.bode.server.comm.IConnectionManager;
import com.hirain.phm.bode.server.comm.IEncoder;
import com.hirain.phm.bode.server.comm.ITransportPacket;

public class CommunicationImpl implements ICommunication {

	private final IConnectionManager connectionManager;

	private final IEncoder encoder = new PacketEncoder();

	public CommunicationImpl(IConnectionFactory factory) {
		connectionManager = new ConnectionManagerImpl(factory);
	}

	@Override
	public int bind(InetSocketAddress... addrs) {
		return connectionManager.bind(addrs);
	}

	@Override
	public void send(InetSocketAddress address, int localport, int pid, byte[] data) {
		ITransportPacket packet = encoder.encode(pid, data);
		packet.setAddress(address);
		packet.setLocalPort(localport);
		connectionManager.send(packet);
	}

	@Override
	public void stop(InetSocketAddress... address) {
		connectionManager.stop(address);
	}

}
