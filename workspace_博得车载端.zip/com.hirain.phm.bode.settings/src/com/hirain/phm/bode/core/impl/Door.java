/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.hirain.phm.bode.core.IDoor;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 4:32:04 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
@XmlRootElement(name = "Door")
@XmlType(propOrder = { "addr" })
@XmlAccessorType(XmlAccessType.FIELD)
public class Door implements IDoor {

	@XmlAttribute(name = "addr", required = true)
	private int addr;

	@Override
	public void setAddr(int addr) {
		this.addr = addr;
	}

	@Override
	public int getAddr() {
		return addr;
	}

}
