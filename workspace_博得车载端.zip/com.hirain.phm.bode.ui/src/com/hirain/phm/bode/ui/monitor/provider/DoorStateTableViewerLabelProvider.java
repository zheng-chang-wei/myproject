package com.hirain.phm.bode.ui.monitor.provider;

import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.swt.graphics.Image;
import org.eclipse.wb.swt.ResourceManager;

import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.monitor.model.Signal;
import com.hirain.phm.bode.ui.monitor.model.SignalState;

public class DoorStateTableViewerLabelProvider implements ITableLabelProvider {

	@Override
	public void addListener(ILabelProviderListener listener) {

	}

	@Override
	public void dispose() {

	}

	@Override
	public boolean isLabelProperty(Object element, String property) {
		return false;
	}

	@Override
	public void removeListener(ILabelProviderListener listener) {

	}

	@Override
	public Image getColumnImage(Object element, int columnIndex) {
		if (element instanceof Signal) {
			Signal signal = (Signal) element;
			switch (columnIndex) {
			case 1:
				SignalState signalState = signal.getSignalState();
				if (signalState != null) {
					Image pluginImage = ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, signalState.getImagePath());
					return pluginImage;
				}
			default:
				break;
			}
		}
		return null;
	}

	@Override
	public String getColumnText(Object element, int columnIndex) {
		if (element instanceof Signal) {
			Signal signal = (Signal) element;
			String signalName = signal.getSignalName();
			String value = signal.getValue();
			switch (columnIndex) {
			case 0:
				return signalName;
			case 1:
				if (value != null) {
					if ("关门时间".equals(signalName)) {
						return String.valueOf(Integer.valueOf(value) * 10) + " ms";
					}
					return value;
				}
			default:
				break;
			}
		}
		return StringUtil.EMPTY;
	}

}
