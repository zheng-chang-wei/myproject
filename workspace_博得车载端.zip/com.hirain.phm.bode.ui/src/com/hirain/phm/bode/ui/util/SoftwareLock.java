/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileLock;

import org.eclipse.jface.dialogs.MessageDialog;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Mar 4, 2019 1:31:42 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Mar 4, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class SoftwareLock {

	static File lockFile;

	static FileLock lock;

	@SuppressWarnings("resource")
	public static boolean checkLock() {
		FileOutputStream lockFileStream = null;
		lockFile = new File(".lock");

		try {
			lockFileStream = new FileOutputStream(lockFile);

			// 加锁，如果程序已经启动就无法获得锁
			lock = lockFileStream.getChannel().tryLock();

			if (lock == null) {
				MessageDialog.openInformation(null, "提示", "软件已启动！");
				return false;
			} else {
				return true;
			}
		} catch (FileNotFoundException e) {
			return false;
		} catch (IOException e) {
			return false;
		}

	}

}
