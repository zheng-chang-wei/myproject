package com.hirain.qsy.shaft.model;

import java.util.List;

import lombok.Data;

@Data
public class PythonData {

	private Integer Train_No;

	private List<Integer> GPSSpeed;

	// private List<Integer> AmbientTemperature;

	private List<Integer> AmbientTemperature_1;

	private List<Integer> AmbientTemperature_2;

	private List<Integer> TemperatureOnPoint_11;

	private List<Integer> TemperatureOnPoint_12;

	private List<Integer> TemperatureOnPoint_13;

	private List<Integer> TemperatureOnPoint_14;

	private List<Integer> TemperatureOnPoint_15;

	private List<Integer> TemperatureOnPoint_16;

	private List<Integer> TemperatureOnPoint_21;

	private List<Integer> TemperatureOnPoint_22;

	private List<Integer> TemperatureOnPoint_23;

	private List<Integer> TemperatureOnPoint_24;

	private List<Integer> TemperatureOnPoint_25;

	private List<Integer> TemperatureOnPoint_26;

	private List<Integer> TemperatureOnPoint_31;

	private List<Integer> TemperatureOnPoint_32;

	private List<Integer> TemperatureOnPoint_33;

	private List<Integer> TemperatureOnPoint_34;

	private List<Integer> TemperatureOnPoint_35;

	private List<Integer> TemperatureOnPoint_36;

	private List<Integer> TemperatureOnPoint_41;

	private List<Integer> TemperatureOnPoint_42;

	private List<Integer> TemperatureOnPoint_43;

	private List<Integer> TemperatureOnPoint_44;

	private List<Integer> TemperatureOnPoint_45;

	private List<Integer> TemperatureOnPoint_46;

	private List<Integer> TemperatureOnPoint_51;

	private List<Integer> TemperatureOnPoint_52;

	private List<Integer> TemperatureOnPoint_53;

	private List<Integer> TemperatureOnPoint_54;

	private List<Integer> TemperatureOnPoint_55;

	private List<Integer> TemperatureOnPoint_56;

	private List<Integer> TemperatureOnPoint_61;

	private List<Integer> TemperatureOnPoint_62;

	private List<Integer> TemperatureOnPoint_63;

	private List<Integer> TemperatureOnPoint_64;

	private List<Integer> TemperatureOnPoint_65;

	private List<Integer> TemperatureOnPoint_66;

}
