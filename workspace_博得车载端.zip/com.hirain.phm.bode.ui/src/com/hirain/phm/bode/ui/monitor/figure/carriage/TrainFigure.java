package com.hirain.phm.bode.ui.monitor.figure.carriage;

import java.util.List;
import java.util.Map;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.ui.monitor.listener.HandlerDoorDestroyManager;
import com.hirain.phm.bode.ui.monitor.listener.HandlerDoorStateManager;
import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月11日 下午1:48:41
 * @Description
 *              <p>
 *              整列车
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月11日 changwei.zheng@hirain.com 1.0 create file
 */
public class TrainFigure extends Figure {

	private int width = 0;

	private int y;

	/**
	 * 车厢高度
	 */
	private int height;

	public TrainFigure(ITrain train, boolean isConfig) {
		setLayoutManager(new XYLayout());
		List<ICar> carriages = train.getCars();
		y = CarriageConstants.carriageHeight + CarriageConstants.carriageVerticalSpacing;
		height = CarriageConstants.carriageHeight;
		if (isConfig) {
			y = CarriageConstants.carriageHeight + CarriageConstants.buttonSpacing * 2 + CarriageConstants.doorWidth;
			height = CarriageConstants.carriageHeight + CarriageConstants.buttonSpacing + CarriageConstants.doorWidth;
		}
		CarriageHeadFigure carriageHeadFigure = new CarriageHeadFigure(carriages.get(0), isConfig);
		add(carriageHeadFigure, new Rectangle(width, 0, carriageHeadFigure.getCarriageWidth(), CarriageConstants.carriageHeight));
		width = width + carriageHeadFigure.getCarriageWidth() + CarriageConstants.carriageHorizontalSpacing;
		CarriageEndFigure carriageEndFigure = new CarriageEndFigure(carriages.get(1), isConfig);
		addDoorDestroyListener(carriageHeadFigure);
		addDoorDestroyListener(carriageEndFigure);
		CommonCarriageFigure figure;
		for (int i = 2; i < carriages.size() / 2 + 1; i++) {
			ICar carriage = carriages.get(i);
			figure = new CarriageFigure(carriage, isConfig, true);
			addDoorDestroyListener(figure);
			add(figure, new Rectangle(width, 0, figure.getCarriageWidth(), height));
			if (!isConfig) {
				HandlerDoorStateManager.getInstatnce().add(figure);
			}
			width = width + figure.getCarriageWidth() + CarriageConstants.carriageHorizontalSpacing;
		}
		width = CarriageConstants.carriageHeadWidth + CarriageConstants.carriageHorizontalSpacing;
		for (int i = carriages.size() / 2 + 1; i < carriages.size(); i++) {
			ICar carriage = carriages.get(i);
			figure = new CarriageFigure(carriage, isConfig, false);
			addDoorDestroyListener(figure);
			add(figure, new Rectangle(width, y, figure.getCarriageWidth(), height + 30));
			if (!isConfig) {
				HandlerDoorStateManager.getInstatnce().add(figure);
			}
			width = width + figure.getCarriageWidth() + CarriageConstants.carriageHorizontalSpacing;
		}
		add(carriageEndFigure, new Rectangle(width, y, carriageEndFigure.getCarriageWidth(), CarriageConstants.carriageHeight));
		if (!isConfig) {
			width = width + carriageEndFigure.getCarriageWidth() + CarriageConstants.carriageHorizontalSpacing;
			LabelFigure labelFigure = new LabelFigure();
			add(labelFigure, new Rectangle(width, 0, labelFigure.getWidth(),
					CarriageConstants.carriageHeight * 2 + CarriageConstants.carriageVerticalSpacing));
			// HandlerDoorStateManager.getInstatnce().add(carriageHeadFigure);
			// HandlerDoorStateManager.getInstatnce().add(carriageEndFigure);
		}
	}

	private void addDoorDestroyListener(CommonCarriageFigure carriageFigure) {
		Map<String, DoorFigure> doorFigureMap = carriageFigure.getDoorMap();
		for (Map.Entry<String, DoorFigure> entry : doorFigureMap.entrySet()) {
			DoorFigure doorFigure = entry.getValue();
			HandlerDoorDestroyManager.getInstatnce().add(doorFigure);
		}
	}
}
