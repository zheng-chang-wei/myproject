package com.hirain.qsy.shaft.model;

import java.util.List;

public class ListInitialData {

	private List<InitialData> listInitialData;

	public List<InitialData> getListInitialData() {

		return listInitialData;
	}

	public void setListInitialData(List<InitialData> listInitialData) {

		this.listInitialData = listInitialData;
	}

}
