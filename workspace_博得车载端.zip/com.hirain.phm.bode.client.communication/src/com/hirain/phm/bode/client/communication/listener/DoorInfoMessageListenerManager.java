/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.listener;

import java.util.List;
import java.util.Vector;

import com.hirain.phm.bode.client.communication.message.DoorInfoMessage;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 25, 2019 11:26:44 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 25, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DoorInfoMessageListenerManager {

	private final List<IDoorInfoMessageListener> listeners = new Vector<IDoorInfoMessageListener>();

	private DoorInfoMessageListenerManager() {
	}

	public static DoorInfoMessageListenerManager getInstance() {
		return DoorInfoMessageListenerManagerClazz.instance;
	}

	private final static class DoorInfoMessageListenerManagerClazz {

		private final static DoorInfoMessageListenerManager instance = new DoorInfoMessageListenerManager();
	}

	public void addListener(final IDoorInfoMessageListener listener) {
		listeners.add(listener);
	}

	public void removeListener(final IDoorInfoMessageListener listener) {
		if (listeners.contains(listener)) {
			listeners.remove(listener);
		}
	}

	public void post(DoorInfoMessage message) {
		for (final IDoorInfoMessageListener listener : listeners) {
			listener.receive(message);
		}
	}

	public List<IDoorInfoMessageListener> getListeners() {
		return listeners;
	}

}
