/*******************************************************************************
 * Copyright (c) 2011, 2011 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.util;

/**
 * @Version 1.0
 * @Author jian.zhang@hirain.com
 * @Created Mar 30, 2012 10:04:31 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Mar 30, 2012 jian.zhang@hirain.com 1.0 create file
 */
public final class StringUtil {

	/**
	 * 
	 */
	public static final String EMPTY = "";

	/**
	 * 
	 */
	public static final String NULL = null;

	/**
	 * 
	 */
	public static final String COMMA = ",";

	/**
	 * 
	 */
	public static final String DOAT = ".";

	/**
	 * 
	 */
	public static final String SEMICOLON = ";";

	/**
	 * 
	 */
	public static final String COLON = ":";

	/**
	 * 
	 */
	public static final String LEFT_SLASH = "/";

	/**
	 * 
	 */
	public static final String UNDER_LINE = "_";

	public static final String MID_LINE = "-";

	/**
	 * 
	 */
	public static final String RIGHT_SLASH = "\\";

	/**
	 * 
	 */
	public static final String FILE_SEPARATOR = System.getProperty("file.separator");

	/**
	 * 
	 */
	public static final String USER_HOME = System.getProperty("user.home");

	/**
	 * 
	 */
	public static final String LINE_SEPARATOR = System.getProperty("line.separator");

	public static final String FORMAT_DECIMAL = "0.00";

	public static final String FORMAT_DATETIME = "yyyyMMddHHmmss";

	public static final String TAB = "	";

	/**
	 * �����ࣨ˽�й��췽����.
	 */
	private StringUtil() {
	}

	/**
	 * @param string
	 *            ��Ҫ�жϵ��ַ���.
	 * @return �жϽ��.
	 */
	public static boolean isEmpty(final String string) {
		return EMPTY.equals(string) || NULL == string;
	}

	/**
	 * @param string
	 *            ��Ҫ�жϵ��ַ���.
	 * @return �жϽ��.
	 */
	public static boolean isNotEmpty(final String string) {
		return !isEmpty(string);
	}

	/**
	 * @param str1
	 *            ��Ҫ�жϵ��ַ���.
	 * @param str2
	 *            ��Ҫ�жϵ��ַ���.
	 * @return �жϽ��.
	 */
	public static boolean isEquals(final String str1, final String str2) {
		if (str1 == NULL || str2 == NULL) {
			return false;
		}
		return str1.equals(str2);
	}
}
