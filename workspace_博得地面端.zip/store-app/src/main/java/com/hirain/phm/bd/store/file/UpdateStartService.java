/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.store.file;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年5月22日 下午5:46:12
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年5月22日 jianwen.xin@hirain.com 1.0 create file
 */
// @Component
// @Order(2)
public class UpdateStartService implements ApplicationRunner {

	// @Autowired
	// private Scheduler scheduler;

	// @Value("${store.file.create.period}")
	// private String cronExpression;

	/**
	 * @see org.springframework.boot.ApplicationRunner#run(org.springframework.boot.ApplicationArguments)
	 */
	@Override
	public void run(ApplicationArguments args) throws Exception {
		// JobDetail jobDetail = JobBuilder.newJob(UpdateFileJob.class).withIdentity("file-update").build();
		//
		// CronScheduleBuilder cronSchedule = CronScheduleBuilder.cronSchedule(cronExpression);
		// CronTrigger trigger = TriggerBuilder.newTrigger().withIdentity("file-update").withSchedule(cronSchedule).build();
		// scheduler.scheduleJob(jobDetail, trigger);
	}

}
