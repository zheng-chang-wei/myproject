/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.login;

import java.util.Timer;
import java.util.TimerTask;

import com.hirain.phm.bode.ui.util.UIConstants;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 25, 2019 10:26:17 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 25, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class HeartBeatTimer extends Timer {

	private static HeartBeatTimer timer = null;

	private HeartBeatTimer(boolean isDaemon) {
		super(isDaemon);
	}

	public static HeartBeatTimer getInstance() {
		if (timer == null) {
			timer = new HeartBeatTimer(true);
		}
		return timer;
	}

	public void start(TimerTask task) {
		timer.schedule(task, 0, UIConstants.HEARTBEAT_PERIOD);
	}

	public void stop() {
		if (timer != null) {
			timer.cancel();
		}
	}

}
