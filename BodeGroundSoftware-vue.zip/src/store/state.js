/**
 * Created by ASen on 2017/8/18.
 */
const state = {
	hardware:'', // 当前选中硬件,
	tem:'', // 当前选中模板,
	applicationchi:'',//当前选中的app类型id
	image:'', // app管理中添加的file文件,
	app_name:'', // 添加的app名字,
	app_type: '', // 添加app的类型
	app_hardware:'', // 选择的app硬件列表
	logo_url: '',//当前选中的app图片地址
	iframe:'',// 模板管理地址
	beforePage:'',//前组件页面名称
	app_id:'',//保存appid
	companyId:'',//保存的企业id
	appId:'',//功能池中appid
	appTypeId:''//apptypeid
}

export default state
