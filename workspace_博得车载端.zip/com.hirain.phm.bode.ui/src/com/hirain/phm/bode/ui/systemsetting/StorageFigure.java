/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.systemsetting;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.FigureUtilities;
import org.eclipse.draw2d.FlowLayout;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Layer;
import org.eclipse.draw2d.LayeredPane;
import org.eclipse.draw2d.LightweightSystem;
import org.eclipse.draw2d.RoundedRectangle;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 22, 2019 10:49:23 AM
 * @Description
 *              <p>
 *              系统配置页面中的存储空间展示图
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 22, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class StorageFigure {

	private static StorageFigure storageFigure = null;

	private Canvas canvas;

	private StorageState storageState;

	private RoundedRectangle storageStateFigure;

	private StorageFigure() {
	}

	public static StorageFigure getFigure(StorageState storageState) {
		if (storageFigure == null) {
			storageFigure = new StorageFigure();
		}
		storageFigure.setStorageState(storageState);
		return storageFigure;
	}

	public void setStorageState(StorageState storageState) {
		this.storageState = storageState;
	}

	public Canvas getCanvas() {
		return canvas;
	}

	/**
	 * 创建显示工作空间存储量的区域
	 */
	public void createCanvasComp(final Composite parent) {
		Composite workspaceComp = new Composite(parent, SWT.NONE);
		workspaceComp.setLayout(new GridLayout());

		canvas = new Canvas(workspaceComp, SWT.DOUBLE_BUFFERED);
		canvas.setBackground(new Color(null, 100, 150, 150));

		final GridData gridData = new GridData(SWT.LEFT, SWT.CENTER, true, false);
		gridData.widthHint = 300;// 显示条的宽度
		gridData.heightHint = 25;
		canvas.setLayoutData(gridData);

		final LayeredPane layeredPane = createLayeredPane();
		final LightweightSystem lightweightSystem = new LightweightSystem(canvas);
		lightweightSystem.setContents(layeredPane);
	}

	private LayeredPane createLayeredPane() {
		final LayeredPane layeredPane = new LayeredPane();
		final Layer gridLayer = createGridLayer();
		layeredPane.add(gridLayer);
		final Layer conentLayer = createContentLayer();
		layeredPane.add(conentLayer);
		return layeredPane;
	}

	private Layer createGridLayer() {
		final Layer contentLayer = new Layer();
		final org.eclipse.draw2d.GridLayout gridLayout = new org.eclipse.draw2d.GridLayout(1, true);
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;
		contentLayer.setLayoutManager(gridLayout);
		final RoundedRectangle roundedRectangle = new RoundedRectangle() {

			@Override
			protected void paintClientArea(final Graphics graphics) {
				try {
					graphics.pushState();
					graphics.setLineWidthFloat(1.f);
					graphics.setLineWidth(1);
					graphics.setAlpha(75);
					graphics.setLineStyle(Graphics.LINE_DOT);
					FigureUtilities.paintGrid(graphics, this, new Point(), 4, -1);
					graphics.setAlpha(100);
					graphics.setLineStyle(Graphics.LINE_SOLID);
					FigureUtilities.paintGrid(graphics, this, new Point(), 8, -1);
				} finally {
					graphics.popState();
				}
				super.paintClientArea(graphics);
			}
		};
		roundedRectangle.setCornerDimensions(new Dimension(4, 4));
		roundedRectangle.setBackgroundColor(ColorConstants.white);
		contentLayer.add(roundedRectangle, new org.eclipse.draw2d.GridData(org.eclipse.draw2d.GridData.FILL_BOTH));
		return contentLayer;
	}

	private Layer createContentLayer() {
		final Layer contentLayer = new Layer();
		final FlowLayout flowLayout = new FlowLayout() {

			@Override
			protected void setBoundsOfChild(final IFigure parent, final IFigure child, final Rectangle bounds) {
				if (storageState.getTotalSpace() > 0) {
					bounds.height = parent.getSize().height;
					final double usedPercent = storageState.getUsedSpace() * 1.0d / (storageState.getTotalSpace() * 1.0d);
					bounds.width = (int) (parent.getSize().width * usedPercent);
				} else {
					bounds.height = parent.getSize().height;
					bounds.width = 0;
				}
				super.setBoundsOfChild(parent, child, bounds);
			}
		};
		flowLayout.setMajorSpacing(0);
		flowLayout.setMinorSpacing(0);
		contentLayer.setLayoutManager(flowLayout);
		storageStateFigure = new RoundedRectangle();
		storageStateFigure.setAlpha(150);
		storageStateFigure.setCornerDimensions(new Dimension(4, 4));
		storageStateFigure.setBackgroundColor(ColorConstants.green);
		contentLayer.add(storageStateFigure);
		return contentLayer;
	}

	public void refresh() {
		final double usedPercent = storageState.getUsedSpace() * 1.0d / (storageState.getTotalSpace() * 1.0d);
		if (usedPercent > 0.9d) {
			storageStateFigure.setBackgroundColor(ColorConstants.red);
		} else if (usedPercent > 0.75d) {
			storageStateFigure.setBackgroundColor(ColorConstants.orange);
		} else if (usedPercent > 0.50d) {
			storageStateFigure.setBackgroundColor(ColorConstants.yellow);
		} else {
			storageStateFigure.setBackgroundColor(ColorConstants.green);
		}
		storageStateFigure.getParent().getLayoutManager().layout(storageStateFigure.getParent());
	}

}
