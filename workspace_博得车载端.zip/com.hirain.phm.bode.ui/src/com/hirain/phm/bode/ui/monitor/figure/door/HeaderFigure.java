package com.hirain.phm.bode.ui.monitor.figure.door;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;

public class HeaderFigure extends Figure implements StatusListener, IFigureMove {

	private final int width = 112;

	private final int height = 23;

	private final RectangleFigure h1 = new RectangleFigure();

	private final RectangleFigure h2 = new RectangleFigure();

	private final RectangleFigure h3 = new RectangleFigure();

	private final int side;

	private int step;

	public HeaderFigure(int side) {
		setLayoutManager(new XYLayout());
		createFigure(side);
		this.side = side;
	}

	private void createFigure(int side) {
		if (side == DoorContent.LEFT) {
			add(h1, new Rectangle(width - 5, height - 12, 10, 5));

			add(h2, new Rectangle(width - 9, height - 8, 14, 6));

			add(h3, new Rectangle(width - 17, height - 3, 22, 10));
			initPos = leftPos;
		} else {
			add(h1, new Rectangle(0, height - 12, 10, 5));

			add(h2, new Rectangle(0, height - 8, 14, 6));

			add(h3, new Rectangle(0, height - 3, 22, 10));
			initPos = rightPos;
		}
	}

	@Override
	public void update(int operation, int step) {
		this.step = step;
		if (side == DoorContent.LEFT) {
			// if (operation == DoorContent.OPEN_OPERATION) {
			moveToLeft();
			// } else if (operation == DoorContent.CLOSE_OPERATION) {
			// moveToRight();
			// }
		} else {
			// if (operation == DoorContent.OPEN_OPERATION) {
			moveToRight();
			// } else if (operation == DoorContent.CLOSE_OPERATION) {
			// moveToLeft();
			// }
		}
	}

	private int[] leftPos = { 190, 186, 178 };

	private int[] rightPos = { 200, 200, 200 };

	private int[] initPos;

	@Override
	public void reset() {
	}

	@Override
	public void moveToRight() {
		h1.getBounds().x = initPos[0] + step;
		h2.getBounds().x = initPos[0] + step;
		h3.getBounds().x = initPos[0] + step;
	}

	@Override
	public void moveToLeft() {
		h1.getBounds().x = initPos[0] - step;
		h2.getBounds().x = initPos[1] - step;
		h3.getBounds().x = initPos[2] - step;
	}
}
