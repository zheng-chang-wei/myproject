package com.hirain.phm.bode.server.client;

import java.net.InetSocketAddress;

public interface ISender {

	void send(InetSocketAddress address, int pid, byte[] datas);
}
