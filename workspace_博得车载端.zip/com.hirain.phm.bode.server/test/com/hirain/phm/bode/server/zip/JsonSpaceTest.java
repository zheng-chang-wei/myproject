package com.hirain.phm.bode.server.zip;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;

import com.hirain.phm.bd.message.CarriagePacket;
import com.hirain.phm.bd.message.CommonMessage;
import com.hirain.phm.bd.message.DoorPacket;
import com.hirain.phm.bd.message.TrainPacket;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.ZipUtil;

public class JsonSpaceTest {

	private static byte[] getBytes(String line) {
		final byte[] bs = new byte[32];
		if (line != null) {
			int index = 0;
			for (int i = 0; i < line.length() - 1; i = i + 2) {
				final String sub = line.substring(i, i + 2);
				final int v = Integer.parseInt(sub, 16);
				bs[index++] = (byte) v;
			}
		}
		return bs;
	}

	public static void main(String[] args) throws IOException {
		final List<String> lines = FileUtils.readLines(new File("E:\\test\\phm_data1.txt"), Charset.forName("utf-8"));
		final List<CarriagePacket> carriagePackets = new ArrayList<>();
		final byte[][] datas = new byte[16][];
		for (int i = 0; i < 16; i++) {
			datas[i] = getBytes(lines.get(i + 1000));
		}

		for (int i = 0; i < 10; i++) {
			final List<DoorPacket> packets = new ArrayList<>();
			for (int j = 0; j < 10; j++) {
				final List<CommonMessage> messages = new ArrayList<>();
				for (int k = 0; k < 16; k++) {
					final CommonMessage message = new CommonMessage(datas[k], true);
					message.setMilli(100);
					messages.add(message);
				}
				packets.add(new DoorPacket(j, messages));
			}
			carriagePackets.add(new CarriagePacket(i, packets));
		}
		final TrainPacket trainPacket = new TrainPacket(0, carriagePackets);
		trainPacket.set("深圳", "7", "7123");
		final String string = Utils.toJsonString(trainPacket);
		final byte[] b1 = string.getBytes(Charset.forName("utf-8"));
		System.out.println("源:\t\t" + b1.length);

		// final byte[] compress = ZipUtil.compress(b1);
		// System.out.println(compress.length);
		// final String line = new String(compress);
		// final String filepath = System.getProperty("user.dir") + File.separator + "test.txt";
		// FileUtils.writeLines(new File(filepath), "utf-8", Arrays.asList(line));
		//
		// final List<String> line2 = FileUtils.readLines(new File(filepath), "utf-8");
		// System.out.println(line2.size());
		// System.out.println(line2.get(0).getBytes().length);
		//
		// final String line3 = FileUtils.readFileToString(new File(filepath), "utf-8");
		// System.out.println(line3.getBytes().length);

		// System.out.println("-------------QuickLz-----------------");
		// long t1 = System.currentTimeMillis();
		// final byte[] res = QuickLZ.compress(b1, 1);
		// long t2 = System.currentTimeMillis();
		// System.out.println("压缩时间:\t" + (t2 - t1));
		//
		// t1 = System.currentTimeMillis();
		// final byte[] bs = QuickLZ.decompress(res);
		// t2 = System.currentTimeMillis();
		// System.out.println("解压时间:\t" + (t2 - t1));
		// System.out.println();
		// System.out.println("压缩后:\t\t" + res.length);
		// System.out.println("解压后:\t\t" + bs.length);
		// System.out.println("比率:\t\t" + (double) res.length / b1.length);
		// System.out.println();
		//
		// TrainPacket packet = Utils.fromJsonString(new String(bs, Charset.forName("utf-8")), TrainPacket.class);
		// System.out.println(packet.getPackets().size());

		// System.out.println("-------------JDK ZIPStream-----------------");
		// t1 = System.currentTimeMillis();
		// final byte[] zip = ZipUtil.zip(b1);
		// t2 = System.currentTimeMillis();
		// System.out.println("压缩时间:\t" + (t2 - t1));
		//
		// t1 = System.currentTimeMillis();
		// final byte[] unzip = ZipUtil.unzip(zip);
		// t2 = System.currentTimeMillis();
		// System.out.println("解压时间:\t" + (t2 - t1));
		//
		// System.out.println();
		// System.out.println("压缩后:\t\t" + zip.length);
		// System.out.println("解压后:\t\t" + unzip.length);
		// System.out.println("比率:\t\t" + (double) zip.length / b1.length);
		// System.out.println();
		// packet = Utils.fromJsonString(new String(unzip, Charset.forName("utf-8")), TrainPacket.class);
		// System.out.println(packet.getPackets().size());
		//
		// // final String string2 = Utils.toJsonString(msgs);
		// // System.out.println(string2.getBytes().length);
		System.out.println("-------------Deflater-----------------");
		long t1 = System.currentTimeMillis();
		final byte[] flater = ZipUtil.compress(b1);
		long t2 = System.currentTimeMillis();
		System.out.println("压缩时间:\t" + (t2 - t1));

		t1 = System.currentTimeMillis();
		final byte[] unflater = ZipUtil.uncompress(flater);
		t2 = System.currentTimeMillis();
		System.out.println("解压时间:\t" + (t2 - t1));

		System.out.println();
		System.out.println("压缩后:\t\t" + flater.length);
		System.out.println("解压后:\t\t" + unflater.length);
		System.out.println("比率:\t\t" + (double) flater.length / b1.length);
		System.out.println();
		final TrainPacket packet = Utils.fromJsonString(new String(unflater, Charset.forName("utf-8")), TrainPacket.class);
		System.out.println(packet.getPackets().size());

		// System.out.println("------------GZIP-------------------");
		// t1 = System.currentTimeMillis();
		// final byte[] gzip = ZipUtil.jdkGzip(b1);
		// t2 = System.currentTimeMillis();
		// System.out.println("压缩时间:\t" + (t2 - t1));
		//
		// t1 = System.currentTimeMillis();
		// final byte[] ungzip = ZipUtil.jdkGunzip(gzip);
		// t2 = System.currentTimeMillis();
		// System.out.println("解压时间:\t" + (t2 - t1));
		//
		// System.out.println();
		// System.out.println("压缩后:\t\t" + gzip.length);
		// System.out.println("解压后:\t\t" + ungzip.length);
		// System.out.println("比率:\t\t" + (double) gzip.length / b1.length);
		// System.out.println();
		// packet = Utils.fromJsonString(new String(ungzip, Charset.forName("utf-8")), TrainPacket.class);
		// System.out.println(packet.getPackets().size());
	}
}
