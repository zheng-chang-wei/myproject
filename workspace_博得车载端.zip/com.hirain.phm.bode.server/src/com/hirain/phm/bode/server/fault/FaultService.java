package com.hirain.phm.bode.server.fault;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.ibatis.session.SqlSession;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.DebugEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.bus.MessageListEvent;
import com.hirain.phm.bode.server.db.DBService;
import com.hirain.phm.bode.server.fault.dao.FaultMapper;
import com.hirain.phm.bode.server.message.DoorMessage;
import com.hirain.phm.bode.server.message.IPreProcessor;

public class FaultService {

	private final IPreProcessor processor;

	private final AtomicBoolean debug = new AtomicBoolean(false);

	private final Map<Integer, FaultDetector> detectorMap = new HashMap<>();

	private final ExecutorService executor = Executors.newSingleThreadExecutor();

	public static Map<Integer, String> FAULT_NAMES;

	public FaultService(IPreProcessor processor) {
		this.processor = processor;
	}

	public void init() {
		InnerEventBus.getInstance().register(this);
		processor.register(this);
		final SqlSession session = DBService.getInstance().getSession(false);
		final FaultMapper mapper = DBService.getInstance().getMapper(FaultMapper.class, session);
		final List<FaultDetail> list = mapper.list();
		FAULT_NAMES = new HashMap<>();
		for (final FaultDetail detail : list) {
			FAULT_NAMES.put(detail.getId(), detail.getName());
		}
	}

	@Subscribe
	public void on(ConfigEvent event) {
		executor.submit(() -> {
			processor.unregister(this);
			final ITrain train = event.getTrain();
			final List<ICar> cars = train.getCars();
			final Set<Integer> idSet = new HashSet<>();
			for (final ICar car : cars) {
				if (car.getType() == 0) {
					continue;
				}
				final int carriageId = car.getIndex();
				FaultDetector detector = detectorMap.get(carriageId);
				if (detector == null) {
					detector = new FaultDetector(carriageId, car.getDoors());
					detector.work();
					detectorMap.put(carriageId, detector);
				}
				idSet.add(carriageId);
			}
			processor.register(this);
			for (final Integer key : detectorMap.keySet()) {
				if (!idSet.contains(key)) {
					FaultDetector detector = detectorMap.get(key);
					detector.stop();
					detector = null;
					detectorMap.remove(key);
				}
			}
		});
	}

	@Subscribe
	public void on(DebugEvent event) {
		debug.set(event.isDebug());
	}

	@Subscribe
	public void on(MessageListEvent event) {
		final List<DoorMessage> messages = event.getMessages();
		final Integer carriageId = messages.get(0).getCarriageId();
		final FaultDetector detector = detectorMap.get(carriageId);
		if (detector != null) {
			detector.push(messages);
		}
	}
}
