package com.hirain.phm.bode.ui.fault.service;

public interface FaultService {

	void selectAll();
}
