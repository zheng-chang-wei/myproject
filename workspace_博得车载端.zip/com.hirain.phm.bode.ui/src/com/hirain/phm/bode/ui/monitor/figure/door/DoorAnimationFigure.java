package com.hirain.phm.bode.ui.monitor.figure.door;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;

/**
 * @Version 1.0
 * @Created 2019年1月22日 下午6:56:15
 * @Description
 *              <p>
 *              门动画封装类
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 */
public class DoorAnimationFigure extends Figure implements StatusListener {

	private final FrameFigure frame = new FrameFigure();

	private final DoorSheetFigure leftDoorSheet = new DoorSheetFigure(DoorContent.LEFT);

	private final DoorSheetFigure rightDoorSheet = new DoorSheetFigure(DoorContent.RIGHT);

	private final DirectionLigthFigure leftLight = new DirectionLigthFigure(DoorContent.LEFT);

	private final DirectionLigthFigure rightLight = new DirectionLigthFigure(DoorContent.RIGHT);

	private final Rectangle leftRectangle = new Rectangle(0, 1, 50, 50);

	private final Rectangle rightRectangle = new Rectangle(360, 1, 50, 50);

	private int times = 0;

	private int operation = -1;

	public DoorAnimationFigure() {
		setLayoutManager(new XYLayout());
		createFigure();
	}

	private void createFigure() {
		add(leftDoorSheet, new Rectangle(0, 70, 200, 225));
		add(rightDoorSheet, new Rectangle(200, 70, 200, 225));
		add(frame, new Rectangle(80, 50, 360, 40));
		add(leftLight, leftRectangle);
		add(rightLight, rightRectangle);
	}

	@Override
	public void update(int operation, int step) {
		if (operation != this.operation) {
			times = 0;
			this.operation = operation;
			if (operation == DoorContent.OPEN_OPERATION) {
				add(leftLight, leftRectangle);
				add(rightLight, rightRectangle);
			} else if (operation == DoorContent.CLOSE_OPERATION) {
				add(leftLight, rightRectangle);
				add(rightLight, leftRectangle);
			}
		}
		leftDoorSheet.update(operation, step);
		rightDoorSheet.update(operation, step);
		frame.update(operation, step);
		if (times % 6 == 0) {
			leftLight.update(operation, step);
			rightLight.update(operation, step);
		}
		times++;
	}

	@Override
	public void reset() {
		leftDoorSheet.update(operation, 0);
		rightDoorSheet.update(operation, 0);
		frame.update(operation, 0);
		leftLight.reset();
		rightLight.reset();
	}

}
