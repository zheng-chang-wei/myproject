package com.hirain.phm.bode.server.comm;

public interface IPost {

	void post(ITransportPacket packet);

}
