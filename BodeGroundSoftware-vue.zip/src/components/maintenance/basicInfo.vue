<template>
  <div>
    <el-collapse-item title="工单具体信息" :name="name" style="margin-left:10px">
      <el-form ref="basicInfoForm" :model="basicInfoForm" :inline="true" :disabled="disableEdit" label-width="110px" :rules="formRules">
        <div style="border:1px solid #000;border-radius: 5px;">
          基本信息
          <div style="margin:10px">
            <el-form-item label="城市" prop="cityName">
              <el-select v-model="basicInfoForm.cityName" placeholder="请选择" @change="selectedCityChange">
                <el-option v-for="item in cityOptions" :key="item.label" :label="item.label" :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item label="线路" prop="lineName">
              <el-select v-model="basicInfoForm.lineName" placeholder="请选择" @change="selectedLineChange">
                <el-option v-for="item in lineOptions" :key="item.label" :label="item.label" :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item label="车辆" prop="trainId">
              <el-select v-model="basicInfoForm.trainId" placeholder="请选择">
                <el-option v-for="item in carOptions" :key="item.label" :label="item.label" :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item label="车门编号" prop="doorId">
              <el-input v-model="basicInfoForm.doorId" />
            </el-form-item>
            <el-form-item label="车门种类" prop="doorType">
              <el-input v-model="basicInfoForm.doorType" />
            </el-form-item>
            <el-form-item label="运行公里数" prop="kilometers">
              <el-input v-model="basicInfoForm.kilometers" />
            </el-form-item>
            <el-form-item label="运营影响" prop="effect">
              <el-input v-model="basicInfoForm.effect" />
            </el-form-item>
            <el-form-item label="一级部件" prop="levelOne">
              <el-input v-model="basicInfoForm.levelOne" />
            </el-form-item>
            <el-form-item label="二级部件" prop="levelTwo">
              <el-input v-model="basicInfoForm.levelTwo" />
            </el-form-item>
          </div>
        </div>
        <div style="border:1px solid #000;margin-top:5px;border-radius: 5px;">
          故障信息
          <div style="margin:10px">
            <el-form-item label="故障件名称" prop="component">
              <el-input v-model="basicInfoForm.component" />
            </el-form-item>
            <el-form-item label="故障件数量" prop="count">
              <el-input v-model="basicInfoForm.count" />
            </el-form-item>
            <el-form-item label="故障发生阶段" prop="stage">
              <el-input v-model="basicInfoForm.stage" />
            </el-form-item>
            <el-form-item label="故障模式" prop="mode">
              <el-input v-model="basicInfoForm.mode" />
            </el-form-item>
            <el-form-item label="发生地点" prop="location">
              <el-input v-model="basicInfoForm.location" />
            </el-form-item>
            <el-form-item label="故障时间" prop="faultTime">
              <el-date-picker
                v-model="basicInfoForm.faultTime"
                type="datetime"
                value-format="yyyy-MM-dd HH:mm:ss"
                placeholder="选择日期时间"
                :editable="false"
              />
              <!-- <el-input v-model="basicInfoForm.faultTime"></el-input> -->
            </el-form-item>
            <el-form-item label="临时处理措施" prop="temporary">
              <el-input v-model="basicInfoForm.temporary" />
            </el-form-item>
            <br>
            <el-form-item style="width:550px" label-position="top" label="故障描述" prop="description">
              <el-input v-model="basicInfoForm.description" style="width:500px" type="textarea" :autosize="{ minRows: 4, maxRows: 8}" placeholder="请输入故障信息、发生地点、时间" />
            </el-form-item>
            <el-form-item style="width:550px" label-position="top" label="初步原因分析" prop="reason">
              <el-input v-model="basicInfoForm.reason" style="width:500px" type="textarea" :autosize="{ minRows: 4, maxRows: 8}" placeholder="请输入初步分析原因以及处理措施，是否复现" />
            </el-form-item>
            <br>

            <el-form-item label="是否需要配件" prop="needParts">
              <template>
                <el-radio-group v-model="basicInfoForm.needParts" style="width:140px">
                  <el-radio :label="true">是</el-radio>
                  <el-radio :label="false">否</el-radio>
                </el-radio-group>
              </template>
            </el-form-item>

            <el-form-item label="需求配件名称" prop="partName">
              <el-input v-model="basicInfoForm.partName" />
            </el-form-item>
            <el-form-item label="需求配件数量" prop="partCount">
              <el-input v-model="basicInfoForm.partCount" />
            </el-form-item>
            <br>
            <el-form-item label="是否分析报告" prop="needReport">
              <template>
                <el-radio-group v-model="basicInfoForm.needReport" style="width:140px">
                  <el-radio :label="true">是</el-radio>
                  <el-radio :label="false">否</el-radio>
                </el-radio-group>
              </template>
            </el-form-item>
            <br>
            <el-form-item label="图片" prop="imagePath">
              <el-image v-for="url in imageUrls" :key="url" style="width: 100px; height: 100px" :src="url" fit="scale-down" :preview-src-list="imageUrls" />
              <el-button @click="uploadImage">上传图片</el-button>
              <el-button @click="deleteImage">删除图片</el-button>
            </el-form-item>
            <br>
            <el-form-item label="现场处理人数" prop="processorCount">
              <el-input v-model="basicInfoForm.processorCount" />
            </el-form-item>
            <el-form-item label="现场处理人" prop="processor">
              <el-input v-model="basicInfoForm.processor" />
            </el-form-item>
          </div>
        </div>
      </el-form>
    </el-collapse-item>
    <div v-if="!disableEdit" style="text-align:center;margin-top:10px;margin-bottom: 20px;">
      <el-button @click="resetForm()">返回</el-button>
      <el-button @click="commitBasicInfo()">提交</el-button>
    </div>
    <el-dialog title="上传图片" :visible.sync="uploadDialogVisible" :close-on-click-modal="false" :before-close="handleClose">
      <el-upload
        ref="upload"
        action=""
        multiple
        accept=".jpg,.png"
        :file-list="fileList"
        :auto-upload="false"
        :on-change="addFile"
        :http-request="uploadFile"
        :before-upload="beforeUpload"
      >
        <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
        <el-button style="margin-left: 10px;" size="small" type="success" @click="submitUpload">上传到服务器
        </el-button>
        <div slot="tip" class="el-upload__tip">只能上传jpg/png文件</div>
      </el-upload>
    </el-dialog>
    <el-dialog title="删除图片" :visible.sync="deleteDialogVisible" :close-on-click-modal="false" :before-close="handleClose">
      <el-button style="margin-left: 10px;" size="small" type="danger" @click="handleDelete">删除图片
      </el-button>
      <el-table :data="tableData" style="width: 100%;margin-top:20px" border @selection-change="selsChange">
        <el-table-column type="selection" width="55" align="center" />
        <el-table-column align="center" prop="url" label="图片">
          <template slot-scope="scope">
            <el-image style="width: 100px; height: 100px" :src="scope.row.url" fit="scale-down" />
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>
<script>
import app from '@/common/js/app'
export default {
  props: {
    basicInfoForm: {
      type: Object,
      default: null
    },
    disableEdit: Boolean,
    name: {
      type: Number,
      default: null
    },
    jump: Boolean,
    sheetId: {
      type: String,
      default: ''
    },
    detailId: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      uploadDialogVisible: false,
      deleteDialogVisible: false,
      sels: [],
      tableData: [],
      fileList: [],
      imageUrls: [],
      imageNames: [],
      cityOptions: [],
      lineOptions: [],
      carOptions: [],
      fileListLength: 0,
      successedFileListLength: 0,
      updateSuccessCount: 0,
      // 表单验证规则
      formRules: {
        kilometers: [{
          required: true,
          message: '请输入公里数',
          trigger: 'change'
        }],
        faultTime: [{
          type: 'string',
          required: true,
          message: '请选择故障日期',
          trigger: 'change'
        }],
        // cityName: [{
        // 	required: true,
        // 	message: "请选择城市",
        // 	trigger: "change"
        // }],
        // lineName: [{
        // 	required: true,
        // 	message: "请选择线路",
        // 	trigger: "change"
        // }],
        // trainId: [{
        // 	required: true,
        // 	message: "请选择车辆",
        // 	trigger: "change"
        // }],
        doorId: [{
          required: true,
          message: '请输入车门编号',
          trigger: 'change'
        }],
        doorType: [{
          required: true,
          message: '请输入车门类别',
          trigger: 'change'
        }],
        effect: [{
          required: true,
          message: '请选择运营影响',
          trigger: 'change'
        }],
        stage: [{
          required: true,
          message: '请选择故障发生阶段',
          trigger: 'change'
        }],
        mode: [{
          required: true,
          message: '请选择故障模式',
          trigger: 'change'
        }],
        levelOne: [{
          required: true,
          message: '请选择一级部件',
          trigger: 'change'
        }],
        levelTwo: [{
          required: true,
          message: '请选择二级部件',
          trigger: 'change'
        }],
        location: [{
          required: true,
          message: '请输入故障发生地点',
          trigger: 'change'
        }],
        component: [{
          required: true,
          message: '请输入故障件名称',
          trigger: 'change'
        }],
        count: [{
          required: true,
          message: '请选择故障故障件数量',
          trigger: 'change'
        }],
        partName: [{
          required: true,
          message: '请输入需求配件名称',
          trigger: 'change'
        }],
        partCount: [{
          required: true,
          message: '请选择需求配件数量',
          trigger: 'change'
        }],
        temporary: [{
          required: true,
          message: '请选择临时处理措施',
          trigger: 'change'
        }],
        description: [{
          required: true,
          message: '请输入故障描述',
          trigger: 'change'
        }],
        needReport: [{
          required: true,
          message: '请选择是否生成分析报告',
          trigger: 'change'
        }],
        needParts: [{
          required: true,
          message: '请选择是否需要配件',
          trigger: 'change'
        }],
        processorCount: [{
          required: true,
          message: '请输入现场处理人数',
          trigger: 'change'
        }],
        reason: [{
          required: true,
          message: '请输入初步原因分析以及处理措施',
          trigger: 'change'
        }],
        processor: [{
          required: true,
          message: '请输入处理人',
          trigger: 'change'
        }]
      }
    }
  },
  mounted() {
    this.getAllCitys()
    if (this.basicInfoForm.imagePath) {
      this.imageNames = this.basicInfoForm.imagePath.split(',')
      this.imageNames.forEach(name => {
        this.imageUrls.push(this.GLOBAL.serverIpAndPort + name)
      })
    }
  },
  methods: {
    getAllCitys() {
      var vm = this
      vm.cityOptions = []
      app.get('get_city_name').then(d => {
        vm.cityOptions = []
        for (var i = 0; i < d.msg.length; i++) {
          if (d.msg[i].cityName != null) {
            vm.cityOptions.push({
              value: d.msg[i].cityName,
              label: d.msg[i].cityName
            })
          }
        }
        if (vm.cityOptions.length > 0) {
          if (vm.basicInfoForm.project) {
            var city_line = vm.basicInfoForm.project.split('_')
            vm.basicInfoForm.cityName = city_line[0]
            vm.basicInfoForm.lineName = city_line[1]
          } else {
            vm.basicInfoForm.cityName = vm.cityOptions[0].value
          }
          vm.selectedCityChange()
        }
      }).catch(err => {
        console.log(err)
      })
    },
    selectedCityChange() {
      var vm = this
      const parm = {
        cityName: this.basicInfoForm.cityName
      }
      this.lineOptions = []
      this.basicInfoForm.lineName = null
      this.carOptions = []
      this.basicInfoForm.train = null
      if (this.basicInfoForm.cityName != null) {
        app.get('get_lines_by_cityName', parm).then(d => {
          vm.lineOptions = []
          for (var i = 0; i < d.msg.length; i++) {
            if (d.msg[i].lineName != null) {
              vm.lineOptions.push({
                value: d.msg[i].lineName,
                label: d.msg[i].lineName
              })
            }
          }
          if (vm.lineOptions.length > 0) {
            if (vm.basicInfoForm.project) {
              var city_line = vm.basicInfoForm.project.split('_')
              vm.basicInfoForm.lineName = city_line[1]
            } else {
              vm.basicInfoForm.lineName = vm.lineOptions[0].value
            }
            vm.selectedLineChange()
          }
        })
      }
    },
    selectedLineChange() {
      var vm = this
      const parm = {
        cityName: this.basicInfoForm.cityName,
        lineName: this.basicInfoForm.lineName
      }
      this.carOptions = []
      this.basicInfoForm.train = null
      if (this.basicInfoForm.lineName != null) {
        app.get('get_train_by_trainParam', parm).then(d => {
          vm.carOptions = []
          for (var i = 0; i < d.msg.length; i++) {
            if (d.msg[i].trainNo != null) {
              vm.carOptions.push({
                value: d.msg[i].trainNo,
                label: d.msg[i].trainNo
              })
            }
          }
          if (vm.carOptions.length > 0) {
            if (!vm.basicInfoForm.trainNo) {
              vm.basicInfoForm.trainId = vm.carOptions[0].value
            }
          }
        })
      }
    },

    beforeUpload(file) {
      const isLt2M = file.size / 1024 / 1024 < 10 // 这里做文件大小限制
      if (!isLt2M) {
        this.$message({
          message: '上传文件须小于 10MB!',
          type: 'warning'
        })
        this.updateSuccessCount++
      }
      return isLt2M
    },
    uploadImage() {
      this.uploadDialogVisible = true
    },
    deleteImage() {
      this.deleteDialogVisible = true
      this.tableData = []
      this.imageUrls.forEach(url => {
        this.tableData.push({
          url: url
        })
      })
    },
    handleDelete() {
      var vm = this
      var filepaths = this.sels.toString()
      if (this.sels.length === 0) {
        this.$message({
          message: '请至少勾选一个图片删除',
          type: 'error'
        })
        return
      }
      this.$confirm('确认删除选中记录？', '提示', {
        type: 'warning'
      }).then(() => {
        const param = {
          filepaths: filepaths
        }
        app.post('delete_file_byFilepaths', param).then(data => {
          vm.listLoading = false
          if (data.code === '0') {
            vm.$message({
              message: '删除成功',
              type: 'success'
            })
            vm.deleteDialogVisible = false
            filepaths.split(',').forEach(filePath => {
              var index = vm.imageNames.indexOf(filePath)
              if (index !== -1) {
                vm.imageUrls.splice(index, 1)
                vm.imageNames.splice(index, 1)
              }
            })
          }
        })
      }).catch(() => {})
    },
    submitUpload() {
      this.updateSuccessCount = 0
      this.$refs.upload.submit()
    },
    // 上传文件
    uploadFile(param) {
      this.loading = this.$loading({
        lock: true,
        text: '文件上传中',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      var vm = this
      vm.fileListLength = vm.fileList.length - vm.successedFileListLength
      const formData = new FormData()
      formData.append('file', param.file)
      app.uploadFile('upload_file', formData).then(data => {
        if (data.msg) {
          if (data.code === 0) {
            vm.successedFileListLength++
            vm.updateSuccessCount++
            if (vm.updateSuccessCount === vm.fileListLength) {
              vm.loading.close()
            }
            vm.$message({
              message: param.file.name + '上传成功',
              type: 'success'
            })
            vm.imageUrls.push(this.GLOBAL.serverIpAndPort + data.data)
            vm.imageNames.push(data.data)
            param.onSuccess()
          }
        }
      }).catch(response => {
        param.onError()
        vm.updateSuccessCount++
        if (vm.updateSuccessCount === vm.fileListLength) {
          vm.loading.close()
        }
      })
    },
    selsChange(sels) {
      this.sels = []
      sels.forEach(sel => {
        var name = sel.url.substring(sel.url.lastIndexOf('/') + 1, sel.url.length)
        this.sels.push(name)
      })
    },
    // 显示上传的文件
    addFile(file, fileList) {
      this.fileList = fileList
    },
    handleClose(done) {
      this.close()
      done()
    },
    close() {
      this.fileList = []
      this.successedFileListLength = 0
    },
    // 返回上一界面
    resetForm() {
      this.$router.go(-1)
    },
    commitBasicInfo() {
      this.$refs.basicInfoForm.validate(valid => {
        if (valid) {
          var url = ''
          var params = {}
          this.basicInfoForm.project = this.basicInfoForm.cityName + '_' + this.basicInfoForm.lineName
          this.basicInfoForm.imagePath = this.imageNames.join(',')
          if (this.jump) {
            url = 'commit_work_detail'
            params = {
              sheetId: this.sheetId,
              object: this.basicInfoForm
            }
          } else {
            url = 'create_work_detail'
            params = this.basicInfoForm
          }
          var vm = this
          app.postData(url, params).then(data => {
            vm.handleMsg(data)
          })
        }
      })
    },
    handleMsg(data) {
      if (data.code === 0) {
        this.$message({
          message: data.msg,
          type: 'success'
        })
        this.resetForm()
      } else {
        this.$message({
          message: data.msg,
          type: 'error'
        })
      }
    }
  }
}

</script>

<style>

</style>
