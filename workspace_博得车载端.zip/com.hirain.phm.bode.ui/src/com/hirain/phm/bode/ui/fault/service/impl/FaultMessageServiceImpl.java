package com.hirain.phm.bode.ui.fault.service.impl;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.core.fault.FaultRecord;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.fault.service.FaultMessageService;

public class FaultMessageServiceImpl implements FaultMessageService {

	private static FaultMessageServiceImpl singleton = null;

	private FaultMessageServiceImpl() {
	}

	public static FaultMessageServiceImpl getInstance() {
		if (singleton == null) {
			singleton = new FaultMessageServiceImpl();
		}
		return singleton;
	}

	@Override
	public void select(FaultRecord faultMessage) {
		StringBuilder sql = new StringBuilder("select * from t_fault_message where ");
		String carriageId = faultMessage.getCarriageId();
		sql.append("carriage_id=" + carriageId);
		String doorId = faultMessage.getDoorId();
		sql.append(" and door_id=" + doorId);
		String start = faultMessage.getStartTime();
		if (start != null) {
			sql.append(" and timestamp>='" + start + "'");
		}
		String end = faultMessage.getEndTime();
		if (end != null) {
			sql.append(" and timestamp<='" + end + "'");
		}
		System.err.println(sql);
		try {
			CommunicationService.getInstance().select(ServiceConstant.PID_DATA_DOWNLOAD, ServiceConstant.FAULT_RECORD_SID, sql.toString());
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}

	public void download(FaultRecord faultRecord) {
		StringBuilder sql = new StringBuilder("select * from t_fault_message where ");
		String carriageId = faultRecord.getCarriageId();
		sql.append("carriage_id=" + carriageId);
		String doorId = faultRecord.getDoorId();
		sql.append(" and door_id=" + doorId);
		String start = faultRecord.getStartTime();
		if (start != null) {
			sql.append(" and timestamp>='" + start + "'");
		}
		String end = faultRecord.getEndTime();
		if (end != null) {
			sql.append(" and timestamp<='" + end + "'");
		}
		System.err.println(sql);
		try {
			ByteBuffer buffer = ByteBuffer.allocate(sql.toString().getBytes().length + 13).order(ByteOrder.LITTLE_ENDIAN);
			buffer.put(ServiceConstant.FAULT_RECORD_SID);
			buffer.put(Byte.parseByte(carriageId));
			buffer.put(Byte.parseByte(doorId));
			buffer.putInt(Integer.valueOf(faultRecord.getFaultId()));
			// 故障发生时间
			String timestamp = faultRecord.getTimestamp();
			DateFormat dateFormat = DateFormat.getDateTimeInstance();
			Date date = dateFormat.parse(timestamp);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);

			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.YEAR) - 2000)));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.MONTH) + 1)));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.DATE))));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.HOUR))));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.MINUTE))));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.SECOND))));
			buffer.put(sql.toString().getBytes());
			CommunicationService.getInstance().download(buffer.array());
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}

}
