package com.hirain.phm.bode.client.communication.transport;

import com.hirain.phm.bode.client.communication.message.AbstractMessage;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 */
public interface IDecoder {

	AbstractMessage decode(ITransportPacket packet);
}
