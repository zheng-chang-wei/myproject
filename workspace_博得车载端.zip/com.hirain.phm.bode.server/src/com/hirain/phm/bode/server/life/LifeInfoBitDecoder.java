/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.server.life;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created May 30, 2019 3:47:37 PM
 * @Description
 *              <p>
 *              寿命信息的解析器，会从报文中解析出每个寿命项点量纲值计算所需的量
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               May 30, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class LifeInfoBitDecoder {

	/**
	 * 得到‘门开好’的标志位
	 * 1：开门到位 0：不到位
	 */
	public static int getDoorOpenedBit(byte[] data) {
		final byte b = data[2];
		return b >> 3 & 1;
	}

	/**
	 * 得到‘门关好’的标志位
	 * 1:关门到位 0:不到位
	 */
	public static int getDoorClosedBit(byte[] data) {
		final byte b = data[2];
		return b >> 4 & 1;
	}

	/**
	 * 得到‘门紧急解锁’的标志位
	 * 1:未激活 0:激活
	 */
	public static int getEmergencyUnlockBit(byte[] data) {
		final byte b = data[2];
		return b >> 2 & 1;
	}

	/**
	 * 得到‘门隔离’的标志位
	 * 1:激活 0:未激活
	 */
	public static int getDoorIsolationBit(byte[] data) {
		final byte b = data[2];
		return b >> 1 & 1;
	}

	/**
	 * 得到‘闭锁开关信号’的值
	 */
	public static int getLockSwitchBit(byte[] data) {
		final byte b = data[5];
		return b >> 7 & 1;
	}

	/**
	 * 获取开门时间
	 */
	public static short getDoorOpenTime(byte[] data) {
		short doorOpenTime = (short) (data[15] << 8 | data[14] & 0xFF);
		return doorOpenTime;
	}

	/**
	 * 获取关门时间
	 */
	public static short getDoorCloseTime(byte[] data) {
		short doorCloseTime = (short) (data[18] << 8 | data[17] & 0xFF);
		return doorCloseTime;
	}

}
