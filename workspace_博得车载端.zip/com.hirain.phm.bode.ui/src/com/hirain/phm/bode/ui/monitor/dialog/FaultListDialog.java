package com.hirain.phm.bode.ui.monitor.dialog;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.monitor.provider.TableViewerContentProvider;
import com.hirain.phm.bode.ui.monitor.provider.TableViewerLabelProvider;
import com.hirain.phm.bode.ui.monitor.utils.ViewUtil;
import com.hirain.phm.bode.ui.util.UIConstants;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年2月14日 下午1:39:59
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年2月14日 changwei.zheng@hirain.com 1.0 create file
 */
public class FaultListDialog extends Dialog {

	List<String> faultList;

	public FaultListDialog(Shell activeShell, List<String> faultList) {
		super(activeShell);
		this.faultList = faultList;
	}

	@Override
	protected void configureShell(Shell newShell) {
		newShell.setImage(BodeUIPlugin.getImage(UIConstants.DIALOGIMAGEPATH));
		super.configureShell(newShell);
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		TableViewer tableViewer = new TableViewer(parent, SWT.BORDER | SWT.FULL_SELECTION | SWT.V_SCROLL);
		final Table tableDevice = tableViewer.getTable();
		TableLayout layoutDevice = new TableLayout();
		tableDevice.setLayout(layoutDevice);
		tableDevice.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 4, 1));

		ViewUtil.setTableHeight(tableDevice, 1.8f);
		layoutDevice.addColumnData(new ColumnWeightData(1));
		new TableColumn(tableDevice, SWT.None);
		tableViewer.setContentProvider(new TableViewerContentProvider());
		tableViewer.setLabelProvider(new TableViewerLabelProvider());
		List<String> list = new ArrayList<>();
		for (int i = faultList.size(); i > 0; i--) {
			list.add(faultList.get(i - 1));
		}
		tableViewer.setInput(list);
		return parent;
	}

	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
	}

	@Override
	protected Point getInitialSize() {
		return new Point(300, 500);
	}

	@Override
	protected boolean isResizable() {
		return true;
	}
}
