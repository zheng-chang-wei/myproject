/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.login;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.listener.HeartbeatListenerManager;
import com.hirain.phm.bode.ui.listener.IHeartbeatListener;
import com.hirain.phm.bode.ui.util.UIConstants;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 21, 2019 1:56:34 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 21, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class AbstractDialog extends Dialog implements IHeartbeatListener {

	protected Label messageLab;

	public AbstractDialog(Shell parentShell) {
		super(parentShell);
	}

	protected void addHeartbeatListener() {
		HeartbeatListenerManager.getInstance().addListener(this);
	}

	@Override
	public boolean close() {
		HeartbeatListenerManager.getInstance().removeListener(this);
		return super.close();
	}

	@Override
	public void updateEnable(boolean enable) {
	}

	@Override
	protected void configureShell(Shell newShell) {
		newShell.setText("PHM-Bode Client");
		newShell.setImage(BodeUIPlugin.getImage(UIConstants.DIALOGIMAGEPATH));
		super.configureShell(newShell);
	}
}
