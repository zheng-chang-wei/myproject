package com.hirain.phm.bode.server.db;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.hirain.phm.bode.server.fault.FaultDetail;
import com.hirain.phm.bode.server.fault.FaultRecord;
import com.hirain.phm.bode.server.fault.dao.FaultMapper;
import com.hirain.phm.bode.server.message.DoorMessage;

public class FaultTest extends DBTestCase {

	@Test
	public void testRecord() {
		final FaultRecord record = new FaultRecord();
		record.setCarriageId(1);
		record.setDoorId(1);
		record.setTimestamp(new Date());
		record.setStartTime(new Date());
		record.setEndTime(new Date());
		record.setDebug(false);
		record.setFaultId(1);
		final FaultMapper mapper = session.getMapper(FaultMapper.class);
		mapper.insert(record);
		System.err.println(record.getId());
		session.commit();

		session.commit();
	}

	@Test
	public void testMessage() {
		final List<DoorMessage> messages = new ArrayList<>();
		{
			final DoorMessage message = new DoorMessage();
			// message.setCarriageId(1);
			message.setDoorId(1);
			message.setTimestamp(new Date());
			message.setDatas(getDatas());
			messages.add(message);
		}
		{
			final DoorMessage message = new DoorMessage();
			// message.setCarriageId(1);
			message.setDoorId(1);
			message.setTimestamp(new Date());
			message.setDatas(getDatas());
			messages.add(message);
		}
		final FaultMapper mapper = session.getMapper(FaultMapper.class);

		mapper.insertMessage(messages, 1);
		session.commit();
	}

	@Test
	public void testQuery() {
		final FaultRecord record = new FaultRecord();
		record.setCarriageId(2);
		record.setDoorId(1);
		record.setStartTime(new Date());
		final Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, 2019);
		calendar.set(Calendar.MONTH, Calendar.FEBRUARY);
		calendar.set(Calendar.DAY_OF_MONTH, 10);
		record.setEndTime(calendar.getTime());
		final FaultMapper mapper = session.getMapper(FaultMapper.class);
		final List<DoorMessage> messages = mapper.findMessage(record, 0, 100);
		System.err.println(messages.size());
		final List<DoorMessage> messages1 = mapper.findMessage(record, 100, 100);
		System.err.println(messages1.size());
	}

	/**
	 * @author zepei.tao
	 */
	@Test
	public void testFindFaultRecord() {
		final FaultRecord record = new FaultRecord();
		record.setCarriageId(1);
		record.setDoorId(1);
		record.setStartTime(new Date(1551873950387L));
		record.setEndTime(new Date(1551874070387L));

		final FaultMapper mapper = session.getMapper(FaultMapper.class);
		System.err.println(mapper.findFaultRecord(record).size());
		session.commit();
	}

	@Test
	public void testListFault() {
		final FaultMapper mapper = session.getMapper(FaultMapper.class);
		final List<FaultDetail> details = mapper.list();
		for (final FaultDetail detail : details) {
			System.out.println("id:" + detail.getId() + ";name:" + detail.getName());
		}
	}

	public byte[] getDatas() {
		final byte[] datas = new byte[32];
		for (int i = 0; i < 32; i++) {
			datas[i] = (byte) i;
		}
		return datas;
	}
}
