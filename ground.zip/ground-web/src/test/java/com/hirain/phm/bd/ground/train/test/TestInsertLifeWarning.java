/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.ground.train.test;

import java.util.Date;
import java.util.List;
import java.util.Random;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hirain.phm.bd.ground.GroundWebApplication;
import com.hirain.phm.bd.ground.life.dao.LifeItemMapper;
import com.hirain.phm.bd.ground.life.dao.LifeTrainInfoMapper;
import com.hirain.phm.bd.ground.life.dao.LifeWarningMapper;
import com.hirain.phm.bd.ground.life.domain.LifeItem;
import com.hirain.phm.bd.ground.life.domain.LifeProjectInfo;
import com.hirain.phm.bd.ground.life.domain.LifeTrainInfo;
import com.hirain.phm.bd.ground.life.domain.LifeWarning;
import com.hirain.phm.bd.ground.life.param.TodayLifeWarning;
import com.hirain.phm.bd.ground.train.dao.ProjectMapper;
import com.hirain.phm.bd.ground.train.domain.Project;
import com.hirain.phm.bd.ground.train.domain.Train;
import com.hirain.phm.bd.ground.train.service.TrainService;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2020年1月7日 上午9:50:46
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2020年1月7日 changwei.zheng@hirain.com 1.0 create file
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = GroundWebApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TestInsertLifeWarning {


	@Autowired
	LifeItemMapper lifeItemMapper;

	@Autowired
	LifeTrainInfoMapper lifeTrainInfoMapper;

	@Autowired
	LifeWarningMapper lifeWarningMapper;

	@Autowired
	TrainService trainService;


	@Autowired
	ProjectMapper projectMapper;

	String[] items = { "到位开关", "紧急解锁开关", "隔离开关", "锁闭开关", "控制器", "电机", "导轨" };

	Integer[] totalLifes = { 500 * 10000, 500 * 10000, 500 * 10000, 500 * 10000, 6 * 10000, 3000, 160 };

	@Test
	public void Test() {
		List<TodayLifeWarning> warningToday = lifeWarningMapper.listLifeWarningToday("上海地铁01号线", "01");
		for (TodayLifeWarning todayLifeWarning : warningToday) {
			System.out.println(todayLifeWarning);
		}
	}

	@Test
	public void insertTest() {
		int i = 0;
		for (String itemName : items) {
			Integer lifeItemId = insert_LifeItem(itemName);
			insert_LifeProjectInfo(lifeItemId);
			insert_LifeTrainInfo(i, lifeItemId);
			insert_LifeWarning(lifeItemId);
			i++;
		}
	}

	@Test
	public void updateWarningDate() {
		List<LifeWarning> all = lifeWarningMapper.selectAll();
		for (LifeWarning lifeWarning : all) {
			lifeWarning.setWarningTime(new Date());
			lifeWarningMapper.updateByPrimaryKeySelective(lifeWarning);
		}
	}


	private void insert_LifeWarning(Integer lifeItemId) {
		List<Train> trains = trainService.selectAll();
		for (Train train : trains) {
			LifeWarning lifeWarning = new LifeWarning();
			lifeWarning.setCarNo(1);
			lifeWarning.setDoorAddr(1);
			lifeWarning.setLifeitemId(lifeItemId);
			lifeWarning.setRemainderLife(new Random().nextDouble());
			lifeWarning.setTrainId(train.getId());
			lifeWarning.setWarningTime(new Date());
			lifeWarningMapper.insert(lifeWarning);
		}
	}

	private Integer insert_LifeItem(String itemName) {
		LifeItem lifeItem = new LifeItem();
		lifeItem.setItemName(itemName);
		lifeItemMapper.insertUseGeneratedKeys(lifeItem);
		Integer lifeItemId = lifeItem.getId();
		return lifeItemId;
	}

	private void insert_LifeTrainInfo(int i, Integer lifeItemId) {
		List<Train> trains = trainService.selectAll();
		for (Train train : trains) {
			LifeTrainInfo lifeTrainInfo = new LifeTrainInfo();
			lifeTrainInfo.setLifeitemId(lifeItemId);
			lifeTrainInfo.setReferenceValue(totalLifes[i]);
			lifeTrainInfo.setTrainId(train.getId());
			lifeTrainInfoMapper.insert(lifeTrainInfo);
		}
	}

	private void insert_LifeProjectInfo(Integer lifeItemId) {
		List<Project> projects = projectMapper.selectAll();
		for (Project project : projects) {
			LifeProjectInfo lifeProjectInfo = new LifeProjectInfo();
			lifeProjectInfo.setProjectId(project.getId());
			lifeProjectInfo.setLifeitemId(lifeItemId);
		}
	}

}
