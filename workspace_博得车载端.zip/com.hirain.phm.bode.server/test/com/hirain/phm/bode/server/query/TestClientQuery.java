package com.hirain.phm.bode.server.query;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;

import org.junit.Test;

import com.hirain.phm.bode.server.TestConstant;
import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ServerClientMock;

public class TestClientQuery {

	private static InetSocketAddress address = new InetSocketAddress(TestConstant.LOCALHOST, 17257);

	public static void setUp() {
		final ServerClientMock mock = new ServerClientMock();
		mock.start();
	}

	@Test
	public void testQueryRecord() throws IOException {
		setUp();
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			TestConstant.login1(client);
			final byte[] bs = getSendData();
			send(client, bs, address);
			System.out.println("send");

			final DatagramPacket receive = new DatagramPacket(new byte[1024], 1024);
			client.receive(receive);
			process(receive);
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	@Test
	public void testQueryFault() throws IOException {
		setUp();
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			TestConstant.login1(client);
			send(client, getFdata(), address);
			System.out.println("send");

			final DatagramPacket receive = new DatagramPacket(new byte[1024], 1024);
			client.receive(receive);
			processf(receive);
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	@Test
	public void testQueryFaultRecord() throws IOException {
		setUp();
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			TestConstant.login1(client);
			send(client, getFRdata(), address);
			System.out.println("send");

			final DatagramPacket receive = new DatagramPacket(new byte[1024], 1024);
			client.receive(receive);
			processfr(receive);
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	@Test
	public void testQueryLogRecord() throws IOException {
		setUp();
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			TestConstant.login1(client);
			final String sql = "select * from t_log";
			final byte[] bs = sql.getBytes();
			final ByteBuffer buffer = ByteBuffer.allocate(bs.length + 1 + 3);
			buffer.put((byte) 0x09);
			buffer.putShort((short) (bs.length + 1));
			buffer.put(ClientConstants.LOG_TAG);
			buffer.put(bs);
			send(client, buffer.array(), address);
			final DatagramPacket receive = new DatagramPacket(new byte[1024], 1024);
			client.receive(receive);
			final byte[] data = receive.getData();
			final ByteBuffer bf = ByteBuffer.wrap(data);
			assertEquals(0x19, bf.get());
			Short.toUnsignedInt(bf.getShort());
			assertEquals(ClientConstants.LOG_TAG, bf.get());
			final int num = Byte.toUnsignedInt(bf.get());
			for (int i = 0; i < num; i++) {
				final int year = bf.get() + 2000;
				final int month = bf.get();
				final int day = bf.get();
				System.out.println(year + "-" + month + "-" + day);
			}
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	private void process(DatagramPacket receive) {
		final ByteBuffer bf = ByteBuffer.wrap(receive.getData());
		assertEquals(0x19, bf.get());
		final int length = Short.toUnsignedInt(bf.getShort());
		System.out.println(length);
		assertEquals(ClientConstants.COMMON_TAG, bf.get());
		final byte num = bf.get();
		assertEquals(num * 13 + 2, length);
		for (int i = 0; i < num; i++) {
			final byte[] data = new byte[13];
			bf.get(data);
			for (int j = 0; j < data.length; j++) {
				System.out.print(data[j] + " ");
			}
			System.out.println();
		}
	}

	private byte[] getSendData() {
		final String sql = "select start_time,end_time,debug from t_carriage2_record where door_id=1";
		final byte[] bs = sql.getBytes();
		final ByteBuffer buffer = ByteBuffer.allocate(bs.length + 1 + 3);
		buffer.put((byte) ClientConstants.DATA_QUERY_ID);
		buffer.putShort((short) (bs.length + 1));
		buffer.put(ClientConstants.COMMON_TAG);
		buffer.put(bs);
		return buffer.array();
	}

	private void processfr(DatagramPacket receive) {
		final ByteBuffer bf = ByteBuffer.wrap(receive.getData());
		assertEquals(0x19, bf.get());
		final int length = Short.toUnsignedInt(bf.getShort());
		System.out.println(length);
		assertEquals(ClientConstants.FAULT_TAG, bf.get());
		final byte num = bf.get();
		assertEquals(num * 20 + 2, length);
		for (int i = 0; i < num; i++) {
			final byte[] data = new byte[20];
			bf.get(data);
			for (int j = 0; j < data.length; j++) {
				System.out.print(data[j] + " ");
			}
			System.out.println();
		}
	}

	private byte[] getFRdata() {
		final String sql = "select fault_id,timestamp,start_time,end_time,debug from t_fault_record where carriage_id=2 and door_id=1";
		final byte[] bs = sql.getBytes();
		final ByteBuffer buffer = ByteBuffer.allocate(bs.length + 1 + 3);
		buffer.put((byte) ClientConstants.DATA_QUERY_ID);
		buffer.putShort((short) (bs.length + 1));
		buffer.put(ClientConstants.FAULT_TAG);
		buffer.put(bs);
		final byte[] array = buffer.array();
		return array;
	}

	private void processf(DatagramPacket receive) {
		final ByteBuffer bf = ByteBuffer.wrap(receive.getData());
		assertEquals(0x19, bf.get());
		final int length = Short.toUnsignedInt(bf.getShort());
		System.out.println(length);
		assertEquals(ClientConstants.FAULT_LIST, bf.get());
		final byte num = bf.get();
		for (int i = 0; i < num; i++) {
			final byte code = bf.get();
			final int l = bf.get() & 0xff;
			final byte[] b = new byte[l];
			bf.get(b);
			String fname;
			fname = new String(b);
			System.out.println(code + ":" + fname);
		}
	}

	private byte[] getFdata() {
		final String sql = "select * from t_fault";
		final byte[] bs = sql.getBytes();
		final ByteBuffer buffer = ByteBuffer.allocate(bs.length + 1 + 3);
		buffer.put((byte) ClientConstants.DATA_QUERY_ID);
		buffer.putShort((short) (bs.length + 1));
		buffer.put(ClientConstants.FAULT_LIST);
		buffer.put(bs);
		final byte[] array = buffer.array();
		return array;
	}

	public void send(DatagramSocket socket, byte[] data, InetSocketAddress address) throws IOException {
		final DatagramPacket send = new DatagramPacket(data, data.length, address);
		socket.send(send);
	}
}
