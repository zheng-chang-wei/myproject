package com.hirain.phm.bode.server.ground;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;

import org.apache.commons.io.FileUtils;

public class SSLFileTest {

	public static void main(String[] args) throws IOException {
		final String string = FileUtils.readFileToString(new File("‪E:\\test\\mqtt\\ca.crt"), Charset.defaultCharset());
		System.out.println(string);
		FileUtils.writeStringToFile(new File("E:\\test\\ca.crt"), string, Charset.defaultCharset());
	}
}
