package com.hirain.phm.bode.ui.monitor.listener;

import java.util.ArrayList;
import java.util.List;

import com.hirain.phm.bode.core.dataframe.DoorStatus;

public class HandlerDoorStateManager {

	private final List<DoorStateListener> listeners = new ArrayList<DoorStateListener>();

	private static HandlerDoorStateManager instance = null;

	private HandlerDoorStateManager() {

	}

	public static HandlerDoorStateManager getInstatnce() {
		if (instance == null) {
			instance = new HandlerDoorStateManager();
		}
		return instance;
	}

	public void add(DoorStateListener listener) {
		listeners.add(listener);
	}

	public void remove(DoorStateListener listener) {
		listeners.remove(listener);
	}

	public void refresh(DoorStatus doorStatus) {
		for (DoorStateListener listener : listeners) {
			listener.refresh(doorStatus);
		}
	}
}
