package com.hirain.phm.bode.server.log;

import java.nio.ByteBuffer;

import com.hirain.phm.bode.core.ITrain;

public class LogEvent {

	public String log;

	public LogType type;

	public LogEvent(String log, LogType type) {
		this.log = log;
		this.type = type;
	}

	@Override
	public String toString() {
		return String.format("[%s] %s", type.desc(), log);
	}

	public static LogEvent ofTrain(ITrain train) {
		final String log = train.getCityName() + " " + train.getLineName() + "号线 " + train.getTrainNo();
		return new LogEvent(log, LogType.CARINFO);
	}

	public static LogEvent ofLogin(String username) {
		return new LogEvent(username, LogType.LOGIN);
	}

	public static LogEvent ofLogout(String username) {
		return new LogEvent(username, LogType.LOGOUT);
	}

	public static LogEvent ofDebug(boolean debug) {
		return new LogEvent(debug ? "开始" : "结束", LogType.DEBUG);
	}

	public static LogEvent ofFault(byte[] message) {
		final ByteBuffer buffer = ByteBuffer.wrap(message);
		final int carriageId = buffer.get();
		final int doorId = buffer.get();
		final int faultId = buffer.getInt();
		final byte[] timeBs = new byte[6];
		buffer.get(timeBs);
		final String time = getTime(timeBs);
		final String log = "车厢号:" + carriageId + " 门地址:" + doorId + " 故障编号:" + faultId + " " + time;
		return new LogEvent(log, LogType.FAULT_DOWNLOAD);
	}

	public static LogEvent ofCommon(byte[] message) {
		final ByteBuffer buffer = ByteBuffer.wrap(message);
		final int carriageId = buffer.get();
		final int doorId = buffer.get();
		final byte[] bs1 = new byte[6];
		buffer.get(bs1);
		final byte[] bs2 = new byte[6];
		buffer.get(bs2);
		final String start = getTime(bs1);
		final String end = getTime(bs2);
		final String log = "车厢号:" + carriageId + " 门地址:" + doorId + " " + start + " -- " + end;
		return new LogEvent(log, LogType.COMMON_DOWNLOAD);
	}

	private static String getTime(byte[] bs) {
		final int year = bs[0] + 2000;
		return year + "-" + bs[1] + "-" + bs[2] + " " + bs[3] + ":" + bs[4] + ":" + bs[5];
	}

}
