<template>
  <div id="sheet-count">
    <el-row class="bar-panel home-card">
      <div class="card-border card-border-top-left" />
      <div class="card-border card-border-top-right" />
      <div class="card-border card-border-bottom-left" />
      <div class="card-border card-border-bottom-right" />
      <el-col :span="24">
        <div class="card-panel">
          <div class="card-title">工单指标</div>
          <ve-histogram
            :data="sheetCount"
            :tooltip-visible="false"
            :legend-visible="false"
            :settings="settings"
            :extend="extend"
            height="420px"
            :colors="colors"
          />
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import VeHistogram from 'v-charts/lib/histogram.common'
export default {
  components: {
    VeHistogram
  },
  props: {
    sheetCount: {
      type: Object,
      default: null
    }
  },
  data() {
    this.colors = [
      '#FD5DA7', '#009999', '#F7F494', '#6666FF'
    ]
    this.settings = {
      labelMap: {
        newSheet: '今日新增',
        handled: '今日处理',
        unhandled: '今日剩余',
        unhandledBeforeMonth: '30天未处理'
      },
      stack: {
        'count': ['newSheet', 'handled', 'unhandled', 'unhandledBeforeMonth']
      }
    }
    this.extend = {
      xAxis: {
        type: 'category',
        axisLine: {
          lineStyle: {
            color: 'white'
          }
        },
        axisLabel: {
          interval: 0,
          textStyle: {
            color: 'white'
          }
        }
      },
      yAxis: {
        type: 'value',
        axisLine: {
          lineStyle: {
            color: 'white'
          }
        },
        splitLine: {
          show: false
        },
        axisLabel: {
          show: false
        }
      },
      series: {
        barWidth: 30,
        itemStyle: {
          normal: {
            label: {
              show: true,
              position: 'top'
            }
          }
        }
      }
    }
    return {}
  }
}

</script>
<style lang="scss" scoped>
  #sheet-count {
    margin: 2px;
    background-color: #0f1741;
    height: 460px;
  }

  .bar-panel {
    height: 100%;

    .card-panel {
      height: 100%;
      position: relative;
      overflow: hidden;
      border-top: 3px solid rgb(253, 93, 167);
    }

    .card-title {
      color: #fff;
      text-align: right;
      width: 100%;
      font-weight: bold;
    }
  }

</style>
