package com.hirain.phm.bode.server.store;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.DebugEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.bus.MessageListEvent;
import com.hirain.phm.bode.server.message.DoorMessage;
import com.hirain.phm.bode.server.message.IPreProcessor;

public class StoreService {

	static Logger logger = Logger.getLogger(StoreService.class);

	private final Map<Integer, MessageStorager> storeMap = new HashMap<Integer, MessageStorager>();

	private final IPreProcessor processor;

	private final ExecutorService executor = Executors.newSingleThreadExecutor();

	public StoreService(IPreProcessor processor) {
		this.processor = processor;
	}

	public void init() {
		InnerEventBus.getInstance().register(this);
		processor.register(this);
	}

	@Subscribe
	public void on(DebugEvent event) {
		final boolean debug = event.isDebug();
		for (final MessageStorager storager : storeMap.values()) {
			storager.setDebug(debug);
		}
	}

	@Subscribe
	public void on(ConfigEvent event) {
		executor.submit(() -> {
			processor.unregister(this);
			final ITrain train = event.getTrain();
			final List<ICar> cars = train.getCars();
			final Set<Integer> idSet = new HashSet<>();
			for (final ICar car : cars) {
				if (car.getType() == 0) {
					continue;
				}
				final int carriageId = car.getIndex();
				MessageStorager storager = storeMap.get(carriageId);
				if (storager == null) {
					storager = new MessageStorager(carriageId, car.getDoors());
					storager.work();
					storeMap.put(carriageId, storager);
				}
				idSet.add(carriageId);
			}
			processor.register(this);
			for (final Integer key : storeMap.keySet()) {
				if (!idSet.contains(key)) {
					MessageStorager storager = storeMap.get(key);
					storager.stop();
					storager = null;
					storeMap.remove(key);
				}
			}
		});
	}

	@Subscribe
	public void on(MessageListEvent event) {
		final List<DoorMessage> messages = event.getMessages();
		final Integer carriageId = messages.get(0).getCarriageId();
		final MessageStorager storager = storeMap.get(carriageId);
		if (storager != null) {
			storager.push(messages);
		}
	}
}
