package com.hirain.phm.bode.server.fault.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hirain.phm.bode.server.fault.FaultDetail;
import com.hirain.phm.bode.server.fault.FaultRecord;
import com.hirain.phm.bode.server.message.DoorMessage;

public interface FaultMapper {

	int insert(FaultRecord record);

	int insertMessage(@Param("list") List<DoorMessage> messages, @Param("carriageId") int carriageId);

	List<DoorMessage> findMessage(@Param("record") FaultRecord record, @Param("offset") int offset, @Param("length") int length);

	/**
	 * 查询对端服务器离线期间对应的故障记录数据
	 * 
	 * @author zepei.tao
	 */
	List<FaultRecord> findFaultRecord(@Param("record") FaultRecord record);

	List<FaultDetail> list();
}
