package com.hirain.phm.bode.server.server;

import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.config.ConfigurationService;

public class ServerServerMock {

	ServerService server;

	public void start() {
		server = new ServerService();
		server.init();

		final ITrain train = ConfigurationService.getInstance().getTrain();
		InnerEventBus.getInstance().post(new ConfigEvent(train, null));
	}

	public static void main(String[] args) {
		new ServerServerMock().start();
	}
}
