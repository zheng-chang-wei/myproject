package com.hirain.phm.bode.ui.monitor.figure.carriage;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.MouseEvent;
import org.eclipse.draw2d.MouseListener;
import org.eclipse.draw2d.MouseMotionListener;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.dataframe.DoorStatus;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.monitor.listener.DoorStateListener;
import com.hirain.phm.bode.ui.monitor.listener.HandlerDoorCheckedManager;
import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;
import com.hirain.phm.bode.ui.monitor.utils.Util;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月11日 下午1:45:30
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月11日 changwei.zheng@hirain.com 1.0 create file
 */
public class CommonCarriageFigure extends Figure implements DoorStateListener {

	protected Map<String, DoorFigure> doorFigureMap = new HashMap<>();

	protected Map<String, DoorStatus> doorStateMap = new HashMap<>();

	protected ICar car;

	protected Label label;

	/**
	 * 是否是系统配置界面的车厢
	 */
	protected final boolean isConfig;

	public CommonCarriageFigure(ICar car, boolean isConfig) {
		this.car = car;
		this.isConfig = isConfig;
		setLayoutManager(new XYLayout());
		label = new Label();
		label.setText(car.getName());
		label.setFont(CarriageConstants.font);
	}

	@Override
	protected void paintFigure(Graphics graphics) {
		if (isConfig) {
			setBackgroundColor(CarriageConstants.color_gray);
		} else {
			setBackgroundColor(ColorConstants.white);
		}
	}

	protected void addListener() {
		for (Map.Entry<String, DoorFigure> entry : doorFigureMap.entrySet()) {
			DoorFigure doorFigure = entry.getValue();
			doorFigure.addMouseListener(new MouseListener() {

				@Override
				public void mousePressed(MouseEvent me) {
					if (car.getType() != 0) {
						HandlerDoorCheckedManager.getInstatnce().doorChecked(car, Integer.valueOf(doorFigure.getName()) - 1);
					}
				}

				@Override
				public void mouseReleased(MouseEvent me) {

				}

				@Override
				public void mouseDoubleClicked(MouseEvent me) {

				}
			});
			doorFigure.addMouseMotionListener(new MouseMotionListener() {

				@Override
				public void mouseDragged(MouseEvent me) {
				}

				@Override
				public void mouseEntered(MouseEvent me) {
					if (!isConfig) {
						doorFigure.removeAll();
						doorFigure.addRectangleFigure();
					}
					if (car.getType() != 0) {
						doorFigure.setBackgroundColor(ColorConstants.gray);
						Display display = Display.getDefault();
						if (display != null) {
							Shell activeShell = display.getActiveShell();
							if (activeShell != null) {
								activeShell.setCursor(display.getSystemCursor(SWT.CURSOR_HAND));
							}
						}
					}
				}

				@Override
				public void mouseExited(MouseEvent me) {
					if (isConfig) {
						doorFigure.setBackgroundColor(ColorConstants.white);
					} else {
						refreshDoor(doorFigure, doorStateMap.get(car.getIndex() + StringUtil.UNDER_LINE + doorFigure.getName()));
					}
					if (car.getType() != 0) {
						Display display = Display.getDefault();
						if (display != null) {
							Shell activeShell = display.getActiveShell();
							if (activeShell != null) {
								activeShell.setCursor(null);
							}
						}
					}
				}

				@Override
				public void mouseHover(MouseEvent me) {
				}

				@Override
				public void mouseMoved(MouseEvent me) {
				}
			});
		}

	}

	@Override
	public void refresh(DoorStatus doorStatus) {
		int index = Util.getDoorIndexByAddr(car, doorStatus.getDoorAddr());
		String key = doorStatus.getCarNo() + StringUtil.UNDER_LINE + (index + 1);
		doorStateMap.put(key, doorStatus);
		refreshDoor(doorFigureMap.get(key), doorStatus);
	}

	private void refreshDoor(DoorFigure doorFigure, DoorStatus doorStatus) {
		if (doorFigure != null) {
			doorFigure.refresh(doorStatus);
		}
	}

	@Override
	public void addMouseListener(MouseListener listener) {
		super.addMouseListener(new MouseListener() {

			@Override
			public void mouseDoubleClicked(MouseEvent arg0) {

			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				if (isConfig) {
					HandlerDoorCheckedManager.getInstatnce().carChecked(car);
					label.setText(car.getName());

				}
			}

			@Override
			public void mouseReleased(MouseEvent arg0) {

			}
		});

	}

	public int getCarriageWidth() {

		return 0;
	}

	public void setLabelText(String carName) {
		label.setText(carName);
	}

	public Map<String, DoorFigure> getDoorMap() {
		return doorFigureMap;
	}
}
