package com.hirain.phm.bode.server.client;

import com.hirain.phm.bode.server.comm.ITransportPacket;

import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.socket.DatagramPacket;

class ClientHeartHandler extends ChannelInboundHandlerAdapter {

	private static byte[] hearts = new byte[] { (byte) 0xBB, 0, 1, 0 };

	private final IHeartPost poster;

	public ClientHeartHandler(IHeartPost poster) {
		this.poster = poster;
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		if (msg instanceof ITransportPacket) {
			final ITransportPacket packet = (ITransportPacket) msg;
			final int pid = packet.getPid() & 0xff;
			if (pid == 0xAA) {
				poster.heart(packet.getAddress().getAddress().getHostAddress());
				final DatagramPacket p = new DatagramPacket(Unpooled.copiedBuffer(hearts), packet.getAddress());
				ctx.writeAndFlush(p);
			}
		}
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		ClientService.logger.error(cause.getMessage(), cause);
	}
}
