package com.hirain.phm.bode.ui;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * The activator class controls the plug-in life cycle
 */
public class BodeUIPlugin extends AbstractUIPlugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "com.hirain.phm.bode.ui"; //$NON-NLS-1$

	// The shared instance
	private static BodeUIPlugin plugin;

	/**
	 * The constructor
	 */
	public BodeUIPlugin() {
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext)
	 */
	@Override
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext)
	 */
	@Override
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static BodeUIPlugin getDefault() {
		return plugin;
	}

	public static void log(String message) {
		plugin.getLog().log(new Status(IStatus.ERROR, PLUGIN_ID, message));
	}

	public static void log(Throwable e) {
		plugin.getLog().log(new Status(IStatus.ERROR, PLUGIN_ID, e.getMessage(), e));
	}

	public static ImageDescriptor getImageDescriptor(final String iconPath) {
		final ImageRegistry registry = plugin.getImageRegistry();
		ImageDescriptor descriptor = registry.getDescriptor(iconPath);
		if (descriptor == null) {
			descriptor = imageDescriptorFromPlugin(PLUGIN_ID, iconPath);
		}
		return descriptor;
	}

	/**
	 * @param iconPath
	 *            图片相对于本插件的路径
	 * @return the image, or <code>null</code> if none
	 */
	public static Image getImage(final String iconPath) {
		final ImageRegistry registry = plugin.getImageRegistry();
		Image image = registry.get(iconPath);
		if (image == null) {
			final ImageDescriptor descriptor = getImageDescriptor(iconPath);
			if (descriptor != null) {
				image = descriptor.createImage();
				if (image != null) {
					registry.put(iconPath, image);
				}
			}

		}
		return image;
	}
}
