/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.datamanager;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.ByteBuffer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.draw2d.ColorConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.nebula.widgets.cdatetime.CDT;
import org.eclipse.nebula.widgets.cdatetime.CDateTime;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.ResourceManager;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.client.communication.message.DataResultMessage;
import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.message.MessageQuery;
import com.hirain.phm.bode.core.message.MessageRecord;
import com.hirain.phm.bode.core.util.FileUtil;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.datamanager.provider.TableViewerLabelProvider;
import com.hirain.phm.bode.ui.datamanager.service.impl.MessageRecordServiceImpl;
import com.hirain.phm.bode.ui.datamanager.service.impl.MessageServiceImpl;
import com.hirain.phm.bode.ui.datamanager.util.DataDecodeUtil;
import com.hirain.phm.bode.ui.listener.IRefreshCarNumAndDoorAddressListener;
import com.hirain.phm.bode.ui.listener.RefreshCarNumAndDoorAddressListenerManager;
import com.hirain.phm.bode.ui.monitor.TrainManager;
import com.hirain.phm.bode.ui.monitor.provider.TableViewerContentProvider;
import com.hirain.phm.bode.ui.monitor.utils.Util;
import com.hirain.phm.bode.ui.util.PlotUtil;
import com.hirain.phm.bode.ui.widget.CommonPart;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 7, 2019 10:54:02 AM
 * @Description
 *              <p>
 *              数据管理界面
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 7, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DataManagerPart extends CommonPart implements IRefreshCarNumAndDoorAddressListener {

	private static DataManagerPart dataManagerPart;

	private Composite dataTableComposite;

	private CDateTime startDateTime;

	private CDateTime endDateTime;

	private Combo carriageCombo;

	private Combo doorAddressCombo;

	private Combo isDebugCombo;

	private Button btnConfirmSearch;

	private Composite dataCurveComposite;

	private TableViewer dataTable;

	private Button btnFirstPage;

	private Button btnLastPage;

	private Button btnPreviousPage;

	private Button btnNextPage;

	private Text currentPage;

	private Button btnDownloadSelected;

	private Integer totalPageNum = 0;

	private Integer currentPageNum = 1;

	private Integer inputPageNum = 1;

	private Integer RecordNumPerPage = 10;

	private List<String[]> doorList;

	private List<TableItem> tableItems = new ArrayList<>();

	MessageQuery messageQuery;

	// TODO：是否要把标签改到服务端
	private boolean dataDownload = false;

	private volatile int downloadCount = 0;

	private PlotUtil plotUtil;

	private String filePath;

	private BlockingQueue<DataResultMessage> queue = new LinkedBlockingDeque<>();

	private DataManagerPart() {
		CommunicationService.getInstance().getEventBus().register(this);
		RefreshCarNumAndDoorAddressListenerManager.getInstatnce().add(this);
	}

	public static DataManagerPart getInstance() {
		if (dataManagerPart == null) {
			dataManagerPart = new DataManagerPart();
		}
		return dataManagerPart;
	}

	@Override
	public void postConstruct(final Composite parent) {
		super.postConstruct(parent);
		scrolledComposite.setMinSize(1000, 1650);

		dataTableComposite = new Composite(coreComposite, SWT.NONE);
		dataTableComposite.setLayout(new GridLayout(1, false));
		dataTableComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		dataCurveComposite = new Composite(coreComposite, SWT.NONE);
		dataCurveComposite.setLayout(new GridLayout(2, false));
		dataCurveComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		createFilterView(dataTableComposite);
		createTableView(dataTableComposite);
		plotUtil = new PlotUtil();
		plotUtil.createPlotArea(dataCurveComposite);

		addListeners();

		initFilters();

		searchDataRecords();
		updatePageInfo();
		decodeMessage();
	}

	private void createFilterView(final Composite parent) {
		Composite selectionFilterComposite = new Composite(parent, SWT.BORDER);
		selectionFilterComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		selectionFilterComposite.setLayout(new GridLayout(3, false));
		linkToScroll(selectionFilterComposite);

		Composite dateComposite = new Composite(selectionFilterComposite, SWT.NONE);
		dateComposite.setLayout(new GridLayout(4, false));
		dateComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		linkToScroll(dateComposite);

		Label startDateLabel = new Label(dateComposite, SWT.NONE);
		startDateLabel.setText("起始时间：");
		startDateTime = addCalendarSelector(dateComposite);

		Label endDateLabel = new Label(dateComposite, SWT.NONE);
		endDateLabel.setText("终止时间：");
		endDateTime = addCalendarSelector(dateComposite);

		Composite filterComposite = new Composite(selectionFilterComposite, SWT.NONE);
		filterComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		filterComposite.setLayout(new GridLayout(6, false));
		linkToScroll(filterComposite);

		new Label(filterComposite, SWT.NONE).setText("车厢号：");
		carriageCombo = new Combo(filterComposite, SWT.BORDER | SWT.READ_ONLY);
		carriageCombo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		new Label(filterComposite, SWT.NONE).setText("门地址：");
		doorAddressCombo = new Combo(filterComposite, SWT.BORDER | SWT.READ_ONLY);
		doorAddressCombo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		new Label(filterComposite, SWT.NONE).setText("是否调试：");
		isDebugCombo = new Combo(filterComposite, SWT.BORDER | SWT.READ_ONLY);
		isDebugCombo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		Composite btnComposite = new Composite(selectionFilterComposite, SWT.NONE);
		btnComposite.setLayoutData(new GridData(SWT.NONE, SWT.FILL, false, false));
		btnComposite.setLayout(new GridLayout(1, false));
		linkToScroll(btnComposite);

		btnConfirmSearch = new Button(btnComposite, SWT.NONE);
		btnConfirmSearch.setText("确认搜索");
	}

	private void createTableView(final Composite parent) {
		dataTable = new TableViewer(parent, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL);
		Table table = dataTable.getTable();
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableLayout tableLayout = new TableLayout();
		table.setLayout(tableLayout);
		GridData layoutData = new GridData(SWT.FILL, SWT.FILL, true, false);
		layoutData.heightHint = 220;
		table.setLayoutData(layoutData);

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnStartDateTime = new TableColumn(table, SWT.CENTER);
		tableColumnStartDateTime.setText("数据记录起始时间");

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnEndDateTime = new TableColumn(table, SWT.CENTER);
		tableColumnEndDateTime.setText("数据记录结束时间");

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnCarNum = new TableColumn(table, SWT.CENTER);
		tableColumnCarNum.setText("车厢号");

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnDoorAddress = new TableColumn(table, SWT.CENTER);
		tableColumnDoorAddress.setText("门地址");

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnDebug = new TableColumn(table, SWT.CENTER);
		tableColumnDebug.setText("是否调试");
		dataTable.setFilters(new ViewerFilter[] {});

		dataTable.setContentProvider(new TableViewerContentProvider());
		dataTable.setLabelProvider(new TableViewerLabelProvider());

		Composite tableToolBarComposite = new Composite(parent, SWT.FILL | SWT.NONE);
		tableToolBarComposite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, false));
		tableToolBarComposite.setLayout(new GridLayout(6, false));
		linkToScroll(tableToolBarComposite);

		btnFirstPage = new Button(tableToolBarComposite, SWT.FLAT);
		btnFirstPage.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/u2261.png"));
		btnFirstPage.setToolTipText("第一页");
		btnPreviousPage = new Button(tableToolBarComposite, SWT.FLAT | SWT.ARROW | SWT.LEFT);
		btnPreviousPage.setToolTipText("上一页");
		currentPage = new Text(tableToolBarComposite, SWT.SINGLE | SWT.CENTER | SWT.BORDER);
		btnNextPage = new Button(tableToolBarComposite, SWT.FLAT | SWT.ARROW | SWT.RIGHT);
		btnNextPage.setToolTipText("下一页");
		btnLastPage = new Button(tableToolBarComposite, SWT.FLAT);
		btnLastPage.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/u2263.png"));
		btnLastPage.setToolTipText("最后一页");
		btnDownloadSelected = new Button(tableToolBarComposite, SWT.NONE);
		btnDownloadSelected.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/u2641.png"));
		btnDownloadSelected.setText("下载所选条目");
		btnDownloadSelected.setEnabled(false);
	}

	private CDateTime addCalendarSelector(Composite parent) {
		CDateTime calendar = new CDateTime(parent, CDT.DATE_SHORT | CDT.TIME_SHORT | CDT.DROP_DOWN | CDT.BORDER);
		calendar.setPattern("yyyy-MM-dd HH:mm:ss");
		GridData calendarLayout = new GridData(SWT.FILL, SWT.FILL, true, false);
		calendar.setLayoutData(calendarLayout);
		calendar.setNullText("");
		return calendar;
	}

	private void addListeners() {
		linkToScroll(dataTableComposite);
		linkToScroll(dataCurveComposite);

		carriageCombo.addModifyListener((e) -> {
			int index = carriageCombo.getSelectionIndex();
			if (index != -1) {
				Util.setDoorAddressItems(doorList.get(index), doorAddressCombo);
			}
		});

		btnConfirmSearch.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			messageQuery = getMessageQuery();
			searchDataRecords();
		}));

		btnFirstPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPageNum = 1;
			searchDataRecords();
		}));

		btnLastPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPageNum = totalPageNum;
			searchDataRecords();
		}));

		btnPreviousPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			if (currentPageNum > 1) {
				currentPageNum--;
			} else {
				currentPageNum = 1;
			}
			searchDataRecords();
		}));

		btnNextPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			if (currentPageNum < totalPageNum) {
				currentPageNum++;
			} else {
				currentPageNum = totalPageNum;
			}
			searchDataRecords();
		}));

		currentPage.addMouseListener(MouseListener.mouseUpAdapter(t -> {
			if (currentPage.getSelectionCount() == 0) {
				currentPage.selectAll();
			}
		}));
		currentPage.addKeyListener(KeyListener.keyPressedAdapter(e -> {
			if (e.keyCode == 13 || e.keyCode == 16777296) {
				try {
					inputPageNum = Integer.parseInt(currentPage.getText());
				} catch (Exception inputErr) {
					System.out.println("invalid input!");
					MessageBox message = new MessageBox(currentPage.getShell(), SWT.APPLICATION_MODAL | SWT.YES);
					message.setText("请输入合法的页码！");
					message.setMessage("请输入合法范围内的正整数\n" + "当前可查询页码范围：" + "1~" + totalPageNum);
					message.open();
				} finally {
					if (inputPageNum > 0 && inputPageNum <= totalPageNum) {
						currentPageNum = inputPageNum;
						searchDataRecords();
					} else {
						MessageBox message = new MessageBox(currentPage.getShell(), SWT.APPLICATION_MODAL | SWT.YES);
						message.setText("输入的页码超出范围！");
						message.setMessage("请输入合法范围内的正整数\n" + "当前可查询页码范围：" + "1~" + totalPageNum);
						message.open();
					}
				}
				btnConfirmSearch.setFocus();
			}
		}));
		currentPage.addVerifyListener((e) -> {
			Pattern dataPattern = Pattern.compile("[0-9]*[/]*[0-9]*");
			Matcher matcher = dataPattern.matcher(e.text);
			if (matcher.matches() || e.text.equals("")) {
				e.doit = true;

			} else {
				e.doit = false;
			}
		});
		currentPage.addFocusListener(FocusListener.focusLostAdapter(t -> {
			updatePageInfo();
		}));

		btnDownloadSelected.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			downloadCount = dataTable.getTable().getSelectionCount();
			downloadSelectedData();
		}));

		dataTable.addDoubleClickListener(e -> {
			dataDownload = false;
			downloadCount = 1;
			int i = dataTable.getTable().getSelectionIndex();
			MessageRecord messageRecord = (MessageRecord) dataTable.getTable().getItem(i).getData();
			if (!messageRecord.isValid()) {
				return;
			} else {
				MessageServiceImpl.getInstance().selectMessages(messageRecord);
				addProgressMonitorDialog("正在加载数据。。。");
			}
			for (TableItem item : tableItems) {
				item.setBackground(1, ColorConstants.white);
			}
			plotUtil.clearXYGraphViewer();
		});
	}

	private void initFilters() {
		isDebugCombo.setItems(new String[] { "是", "否", StringUtil.EMPTY });
		refreshCarNumAndDoorAddr();
	}

	private void searchDataRecords() {
		if (messageQuery == null) {
			messageQuery = getMessageQuery();
		}
		// currentPageNum = 1;
		MessageRecordServiceImpl.getInstance().getSelectPageNum(messageQuery);
	}

	private MessageQuery getMessageQuery() {
		MessageQuery messageQuery = new MessageQuery();
		String carriageId = carriageCombo.getText();
		if (StringUtil.isNotEmpty(carriageId)) {
			messageQuery.setCarriageId(Integer.valueOf(carriageId));
		}
		String isDebug = isDebugCombo.getText();
		if (StringUtil.isNotEmpty(isDebug)) {
			messageQuery.setDebug("是".equals(isDebug));
		}
		String doorId = doorAddressCombo.getText();
		if (StringUtil.isNotEmpty(doorId)) {
			messageQuery.setDoorId(Integer.parseInt(doorId));
		}
		String startTime = startDateTime.getText();
		String endTime = endDateTime.getText();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			if (StringUtil.isNotEmpty(startTime)) {
				messageQuery.setStartTime(dateFormat.parse(startTime));
			}
		} catch (ParseException e) {
			e.printStackTrace();
			BodeUIPlugin.log(e);
		}
		if (StringUtil.isNotEmpty(endTime)) {
			try {
				messageQuery.setEndTime(dateFormat.parse(endTime));
			} catch (ParseException e) {
				e.printStackTrace();
				BodeUIPlugin.log(e);
			}
		}
		return messageQuery;
	}

	private void downloadSelectedData() {
		IStructuredSelection selection = (IStructuredSelection) dataTable.getSelection();
		Iterator<?> iterator = selection.iterator();
		if (!iterator.hasNext()) {
			return;
		}
		FileDialog directoryDialog = new FileDialog(Display.getDefault().getActiveShell(), SWT.SAVE);
		directoryDialog.setFilterExtensions(new String[] { "*.txt" });
		filePath = directoryDialog.open();
		if (StringUtil.isEmpty(filePath)) {
			return;
		}
		File file;
		file = new File(filePath);
		while (file.exists()) {
			boolean confirm = MessageDialog.openConfirm(Display.getDefault().getActiveShell(), "文件已存在", filePath + "文件已存在，是否覆盖原文件？");
			if (confirm) {
				file.delete();
			} else {
				directoryDialog.setFileName(null);
				filePath = directoryDialog.open();
				if (StringUtil.isEmpty(filePath)) {
					return;
				}
				file = new File(filePath);
			}
		}
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (!StringUtil.isEmpty(filePath)) {
			addProgressMonitorDialog("正在下载数据。。。");
			dataDownload = true;
			while (iterator.hasNext()) {
				MessageRecord messageRecord = (MessageRecord) iterator.next();
				MessageServiceImpl.getInstance().downloadMessages(messageRecord);
			}
		}
	}

	private void updatePageInfo() {
		if (totalPageNum < 0) {
			totalPageNum = 0;
		}
		if (currentPageNum < 1) {
			currentPageNum = 1;
		} else if (currentPageNum > totalPageNum && totalPageNum > 0) {
			currentPageNum = totalPageNum;
		}

		btnFirstPage.setEnabled(currentPageNum > 1);
		btnPreviousPage.setEnabled(currentPageNum > 1);
		btnLastPage.setEnabled(currentPageNum < totalPageNum);
		btnNextPage.setEnabled(currentPageNum < totalPageNum);

		currentPage.setToolTipText("当前可查询页码范围：1~" + totalPageNum);
		if (totalPageNum > 0) {
			currentPage.setText("" + currentPageNum + "/" + totalPageNum);
		} else {
			currentPage.setText("");
		}
		currentPage.getParent().layout();
	}

	@Subscribe
	void on(DataResultMessage message) {
		queue.add(message);
	}

	private void decodeMessage() {
		new Thread(() -> {
			while (true) {
				try {
					DataResultMessage message = queue.take();
					Display.getDefault().syncExec(() -> {
						byte pid = message.getPid();
						if (pid == ServiceConstant.PID_DATA_COUNT_ACK) {
							if (message.getData() != null) {
								byte[] data = message.getData();
								ByteBuffer buffer = ByteBuffer.wrap(data);
								buffer.get();
								long recordCount = buffer.getLong();
								totalPageNum = (int) Math.ceil((double) recordCount / RecordNumPerPage);
								updatePageInfo();
							}
							MessageRecordServiceImpl.getInstance().selectByPage(messageQuery, currentPageNum, RecordNumPerPage);
						} else if (pid == ServiceConstant.PID_DATA_QUERY_ACK) {
							if (message.getSid() == ServiceConstant.COMMON_TAG) {
								List<MessageRecord> list1 = DataDecodeUtil.getMessageRecord(message);
								if (list1.size() > 0) {
									for (MessageRecord messageRecord : list1) {
										messageRecord.setCarriageId(messageQuery.getCarriageId());
										messageRecord.setDoorId(messageQuery.getDoorId());
									}
									btnDownloadSelected.setEnabled(true);
								} else {
									list1.add(new MessageRecord());
									btnDownloadSelected.setEnabled(false);
								}
								dataTable.setInput(list1);
								updatePageInfo();
							}
						} else if (pid == ServiceConstant.PID_DATA_DOWNLOAD_ACK) { // TODO change constant name
							if (message.getSid() == ServiceConstant.MESSAGE_DOWNLOAD_COMPLETE_SID) {
								System.out.println("数据记录下载完成");
								downloadCount--;
							} else {
								if (dataDownload) {
									// System.out.println(a++);
									List<String> list2 = DataDecodeUtil.getDownloadMessage(message);
									try {
										FileUtil.appendFile(list2, filePath);
									} catch (Exception e) {
										e.printStackTrace();
									}
								} else {
									plotUtil.decodeResultMessage(message.getData());
								}
							}
						}
					});
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}).start();
	}

	private void addProgressMonitorDialog(String message) {
		Display.getDefault().asyncExec(() -> {
			final ProgressMonitorDialog progress = new ProgressMonitorDialog(null);
			final IRunnableWithProgress runnableWithProgress = m -> {
				m.beginTask(message, IProgressMonitor.UNKNOWN);
				int countHis = downloadCount;
				int waitSec = 0;
				while (downloadCount > 0) {
					if (countHis != downloadCount) {
						waitSec = 0;
						countHis = downloadCount;
					} else {
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						waitSec++;
					}
					if (waitSec > 5) {
						m.done();
						return;
					}
				}
				m.done();
				return;
			};
			try {
				progress.run(true, false, runnableWithProgress);
			} catch (InvocationTargetException e1) {
				e1.printStackTrace();
			} catch (InterruptedException e2) {
				e2.printStackTrace();
			}
		});
	}

	@Override
	public void doorChecked(ICar car, int doorIndex) {
		IDoor iDoor = car.getDoors().get(doorIndex);
		carriageCombo.setText(String.valueOf(car.getIndex()));
		doorAddressCombo.setText(String.valueOf(iDoor.getAddr()));
	}

	@Override
	public void refreshCarNumAndDoorAddr() {

		TrainManager instance = TrainManager.getInstance();
		train = instance.getTrain();
		if (train != null) {
			List<ICar> cars = train.getCarriages();
			if (cars != null) {
				int carSize = cars.size();
				String[] carNums = new String[carSize];
				if (doorList == null) {
					doorList = new ArrayList<>();
				} else {
					doorList.clear();
				}
				for (int i = 0; i < carSize; i++) {
					ICar car = cars.get(i);
					carNums[i] = String.valueOf(car.getIndex());
					Util.getDoorItems(car, doorList);
				}
				carriageCombo.setItems(carNums);
				carriageCombo.setText(String.valueOf(carNums[0]));
				Util.setDoorAddressItems(doorList.get(0), doorAddressCombo);
			}
		}
	}

	public void refreshTable() {
		searchDataRecords();
	}

}
