package com.hirain.phm.bode.ui.monitor.figure.door;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Ellipse;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.MarginBorder;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.swt.SWT;

public class DirectionLigthFigure extends Figure implements StatusListener {

	private final ArrowFigure arrowFigure;

	public DirectionLigthFigure(int side) {
		arrowFigure = new ArrowFigure(side);
		setLayoutManager(new XYLayout());
		createFigure(side);
	}

	private void createFigure(int side) {
		Ellipse ellipseOutside = new Ellipse();
		ellipseOutside.setBorder(new MarginBorder(6));
		ellipseOutside.setBounds(new Rectangle(0, 0, 40, 40));
		ellipseOutside.setBackgroundColor(ColorConstants.gray);
		ellipseOutside.setAntialias(SWT.ON);

		Ellipse ellipseInside = new Ellipse();
		ellipseInside.setFill(true);
		ellipseInside.setBounds(new Rectangle(3, 3, 34, 34));
		ellipseInside.setOpaque(true);
		ellipseInside.setAntialias(SWT.ON);

		arrowFigure.setOpaque(true);
		arrowFigure.setBackgroundColor(ColorConstants.gray);
		arrowFigure.setBounds(new Rectangle(5, 5, 30, 30));

		add(ellipseOutside);
		add(ellipseInside);
		add(arrowFigure);
	}

	@Override
	public void update(int operation, int step) {
		if (arrowFigure.getBackgroundColor().equals(ColorConstants.gray)) {
			arrowFigure.setBackgroundColor(ColorConstants.green);
		} else {
			arrowFigure.setBackgroundColor(ColorConstants.gray);
		}
	}

	@Override
	public void reset() {
		arrowFigure.setBackgroundColor(ColorConstants.gray);
	}
}
