package com.hirain.phm.bode.server.comm.impl;

import com.hirain.phm.bode.server.comm.IEncoder;
import com.hirain.phm.bode.server.comm.ITransportPacket;

public class PacketEncoder implements IEncoder {

	@Override
	public ITransportPacket encode(int sid, byte[] data) {
		ITransportPacket packet = new TransportPacketImpl();
		packet.setPid(sid);
		packet.setLength(data.length);
		packet.setData(data);
		return packet;
	}

}
