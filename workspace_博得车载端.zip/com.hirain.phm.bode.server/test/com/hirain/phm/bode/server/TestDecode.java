package com.hirain.phm.bode.server;

import java.util.Calendar;

import org.junit.Test;

public class TestDecode {

	@Test
	public void testAdjustDate() {
		for (int i = 1; i < 32; i++) {
			Calendar calendar = Calendar.getInstance();
			calendar.set(2019, 11, 1, 0, 0, 0);
//			System.out.println(calendar.getTime());
//			calendar.set(Calendar.DAY_OF_MONTH, 1);
			if (adjustDay_old(calendar, i)) {
				System.out.println(i + " : " + calendar.getTime());
			} else {
				System.out.println(i + " adjust failed");
			}
			if (adjustDay(calendar, i)) {
				System.out.println("new" + i + " : " + calendar.getTime());
			} else {
				System.out.println(i + " adjust failed");
			}
		}
	}

	private boolean adjustDay(Calendar calendar, int day) {
		if (calendar.get(Calendar.DAY_OF_MONTH) == day) {
			return true;
		} else {
			int date = calendar.get(Calendar.DAY_OF_MONTH);
			calendar.add(Calendar.DAY_OF_MONTH, -1);
			if (calendar.get(Calendar.DAY_OF_MONTH) == day) {
				return true;
			} else {
				calendar.add(Calendar.DAY_OF_MONTH, 2);
				if (calendar.get(Calendar.DAY_OF_MONTH) == day) {
					return true;
				} else {
					calendar.set(Calendar.DAY_OF_MONTH, date);
					return false;
				}
			}
		}
	}

	private boolean adjustDay_old(Calendar calendar, int day) {
		if (calendar.get(Calendar.DAY_OF_MONTH) == day) {
			return true;
		} else {/* if (calendar.get(Calendar.DAY_OF_MONTH) != day) */
			int date = calendar.get(Calendar.DAY_OF_MONTH);
			calendar.set(Calendar.DAY_OF_MONTH, date - 1);
			if (calendar.get(Calendar.DAY_OF_MONTH) == day) {
				return true;
			} else {
				calendar.set(Calendar.DAY_OF_MONTH, date + 1);
				if (calendar.get(Calendar.DAY_OF_MONTH) == day) {
					return true;
				} else {
					return false;
				}
			}
		}
	}
}
