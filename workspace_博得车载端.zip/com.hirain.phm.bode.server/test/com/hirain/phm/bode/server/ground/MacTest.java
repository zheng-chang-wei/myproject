package com.hirain.phm.bode.server.ground;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;

public class MacTest {

	public static void main(String[] args) throws Exception {
		final InetAddress host = InetAddress.getLocalHost();
		System.out.println(host);
		final byte[] mac = NetworkInterface.getByInetAddress(new InetSocketAddress("10.40.101.236", 0).getAddress()).getHardwareAddress();
		final StringBuffer sb = new StringBuffer();
		for (int i = 0; i < mac.length; i++) {
			if (i != 0) {
				sb.append("-");
			}
			final int temp = mac[i] & 0xff;
			final String s = Integer.toHexString(temp);
			if (s.length() == 1) {
				sb.append("0").append(s);
			} else {
				sb.append(s);
			}
		}
		System.out.println(sb.toString().toUpperCase());
	}
}
