<template>
  <div class="app-container default-dashboard">
    <el-row>
      <el-col :span="4" style="margin-top: 10px">
        <el-row>
          <train-online :train="train" />
        </el-row>
        <el-row>
          <worksheet-count :sheet-count="sheetCount" />
        </el-row>
      </el-col>
      <el-col :span="10" style="margin-top: 10px">
        <el-row>
          <div style="height: 464px">
            <fault-list :fault-list="faultList" :table-height="420" />
          </div>
        </el-row>
        <el-row>
          <div style="height: 208px">
            <annual-fault :annual-fault="annualFault" :chart-height="'180px'" :title="'故障'" />
          </div>
        </el-row>
      </el-col>
      <el-col :span="10" style="margin-top: 10px">
        <el-row>
          <div style="height: 230px">
            <subhealth-list :subhealth-list="subhealthList" :table-height="190" />
          </div>
        </el-row>
        <el-row>
          <life-list :life-list="lifeList" />
        </el-row>
        <el-row>
          <component-list />
        </el-row>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import TrainOnline from './TrainOnline'
import WorksheetCount from './WorksheetCount'

import FaultList from './FaultList'
import AnnualFault from './AnnualFault'

import SubhealthList from './SubhealthList'
import LifeList from './LifeList'
import ComponentList from './ComponentList'

import app from '@/common/js/app'

const thisYear = new Date().getFullYear()
const lastYear = thisYear - 1

export default {
  components: {
    TrainOnline,
    WorksheetCount,
    FaultList,
    AnnualFault,
    SubhealthList,
    LifeList,
    ComponentList
  },
  data() {
    return {
      train: {
        online: 0,
        total: 0,
        onlineDoor: 0
      },
      sheetCount: {
        columns: ['type',
          'newSheet', 'handled', 'unhandled', 'unhandledBeforeMonth'
        ],
        rows: [{
          'type': '今日工单',
          'newSheet': 0
        },
        {
          'type': '今日处理',
          'handled': 0
        },
        {
          'type': '今日剩余',
          'unhandled': 0
        },
        {
          'type': '30天未处理',
          'unhandledBeforeMonth': 0
        }
        ]
      },
      faultList: [],
      subhealthList: [],
      lifeList: [],
      annualFault: {
        columns: ['month', 'thisYear', 'lastYear'],
        rows: [{
          'month': '1',
          'thisYear': 0,
          'lastYear': 0
        },
        {
          'month': '2',
          'thisYear': 0,
          'lastYear': 0
        },
        {
          'month': '3',
          'thisYear': 0,
          'lastYear': 0
        },
        {
          'month': '4',
          'thisYear': 0,
          'lastYear': 0
        },
        {
          'month': '5',
          'thisYear': 0,
          'lastYear': 0
        },
        {
          'month': '6',
          'thisYear': 0,
          'lastYear': 0
        },
        {
          'month': '7',
          'thisYear': 0,
          'lastYear': 0
        },
        {
          'month': '8',
          'thisYear': 0,
          'lastYear': 0
        },
        {
          'month': '9',
          'thisYear': 0,
          'lastYear': 0
        },
        {
          'month': '10',
          'thisYear': 0,
          'lastYear': 0
        },
        {
          'month': '11',
          'thisYear': 0,
          'lastYear': 0
        },
        {
          'month': '12',
          'thisYear': 0,
          'lastYear': 0
        }
        ]
      }
    }
  },
  mounted() {
    this.countRecycle()
    this.countAnnualFault()
  },
  methods: {
    countRecycle() {
      this.countTrains()
      this.countSheets()
      this.countTodayFault()
      this.countTodaySubhealth()
      this.countCurrentMonthFault()
      setTimeout(() => {
        this.countRecycle()
      }, 60 * 10 * 1000)
    },
    countTrains() {
      console.log('count trains')
      const vm = this
      app.get('dashboard_train').then(data => {
        if (data) {
          vm.train = data.msg
        }
      })
    },
    methods: {
      countRecycle() {
        this.countTrains()
        this.countSheets()
        this.countTodayFault()
        this.countTodaySubhealth()
        this.countCurrentMonthFault()
        setTimeout(() => {
          this.countRecycle()
        }, 60 * 10 * 1000)
      },
      countTrains() {
        console.log('count trains')
        const vm = this
        app.get('dashboard_train').then(data => {
          if (data) {
            vm.train = data.msg
          }
        })
      },
      countSheets() {
        console.log('count sheets')
        const vm = this
        app.get('dashboard_sheet').then(data => {
          if (data) {
            const rows = []
            const count = data.data
            rows.push({
              'type': '今日工单',
              'newSheet': count.newSheets
            })
            rows.push({
              'type': '今日处理',
              'handled': count.handled
            })
            rows.push({
              'type': '今日剩余',
              'unhandled': count.unHandled
            })
            rows.push({
              'type': '30天未处理',
              'unhandledBeforeMonth': count.unHandledBeforeMonth
            })
            vm.sheetCount.rows = rows
          }
        })
      },
      countTodayFault() {
        console.log('today fault')
        const vm = this
        vm.faultList = []
        app.get('dashboard_fault_today').then(data => {
          if (data) {
            const list = data.msg
            list.forEach(fault => {
              vm.faultList.push({
                project: fault.project,
                train: fault.trainNo,
                faultContent: '' + fault.carNo + '车' + fault.doorAddr + '门' + fault.faultName,
                faultTime: fault.faultTime,
                suggestion: fault.suggestion,
                treatment: fault.treatment ? fault.treatment.trim() : '无',
                repair: fault.repair ? fault.repair : '无',
                carriage: fault.carNo,
                door: fault.doorAddr,
                faultMode: fault.faultName
              })
            })
          }
        })
      },
      countTodaySubhealth() {
        console.log('today subhealth')
        const vm = this
        vm.subhealthList = []
        app.get('dashboard_subhealth').then(data => {
          if (data) {
            const list = data.msg
            list.forEach(fault => {
              vm.subhealthList.push({
                project: fault.project,
                train: fault.trainNo,
                faultContent: '' + fault.carNo + '车' + fault.doorAddr + '门' + fault.subhealthName,
                faultTime: fault.startTime,
                suggestion: fault.suggestion,
                treatment: fault.treatment ? fault.treatment : '无',
                repair: fault.repair ? fault.repair : '无',
                carriage: fault.carNo,
                door: fault.doorAddr,
                faultMode: fault.subhealthName
              })
            })
          }
        })
      },
      countAnnualFault() {
        const vm = this
        app.get('dashboard_fault_annual', {
          year: lastYear
        }).then(res => {
          if (res) {
            const counts = res.msg
            for (let i = 0; i < 12; i++) {
              vm.annualFault.rows[i].lastYear = counts.counts[i]
            }
          }
        })
        app.get('dashboard_fault_annual', {
          year: thisYear
        }).then(res => {
          if (res) {
            const counts = res.msg
            for (let i = 0; i < 12; i++) {
              vm.annualFault.rows[i].thisYear = counts.counts[i]
            }
          }
        })
      },
      countCurrentMonthFault() {
        const vm = this
        const month = new Date().getMonth() + 1
        app.get('dashboard_fault_month', {
          year: thisYear,
          month: month
        }).then(res => {
          if (res) {
            const count = res.msg
            vm.annualFault.rows[month - 1].thisYear = count
          }
        })
      }
    }
  }
}

</script>

<style scoped>
  .app-container {
    height: 704px;
    padding: 0px;
    background-color: #242640;
  }

</style>

<style lang="scss">
  $border-color:rgb(54, 227, 253);
  #home .card-border {
    position: absolute;
    width: 15px;
    height: 15px;
  }

  #home .home-card {
    border: 1px solid rgb(54, 88, 141);
    box-shadow: rgb(105, 149, 02) 0px 0px 8px inset;
    padding: 10px;
    position: relative;
  }

  #home .card-border-top-left {
    top: -1px;
    left: -1px;
    border-left: 1px solid $border-color;
    border-top: 1px solid $border-color;
    box-shadow: $border-color 2px 2px 2px inset;
  }

  #home .card-border-top-right {
    top: -1px;
    right: -1px;
    border-right: 1px solid $border-color;
    border-top: 1px solid $border-color;
    box-shadow: rgb(11, 234, 235) -2px 2px 2px inset;
  }

  #home .card-border-bottom-left {
    bottom: -1px;
    left: -1px;
    border-bottom: 1px solid $border-color;
    border-left: 1px solid $border-color;
    box-shadow: rgb(11, 234, 235) 2px -2px 2px inset;
  }

  #home .card-border-bottom-right {
    bottom: -1px;
    right: -1px;
    border-right: 1px solid $border-color;
    border-bottom: 1px solid $border-color;
    box-shadow: rgb(11, 234, 235) -2px -2px 2px inset;
  }

  .default-dashboard .el-table--enable-row-hover .el-table__body tr:hover>td {
    background-color: #394761 !important;
  }

  .default-dashboard .el-table,
  .default-dashboard .el-table__expanded-cell {
    background-color: #0f1741 !important;
  }

  .default-dashboard .el-table--border::after,
  .default-dashboard .el-table--group::after,
  .default-dashboard .el-table::before {
    background-color: #0f1741 !important;
  }

</style>
