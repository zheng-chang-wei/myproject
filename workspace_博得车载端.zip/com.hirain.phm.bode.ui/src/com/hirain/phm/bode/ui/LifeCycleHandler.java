/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui;

import org.eclipse.e4.ui.workbench.lifecycle.PostContextCreate;
import org.eclipse.jface.window.Window;

import com.hirain.phm.bode.ui.login.LoginDialog;
import com.hirain.phm.bode.ui.util.SoftwareLock;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 4, 2019 10:32:59 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 4, 2019 zepei.tao@hirain.com 1.0 create file
 */
@SuppressWarnings("restriction")
public class LifeCycleHandler {

	@PostContextCreate
	public void contextCreate() {
		if (!SoftwareLock.checkLock()) {
			System.exit(0);
		}

		LoginDialog dialog = LoginDialog.getInstance();
		if (dialog.open() == Window.OK) {

		} else {
			System.exit(0);
		}

	}

}
