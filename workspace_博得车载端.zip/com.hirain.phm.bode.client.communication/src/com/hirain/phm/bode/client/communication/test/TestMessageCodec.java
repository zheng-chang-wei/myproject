package com.hirain.phm.bode.client.communication.test;

import java.nio.ByteBuffer;
import java.util.List;

import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.client.communication.transport.ITransportPacket;
import com.hirain.phm.bode.client.communication.transport.impl.TransportPacketImpl;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.socket.DatagramPacket;
import io.netty.handler.codec.MessageToMessageCodec;

public class TestMessageCodec extends MessageToMessageCodec<DatagramPacket, ITransportPacket> {

	private static byte[] systemInfoBytes = new byte[] { (byte) 0x00, (byte) 0x62, (byte) 0x6a, (byte) 0x01, (byte) 0x30, (byte) 0x30, (byte) 0x31,
			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x01, (byte) 0x02, (byte) 0x0a, (byte) 0x0a, (byte) 0x0a,
			(byte) 0x0a, (byte) 0x0a, (byte) 0x28, (byte) 0x1e, (byte) 0x84, (byte) 0x0a, (byte) 0x0a, (byte) 0x0a, (byte) 0x0a, (byte) 0x0a,
			(byte) 0x0a, (byte) 0x0a, (byte) 0x0a, (byte) 0x0a, (byte) 0x0a, (byte) 0x0a, (byte) 0x0a, (byte) 0x0a, (byte) 0x0a, (byte) 0x0a,
			(byte) 0x0a, (byte) 0x00, (byte) 0x00, (byte) 0x63, (byte) 0x61, (byte) 0x72, (byte) 0x31, (byte) 0x00, (byte) 0x00, (byte) 0x01,
			(byte) 0x00, (byte) 0x63, (byte) 0x61, (byte) 0x72, (byte) 0x32, (byte) 0x00, (byte) 0x00, (byte) 0x02, (byte) 0x01, (byte) 0x63,
			(byte) 0x61, (byte) 0x72, (byte) 0x33, (byte) 0x0a, (byte) 0x28, (byte) 0x1e, (byte) 0x84, (byte) 0x00, (byte) 0x00, (byte) 0x00,
			(byte) 0x00, (byte) 0x00, (byte) 0x00, };

	@Override
	protected void decode(ChannelHandlerContext ctx, DatagramPacket msg, List<Object> out) throws Exception {
		// System.out.println(msg.getClass());
		ByteBuf buf = msg.content();
		ITransportPacket packet = getPacket(buf);
		packet.setAddress(msg.sender());
		out.add(packet);
	}

	@Override
	protected void encode(ChannelHandlerContext ctx, ITransportPacket packet, List<Object> out) throws Exception {
		ByteBuffer buffer = ByteBuffer.wrap(packet.toByte());
		DatagramPacket datagramPacket = new DatagramPacket(Unpooled.copiedBuffer(buffer.array()), packet.getAddress());
		ctx.writeAndFlush(datagramPacket);
	}

	private ITransportPacket getPacket(ByteBuf buf) {
		ITransportPacket packet = new TransportPacketImpl();
		byte pid = buf.readByte();
		@SuppressWarnings("unused")
		byte length = buf.readByte();
		switch (pid) {
		case ServiceConstant.PID_HEART_INQUIRY:
			packet.setPid(ServiceConstant.PID_HEART_INQUIRY_ACK);
			packet.setLength(4);
			packet.setData(ServiceConstant.EMPTY_DATA);
			break;
		case ServiceConstant.PID_LOGIN:
			packet.setPid(ServiceConstant.PID_LOGIN_ACK);
			packet.setLength(4);
			packet.setData(ServiceConstant.EMPTY_DATA);
			break;
		case ServiceConstant.PID_SYSTEMINFO_INQUIRY:
			packet.setPid(ServiceConstant.PID_SYSTEMINFO_INQUIRY_ACK);
			packet.setLength(72);
			// packet.setData(new byte[] { 0x01, 0x12 });// TODO 这里要造一组假数据 （第一个0x00表示配置信息是否完整）
			packet.setData(systemInfoBytes);
			break;
		case ServiceConstant.PID_SPACE_INQUIRY:
			packet.setPid(ServiceConstant.PID_SPACE_INQUIRY_ACK);
			packet.setLength(20);

			long totalSpace = 223346683904L;
			long usedSpace = 93685805056L;

			byte[] result = new byte[17];
			result[0] = (byte) 0x00;
			System.arraycopy(longToBytes(totalSpace), 0, result, 1, longToBytes(totalSpace).length);
			System.arraycopy(longToBytes(usedSpace), 0, result, 9, longToBytes(usedSpace).length);
			packet.setData(result);
			break;
		case ServiceConstant.PID_SYSTEMINFO_CONFIG:
			packet.setPid(ServiceConstant.PID_SYSTEMINFO_CONFIG_ACK);
			packet.setLength(4);
			packet.setData(ServiceConstant.EMPTY_DATA);
			break;
		case ServiceConstant.PID_DEBUGMODE:
			packet.setPid(ServiceConstant.PID_DEBUGMODE_ACK);
			packet.setLength(4);
			packet.setData(ServiceConstant.EMPTY_DATA);
			break;
		default:
			break;
		}
		return packet;
	}

	private byte[] longToBytes(long x) {
		ByteBuffer buffer = ByteBuffer.allocate(8);
		buffer.putLong(0, x);
		return buffer.array();
	}

}
