package com.hirain.phm.bode.ui.monitor.figure.door;

public class DoorContent {

	public static final int LEFT = 10;

	public static final int RIGHT = 11;

	public static final int STEP = 1;

	public static final int OPEN_OPERATION = 1;

	public static final int CLOSE_OPERATION = -1;
}
