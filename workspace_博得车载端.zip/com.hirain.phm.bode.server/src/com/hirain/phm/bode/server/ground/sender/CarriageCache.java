package com.hirain.phm.bode.server.ground.sender;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hirain.phm.bd.message.CommonMessage;
import com.hirain.phm.bd.message.DoorPacket;
import com.hirain.phm.bode.server.message.DoorMessage;

public class CarriageCache {

	private final Map<Integer, DoorCache> map = new HashMap<>();

	public CarriageCache() {

	}

	public void add(int doorId, CommonMessage message) {
		DoorCache doorCache = map.get(doorId);
		if (doorCache != null) {
			doorCache.add(message);
		} else {
			doorCache = new DoorCache();
			map.put(doorId, doorCache);
			doorCache.add(message);
		}
	}

	public void add(int doorId, List<DoorMessage> messages, boolean debug) {
		DoorCache doorCache = map.get(doorId);
		if (doorCache != null) {
			doorCache.add(messages, debug);
		} else {
			doorCache = new DoorCache();
			map.put(doorId, doorCache);
			doorCache.add(messages, debug);
		}
	}

	public List<DoorPacket> get(int count) {
		final List<DoorPacket> packets = new ArrayList<>();
		for (final Integer key : map.keySet()) {
			final DoorCache cache = map.get(key);
			final List<CommonMessage> list = cache.get(count);
			if (!list.isEmpty()) {
				packets.add(new DoorPacket(key, list));
			}
		}
		return packets;
	}
}
