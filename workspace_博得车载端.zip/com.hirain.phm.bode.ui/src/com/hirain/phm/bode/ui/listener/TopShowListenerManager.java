/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.listener;

import java.util.List;
import java.util.Vector;

import com.hirain.phm.bode.ui.util.ShowModuleEnum;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 10:38:21 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class TopShowListenerManager {

	private final List<ITopShowListener> listeners = new Vector<ITopShowListener>();

	private TopShowListenerManager() {
	}

	public static TopShowListenerManager getInstance() {
		return TopShowListenerManagerClazz.instance;
	}

	private final static class TopShowListenerManagerClazz {

		private final static TopShowListenerManager instance = new TopShowListenerManager();
	}

	public void addListener(final ITopShowListener listener) {
		listeners.add(listener);
	}

	public void removeListener(final ITopShowListener listener) {
		if (listeners.contains(listener)) {
			listeners.remove(listener);
		}
	}

	public void notifyChanged(ShowModuleEnum showModule) {
		for (final ITopShowListener listener : listeners) {
			listener.showTopComposite(showModule);
		}
	}

}
