package com.hirain.phm.bode.ui.datamanager.service.impl;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.core.message.MessageRecord;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.datamanager.service.MessageService;

public class MessageServiceImpl implements MessageService {

	private static MessageServiceImpl singleton = null;

	private MessageServiceImpl() {
	}

	public static MessageServiceImpl getInstance() {
		if (singleton == null) {
			singleton = new MessageServiceImpl();
		}
		return singleton;
	}

	@Override
	public void selectMessages(MessageRecord messageRecord) {
		StringBuilder sql = new StringBuilder("select * from  t_carriage" + messageRecord.getCarriageId() + "_message where true");
		String doorId = messageRecord.getDoorId();
		sql.append(" and door_id=" + doorId);
		String start = messageRecord.getStartTime();
		if (start != null) {
			sql.append(" and timestamp>='" + start + "'");
		}
		String end = messageRecord.getEndTime();
		if (end != null) {
			sql.append(" and timestamp<='" + end + "'");
		}
		System.err.println(sql);
		try {
			// TODO change constant name
			CommunicationService.getInstance().select(ServiceConstant.PID_DATA_DOWNLOAD, ServiceConstant.COMMON_TAG, sql.toString());
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}

	@Override
	public void downloadMessages(MessageRecord messageRecord) {
		StringBuilder sql = new StringBuilder("select * from  t_carriage" + messageRecord.getCarriageId() + "_message where true");
		String doorId = messageRecord.getDoorId();
		sql.append(" and door_id=" + doorId);
		String start = messageRecord.getStartTime();
		if (start != null) {
			sql.append(" and timestamp>='" + start + "'");
		}
		String end = messageRecord.getEndTime();
		if (end != null) {
			sql.append(" and timestamp<='" + end + "'");
		}
		System.err.println(sql);
		try {
			ByteBuffer buffer = ByteBuffer.allocate(sql.toString().getBytes().length + 15).order(ByteOrder.LITTLE_ENDIAN);
			buffer.put(ServiceConstant.MESSAGE_DOWNLOAD_SID);
			buffer.put(Byte.parseByte(messageRecord.getCarriageId()));
			buffer.put(Byte.parseByte(doorId));
			// 起止时间
			String time = messageRecord.getStartTime();
			DateFormat dateFormat = DateFormat.getDateTimeInstance();
			Date date = dateFormat.parse(time);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);

			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.YEAR) - 2000)));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.MONTH) + 1)));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.DATE))));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.HOUR))));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.MINUTE))));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.SECOND))));

			time = messageRecord.getEndTime();
			date = dateFormat.parse(time);
			calendar.setTime(date);

			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.YEAR) - 2000)));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.MONTH) + 1)));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.DATE))));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.HOUR))));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.MINUTE))));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.SECOND))));
			// sql语句
			buffer.put(sql.toString().getBytes());

			CommunicationService.getInstance().download(buffer.array());
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}

}
