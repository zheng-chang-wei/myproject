package com.hirain.phm.bode.server.client;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.List;

import com.hirain.phm.bode.server.comm.ITransportPacket;
import com.hirain.phm.bode.server.comm.impl.TransportPacketImpl;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.socket.DatagramPacket;
import io.netty.handler.codec.MessageToMessageDecoder;

class ClientMessageDecoder extends MessageToMessageDecoder<DatagramPacket> {

	@Override
	protected void decode(ChannelHandlerContext ctx, DatagramPacket msg, List<Object> out) throws Exception {
		if (msg.content().readableBytes() < 3) {
			return;
		}
		final ByteBuf buf = msg.content();
		final int pos = buf.readerIndex();
		// byte length = buf.getByte(pos + 1);
		final int length = buf.getUnsignedShort(pos + 1);
		if (msg.content().readableBytes() < length + 3) {
			return;
		}
		final byte[] bs = new byte[length + 3];
		buf.readBytes(bs);
		final ITransportPacket packet = decode(bs, msg.sender());
		out.add(packet);
	}

	private ITransportPacket decode(byte[] bs, InetSocketAddress address) {
		final ITransportPacket packet = new TransportPacketImpl();
		final ByteBuffer buffer = ByteBuffer.wrap(bs);
		packet.setPid(buffer.get());
		packet.setLength(Short.toUnsignedInt(buffer.getShort()));
		final byte[] data = new byte[packet.getLength()];
		buffer.get(data);
		packet.setData(data);
		packet.setAddress(address);
		return packet;
	}

}
