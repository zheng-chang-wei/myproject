package com.hirain.phm.bode.ui.log.model;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年2月22日 下午3:52:17
 * @Description
 *              <p>
 *              日志查询条件
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年2月22日 changwei.zheng@hirain.com 1.0 create file
 */
public class LogQueryCondition {

	private String startTime;

	private String endTime;

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}
