package com.hirain.phm.bode.server.db;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.hirain.phm.bode.server.message.DoorMessage;
import com.hirain.phm.bode.server.store.MessageRecord;
import com.hirain.phm.bode.server.store.dao.StoreMapper;

public class StoreTest extends DBTestCase {

	@Test
	public void testRecord() {
		final MessageRecord record = new MessageRecord();
		record.setCarriageId(1);
		record.setDoorId(1);
		record.setStartTime(new Date());
		record.setEndTime(new Date());
		final StoreMapper mapper = session.getMapper(StoreMapper.class);
		mapper.insert(record);
		System.err.println(record.getId());
		session.commit();
	}

	@Test
	public void testMessage() {
		final DoorMessage message = new DoorMessage();
		message.setCarriageId(1);
		message.setDoorId(1);
		message.setTimestamp(new Date());
		message.setDatas(getDatas());
		final StoreMapper mapper = session.getMapper(StoreMapper.class);

		final Map<String, Object> map = new HashMap<>();
		map.put("carriageId", 1);
		map.put("list", Arrays.asList(message));
		mapper.insertMessage(map);
		session.commit();
	}

	/**
	 * @author zepei.tao
	 */
	@Test
	public void testFindMessage() {
		final StoreMapper mapper = session.getMapper(StoreMapper.class);

		final MessageRecord record = new MessageRecord();
		record.setCarriageId(1);
		record.setDoorId(1);
		record.setStartTime(new Date(1552010185387L));
		record.setEndTime(new Date(1552010186387L));
		System.out.println("查询结果大小---  " + mapper.findMessage(record).size());
		session.commit();
	}

	public byte[] getDatas() {
		final byte[] datas = new byte[32];
		for (int i = 0; i < 32; i++) {
			datas[i] = (byte) i;
		}
		return datas;
	}

}
