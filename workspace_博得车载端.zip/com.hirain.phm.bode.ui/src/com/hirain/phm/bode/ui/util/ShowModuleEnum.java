/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.util;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 10:46:42 AM
 * @Description
 *              <p>
 *              各个模块展示的枚举类：系统设置、在线监控、故障回放、日志管理、数据管理
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
public enum ShowModuleEnum {
	// 系统设置
	SETTING,
	// 在线监控
	ONLINE_MONITOR,
	// 故障回放
	FAULT,
	// 日志管理
	LOG,
	// 数据管理
	DATA_MANAGER;
}
