package com.hirain.phm.bode.server.server;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.util.SystemInfoUtil;
import com.hirain.phm.bode.server.TestConstant;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.DebugEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.bus.MessageEvent;
import com.hirain.phm.bode.server.config.ConfigurationService;

public class TestServer {

	private static InetSocketAddress serverAddr = new InetSocketAddress(TestConstant.LOCALHOST, 17227);

	public static void setUp() {
		final ServerServerMock mock = new ServerServerMock();
		mock.start();
	}

	@Test
	public void testDebug() throws IOException, InterruptedException {
		setUp();
		DatagramSocket otherServer = null;
		try {
			otherServer = new DatagramSocket(17229);
			final ByteBuffer buf = ByteBuffer.allocate(4);
			buf.put((byte) ServerConstant.DEBUG_COMMAND_ID);
			buf.putShort((short) 1);
			buf.put((byte) 1);
			final SyncSubscriber<DebugEvent> result = new SyncSubscriber<DebugEvent>() {

				@Subscribe
				public void on(DebugEvent event) {
					setResponse(event);
				}
			};
			InnerEventBus.getInstance().register(result);

			final DatagramPacket packet = new DatagramPacket(buf.array(), 4);
			packet.setSocketAddress(serverAddr);
			otherServer.send(packet);

			final DebugEvent event = result.get();
			assertTrue(event.isDebug());
			InnerEventBus.getInstance().unregister(result);

			final DatagramPacket receive = new DatagramPacket(new byte[4], 4);
			otherServer.receive(receive);
			final byte[] data = receive.getData();
			assertEquals(ServerConstant.DEBUG_RESPONCE_ID, data[0]);
			assertEquals(0, data[3]);
		} finally {
			if (otherServer != null) {
				otherServer.close();
			}
		}
	}

	@Test
	public void testSetting() throws Exception {
		setUp();
		DatagramSocket otherServer = null;
		try {
			otherServer = new DatagramSocket(17229);
			final ITrain train = ConfigurationService.getInstance().getTrain();
			final byte[] bs = SystemInfoUtil.convertSystemInfo2XmlBytes(train);
			final ByteBuffer buffer = ByteBuffer.allocate(3 + bs.length);
			buffer.put((byte) ServerConstant.SETTING_COMMAND_ID);
			buffer.putShort((short) bs.length);
			buffer.put(bs);
			final SyncSubscriber<ConfigEvent> result = new SyncSubscriber<ConfigEvent>() {

				@Subscribe
				public void on(ConfigEvent event) {
					setResponse(event);
				}
			};
			InnerEventBus.getInstance().register(result);

			final DatagramPacket packet = new DatagramPacket(buffer.array(), 3 + bs.length);
			packet.setSocketAddress(serverAddr);
			otherServer.send(packet);

			final ConfigEvent event = result.get();
			final ITrain train1 = event.getTrain();
			assertNotNull(train1);
			assertEquals(train.getCityName(), train1.getCityName());
			InnerEventBus.getInstance().unregister(result);

			final DatagramPacket receive = new DatagramPacket(new byte[4], 4);
			otherServer.receive(receive);
			final byte[] data = receive.getData();
			assertEquals(ServerConstant.SETTING_RESPONCE_ID, data[0]);
			assertEquals(0, data[3]);
		} finally {
			if (otherServer != null) {
				otherServer.close();
			}
		}
	}

	@Test
	public void testMessage() throws IOException, InterruptedException {
		setUp();
		// MDCUMock mdcuMock = new MDCUMock();
		try {
			// mdcuMock.start(true);
			InnerEventBus.getInstance().register(this);
			final ITrain train = ConfigurationService.getInstance().getTrain();
			if (train != null) {
				InnerEventBus.getInstance().post(new ConfigEvent(train, null));
			} else {
				return;
			}
			TimeUnit.SECONDS.sleep(60);
			InnerEventBus.getInstance().unregister(this);
		} finally {
			// mdcuMock.stop();
		}
	}

	@Subscribe
	public void on(MessageEvent event) {
		System.out.println(convertBytes2Line(event.getDatas()));
	}

	public byte[] convertLine2Bytes(String line) {
		final byte[] result = new byte[32];
		int index = 0;
		for (int i = 0; i < line.length() - 1; i = i + 2) {
			final String n = line.substring(i, i + 2);
			final int r = Integer.parseInt(n, 16);
			result[index] = (byte) r;
			index++;
		}
		return result;
	}

	public String convertBytes2Line(byte[] bs) {
		final StringBuilder sb = new StringBuilder();
		for (int i = 0; i < bs.length; i++) {
			final byte b = bs[i];
			final String hex = Integer.toHexString(b & 0xff);
			if (hex.length() < 2) {
				sb.append("0");
			}
			sb.append(hex.toUpperCase()).append(" ");
		}
		return sb.toString();
	}
}
