/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.impl;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.ICarInfo;
import com.hirain.phm.bode.core.IServer;
import com.hirain.phm.bode.core.ITrain;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 4:07:55 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
@XmlRootElement(name = "Train")
@XmlType(propOrder = { "cityName", "lineName", "trainNo", "servers", "carInfo", "cars" })
@XmlAccessorType(XmlAccessType.FIELD)
public class Train implements ITrain {

	@XmlElement(name = "cityName", required = true)
	private String cityName;

	@XmlElement(name = "lineName", required = true)
	private Integer lineName;

	@XmlElement(name = "trainNo", required = true)
	private String trainNo;

	@XmlElement(name = "carInfo", required = true, type = CarInfo.class)
	private ICarInfo carInfo;

	@XmlElementWrapper(name = "servers")
	@XmlElement(name = "server", required = true, type = Server.class)
	private List<IServer> servers;

	@XmlElementWrapper(name = "cars")
	@XmlElement(name = "car", required = true, type = Car.class)
	private List<ICar> cars;

	@Override
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	@Override
	public String getCityName() {
		return cityName;
	}

	@Override
	public void setLineName(Integer lineName) {
		this.lineName = lineName;
	}

	@Override
	public Integer getLineName() {
		return lineName;
	}

	@Override
	public void setTrainNo(String trainNo) {
		this.trainNo = trainNo;
	}

	@Override
	public String getTrainNo() {
		return trainNo;
	}

	@Override
	public ICarInfo getCarInfo() {
		if (carInfo == null) {
			carInfo = new CarInfo();
		}
		return this.carInfo;
	}

	@Override
	public List<IServer> getServers() {
		if (servers == null) {
			servers = new ArrayList<IServer>();
		}
		return this.servers;
	}

	@Override
	public List<ICar> getCars() {
		if (cars == null) {
			cars = new ArrayList<ICar>();
		}
		return this.cars;
	}

	/**
	 * 获取不含车头和车尾的车厢列表
	 * 
	 * @return
	 */
	public List<ICar> getCarriages() {
		List<ICar> list = new ArrayList<>();
		if (cars != null) {
			for (int i = 2; i < cars.size(); i++) {
				list.add(cars.get(i));
			}
		}
		return list;
	}

	public void setCars(List<ICar> cars) {
		this.cars = cars;
	}

	public void setCarInfo(ICarInfo carInfo) {
		this.carInfo = carInfo;
	}

	public void setServers(List<IServer> servers) {
		this.servers = servers;
	}

}
