
/*******************************************************************************
 * Copyright (c) 2017, 2017 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.monitor.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.LightweightSystem;
import org.eclipse.nebula.visualization.xygraph.dataprovider.CircularBufferDataProvider;
import org.eclipse.nebula.visualization.xygraph.figures.Trace;
import org.eclipse.nebula.visualization.xygraph.figures.Trace.PointStyle;
import org.eclipse.nebula.visualization.xygraph.figures.XYGraph;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Listener;

/**
 * @Version 1.0
 * @Author hao.zheng@hirain.com
 * @Created Oct 12, 2017 3:27:13 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Oct 12, 2017 hao.zheng@hirain.com 1.0 create file
 */
public class XYGraphViewer {

	private XYGraph graph;

	private final Composite content;

	private final List<Trace> traces = new ArrayList<Trace>();

	private final List<CircularBufferDataProvider> traceDataProviders = new ArrayList<CircularBufferDataProvider>();

	private ToolbarArmedXYGraph toolbarArmedXYGraph;

	public XYGraphViewer(final Composite parent) {
		content = new Composite(parent, SWT.BORDER);
		content.setLayout(gridLayout(1));
		createSection(content);
	}

	public static GridLayout gridLayout(final int n) {
		final GridLayout gridLayout = new GridLayout(n, false);
		gridLayout.horizontalSpacing = 0;
		gridLayout.verticalSpacing = 0;
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;
		return gridLayout;
	}

	private void createSection(final Composite parent) {
		final Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout());
		{
			final GridData layoutData = new GridData(GridData.FILL_BOTH);
			layoutData.minimumHeight = 300;
			composite.setLayoutData(layoutData);
		}

		graph = new XYGraph();
		graph.getPrimaryXAxis().setTitle("");
		graph.getPrimaryYAxis().setTitle("");
		graph.getPrimaryXAxis().setAutoScale(true);
		graph.getPrimaryYAxis().setAutoScale(true);
		graph.getPrimaryXAxis().setDateEnabled(true);
		graph.getPrimaryXAxis().setFormatPattern("HH:mm:ss SSS");
		toolbarArmedXYGraph = new ToolbarArmedXYGraph(graph);
		toolbarArmedXYGraph.setShowToolbar(false);
		inCanvas(composite, toolbarArmedXYGraph);

	}

	public void setToolbarEnable(boolean enable) {
		toolbarArmedXYGraph.setShowToolbar(enable);
	}

	/**
	 * @return the content
	 */
	public Composite getContent() {
		return content;
	}

	int bufferSize = 0;

	public void setBufferSize(int bufferSize) {
		this.bufferSize = bufferSize;
	}

	public void setInput(final List<XYSeries> input) {
		for (final XYSeries sery : input) {
			CircularBufferDataProvider traceDataProvider = new CircularBufferDataProvider(false);
			double[] xAxisData = sery.getxAxisData();
			double[] yAxisData = sery.getyAxisData();
			// if (xAxisData.length > 0) {
			if (bufferSize != 0) {
				traceDataProvider.setBufferSize(bufferSize);
			} else {
				if (xAxisData.length > 0) {
					traceDataProvider.setBufferSize(xAxisData.length);
				}
			}
			traceDataProvider.setCurrentXDataArray(xAxisData);
			traceDataProvider.setCurrentYDataArray(yAxisData);

			Trace trace = new Trace(sery.getId(), graph.getPrimaryXAxis(), graph.getPrimaryYAxis(), traceDataProvider);

			// set trace property
			trace.setPointStyle(PointStyle.NONE);
			trace.setTraceColor(sery.getColor());
			// add the trace to xyGraph
			graph.addTrace(trace);
			traces.add(trace);
			traceDataProviders.add(traceDataProvider);
			// }
		}
		graph.setShowLegend(false);
	}

	public int removeTrace(String id) {
		if (traces.isEmpty()) {
			return 0;
		}
		Iterator<Trace> iterator = traces.iterator();
		int i = 0;
		while (iterator.hasNext()) {
			Trace trace = iterator.next();
			if (trace != null && trace.getName().equals(id)) {
				iterator.remove();
				graph.removeTrace(trace);
				traceDataProviders.remove(i);
				break;
			}
			i++;
		}
		return i;
	}

	public void clearTrace() {
		if (traces.isEmpty()) {
			return;
		}
		for (final Trace trace : traces) {
			graph.removeTrace(trace);
		}
		traces.clear();
		traceDataProviders.clear();
	}

	public void update(List<Position> positions) {
		for (int i = 0; i < positions.size(); i++) {
			Position position = positions.get(i);
			double x = position.getX();
			double y = position.getY();
			int size = traceDataProviders.size();
			if (size > i) {
				CircularBufferDataProvider traceDataProvider = traceDataProviders.get(i);
				traceDataProvider.setCurrentXData(x);
				traceDataProvider.setCurrentYData(y);
			}
		}

	}

	public void update(List<Position> positions, int j) {
		double[] x = new double[positions.size()];
		double[] y = new double[positions.size()];
		for (int i = 0; i < positions.size(); i++) {
			Position position = positions.get(i);
			x[i] = position.getX();
			y[i] = position.getY();
		}
		int size = traceDataProviders.size();
		if (size > j) {
			CircularBufferDataProvider traceDataProvider = traceDataProviders.get(j);
			traceDataProvider.setCurrentXDataArray(x);
			traceDataProvider.setCurrentYDataArray(y);
		}

	}

	/**
	 * @param shell
	 * @param graph
	 */
	private void inCanvas(final Composite shell, final Figure graph) {
		final Canvas canvas = new Canvas(shell, SWT.NONE);
		canvas.setLayoutData(new GridData(GridData.FILL_BOTH));

		final LightweightSystem lws = new LightweightSystem(canvas);
		lws.setContents(graph);

		Listener[] listener2 = canvas.getListeners(SWT.Move);
		for (int i = 0; i < listener2.length; i++) {
			canvas.removeListener(SWT.Move, listener2[i]);
		}
	}

}
