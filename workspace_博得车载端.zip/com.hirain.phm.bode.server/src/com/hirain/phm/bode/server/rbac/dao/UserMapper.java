package com.hirain.phm.bode.server.rbac.dao;

import com.hirain.phm.bode.server.rbac.impl.UserImpl;

public interface UserMapper {

	int insert(UserImpl record);

	UserImpl get(String username);

	int update(UserImpl record);

	int deleteByPrimaryKey(String username);
}