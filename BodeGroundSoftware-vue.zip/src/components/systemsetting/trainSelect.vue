<template>
  <el-col :span="24" class="query" style="padding-bottom: 0px;min-width:900px">
    <el-form :inline="true" :model="retrieveForm">
      <el-form-item label="城市" prop="cityName">
        <el-select v-model="retrieveForm.city" placeholder="请选择" @change="selectedCityChange">
          <el-option v-for="item in cityOptions" :key="item.label" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>
      <el-form-item label="线路" prop="line">
        <el-select v-model="retrieveForm.line" placeholder="请选择" @change="selectedLineChange">
          <el-option v-for="item in lineOptions" :key="item.label" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>
      <el-form-item label="车辆" prop="train">
        <el-select v-model="retrieveForm.train" placeholder="请选择">
          <el-option v-for="item in carOptions" :key="item.label" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="search" :disabled="checkButton()" @click="query">查询</el-button>
      </el-form-item>
    </el-form>
  </el-col>
</template>
<script>
const all_option = {
  value: null,
  label: '全部'
}
import app from '@/common/js/app'
export default {
  props: {
    single: Boolean
  },
  data() {
    return {
      cityOptions: [all_option],
      lineOptions: [all_option],
      carOptions: [all_option],
      // 查询功能数据
      retrieveForm: {
        city: null,
        line: null,
        train: null
      }
    }
  },
  mounted() {
    this.getAllCitys()
  },
  methods: {
    getAllCitys() {
      var vm = this
      vm.cityOptions = []
      app.get('get_city_name').then(d => {
        vm.cityOptions = []
        for (var i = 0; i < d.msg.length; i++) {
          if (d.msg[i].cityName != null) {
            vm.cityOptions.push({
              value: d.msg[i].cityName,
              label: d.msg[i].cityName
            })
          }
        }
        vm.cityOptions.push(all_option)
      }).catch(err => {
        console.log(err)
      })
    },
    selectedCityChange() {
      var vm = this
      const parm = {
        cityName: this.retrieveForm.city
      }
      this.lineOptions = [all_option]
      this.retrieveForm.line = null
      this.carOptions = [all_option]
      this.retrieveForm.train = null
      if (this.retrieveForm.city != null) {
        app.get('get_lines_by_cityName', parm).then(d => {
          vm.lineOptions = []
          for (var i = 0; i < d.msg.length; i++) {
            if (d.msg[i].lineName != null) {
              vm.lineOptions.push({
                value: d.msg[i].lineName,
                label: d.msg[i].lineName
              })
            }
          }
          vm.lineOptions.push(all_option)
        })
      }
    },
    selectedLineChange() {
      var vm = this
      const parm = {
        cityName: this.retrieveForm.city,
        lineName: this.retrieveForm.line
      }
      this.carOptions = [all_option]
      this.retrieveForm.train = null
      if (this.retrieveForm.line != null) {
        app.get('get_train_by_trainParam', parm).then(d => {
          console.log(d)
          vm.carOptions = []
          for (var i = 0; i < d.msg.length; i++) {
            if (d.msg[i].trainNo != null) {
              vm.carOptions.push({
                value: d.msg[i].trainNo,
                label: d.msg[i].trainNo
              })
            }
          }
          vm.carOptions.push(all_option)
        })
      }
    },
    query() {
      this.$emit('query', this.retrieveForm)
    },
    checkButton() {
      if (this.single) {
        return !(this.retrieveForm.city && this.retrieveForm.line && this.retrieveForm.train)
      } else {
        return false
      }
    }
  }
}

</script>
<style>
	.el-form-item {
		margin-bottom: 10px;
	}

</style>
