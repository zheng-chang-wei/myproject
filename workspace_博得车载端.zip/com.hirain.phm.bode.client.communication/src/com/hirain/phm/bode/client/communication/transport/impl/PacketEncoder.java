package com.hirain.phm.bode.client.communication.transport.impl;

import com.hirain.phm.bode.client.communication.transport.IEncoder;
import com.hirain.phm.bode.client.communication.transport.ITransportPacket;

public class PacketEncoder implements IEncoder {

	@Override
	public ITransportPacket encode(byte pid, byte[] data) {
		ITransportPacket packet = new TransportPacketImpl();
		packet.setPid(pid);
		packet.setLength(data.length);
		packet.setData(data);
		return packet;
	}

}
