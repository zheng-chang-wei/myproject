const apiDomain = {
     ip:'10.40.16.223:18081' 
    // ip:'10.40.101.236:18081'
}
export default apiDomain
