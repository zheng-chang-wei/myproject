package com.hirain.phm.bode.ui.monitor.figure.carriage;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;

import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;
import com.hirain.phm.bode.ui.monitor.model.DoorStateEnum;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月11日 下午1:46:55
 * @Description
 *              <p>
 *              各颜色标识
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月11日 changwei.zheng@hirain.com 1.0 create file
 */
public class LabelFigure extends Figure {

	int width = 0;

	int rightWidth = 80;

	int leftWidth = 100;

	public LabelFigure() {
		setLayoutManager(new XYLayout());
		DoorStateEnum[] values = DoorStateEnum.values();

		for (int i = 0; i < values.length; i++) {
			Label label = new Label();
			label.setText(values[i].getLable());
			label.setFont(CarriageConstants.font);
			switch (i) {
			case 6:
				width = CarriageConstants.doorWidth + 5 + leftWidth + 5;
				IsolationFigure isolationFigure = new IsolationFigure();
				add(isolationFigure, new Rectangle(width, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));

				add(label, new Rectangle(width + CarriageConstants.doorWidth + CarriageConstants.carriageHorizontalSpacing, 0, rightWidth,
						CarriageConstants.doorWidth));
				break;
			case 7:
				EmergencyUnlockFigure emergencyUnlockFigure = new EmergencyUnlockFigure();
				add(emergencyUnlockFigure,
						new Rectangle(width, (CarriageConstants.doorWidth + 11) * 1, CarriageConstants.doorWidth, CarriageConstants.doorWidth));

				add(label, new Rectangle(width + CarriageConstants.doorWidth + CarriageConstants.carriageHorizontalSpacing,
						(CarriageConstants.doorWidth + 11) * 1, rightWidth, CarriageConstants.doorWidth));
				break;
			case 8:
				AntiCrushFigure antiCrushFigure = new AntiCrushFigure();
				add(antiCrushFigure,
						new Rectangle(width, (CarriageConstants.doorWidth + 11) * 2, CarriageConstants.doorWidth, CarriageConstants.doorWidth));

				add(label, new Rectangle(width + CarriageConstants.doorWidth + CarriageConstants.carriageHorizontalSpacing,
						(CarriageConstants.doorWidth + 11) * 2, rightWidth, CarriageConstants.doorWidth));
				width = width + CarriageConstants.doorWidth + CarriageConstants.carriageHorizontalSpacing + rightWidth;
				break;

			default:
				RectangleFigure rectangleFigure = new RectangleFigure();
				rectangleFigure.setBackgroundColor(values[i].getColor());
				add(rectangleFigure,
						new Rectangle(0, (CarriageConstants.doorWidth + 11) * i, CarriageConstants.doorWidth, CarriageConstants.doorWidth));

				add(label, new Rectangle(CarriageConstants.doorWidth + 5, (CarriageConstants.doorWidth + 11) * i, leftWidth,
						CarriageConstants.doorWidth));
				break;
			}
		}
	}

	public int getWidth() {
		return width;
	}

}
