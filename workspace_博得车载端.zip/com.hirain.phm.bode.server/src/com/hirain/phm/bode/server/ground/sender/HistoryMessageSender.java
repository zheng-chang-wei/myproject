package com.hirain.phm.bode.server.ground.sender;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.log4j.Logger;

import com.hirain.phm.bode.server.mqtt.MqttPublisher;

import lombok.Setter;

public class HistoryMessageSender {

	static Logger logger = Logger.getLogger(HistoryMessageSender.class);

	private final static int POLL_PERIOD = 100;

	@Setter
	private MessageFileCache fileCache;

	private final ExecutorService executor;

	@Setter
	private MqttPublisher publisher;

	@Setter
	private String topic;

	private AtomicBoolean stop = new AtomicBoolean(false);

	public HistoryMessageSender() {
		executor = Executors.newSingleThreadExecutor(r -> new Thread(r, HistoryMessageSender.class.getName()));
		fileCache = new MessageFileCache();

	}

	public void send(byte[] payload) {
		fileCache.write(payload);
	}

	public void start() {
		stop.set(false);
		fileCache.init();
		executor.submit(() -> {
			while (true) {
				if (stop.get()) {
					fileCache.close();
					break;
				}
				byte[] payload = fileCache.read();
				if (payload != null) {
					System.out.println("history:" + payload.length);
					sendMessage(payload);
				} else {
					try {
						TimeUnit.MILLISECONDS.sleep(POLL_PERIOD);
					} catch (InterruptedException e) {
						logger.error(e.getMessage(), e);
					}
				}
			}
		});
	}

	private void sendMessage(byte[] payload) {
		while (true) {
			try {
				if (publisher != null && publisher.isConnected()) {
					publisher.send(topic, payload, 1, false);
					break;
				}
			} catch (final Exception e) {
				logger.error(e.getMessage(), e);
			}
			try {
				TimeUnit.MILLISECONDS.sleep(POLL_PERIOD);
			} catch (final InterruptedException e) {
			}
		}
	}

	public void stop() {
		stop.set(true);
	}
}
