package com.hirain.phm.bode.server.client.data;

import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.ibatis.session.SqlSession;

import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ISender;
import com.hirain.phm.bode.server.client.Token;
import com.hirain.phm.bode.server.db.DBService;

public class DataStatisticeHandler {

	private final ExecutorService pool;

	private final String sql;

	private final ISender sender;

	private final Token token;

	private final byte type;

	public DataStatisticeHandler(ISender sender, byte type, String sql, Token token) {
		pool = Executors.newSingleThreadExecutor(r -> new Thread(r, "data-count-thread"));
		this.sender = sender;
		this.sql = sql;
		this.token = token;
		this.type = type;
	}

	public void work() {
		count();
	}

	private void count() {
		pool.submit(() -> {
			SqlSession session = null;
			try {
				session = DBService.getInstance().getSession(false);
				final ClientMapper mapper = DBService.getInstance().getMapper(ClientMapper.class, session);
				final Long count = mapper.count(sql);
				DBService.getInstance().disconnect(session);

				final ByteBuffer buffer = ByteBuffer.allocate(9);
				buffer.put(type);
				buffer.putLong(count);
				sender.send(token.getAddress(), ClientConstants.DATA_STATISTICS_RESPONSE, buffer.array());
			} catch (final Exception e) {
				DBService.getInstance().disconnect(session);
			}
		});
	}
}
