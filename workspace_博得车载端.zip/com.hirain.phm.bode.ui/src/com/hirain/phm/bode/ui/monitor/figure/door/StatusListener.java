package com.hirain.phm.bode.ui.monitor.figure.door;

public interface StatusListener {

	void update(int operation, int step);

	void reset();
}
