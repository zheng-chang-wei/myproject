/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;

import com.hirain.phm.bode.core.IServerIp;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 9, 2019 11:34:46 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 9, 2019 zepei.tao@hirain.com 1.0 create file
 */
@XmlRootElement(name = "ip")
@XmlType(propOrder = { "type" })
@XmlAccessorType(XmlAccessType.FIELD)
public class ServerIp implements IServerIp {

	@XmlAttribute(name = "type", required = true)
	private ServerIpType type;

	@XmlValue
	private String ip;

	@Override
	public void setType(ServerIpType type) {
		this.type = type;
	}

	@Override
	public ServerIpType getType() {
		return type;
	}

	@Override
	public void setIp(String ip) {
		this.ip = ip;
	}

	@Override
	public String getIp() {
		return ip;
	}

}
