package com.hirain.phm.bd.ground.life.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hirain.phm.bd.ground.life.domain.LifeDoorItem;
import com.hirain.phm.bd.ground.life.domain.LifeItem;
import com.hirain.phm.bd.ground.life.domain.LifeTrainInfo;
import com.hirain.phm.bd.ground.life.param.DoorItemLifeResult;
import com.hirain.phm.bd.ground.life.param.LifeMonitorRequest;
import com.hirain.phm.bd.ground.life.service.LifeDoorItemService;
import com.hirain.phm.bd.ground.life.service.LifeItemService;
import com.hirain.phm.bd.ground.life.service.LifeService;
import com.hirain.phm.bd.ground.life.service.LifeTrainInfoService;
import com.hirain.phm.bd.ground.train.controller.TrainGateWay;
import com.hirain.phm.bd.ground.train.domain.Train;

@Service
public class LifeServiceImpl implements LifeService {

	@Autowired
	private LifeItemService lifeItemService;

	@Autowired
	private LifeTrainInfoService trainLifeService;

	@Autowired
	private LifeDoorItemService doorItemService;

	@Autowired
	private TrainGateWay trainGW;

	@Override
	public List<DoorItemLifeResult> findItemLifeByDoor(LifeMonitorRequest request) {
		List<DoorItemLifeResult> results = new ArrayList<>();
		Train train = trainGW.selectTrain(request.getProject(), request.getTrainNo());

		List<LifeDoorItem> doorItemLifes = doorItemService.findDoorItemLifeInfos(train.getId(), request.getCarNo(), request.getDoorAddr());
		for (LifeDoorItem doorItemLife : doorItemLifes) {
			DoorItemLifeResult result = new DoorItemLifeResult();

			Integer lifeItemId = doorItemLife.getLifeitemId();
			LifeItem lifeItem = lifeItemService.findLifeItemById(lifeItemId);
			result.setItemName(lifeItem.getItemName());

			LifeTrainInfo trainLifeInfo = trainLifeService.findTrainLifeInfoByTrainIDItemId(train.getId(), lifeItemId);
			Integer referenceValue = trainLifeInfo.getReferenceValue();
			double lifePercentage = 0.0;
			if (referenceValue != 0) {
				lifePercentage = doorItemLife.getValue() * 1.0 / referenceValue;
				result.setReferenceValue(referenceValue);
			}
			result.setLifeValue(doorItemLife.getValue());
			result.setLifePercentage((int) lifePercentage * 100);
			results.add(result);
		}
		return results;
	}

}
