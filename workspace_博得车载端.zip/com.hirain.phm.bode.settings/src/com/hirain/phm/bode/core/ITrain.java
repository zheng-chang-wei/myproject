/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core;

import java.util.List;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 3:38:20 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
public interface ITrain {

	void setCityName(String cityName);

	String getCityName();

	void setLineName(Integer lineName);

	Integer getLineName();

	void setTrainNo(String trainNo);

	String getTrainNo();

	ICarInfo getCarInfo();

	void setCarInfo(ICarInfo carInfo);

	List<IServer> getServers();

	void setServers(List<IServer> servers);

	List<ICar> getCars();

	List<ICar> getCarriages();

	void setCars(List<ICar> cars);
}
