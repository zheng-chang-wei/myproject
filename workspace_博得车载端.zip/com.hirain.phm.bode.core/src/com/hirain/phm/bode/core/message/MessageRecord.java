package com.hirain.phm.bode.core.message;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MessageRecord {

	private Long id;

	private Date startTime;

	private Integer doorId;

	private Integer carriageId;

	private Date endTime;

	private Boolean debug;

	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public String getDoorId() {
		return doorId.toString();
	}

	public void setDoorId(Integer doorId) {
		this.doorId = doorId;
	}

	public String getEndTime() {
		return dateFormat.format(endTime);
	}

	public void setEndTime(String endTime) {
		try {
			this.endTime = dateFormat.parse(endTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	public String getDebug() {
		return new String(debug == true ? "是" : "否");
	}

	public void setDebug(String debug) {
		this.debug = debug.equals("是");
	}

	public String getId() {
		return id.toString();
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStartTime() {
		return dateFormat.format(startTime);
	}

	public void setStartTime(String startTime) {
		try {
			this.startTime = dateFormat.parse(startTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	public String getCarriageId() {
		return carriageId.toString();
	}

	public void setCarriageId(Integer carriageId) {
		this.carriageId = carriageId;
	}

	public boolean isValid() {
		return startTime != null && endTime != null && doorId != null && carriageId != null && debug != null;
	}
}