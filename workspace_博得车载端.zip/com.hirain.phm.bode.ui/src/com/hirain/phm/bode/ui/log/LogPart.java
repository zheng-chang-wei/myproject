/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.log;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.nebula.widgets.cdatetime.CDT;
import org.eclipse.nebula.widgets.cdatetime.CDateTime;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.ResourceManager;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.client.communication.message.LogResultMessage;
import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.log.model.LogQueryCondition;
import com.hirain.phm.bode.ui.log.model.LogTable;
import com.hirain.phm.bode.ui.log.provider.LogTableViewerLabelProvider;
import com.hirain.phm.bode.ui.log.service.impl.LogServiceImpl;
import com.hirain.phm.bode.ui.log.utils.LogDecodeUtil;
import com.hirain.phm.bode.ui.monitor.provider.TableViewerContentProvider;
import com.hirain.phm.bode.ui.widget.CommonPart;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 7, 2019 10:59:27 AM
 * @Description
 *              <p>
 *              日志管理界面
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 7, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class LogPart extends CommonPart {

	private static LogPart logPart;

	private Button btnFirstPage;

	private Button btnPreviousPage;

	private Text txtCurrentPage;

	private Button btnNextPage;

	private Button btnLastPage;

	private Button btnDownloadSelected;

	private int currentPage;

	private long pageCount;

	private int pageSize = 10;

	private String filePath;

	private TableViewer tv;

	private Button btnQuery;

	private CDateTime cdtEnd;

	private CDateTime cdtStart;

	private volatile int downloadCount = 0;

	private BlockingQueue<LogResultMessage> queue = new LinkedBlockingDeque<>();

	private LogPart() {
		CommunicationService.getInstance().getEventBus().register(this);
	}

	public static LogPart getInstance() {
		if (logPart == null) {
			logPart = new LogPart();
		}
		return logPart;
	}

	@Override
	public void postConstruct(final Composite parent) {
		super.postConstruct(parent);
		// scrolledComposite.setMinSize(1000, 1650);
		createQueryConditionArea(coreComposite);
		createTableArea(coreComposite);
		createToolbarArea(coreComposite);
		initListener();
		decodeMessage();
		selectCount();
	}

	private void createQueryConditionArea(Composite parent) {
		Composite composite = new Composite(parent, SWT.BORDER);
		composite.setLayout(new GridLayout(15, false));
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		new Label(composite, SWT.None).setText("起始时间");
		cdtStart = new CDateTime(composite, CDT.BORDER | CDT.DROP_DOWN | CDT.DATE_MEDIUM);
		cdtStart.setNullText("");
		GridData layoutData = new GridData(SWT.FILL, SWT.FILL, false, true);
		layoutData.widthHint = 150;
		cdtStart.setLayoutData(layoutData);
		new Label(composite, SWT.None).setText("结束时间");
		cdtEnd = new CDateTime(composite, CDT.BORDER | CDT.DROP_DOWN | CDT.DATE_MEDIUM);
		cdtEnd.setNullText("");
		cdtEnd.setLayoutData(layoutData);

		btnQuery = new Button(composite, SWT.None);
		btnQuery.setText("确认搜索");
	}

	private void createTableArea(Composite parent) {
		tv = new TableViewer(parent, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL);
		Table table = tv.getTable();
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableLayout tableLayout = new TableLayout();
		table.setLayout(tableLayout);
		GridData layoutData = new GridData(SWT.FILL, SWT.FILL, true, true);
		table.setLayoutData(layoutData);

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnFaultTime = new TableColumn(table, SWT.CENTER);
		tableColumnFaultTime.setText("日志时间");

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnFaultName = new TableColumn(table, SWT.CENTER);
		tableColumnFaultName.setText("日志名称");

		tv.setContentProvider(new TableViewerContentProvider());
		tv.setLabelProvider(new LogTableViewerLabelProvider());
	}

	private void createToolbarArea(Composite parent) {
		Composite tableToolBarComposite = new Composite(parent, SWT.FILL | SWT.NONE);
		tableToolBarComposite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, false));
		tableToolBarComposite.setLayout(new GridLayout(7, false));
		btnFirstPage = new Button(tableToolBarComposite, SWT.FLAT);
		btnFirstPage.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/u2261.png"));
		btnFirstPage.setToolTipText("第一页");
		btnPreviousPage = new Button(tableToolBarComposite, SWT.FLAT | SWT.ARROW | SWT.LEFT);
		btnPreviousPage.setToolTipText("上一页");
		txtCurrentPage = new Text(tableToolBarComposite, SWT.SINGLE | SWT.CENTER | SWT.BORDER);
		btnNextPage = new Button(tableToolBarComposite, SWT.FLAT | SWT.ARROW | SWT.RIGHT);
		btnNextPage.setToolTipText("下一页");
		btnLastPage = new Button(tableToolBarComposite, SWT.FLAT);
		btnLastPage.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/u2263.png"));
		btnLastPage.setToolTipText("最后一页");
		btnDownloadSelected = new Button(tableToolBarComposite, SWT.NONE);
		btnDownloadSelected.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/u2641.png"));
		btnDownloadSelected.setText("下载所选条目");
		linkToScroll(tableToolBarComposite);

	}

	private void initListener() {
		btnQuery.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPage = 1;
			selectCount();
		}));
		btnPreviousPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPage--;
			selectByPage(currentPage, pageSize);
		}));
		btnNextPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPage++;
			selectByPage(currentPage, pageSize);

		}));
		btnFirstPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPage = 1;
			selectByPage(currentPage, pageSize);
		}));
		btnLastPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPage = (int) pageCount;
			selectByPage(currentPage, pageSize);
		}));
		btnDownloadSelected.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			FileDialog directoryDialog = new FileDialog(Display.getDefault().getActiveShell(), SWT.SAVE);
			directoryDialog.setFilterExtensions(new String[] { "*.log" });
			filePath = directoryDialog.open();
			if (StringUtil.isEmpty(filePath)) {
				return;
			}
			File file = new File(filePath);
			while (file.exists()) {
				boolean confirm = MessageDialog.openConfirm(Display.getDefault().getActiveShell(), "文件已存在", filePath + "文件已存在，是否覆盖原文件？");
				if (confirm) {
					file.delete();
				} else {
					directoryDialog.setFileName(null);
					filePath = directoryDialog.open();
					if (StringUtil.isEmpty(filePath)) {
						return;
					}
					file = new File(filePath);
				}
			}
			try {
				file.createNewFile();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			if (!StringUtil.isEmpty(filePath)) {
				downloadCount = tv.getTable().getSelectionCount();
				addProgressMonitorDialog("正在下载数据。。。");
				IStructuredSelection selection = (IStructuredSelection) tv.getSelection();
				Iterator<?> iterator = selection.iterator();
				while (iterator.hasNext()) {
					LogTable logTable = (LogTable) iterator.next();
					LogServiceImpl.getInstance().download(logTable);
				}
			}
		}));
	}

	/**
	 * 添加进度条对话框
	 */
	private void addProgressMonitorDialog(String message) {
		Display.getDefault().asyncExec(new Runnable() {

			@Override
			public void run() {
				final ProgressMonitorDialog progress = new ProgressMonitorDialog(null);
				final IRunnableWithProgress runnableWithProgress = new IRunnableWithProgress() {

					@Override
					public void run(final IProgressMonitor m) {
						m.beginTask(message, IProgressMonitor.UNKNOWN);
						int countHis = downloadCount;
						int waitSec = 0;
						while (downloadCount > 0) {
							if (countHis != downloadCount) {
								waitSec = 0;
								countHis = downloadCount;
							} else {
								try {
									Thread.sleep(1000);
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
								waitSec++;
							}
							if (waitSec > 5) {
								m.done();
								return;
							}
						}
						m.done();
						return;
					}
				};
				try {
					progress.run(true, false, runnableWithProgress);
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 分页查询
	 * 
	 * @param currentPage
	 * @param pageSize
	 * @return
	 */
	private void selectByPage(int currentPage, int pageSize) {
		LogQueryCondition logQueryCondition = getQueryCondition();
		LogServiceImpl.getInstance().selectByPage(logQueryCondition, currentPage, pageSize);
	}

	/**
	 * 获取查询条件
	 * 
	 * @return
	 */
	private LogQueryCondition getQueryCondition() {
		LogQueryCondition logQuery = new LogQueryCondition();

		String startTime = cdtStart.getText();
		String endTime = cdtEnd.getText();
		if (StringUtil.isNotEmpty(startTime)) {
			logQuery.setStartTime(startTime);
		}
		if (StringUtil.isNotEmpty(endTime)) {
			logQuery.setEndTime(endTime);
		}
		return logQuery;
	}

	private void selectCount() {
		LogQueryCondition queryCondition = getQueryCondition();
		try {
			LogServiceImpl.getInstance().selectCount(queryCondition);
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}

	@Subscribe
	void on(LogResultMessage message) {
		queue.add(message);
	}

	private void updatePageInfo() {
		if (pageCount > 0) {
			txtCurrentPage.setText(currentPage + "/" + pageCount);
		} else {
			txtCurrentPage.setText("");
		}
		btnFirstPage.setEnabled(currentPage > 1);
		btnPreviousPage.setEnabled(currentPage > 1);
		btnNextPage.setEnabled(currentPage < pageCount);
		btnLastPage.setEnabled(currentPage < pageCount);
	}

	/**
	 * 开启线程解析数据
	 */
	private void decodeMessage() {
		new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {
					try {
						LogResultMessage message = queue.take();
						Display.getDefault().syncExec(new Runnable() {

							@Override
							public void run() {
								byte pid = message.getPid();
								// 统计结果
								if (pid == ServiceConstant.PID_DATA_COUNT_ACK) {
									if (message.getData() != null) {
										byte[] data = message.getData();
										ByteBuffer buffer = ByteBuffer.wrap(data);
										buffer.get();
										long count = buffer.getLong();
										pageCount = (count + pageSize - 1) / pageSize;
										if (pageCount != 0) {
											currentPage = 1;
											selectByPage(currentPage, pageSize);
										} else {
											currentPage = 0;
											List<LogTable> logs = new ArrayList<>();
											LogTable logTable = new LogTable();
											logTable.setLogTime("数据库中没有符合条件的记录");
											logTable.setLogName(StringUtil.EMPTY);
											logs.add(logTable);
											tv.setInput(logs);
										}
										updatePageInfo();
									} else {
										currentPage = 0;
									}

								} else if (pid == ServiceConstant.PID_DATA_QUERY_ACK) {
									List<LogTable> logs = LogDecodeUtil.getLogs(message);
									tv.setInput(logs);
									if (logs.size() != 0) {
										updatePageInfo();
									} else {
										btnPreviousPage.setEnabled(false);
										btnNextPage.setEnabled(false);
										btnFirstPage.setEnabled(false);
										btnLastPage.setEnabled(false);
									}
								} else if (pid == ServiceConstant.PID_DATA_DOWNLOAD_ACK) {
									byte sid = message.getSid();
									if (sid == ServiceConstant.LOG_DOWNLOAD_COMPLETE_SID) {
										System.out.println("下载完成");
										downloadCount--;
									} else {
										System.out.println("下载");
										LogDecodeUtil.saveLogMessages(message, filePath);
									}
								}
							}
						});
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		}).start();
	}

	public void refreshTable() {
		selectCount();
	}
}
