import apiDomain from './apiDomain.js'
const appApi = {
  countByMonth: '/bode/statistics/month',
  trains: '/bode/statistics/trains',
  countByYear: '/bode/statistics/year',
  countByFaultType: '/bode/statistics/type/fault',
  countBySubhealthType: '/bode/statistics/type/subhealth',
  countByTopType: '/bode/statistics/type/top',

  get_all_project: '/train/projects',
  get_train_no: '/train/project/trains',
  get_train_config_info: '/train/getTrainConfigInfo', // 获取车辆配置信息

  dashboard_train: '/train/dashboard',
  faultData: '/fault/faultData',
  dashboard_fault_today: '/fault/dashboard/today',

  subhealthData: '/subhealth/subhealthData',
  dashboard_subhealth: '/subhealth/dashboard',

  listLifeWarningToday: '/lifewarning/listLifeWarningToday'
}
for (var i in appApi) {
  appApi[i] = 'http://' + apiDomain.ip + appApi[i]
}
export default appApi
