package com.hirain.phm.bd.ground.authority.service;

import com.hirain.phm.bd.ground.common.event.TrainOnlineEvent;

public interface TrainUserService {

	void updateTrainUser(TrainOnlineEvent event);

}
