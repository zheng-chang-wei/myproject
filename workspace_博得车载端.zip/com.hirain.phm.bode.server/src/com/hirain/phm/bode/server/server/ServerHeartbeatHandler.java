/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.server.server;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.ibatis.session.SqlSession;

import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.comm.ITransportPacket;
import com.hirain.phm.bode.server.db.DBService;
import com.hirain.phm.bode.server.fault.FaultRecord;
import com.hirain.phm.bode.server.fault.dao.FaultMapper;
import com.hirain.phm.bode.server.message.DoorMessage;
import com.hirain.phm.bode.server.message.DoorMessageDecoder;
import com.hirain.phm.bode.server.store.MessageRecord;
import com.hirain.phm.bode.server.store.dao.StoreMapper;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Mar 26, 2019 2:45:40 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Mar 26, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class ServerHeartbeatHandler {

	private ScheduledExecutorService heartExecutor;

	private ServerService server;

	private final DoorMessageDecoder decoder = new DoorMessageDecoder();

	private final int timeout = 4;// 心跳回复超时时间 单位：s

	private final int heartbeat_period = 5;// 心跳查询周期 单位：s

	private ITrain train;

	private final EventBus eventBus = new EventBus("ServersHeartbeat");

	private boolean offLine = false;

	private long offLine_startTime;// 开始断线时戳

	private long offLine_endTime;// 结束断线时戳

	private StoreMapper storeMapper;

	private FaultMapper faultMapper;

	public ServerHeartbeatHandler() {

	}

	public ServerHeartbeatHandler(ServerService server, ITrain train) {
		heartExecutor = Executors.newSingleThreadScheduledExecutor(r -> new Thread(r, "server-heartbeat-handler"));
		this.server = server;
		this.train = train;
	}

	public void setTrain(ITrain train) {
		this.train = train;
	}

	public void setOffLine_startTime(long offLine_startTime) {
		this.offLine_startTime = offLine_startTime;
	}

	public void setOffLine_endTime(long offLine_endTime) {
		this.offLine_endTime = offLine_endTime;
	}

	public void start() {
		heartExecutor.scheduleAtFixedRate(() -> {
			final SyncSubscriber<ITransportPacket> subscriber = new SyncSubscriber<ITransportPacket>() {

				@Subscribe
				void on(ITransportPacket message) {
					setResponse(message);
				}
			};
			eventBus.register(subscriber);
			server.inquireHeartbeat();
			try {
				final ITransportPacket transportPacket = subscriber.get(timeout, TimeUnit.SECONDS);
				if (transportPacket == null) {
					//System.out.println("-------超时未收到心跳回复-------");
					offLine_startTime = System.currentTimeMillis();
					offLine = true;
				} else if (offLine && transportPacket != null) {
					System.out.println("-------心跳恢复-------");
					offLine = false;
					offLine_endTime = System.currentTimeMillis();
					sendData2OtherServer();
				}
			} catch (final InterruptedException e) {
				e.printStackTrace();
			}
		}, 0, heartbeat_period, TimeUnit.SECONDS);
	}

	/**
	 * 向对端服务器发送相应的数据
	 */
	private void sendData2OtherServer() {
		final SqlSession session = DBService.getInstance().getSession(true);
		storeMapper = session.getMapper(StoreMapper.class);
		faultMapper = session.getMapper(FaultMapper.class);
		server.sendLostData(inquireLostMessage());// 发送丢失的实时数据
		server.sendLostData(inquireLostFaultRecord());// 发送丢失的故障记录数据

		DBService.getInstance().disconnect(session);
	}

	public void stop() {
		heartExecutor.shutdown();
		heartExecutor = null;
	}

	public EventBus getEventBus() {
		return eventBus;
	}

	/**
	 * 从数据库中查询离线期间的车门实时数据
	 */
	public byte[] inquireLostMessage() {
		final List<DoorMessage> result = new ArrayList<DoorMessage>();
		try {
			final List<ICar> cars = train.getCars();
			List<DoorMessage> findMessage;
			for (int i = 2; i < cars.size(); i++) {
				final ICar car = cars.get(i);
				final List<IDoor> doors = car.getDoors();
				for (final IDoor door : doors) {
					final MessageRecord record = new MessageRecord();
					record.setCarriageId(car.getIndex());
					record.setDoorId(door.getAddr());
					record.setStartTime(new Date(offLine_startTime));
					record.setEndTime(new Date(offLine_endTime));
					findMessage = storeMapper.findMessage(record);
					result.addAll(findMessage);
				}
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}
		final ByteBuffer buffer = ByteBuffer.allocate(result.size() * 32).order(ByteOrder.LITTLE_ENDIAN);
		for (final DoorMessage message : result) {
			buffer.put(message.getDatas());
		}
		return buffer.array();
	}

	/**
	 * 向数据库中插入离线期间丢失的车门实时数据
	 */
	public void insertLostMessage(Map<Integer, Object> map) {
		try {
			for (final Integer carriageId : map.keySet()) {
				final Map<String, Object> insertMap = new HashMap<String, Object>();
				insertMap.put("carriageId", String.valueOf(carriageId));
				insertMap.put("list", map.get(carriageId));
				storeMapper.insertMessage(insertMap);
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 解析接收到的主服务器发送的车门实时数据的报文
	 * 
	 * @param data
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<Integer, Object> parseDoorMessageData(byte[] data) {
		final ByteBuffer buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
		final int times = data.length / 32;
		final byte[] bb = new byte[32];
		final Map<Integer, Object> map = new HashMap<Integer, Object>();
		for (int i = 0; i < times; i++) {
			buffer.get(bb, i * 32, 32);
			final DoorMessage message = decoder.decode(bb);
			if (map.get(message.getCarriageId()) == null) {
				final List<DoorMessage> list = new ArrayList<DoorMessage>();
				list.add(message);
				map.put(message.getCarriageId(), list);
			} else {
				((List<DoorMessage>) map.get(message.getCarriageId())).add(message);
			}
		}
		return map;
	}

	/**
	 * 从数据库中查询离线期间的故障记录
	 */
	public byte[] inquireLostFaultRecord() {
		final List<FaultRecord> result = new ArrayList<FaultRecord>();
		try {
			final List<ICar> cars = train.getCars();
			for (int i = 2; i < cars.size(); i++) {// 从第三节车厢开始查，因为前两节车厢为车头
				final ICar car = cars.get(i);
				final List<IDoor> doors = car.getDoors();
				for (final IDoor door : doors) {
					final FaultRecord record = new FaultRecord();
					record.setCarriageId(car.getIndex());
					record.setDoorId(door.getAddr());
					record.setStartTime(new Date(offLine_startTime));
					record.setEndTime(new Date(offLine_endTime));
					final List<FaultRecord> findFaultRecord = faultMapper.findFaultRecord(record);
					result.addAll(findFaultRecord);
				}
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}
		final ByteBuffer buffer = ByteBuffer.allocate(result.size() * 37).order(ByteOrder.LITTLE_ENDIAN);
		for (final FaultRecord record : result) {
			// 共37字节
			buffer.putInt(record.getFaultId());
			buffer.putInt(record.getCarriageId());
			buffer.putInt(record.getDoorId());
			buffer.putLong(record.getTimestamp().getTime());
			buffer.putLong(record.getStartTime().getTime());
			buffer.putLong(record.getEndTime().getTime());
			buffer.put(record.getDebug() ? (byte) 1 : (byte) 0);
		}
		return buffer.array();
	}

	/**
	 * 解析收到的主服务器发送的故障记录数据
	 */
	public List<FaultRecord> parseFaultRecordData(byte[] data) {
		final List<FaultRecord> list = new ArrayList<FaultRecord>();
		final ByteBuffer buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
		final int times = data.length / 37;
		final FaultRecord record = new FaultRecord();
		for (int i = 0; i < times; i++) {
			record.setFaultId(buffer.getInt());
			record.setCarriageId(buffer.getInt());
			record.setDoorId(buffer.getInt());
			record.setTimestamp(new Date(buffer.getLong()));
			record.setStartTime(new Date(buffer.getLong()));
			record.setEndTime(new Date(buffer.getLong()));
			record.setDebug(buffer.get() == (byte) 1 ? true : false);
			list.add(record);
		}
		return list;
	}

	/**
	 * 向数据库中插入离线期间丢失的故障记录数据,并根据该故障记录向t_fault_message表中插入故障数据
	 */
	public void insertLostFaultRecord(List<FaultRecord> list) {
		try {
			for (final FaultRecord faultRecord : list) {
				faultMapper.insert(faultRecord);// 向数据表中插入一条故障记录
				// 根据故障记录从实时数据表中查询故障数据,将查询结果存入t_fault_message表中
				faultMapper.insertMessage(inquireLostFaultMessage(faultRecord), faultRecord.getCarriageId());
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 从车门实时数据表中查出离线期间丢失的故障实时数据
	 */
	private List<DoorMessage> inquireLostFaultMessage(FaultRecord faultRecord) {
		final MessageRecord messageRecord = new MessageRecord();
		messageRecord.setCarriageId(faultRecord.getCarriageId());
		messageRecord.setDoorId(faultRecord.getDoorId());
		messageRecord.setStartTime(faultRecord.getStartTime());
		messageRecord.setEndTime(faultRecord.getEndTime());
		try {
			return storeMapper.findMessage(messageRecord);
		} catch (final Exception e) {
			e.printStackTrace();
		}
		return new ArrayList<DoorMessage>();
	}

}
