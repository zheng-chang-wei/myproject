package com.hirain.qsy.shaft.dao;

import com.hirain.qsy.shaft.common.config.MyMapper;
import com.hirain.qsy.shaft.model.UserRole;

public interface UserRoleMapper extends MyMapper<UserRole> {
}