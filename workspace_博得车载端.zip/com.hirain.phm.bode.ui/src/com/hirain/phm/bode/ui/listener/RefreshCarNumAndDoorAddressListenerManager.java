/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.listener;

import java.util.ArrayList;
import java.util.List;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年3月11日 下午5:06:00
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年3月11日 changwei.zheng@hirain.com 1.0 create file
 */
public class RefreshCarNumAndDoorAddressListenerManager {

	private final List<IRefreshCarNumAndDoorAddressListener> listeners = new ArrayList<IRefreshCarNumAndDoorAddressListener>();

	private static RefreshCarNumAndDoorAddressListenerManager instance = null;

	private RefreshCarNumAndDoorAddressListenerManager() {

	}

	public static RefreshCarNumAndDoorAddressListenerManager getInstatnce() {
		if (instance == null) {
			instance = new RefreshCarNumAndDoorAddressListenerManager();
		}
		return instance;
	}

	public void add(IRefreshCarNumAndDoorAddressListener listener) {
		listeners.add(listener);
	}

	public void remove(IRefreshCarNumAndDoorAddressListener listener) {
		listeners.remove(listener);
	}

	public void refreshCarNumAndDoorAddr() {
		for (IRefreshCarNumAndDoorAddressListener listener : listeners) {
			listener.refreshCarNumAndDoorAddr();
		}
	}

}
