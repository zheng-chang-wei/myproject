/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.store.hdfs;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.hirain.phm.bd.store.file.StoreProperties;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年5月22日 下午3:09:54
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年5月22日 jianwen.xin@hirain.com 1.0 create file
 */
@Component
@Order(3)
public class UploadStartService implements ApplicationRunner {

	@Autowired
	private Scheduler scheduler;

	@Autowired
	private StoreProperties storeProperties;

	@Value("${store.file.upload.period}")
	private String cronExpression;

	@Value("${store.hdfs.username}")
	private String hadoopUsername;

	/**
	 * @see org.springframework.boot.ApplicationRunner#run(org.springframework.boot.ApplicationArguments)
	 */
	@Override
	public void run(ApplicationArguments args) throws Exception {
		System.setProperty("HADOOP_USER_NAME", hadoopUsername);
		JobDetail jobDetail = JobBuilder.newJob(UploadFileJob.class).withIdentity("upload-file").build();
		jobDetail.getJobDataMap().put("file.root", storeProperties.getRoot());
		jobDetail.getJobDataMap().put("file.container", storeProperties.getFolder());
		jobDetail.getJobDataMap().put("file.extension", storeProperties.getExtension());
		jobDetail.getJobDataMap().put("hdfs.root", storeProperties.getHdfsRoot());

		CronScheduleBuilder cronSchedule = CronScheduleBuilder.cronSchedule(cronExpression);
		CronTrigger trigger = TriggerBuilder.newTrigger().withIdentity("file-upload").withSchedule(cronSchedule).build();
		scheduler.scheduleJob(jobDetail, trigger);
	}

}
