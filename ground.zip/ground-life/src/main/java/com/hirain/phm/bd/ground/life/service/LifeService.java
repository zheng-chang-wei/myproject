package com.hirain.phm.bd.ground.life.service;

import java.util.List;

import com.hirain.phm.bd.ground.life.param.DoorItemLifeResult;
import com.hirain.phm.bd.ground.life.param.LifeMonitorRequest;

public interface LifeService {

	List<DoorItemLifeResult> findItemLifeByDoor(LifeMonitorRequest request);
}
