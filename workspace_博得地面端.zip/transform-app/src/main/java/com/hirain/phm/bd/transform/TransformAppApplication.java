package com.hirain.phm.bd.transform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransformAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransformAppApplication.class, args);
	}

}
