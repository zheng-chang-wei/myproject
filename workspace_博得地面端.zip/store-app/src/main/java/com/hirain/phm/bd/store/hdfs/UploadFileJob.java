/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.store.hdfs;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;

import lombok.extern.slf4j.Slf4j;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年5月22日 上午10:05:32
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年5月22日 jianwen.xin@hirain.com 1.0 create file
 */
@Slf4j
public class UploadFileJob implements Job {

	@Autowired
	private IHadoopService hadoopService;

	@Autowired
	private ApplicationEventPublisher publisher;

	private static IOFileFilter filter = new IOFileFilter() {

		@Override
		public boolean accept(File dir, String name) {
			return true;
		}

		@Override
		public boolean accept(File file) {
			return true;
		}
	};

	/**
	 * @see org.quartz.Job#execute(org.quartz.JobExecutionContext)
	 */
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		try {
			JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
			String root = jobDataMap.getString("file.root");
			String container = jobDataMap.getString("file.container");
			String extension = jobDataMap.getString("file.extension");
			String hdfsRoot = jobDataMap.getString("hdfs.root");
			Collection<File> files = listFiles(root, container, extension);
			List<String> filepaths = new ArrayList<>();
			for (File file : files) {
				String dest = generateRemotePath(file, hdfsRoot, root);
				System.out.println(dest);
				boolean result = hadoopService.uploadFileToHdfs(file.getAbsolutePath(), dest);
				if (result) {
					log.info("file upload:{}", file.getAbsolutePath());
					file.delete();
					filepaths.add(file.getAbsolutePath());
				}
			}
			clearEmptyFolder(root, container);
			publisher.publishEvent(new UploadRecord(filepaths));
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
		}
	}

	/**
	 * @param root
	 * @param container
	 * @param extension
	 * @return
	 */
	private Collection<File> listFiles(String root, String container, String extension) {
		File rootFile = new File(root + File.separator + container);
		Collection<File> files = FileUtils.listFiles(rootFile, new IOFileFilter() {

			@Override
			public boolean accept(File dir, String name) {
				return true;
			}

			@Override
			public boolean accept(File file) {
				if (file.getName().startsWith("~")) {
					return false;
				}
				File t = new File(file.getParentFile(), "~" + file.getName());
				if (t.exists()) {
					return false;
				}
				if (file.getName().endsWith(extension)) {
					return true;
				}
				return false;
			}
		}, filter);
		return files;
	}

	private String generateRemotePath(File file, String hdfsRoot, String root) {
		String src = file.getAbsolutePath();
		String temp = src.substring(root.length());
		String dest = hdfsRoot + temp;
		return dest.replaceAll("\\\\", "/");
	}

	/**
	 * @param root
	 * @param folder
	 */
	private void clearEmptyFolder(String root, String folder) {
		Collection<File> files = FileUtils.listFilesAndDirs(new File(root + File.separator + folder), DirectoryFileFilter.DIRECTORY,
				DirectoryFileFilter.DIRECTORY);
		for (File file : files) {
			if (file.listFiles().length == 0) {
				file.delete();
				System.out.println(file.getAbsolutePath());
			}
		}
	}

}
