package com.hirain.phm.bode.server.bus;

public class SSLEntity {

	private String caCrt;

	private String crt;

	private String key;

	private String password;

	public String getCaCrt() {
		return caCrt;
	}

	public void setCaCrt(String caCrt) {
		this.caCrt = caCrt;
	}

	public String getCrt() {
		return crt;
	}

	public void setCrt(String crt) {
		this.crt = crt;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}