package com.hirain.phm.bode.server.mqtt;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MqttHandler implements MqttCallbackExtended {

	private String name = "";

	public MqttHandler(String name) {
		this.name = name;
	}

	public MqttHandler() {
	}

	@Override
	public void connectionLost(Throwable cause) {
		cause.printStackTrace();
	}

	@Override
	public void messageArrived(String topic, MqttMessage message) throws Exception {
		System.out.println("class:" + name + " topic:" + topic + " message:" + new String(message.getPayload()));
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken token) {
		System.out.println("deliveryComplete");
	}

	@Override
	public void connectComplete(boolean reconnect, String serverURI) {
		System.out.println("connect " + serverURI);
	}

}
