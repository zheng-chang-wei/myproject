package com.hirain.phm.bode.server.server;

import java.nio.ByteBuffer;
import java.util.List;

import com.hirain.phm.bode.server.comm.ITransportPacket;
import com.hirain.phm.bode.server.comm.impl.TransportPacketImpl;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.socket.DatagramPacket;
import io.netty.handler.codec.MessageToMessageCodec;

class MDCUMessageCodec extends MessageToMessageCodec<DatagramPacket, ITransportPacket> {

	@Override
	protected void decode(ChannelHandlerContext ctx, DatagramPacket msg, List<Object> out) throws Exception {
		if (msg.content().readableBytes() < 32) {
			return;
		}
		final ByteBuf buf = msg.content();
		final byte[] bs = new byte[32];
		buf.readBytes(bs);
		final ITransportPacket packet = new TransportPacketImpl();
		packet.setData(bs);
		packet.setPid(ServerConstant.DOOR_MESSAGE_PID);
		packet.setLength(bs.length);
		packet.setAddress(msg.sender());
		out.add(packet);
	}

	@Override
	protected void encode(ChannelHandlerContext ctx, ITransportPacket packet, List<Object> out) throws Exception {
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		final DatagramPacket datagramPacket = new DatagramPacket(Unpooled.copiedBuffer(buffer.array()), packet.getAddress());
		ctx.writeAndFlush(datagramPacket);
	}

}
