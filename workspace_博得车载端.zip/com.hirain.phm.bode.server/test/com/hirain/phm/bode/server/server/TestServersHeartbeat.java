/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.server.server;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.lf5.util.DateFormatManager;
import org.junit.Test;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.impl.Car;
import com.hirain.phm.bode.core.impl.Door;
import com.hirain.phm.bode.core.impl.Train;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Mar 26, 2019 4:01:12 PM
 * @Description
 *              <p>
 *              测试两个服务器之间的心跳通信
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Mar 26, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class TestServersHeartbeat {

	// @Before
	// public void setUp() {
	// final ServerServerMock mock = new ServerServerMock();
	// mock.start();
	// }

	public static void main(String[] args) {
		final ServerServerMock mock = new ServerServerMock();
		mock.start();
	}

	@Test
	public void testInquireLostMessage() {
		ServerHeartbeatHandler handler = new ServerHeartbeatHandler();
		ITrain train = new Train();
		List<ICar> cars = new ArrayList<ICar>();
		ICar car1 = new Car();
		car1.setIndex(-1);
		cars.add(car1);
		ICar car2 = new Car();
		car2.setIndex(0);
		cars.add(car2);
		ICar car3 = new Car();
		car3.setIndex(1);
		cars.add(car3);
		List<IDoor> doors = new ArrayList<IDoor>();
		IDoor door1 = new Door();
		door1.setAddr(1);
		doors.add(door1);
		car3.setDoors(doors);
		train.setCars(cars);
		handler.setTrain(train);
		handler.setOffLine_startTime(1552010185387L);
		handler.setOffLine_endTime(1552010186387L);
		handler.inquireLostMessage();
	}

	@Test
	public void testTime() throws ParseException {
		DateFormatManager dateFormatManager = new DateFormatManager("yyyy-MM-dd HH:mm:ss SSS");
		Date date = dateFormatManager.getDateFormatInstance().parse("2019-03-06 20:07:50 387");
		System.out.println(date.getTime());
	}

}
