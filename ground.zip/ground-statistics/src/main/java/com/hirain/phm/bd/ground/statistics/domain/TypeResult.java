package com.hirain.phm.bd.ground.statistics.domain;

import lombok.Data;

@Data
public class TypeResult {

	private String type;

	private Integer percent;
}
