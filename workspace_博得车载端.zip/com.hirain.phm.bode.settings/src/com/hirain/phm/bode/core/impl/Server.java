/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.impl;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.hirain.phm.bode.core.IServer;
import com.hirain.phm.bode.core.IServerIp;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 4:26:55 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
@XmlRootElement(name = "Server")
@XmlType(propOrder = { "serverIps", "gateWay" })
@XmlAccessorType(XmlAccessType.FIELD)
public class Server implements IServer {

	@XmlElement(name = "ip", required = true, type = ServerIp.class)
	private List<IServerIp> serverIps;

	@XmlElement(name = "gateWay", required = true)
	private String gateWay;

	@Override
	public void setGateWay(String gateWay) {
		this.gateWay = gateWay;
	}

	@Override
	public String getGateWay() {
		return gateWay;
	}

	@Override
	public List<IServerIp> getServesIps() {
		if (serverIps == null) {
			serverIps = new ArrayList<IServerIp>();
		}
		return this.serverIps;
	}

	public void setServerIps(List<IServerIp> serverIps) {
		this.serverIps = serverIps;
	}
}
