package com.hirain.phm.bode.client.communication.service;

import java.util.Arrays;

import com.hirain.phm.bode.client.communication.transport.IConnection;
import com.hirain.phm.bode.client.communication.transport.IConnectionFactory;
import com.hirain.phm.bode.client.communication.transport.IDecoder;
import com.hirain.phm.bode.client.communication.transport.impl.UDPConnection;

public class ServiceConnectionFactory implements IConnectionFactory {

	private IDecoder decoder;

	public ServiceConnectionFactory(IDecoder decoder) {
		this.decoder = decoder;
	}

	@Override
	public IConnection create(int port) {
		// TODO 区分编解码器
		IConnection connection = new UDPConnection(port, Arrays.asList(new MessageCodec(), new ServiceHandler(decoder)));
		return connection;
	}

}
