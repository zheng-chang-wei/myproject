package com.hirain.phm.bode.server.mqtt;

public interface MqttPublisher {

	public void send(String topic, byte[] payload) throws Exception;

	public void send(String topic, byte[] payload, int qos, boolean retained) throws Exception;

	public void sendAsync(String topic, byte[] payload);

	boolean isConnected();
}
