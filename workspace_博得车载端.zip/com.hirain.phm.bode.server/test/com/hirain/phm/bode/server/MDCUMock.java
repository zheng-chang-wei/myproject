package com.hirain.phm.bode.server;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import com.hirain.phm.bode.server.server.ServerConstant;

public class MDCUMock {

	DatagramSocket mdcu = null;

	private ExecutorService executor;

	public static void main(String[] args) throws IOException, InterruptedException {
		new MDCUMock().start(true);
	}

	public void start(boolean loop) throws IOException, InterruptedException {
		mdcu = new DatagramSocket(ServerConstant.TO_MDCU_PORT);
		executor = Executors.newSingleThreadExecutor();
		executor.submit(() -> {
			final String filepath = "C:\\Users\\changwei.zheng\\Desktop\\phm_data.txt";
			InputStreamReader reader = null;
			BufferedReader br = null;
			try {
				while (true) {
					final DatagramPacket ok = new DatagramPacket(new byte[100], 100);
					mdcu.receive(ok);
					final SocketAddress sender = ok.getSocketAddress();
					System.out.println(sender);
					reader = new InputStreamReader(new FileInputStream(filepath));
					br = new BufferedReader(reader);
					if (loop) {
						sendLoop(br, sender);
					} else {
						send(br, sender);
					}
				}
			} catch (final IOException e) {
				e.printStackTrace();
			} catch (final InterruptedException e) {
				e.printStackTrace();
			} finally {
				if (br != null) {
					try {
						br.close();
					} catch (final IOException e) {
						e.printStackTrace();
					}
				}
				if (reader != null) {
					try {
						reader.close();
					} catch (final IOException e) {
						e.printStackTrace();
					}
				}
			}
		});
	}

	void send(BufferedReader br, SocketAddress sender) throws IOException, InterruptedException {
		int lastSeq = -1;
		for (int i = 0; i < 500; i++) {
			final String line = br.readLine();
			final byte[] datas = convertLine2Bytes(line);
			datas[12] = 0x18;
			if (lastSeq != -1) {
				final int seq = datas[0];
				final int devide = between(seq, lastSeq);
				System.out.println(devide);
				TimeUnit.MILLISECONDS.sleep(50 * devide);
				lastSeq = seq;
			} else {
				lastSeq = datas[0];
			}
			final DatagramPacket packet = new DatagramPacket(datas, datas.length);
			packet.setSocketAddress(sender);
			mdcu.send(packet);
		}
	}

	void sendLoop(BufferedReader br, SocketAddress sender) throws IOException, InterruptedException {
		int lastSeq = -1;
		while (true) {
			final String line = br.readLine();
			byte[] datas;
			if (line != null) {
				datas = convertLine2Bytes(line);
			} else {
				break;
			}
			if (lastSeq != -1) {
				final byte seq = datas[0];
				final int d = between(seq, lastSeq);
				TimeUnit.MILLISECONDS.sleep(50 * d);
				lastSeq = seq;
			} else {
				lastSeq = datas[0];
			}
			datas[12] = 0x18;
			final DatagramPacket packet = new DatagramPacket(datas, datas.length);
			packet.setSocketAddress(sender);
			mdcu.send(packet);
			// datas[12] = 0x1A;
			// final DatagramPacket packet2 = new DatagramPacket(datas, datas.length);
			// packet2.setSocketAddress(sender);
			// mdcu.send(packet2);
			// TimeUnit.MILLISECONDS.sleep(50);
		}
	}

	public int between(int seq, int last) {
		if (seq > last) {
			return seq - last;
		} else {
			return seq + 16 - last;
		}
	}

	public void stop() {
		if (executor != null) {
			executor.shutdown();
			executor = null;
		}
		if (mdcu != null) {
			mdcu.close();
		}
	}

	public byte[] convertLine2Bytes(String line) {
		final byte[] result = new byte[32];
		int index = 0;
		for (int i = 0; i < line.length() - 1; i = i + 2) {
			final String n = line.substring(i, i + 2);
			final int r = Integer.parseInt(n, 16);
			result[index] = (byte) r;
			index++;
		}
		return result;
	}

}
