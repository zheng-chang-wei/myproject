/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.server.life;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created May 30, 2019 5:10:34 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               May 30, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DoorLifeProcessor {

	private int lastOpenBit = 1;

	private int lastClosedBit = 1;

	private int lastInsulateBit = 1;

	private int lastEmergencyUnlock = 1;

	private int lastLockSwitch = 1;

	/**
	 * 判断门是否开好
	 */
	public boolean checkDoorOpend(int openBit) {
		if (lastOpenBit == 0 && openBit == 1) {
			lastOpenBit = openBit;
			return true;
		}
		lastOpenBit = openBit;
		return false;
	}

	/**
	 * 判断门是否关好
	 */
	public boolean checkClosed(int closeBit) {
		if (lastClosedBit == 0 && closeBit == 1) {
			lastClosedBit = closeBit;
			return true;
		}
		lastClosedBit = closeBit;
		return false;
	}

	/**
	 * 判断是否是门隔离状态
	 */
	public boolean checkIsulated(int insulateBit) {
		if (lastInsulateBit == 0 && insulateBit == 1) {
			lastInsulateBit = insulateBit;
			return true;
		}
		lastInsulateBit = insulateBit;
		return false;
	}

	/**
	 * 判断是否是紧急解锁状态
	 */
	public boolean checkEmergencyUnlock(int emergencyUnlock) {
		if (lastEmergencyUnlock == 0 && emergencyUnlock == 1) {
			lastEmergencyUnlock = emergencyUnlock;
			return true;
		}
		return false;
	}

	/**
	 * 判断锁闭开关是否有变化
	 */
	public boolean checkLockSwitch(int lockSwitch) {
		if (lastLockSwitch != lockSwitch) {
			lastLockSwitch = lockSwitch;
			return true;
		}
		return false;
	}

}
