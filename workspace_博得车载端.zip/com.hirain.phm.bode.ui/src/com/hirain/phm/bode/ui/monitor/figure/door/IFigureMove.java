package com.hirain.phm.bode.ui.monitor.figure.door;

public interface IFigureMove {

	void moveToRight();

	void moveToLeft();

}
