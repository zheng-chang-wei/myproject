/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.systemsetting;

import java.io.File;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.draw2d.FigureCanvas;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;

import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.ICarInfo;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.IMdcu;
import com.hirain.phm.bode.core.IServer;
import com.hirain.phm.bode.core.IServerIp;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.exception.SystemInfoException;
import com.hirain.phm.bode.core.impl.Car;
import com.hirain.phm.bode.core.impl.Door;
import com.hirain.phm.bode.core.impl.Mdcu;
import com.hirain.phm.bode.core.impl.Server;
import com.hirain.phm.bode.core.impl.ServerIp;
import com.hirain.phm.bode.core.impl.ServerIpType;
import com.hirain.phm.bode.core.impl.Train;
import com.hirain.phm.bode.core.util.MarshalUtil;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.core.util.SystemInfoUtil;
import com.hirain.phm.bode.ui.listener.RefreshCarNumAndDoorAddressListenerManager;
import com.hirain.phm.bode.ui.listener.TopShowListenerManager;
import com.hirain.phm.bode.ui.monitor.TrainManager;
import com.hirain.phm.bode.ui.monitor.figure.carriage.TrainFigure;
import com.hirain.phm.bode.ui.monitor.listener.DoorCheckedListener;
import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;
import com.hirain.phm.bode.ui.systemsetting.dialog.CarNameConfigDialog;
import com.hirain.phm.bode.ui.systemsetting.dialog.DoorAddressConfigDialog;
import com.hirain.phm.bode.ui.systemsetting.dialog.MDCUConfigDialog;
import com.hirain.phm.bode.ui.systemsetting.utils.PatternUtil;
import com.hirain.phm.bode.ui.util.ShowModuleEnum;
import com.hirain.phm.bode.ui.util.UIConstants;
import com.hirain.phm.bode.ui.util.UIUtilMethod;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 4, 2019 4:37:16 PM
 * @Description
 *              <p>
 *              系统配置界面
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 4, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class SystemSettingPart implements DoorCheckedListener {

	private static SystemSettingPart systemSettingPart;

	private final String DEFAULT_FONT = "Microsoft YaHei UI";

	private boolean init = false;

	private boolean configSuccess = false;// 向下发送系统配置信息是否成功

	private static ITrain train;

	private static ITrain originalTrain;

	private Train customizeTrain = new Train();

	private Button xmlBrowseBtn;

	private Button sureBtn;

	private Button applicationSetBtn;

	private Button cancelBtn;

	private Button clearBtn;

	private Button exportBtn;

	private Button importBtn;

	private Text xmlText;

	private Text cityNameText;

	private Text lineNameText;

	private Text localIPText;

	private Text trainNoText;

	private Text oppositeIPText;

	private Combo carAmountCombo;

	private Combo doorAmountCombo;

	private Text wirelessIPText_1;

	private Text wirelessIPText_2;

	private final StorageState storageState = new StorageState();

	private Label totalSpace_lab;

	private Label usedSpace_Lab;

	private Label errorInfo_Lab;

	private Group doorInfoGroup;

	private FigureCanvas topologicalCanvas;

	private SystemSettingPart() {
	}

	public static SystemSettingPart getInstance() {
		if (systemSettingPart == null) {
			systemSettingPart = new SystemSettingPart();
		}
		train = TrainManager.getInstance().getTrain();
		if (train != null) {
			originalTrain = new Train();
			copyTrain(train, originalTrain);
		}
		return systemSettingPart;
	}

	public void postConstruct(final Composite parent) {
		parent.setLayout(new GridLayout(2, true));
		parent.setBackground(SWTResourceManager.getColor(181, 181, 181));

		Composite xmlCom = new Composite(parent, SWT.NONE);
		GridData gd = new GridData();
		gd.horizontalAlignment = GridData.END;
		gd.horizontalSpan = 2;
		xmlCom.setLayoutData(gd);
		xmlCom.setLayout(new GridLayout(5, false));

		createXMLArea(xmlCom);

		doorInfoGroup = new Group(parent, SWT.NONE);
		doorInfoGroup.setText("门信息设置");
		doorInfoGroup.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 11, SWT.NORMAL));
		doorInfoGroup.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		doorInfoGroup.setBackground(CarriageConstants.doorInfoConfigBackgroundColor);

		Group baseInfoGroup = new Group(parent, SWT.NONE);
		baseInfoGroup.setText("基本信息设置");
		baseInfoGroup.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 11, SWT.NORMAL));
		baseInfoGroup.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		Group communicationGroup = new Group(parent, SWT.NONE);
		communicationGroup.setText("通信设置");
		communicationGroup.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 11, SWT.NORMAL));
		communicationGroup.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		Group storageSpaceGroup = new Group(parent, SWT.NONE);
		storageSpaceGroup.setText("存储空间");
		storageSpaceGroup.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 11, SWT.NORMAL));
		storageSpaceGroup.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));

		Composite buttonBarCom = new Composite(parent, SWT.NONE);
		buttonBarCom.setLayoutData(new GridData(GridData.CENTER, SWT.FILL, false, false, 2, 1));
		buttonBarCom.setLayout(new GridLayout(5, true));

		createDoorInfoArea();
		createBaseInfoArea(baseInfoGroup);
		createCommunicationArea(communicationGroup);
		createStorageArea(storageSpaceGroup);
		createButtonBar(buttonBarCom);

		errorInfo_Lab = new Label(parent, SWT.NONE);
		errorInfo_Lab.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		if (train != null) {
			initUIInfo(train);
		}

		initListener();
		init = true;
	}

	public boolean isInit() {
		return init;
	}

	public StorageState getStorageState() {
		return storageState;
	}

	/**
	 * 右上角导入xml文件区域
	 */
	private void createXMLArea(Composite parent) {
		Label xmlLb = new Label(parent, SWT.NONE);
		xmlLb.setText("导入xml设置文件：");

		xmlText = new Text(parent, SWT.BORDER | SWT.READ_ONLY);
		GridData xmlGd = new GridData();
		xmlGd.horizontalSpan = 2;
		xmlGd.widthHint = 200;
		xmlText.setLayoutData(xmlGd);

		xmlBrowseBtn = new Button(parent, SWT.NONE);
		xmlBrowseBtn.setText("浏览…");

		importBtn = new Button(parent, SWT.NONE);
		importBtn.setText("导入");
		importBtn.setEnabled(!StringUtil.isEmpty(xmlText.getText()));
	}

	/**
	 * 基本信息设置区域，包括：城市名称、线路名称、列车编号、车厢车门数量
	 */
	private void createBaseInfoArea(Composite parent) {
		parent.setLayout(new GridLayout(2, true));
		GridData gd = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		{
			Composite composite_1 = new Composite(parent, SWT.NONE);
			composite_1.setLayoutData(new GridData(GridData.FILL_BOTH));
			composite_1.setLayout(new GridLayout(2, false));

			Label cityNameLb = new Label(composite_1, SWT.NONE);
			cityNameLb.setText("城市名称：");
			cityNameText = new Text(composite_1, SWT.BORDER | SWT.READ_ONLY);
			cityNameText.setLayoutData(gd);
			cityNameText.setEnabled(false);

			Label lineNameLb = new Label(composite_1, SWT.NONE);
			lineNameLb.setText("线路名称：");
			lineNameText = new Text(composite_1, SWT.BORDER);
			lineNameText.setLayoutData(gd);
			lineNameText.setTextLimit(3);
			lineNameText.setToolTipText("可输入1~254的整数");
		}

		{
			Composite composite_2 = new Composite(parent, SWT.NONE);
			composite_2.setLayoutData(new GridData(GridData.FILL_BOTH));
			composite_2.setLayout(new GridLayout(4, false));

			Label trainNoLb = new Label(composite_2, SWT.NONE);
			trainNoLb.setText("列车编号：");
			trainNoText = new Text(composite_2, SWT.BORDER);
			trainNoText.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 3, 1));

			Label carAmountLb = new Label(composite_2, SWT.NONE);
			carAmountLb.setText("车厢数量：");
			carAmountCombo = new Combo(composite_2, SWT.BORDER | SWT.READ_ONLY);
			carAmountCombo.setLayoutData(gd);
			carAmountCombo.setItems(UIConstants.CAR_AMOUNTS);
			carAmountCombo.select(0);

			Label doorAmountLb = new Label(composite_2, SWT.NONE);
			doorAmountLb.setText("车厢门数：");
			doorAmountCombo = new Combo(composite_2, SWT.BORDER | SWT.READ_ONLY);
			doorAmountCombo.setLayoutData(gd);
			doorAmountCombo.setItems(UIConstants.DOOR_AMOUNTS);
			doorAmountCombo.select(0);
		}
	}

	/**
	 * 通信设置区域
	 */
	private void createCommunicationArea(Composite parent) {
		parent.setLayout(new GridLayout(2, true));
		GridData gd = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		{
			Composite composite_3 = new Composite(parent, SWT.NONE);
			composite_3.setLayoutData(new GridData(GridData.FILL_BOTH));
			composite_3.setLayout(new GridLayout(2, false));

			Label localIPLb = new Label(composite_3, SWT.NONE);
			localIPLb.setText("本机IP地址：");
			localIPText = new Text(composite_3, SWT.BORDER);
			localIPText.setLayoutData(gd);

			Label oppositeIPLb = new Label(composite_3, SWT.NONE);
			oppositeIPLb.setText("对端IP地址：");
			oppositeIPText = new Text(composite_3, SWT.BORDER);
			oppositeIPText.setLayoutData(gd);
		}
		{
			Composite composite_4 = new Composite(parent, SWT.NONE);
			composite_4.setLayoutData(new GridData(GridData.FILL_BOTH));
			composite_4.setLayout(new GridLayout(2, false));

			Label wirelessIPLb_1 = new Label(composite_4, SWT.NONE);
			wirelessIPLb_1.setText("无线网关IP地址1：");
			wirelessIPText_1 = new Text(composite_4, SWT.BORDER);
			wirelessIPText_1.setLayoutData(gd);

			Label wirelessIPLb_2 = new Label(composite_4, SWT.NONE);
			wirelessIPLb_2.setText("无线网关IP地址2：");
			wirelessIPText_2 = new Text(composite_4, SWT.BORDER);
			wirelessIPText_2.setLayoutData(gd);
		}

	}

	private void createStorageArea(Composite parent) {
		parent.setLayout(new GridLayout(3, true));

		totalSpace_lab = new Label(parent, SWT.NONE);
		totalSpace_lab.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 11, SWT.NORMAL));

		StorageFigure.getFigure(storageState).createCanvasComp(parent);

		usedSpace_Lab = new Label(parent, SWT.NONE);
		usedSpace_Lab.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 11, SWT.NORMAL));

		refreshStorageCanvas();

	}

	private void createDoorInfoArea() {
		doorInfoGroup.setLayout(new GridLayout());
		topologicalCanvas = new FigureCanvas(doorInfoGroup) {

			@Override
			public boolean setFocus() {
				return false;
			}
		};
	}

	private void initUIInfo(ITrain train) {
		copyTrain(train, customizeTrain);
		refreshFigure(train);
		refreshTextInfo(train);
	}

	/**
	 * 刷新车厢、车门信息区域
	 * 
	 * @param train
	 */
	public void refreshFigure(ITrain train) {
		copyTrain(train, customizeTrain);
		TrainFigure trainFigure = new TrainFigure(train, true);
		if (topologicalCanvas.isDisposed()) {
			topologicalCanvas = new FigureCanvas(doorInfoGroup) {

				@Override
				public boolean setFocus() {
					return false;
				}
			};
		}
		topologicalCanvas.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, true));
		topologicalCanvas.setContents(trainFigure);
		doorInfoGroup.layout();
		doorInfoGroup.getParent().layout();
	}

	/**
	 * 刷新下方文本区域
	 * 
	 * @param train
	 */
	public void refreshTextInfo(ITrain train) {
		String cityName = train.getCityName();
		if (StringUtil.isNotEmpty(cityName)) {
			cityNameText.setText(cityName);
		}
		String trainNo = train.getTrainNo();
		if (StringUtil.isNotEmpty(trainNo)) {
			trainNoText.setText(trainNo);
		}
		String lineName = String.valueOf(train.getLineName());
		if (StringUtil.isNotEmpty(lineName)) {
			lineNameText.setText(lineName);
		}
		String carNum = String.valueOf(train.getCarInfo().getCarNum());
		if (StringUtil.isNotEmpty(carNum)) {
			carAmountCombo.setText(carNum);
		}
		String gateNum = String.valueOf(train.getCarInfo().getGateNum());
		if (StringUtil.isNotEmpty(gateNum)) {
			doorAmountCombo.setText(gateNum);
		}
		String localIp = train.getServers().get(0).getServesIps().get(0).getIp();
		if (StringUtil.isNotEmpty(localIp)) {
			localIPText.setText(localIp);
		}
		String oppositeIp = train.getServers().get(1).getServesIps().get(0).getIp();
		if (StringUtil.isNotEmpty(oppositeIp)) {
			oppositeIPText.setText(oppositeIp);
		}
		String gateWay1 = train.getServers().get(0).getGateWay();
		if (StringUtil.isNotEmpty(gateWay1)) {
			wirelessIPText_1.setText(gateWay1);
		}
		String gateWay2 = train.getServers().get(1).getGateWay();
		if (StringUtil.isNotEmpty(gateWay2)) {
			wirelessIPText_2.setText(gateWay2);
		}
	}

	/**
	 * 创建最下方一排按钮区域
	 */
	private void createButtonBar(Composite parent) {
		sureBtn = new Button(parent, SWT.NONE);
		sureBtn.setText("确定");
		sureBtn.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));

		applicationSetBtn = new Button(parent, SWT.NONE);
		applicationSetBtn.setText("应用设置");
		applicationSetBtn.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));

		cancelBtn = new Button(parent, SWT.NONE);
		cancelBtn.setText("取消");
		cancelBtn.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));

		clearBtn = new Button(parent, SWT.NONE);
		clearBtn.setText("清除设置");
		clearBtn.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));

		exportBtn = new Button(parent, SWT.NONE);
		exportBtn.setText("导出xml");
		exportBtn.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		setButtonEnable(checkInfoCorrect());
	}

	private void initListener() {
		xmlText.addModifyListener(e -> {
			importBtn.setEnabled(!StringUtil.isEmpty(xmlText.getText()));
		});
		xmlBrowseBtn.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			final FileDialog fileDialog = new FileDialog(Display.getDefault().getActiveShell());
			fileDialog.setFilterExtensions(new String[] { "*.xml" });
			final String path = fileDialog.open();
			if (StringUtil.isNotEmpty(path)) {
				xmlText.setText(path);
			}
		}));
		importBtn.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			try {
				train = TrainManager.getInstance().load(xmlText.getText());
				// 校验xml文件的有效性
				if (train != null) {
					SystemInfoUtil.vaildModel(train);
					copyTrain(train, customizeTrain);
					updateUIInfo(train);
					refreshFigure(train);
				}
			} catch (Exception e) {
				if (e instanceof SystemInfoException) {
					MessageDialog.openError(null, "系统配置XML文件有误", ((SystemInfoException) e).getDescription());
				} else {
					MessageDialog.openError(null, "xml文件格式不正确", "xml文件格式不正确，请修改");
				}
				e.printStackTrace();
			}
		}));
		sureBtn.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			if (applicationSetBtn.isEnabled()) {// 说明还没有配置，需要先执行配置操作，即applicationSetBtn按下的操作，再进入监控页面
				boolean checkInfoCorrect = checkInfoCorrect();
				if (checkInfoCorrect) {
					setTrainInfo();
					configTrainProcess();
					if (configSuccess) {
						TrainManager.getInstance().setTrain(customizeTrain);
						RefreshCarNumAndDoorAddressListenerManager.getInstatnce().refreshCarNumAndDoorAddr();
						if (originalTrain != null) {
							copyTrain(customizeTrain, originalTrain);
						}
						configSuccess = false;
						TopShowListenerManager.getInstance().notifyChanged(ShowModuleEnum.ONLINE_MONITOR);
					}
				}
			} else {// 说明已经向服务端配置过了,直接跳转到监控页面
				TopShowListenerManager.getInstance().notifyChanged(ShowModuleEnum.ONLINE_MONITOR);
			}
		}));
		applicationSetBtn.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			boolean checkInfoCorrect = checkInfoCorrect();
			if (checkInfoCorrect) {
				setTrainInfo();
				configTrainProcess();
				if (configSuccess) {
					TrainManager.getInstance().setTrain(customizeTrain);
					RefreshCarNumAndDoorAddressListenerManager.getInstatnce().refreshCarNumAndDoorAddr();
					if (originalTrain != null) {
						copyTrain(customizeTrain, originalTrain);
					}
					MessageDialog.openInformation(Display.getDefault().getActiveShell(), "提示", "配置成功");
					configSuccess = false;
					applicationSetBtn.setEnabled(false);
				}
			}
		}));
		cancelBtn.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			TrainManager.getInstance().setTrain(originalTrain);
			if (originalTrain != null) {
				// 点击“取消”按钮，则直接退出设置界面，重新回到默认的监控界面
				TopShowListenerManager.getInstance().notifyChanged(ShowModuleEnum.ONLINE_MONITOR);
			} else {

			}
		}));
		clearBtn.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			clearUIInfo();
			topologicalCanvas.dispose();
			doorInfoGroup.layout();
			doorInfoGroup.getParent().layout();
			train = null;
		}));
		exportBtn.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			final FileDialog fileSaveDialog = new FileDialog(Display.getDefault().getActiveShell(), SWT.SAVE);
			fileSaveDialog.setFilterExtensions(new String[] { "*.xml" });
			fileSaveDialog.setText("导出系统配置文件");
			final String pathSave = fileSaveDialog.open();
			if (pathSave == null) {
				return;
			}

			final File newFile = new File(pathSave);
			if (newFile.exists()) {// 判断文件是否存在
				if (!MessageDialog.openConfirm(Display.getDefault().getActiveShell(), "提示", "文件已存在，是否覆盖源文件")) {
					return;
				}
			}
			try {
				// final ITrain train = MCTUIUtil.getActiveProjectModel();
				MarshalUtil.marshalToXml(customizeTrain, pathSave);
				MessageDialog.openInformation(null, "提示", "成功导出配置文件到 " + StringUtil.LINE_SEPARATOR + pathSave);
			} catch (final Exception e) {
				e.printStackTrace();
				final File file = new File(pathSave);
				if (file.exists()) {
					file.delete();
				}
				MessageDialog.openInformation(null, "失败", "导出失败");
				return;
			}
		}));
		carAmountCombo.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			Integer carCount = Integer.valueOf(carAmountCombo.getText()) + 2;
			Integer doorCount = Integer.valueOf(doorAmountCombo.getText());
			refreshTrain(carCount, doorCount);
			setButtonEnable(checkInfoCorrect());
		}));
		doorAmountCombo.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			Integer carCount = Integer.valueOf(carAmountCombo.getText()) + 2;
			Integer doorCount = Integer.valueOf(doorAmountCombo.getText());
			refreshTrain(carCount, doorCount);
			setButtonEnable(checkInfoCorrect());
		}));

		initEditListener();
	}

	private void setTrainInfo() {
		// copyTrain(train, customizeTrain);
		String cityName = cityNameText.getText();
		String lineName = lineNameText.getText();
		String trainNo = trainNoText.getText();
		String carCount = carAmountCombo.getText();
		String doorCount = doorAmountCombo.getText();
		String localIP = localIPText.getText();
		String oppositeIp = oppositeIPText.getText();
		String wirelessIP_1 = wirelessIPText_1.getText();
		String wirelessIP_2 = wirelessIPText_2.getText();
		List<IServer> servers = customizeTrain.getServers();
		customizeTrain.setCityName(cityName);
		customizeTrain.setLineName(Integer.valueOf(lineName));
		customizeTrain.setTrainNo(trainNo);
		ICarInfo carInfo = customizeTrain.getCarInfo();
		carInfo.setCarNum(Integer.valueOf(carCount));
		carInfo.setGateNum(Integer.valueOf(doorCount));
		servers.get(0).getServesIps().get(0).setIp(localIP);
		servers.get(0).getServesIps().get(1).setIp(localIP);
		servers.get(1).getServesIps().get(0).setIp(oppositeIp);
		servers.get(1).getServesIps().get(1).setIp(oppositeIp);
		servers.get(0).setGateWay(wirelessIP_1);
		servers.get(1).setGateWay(wirelessIP_2);
	}

	private void initEditListener() {
		ModifyListener modifyListener = e -> {
			setButtonEnable(checkInfoCorrect());
		};
		lineNameText.addModifyListener(modifyListener);
		trainNoText.addModifyListener(modifyListener);
		localIPText.addModifyListener(modifyListener);
		oppositeIPText.addModifyListener(modifyListener);
		wirelessIPText_1.addModifyListener(modifyListener);
		wirelessIPText_2.addModifyListener(modifyListener);

		lineNameText.addVerifyListener(PatternUtil.numVerifyListener);
		localIPText.addVerifyListener(PatternUtil.ipVerifyListener);
		oppositeIPText.addVerifyListener(PatternUtil.ipVerifyListener);
		wirelessIPText_1.addVerifyListener(PatternUtil.ipVerifyListener);
		wirelessIPText_2.addVerifyListener(PatternUtil.ipVerifyListener);
	}

	/**
	 * 校验所填信息的合法性
	 * 
	 * @return
	 */
	private boolean checkInfoCorrect() {
		String lineName = lineNameText.getText().trim();
		if (!isNumberic(lineName)) {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, "线路名称 只能为数字");
			return false;
		}
		if (StringUtil.isNotEmpty(lineName) && (Integer.valueOf(lineName) >= 255 || Integer.valueOf(lineName) < 0)) {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, "线路名称 超出范围(正常范围：1~254)");
			return false;
		}
		if (StringUtil.isEmpty(lineName)) {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, "线路名称不能为空");
			return false;
		}
		if (StringUtil.isEmpty(trainNoText.getText())) {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, "列车编号不能为空");
			return false;
		}
		if (localIPText != null && !UIUtilMethod.verfityIp(localIPText.getText().trim())) {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, "本机IP地址 有误");
			return false;
		}
		if (oppositeIPText != null && !UIUtilMethod.verfityIp(oppositeIPText.getText().trim())) {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, "对端IP地址 有误");
			return false;
		}
		if (localIPText != null && oppositeIPText != null && localIPText.getText().trim().equals(oppositeIPText.getText().trim())) {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, "本机IP 和 对端IP 不能相同");
			return false;
		}
		if (wirelessIPText_1 != null && !UIUtilMethod.verfityIp(wirelessIPText_1.getText().trim())) {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, "无线网关IP地址1 有误");
			return false;
		}
		if (wirelessIPText_2 != null && !UIUtilMethod.verfityIp(wirelessIPText_2.getText().trim())) {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, "无线网关IP地址2 有误");
			return false;
		}
		if (wirelessIPText_1 != null && wirelessIPText_2 != null && wirelessIPText_1.getText().trim().equals(wirelessIPText_2.getText().trim())) {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, "无线网关IP地址1 和 无线网关IP地址2 不能相同");
			return false;
		}
		if (!checkTrain()) {
			return false;
		}
		boolean result = StringUtil.isNotEmpty(lineNameText.getText()) && StringUtil.isNotEmpty(trainNoText.getText())
				&& StringUtil.isNotEmpty(carAmountCombo.getText()) && StringUtil.isNotEmpty(doorAmountCombo.getText())
				&& StringUtil.isNotEmpty(localIPText.getText()) && StringUtil.isNotEmpty(oppositeIPText.getText())
				&& StringUtil.isNotEmpty(wirelessIPText_1.getText()) && StringUtil.isNotEmpty(wirelessIPText_2.getText());

		if (result) {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, StringUtil.EMPTY);
			return true;
		}
		return false;
	}

	/**
	 * 判断内容是否为纯数字
	 */
	private boolean isNumberic(String str) {
		Pattern pattern = Pattern.compile("^?[\\d]*$");
		return pattern.matcher(str).matches();
	}

	/**
	 * 向服务端配置系统信息的过程
	 */
	private void configTrainProcess() {
		final ProgressMonitorDialog monitorDialog = new ProgressMonitorDialog(Display.getDefault().getActiveShell());
		final IRunnableWithProgress runProgress = new IRunnableWithProgress() {

			@Override
			public void run(final IProgressMonitor monitor) {
				monitor.beginTask("正在与地面服务端同步，请稍后……", IProgressMonitor.UNKNOWN);
				// 相应的业务逻辑:向服务端发送配置信息
				try {
					configSuccess = CommunicationService.getInstance().configSystemInfo(SystemInfoUtil.convertSystemInfo2XmlBytes(customizeTrain));
				} catch (Exception e) {
					e.printStackTrace();
				}
				monitor.done();
			}

		};
		try {
			monitorDialog.run(true, false, runProgress);
			if (!configSuccess) {
				monitorDialog.close();
				UIUtilMethod.showCommunicationException();
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 校验车厢信息
	 * 
	 * @return
	 */
	private boolean checkTrain() {
		if (customizeTrain != null) {
			List<ICar> cars = customizeTrain.getCarriages();
			for (ICar iCar : cars) {
				if (iCar.getName() == null) {
					UIUtilMethod.setErrorMessage(errorInfo_Lab, "车厢名称不能为空");
					return false;
				}
				List<IMdcu> mdcus = iCar.getMdcus();
				if (mdcus.size() == 0) {
					UIUtilMethod.setErrorMessage(errorInfo_Lab, iCar.getName() + "车厢的MDCU不能为空");
					return false;
				}
				for (IMdcu mdcu : mdcus) {
					if (StringUtil.isEmpty(mdcu.getIp())) {
						UIUtilMethod.setErrorMessage(errorInfo_Lab, iCar.getName() + "车厢的MDCU不能为空");
						return false;
					}
				}
				List<IDoor> doors = iCar.getDoors();
				for (int i = 0; i < doors.size(); i++) {
					IDoor door = doors.get(i);
					if (door.getAddr() == 0) {
						UIUtilMethod.setErrorMessage(errorInfo_Lab, iCar.getName() + "车厢" + (i + 1) + "号门的门地址不能为空");
						return false;
					}
				}
			}
			return true;
		} else {
			UIUtilMethod.setErrorMessage(errorInfo_Lab, "车厢不能为空");
			return false;
		}
	}

	private void refreshTrain(Integer carCount, Integer doorCount) {

		if (train == null) {
			List<ICar> carList = new ArrayList<>();
			customizeTrain.setCars(carList);
			List<IServer> servers = new ArrayList<>();

			IServer server1 = new Server();
			List<IServerIp> serverIps1 = new ArrayList<>();
			IServerIp serverIp11 = new ServerIp();
			serverIp11.setType(ServerIpType.Type1);
			serverIps1.add(serverIp11);
			IServerIp serverIp12 = new ServerIp();
			serverIp12.setType(ServerIpType.Type2);
			serverIps1.add(serverIp12);
			server1.setServerIps(serverIps1);

			IServer server2 = new Server();
			List<IServerIp> serverIps2 = new ArrayList<>();
			IServerIp serverIp21 = new ServerIp();
			serverIp21.setType(ServerIpType.Type1);
			serverIps2.add(serverIp21);
			IServerIp serverIp22 = new ServerIp();
			serverIp22.setType(ServerIpType.Type2);
			serverIps2.add(serverIp22);
			server2.setServerIps(serverIps2);

			servers.add(server1);
			servers.add(server2);
			customizeTrain.setServers(servers);
			for (int i = 0; i < carCount; i++) {
				ICar car = new Car();
				if (i == 0 || i == 1) {
					car.setIndex(i - 1);
					car.setType((byte) 0);
					car.setName("end");
					List<IDoor> doorList = new ArrayList<>();
					car.setDoors(doorList);
					for (int j = 0; j < 2; j++) {
						Door door = new Door();
						door.setAddr(j + 1);
						doorList.add(door);
					}
				} else {
					car.setType((byte) 1);
					car.setIndex(i - 1);
					car.setName(String.valueOf(i - 1));
					List<IDoor> doorList = new ArrayList<>();
					car.setDoors(doorList);
					List<IMdcu> mdcus = new ArrayList<>();
					mdcus.add(new Mdcu());
					mdcus.add(new Mdcu());
					car.setMdcus(mdcus);
					for (int j = 0; j < doorCount; j++) {
						Door door = new Door();
						door.setAddr(j + 1);
						doorList.add(door);
					}
				}
				carList.add(car);
			}
			train = new Train();
			copyTrain(customizeTrain, train);
		} else {
			copyTrain(train, customizeTrain);
			List<ICar> cars = customizeTrain.getCars();
			int carSize = cars.size();
			if (train.getCars().size() >= carCount) {
				for (int i = 0; i < carSize - carCount; i++) {
					cars.remove(cars.size() - 1);
				}
				for (int i = 2; i < cars.size(); i++) {
					List<IDoor> doors = cars.get(i).getDoors();
					if (doors != null) {
						int doorSize = doors.size();
						if (doorSize > doorCount) {
							for (int j = 0; j < doorSize - doorCount; j++) {
								doors.remove(doors.size() - 1);
							}
						} else if (doorSize < doorCount) {
							for (int j = 0; j < doorCount - doorSize; j++) {
								Door door = new Door();
								door.setAddr(doors.get(doors.size() - 1).getAddr() + 1);
								doors.add(door);
								if (i == cars.size() - 1 && j == doorCount - doorSize - 1) {
									copyTrain(customizeTrain, train);
								}
							}
						} else {
							break;
						}
					}
				}
			} else {
				for (int i = 0; i < carCount - carSize; i++) {
					ICar car = new Car();
					car.setType((byte) 1);
					List<IMdcu> mdcus = new ArrayList<>();
					mdcus.add(new Mdcu());
					mdcus.add(new Mdcu());
					car.setMdcus(mdcus);
					ICar iCar = cars.get(cars.size() - 1);
					car.setIndex(iCar.getIndex() + 1);
					// String name = iCar.getName();
					// if (name.matches("\\d*")) {
					// // car.setName(String.valueOf(Integer.valueOf(name) + 1));
					// } else {
					// // car.setName(name + 1);
					// }
					List<IDoor> doorList = new ArrayList<>();
					car.setDoors(doorList);
					for (int j = 0; j < doorCount; j++) {
						Door door = new Door();
						door.setAddr(j + 1);
						doorList.add(door);
					}
					cars.add(car);
				}
				copyTrain(customizeTrain, train);
			}
		}
		refreshFigure(customizeTrain);
	}

	private static void copyTrain(ITrain srcTrain, ITrain desTrain) {
		ICarInfo carInfo = srcTrain.getCarInfo();
		String cityName = srcTrain.getCityName();
		Integer lineName = srcTrain.getLineName();
		List<IServer> servers = srcTrain.getServers();
		String trainNo = srcTrain.getTrainNo();
		desTrain.setCarInfo(carInfo);
		desTrain.setCityName(cityName);
		desTrain.setLineName(lineName);
		desTrain.setServers(servers);
		desTrain.setTrainNo(trainNo);
		List<ICar> srcCars = srcTrain.getCars();
		List<ICar> desCars = new ArrayList<>();
		for (int i = 0; i < srcCars.size(); i++) {
			ICar iCar = srcCars.get(i);
			ICar customizeCar = new Car();
			customizeCar.setIndex(iCar.getIndex());
			customizeCar.setName(iCar.getName());
			customizeCar.setMdcus(iCar.getMdcus());
			customizeCar.setType(iCar.getType());
			List<IDoor> doorList = new ArrayList<>();
			for (IDoor iDoor : iCar.getDoors()) {
				IDoor door = new Door();
				door.setAddr(iDoor.getAddr());
				doorList.add(door);
			}
			customizeCar.setDoors(doorList);
			desCars.add(customizeCar);
		}
		desTrain.setCars(desCars);
	}

	/**
	 * 更新系统配置页面解码上的展示信息
	 * 
	 * @param train
	 */
	private void updateUIInfo(ITrain train) {
		cityNameText.setText(train.getCityName());
		lineNameText.setText(String.valueOf(train.getLineName()));
		trainNoText.setText(train.getTrainNo());
		carAmountCombo.setText(String.valueOf(train.getCarInfo().getCarNum()));
		doorAmountCombo.setText(String.valueOf(train.getCarInfo().getGateNum()));

		List<IServer> servers = train.getServers();
		if (servers.size() == 2) {
			localIPText.setText(servers.get(0).getServesIps().get(0).getIp());
			oppositeIPText.setText(servers.get(1).getServesIps().get(0).getIp());
			wirelessIPText_1.setText(servers.get(0).getGateWay());
			wirelessIPText_2.setText(servers.get(1).getGateWay());
		}

	}

	/**
	 * 清除UI上显示的信息
	 */
	public void clearUIInfo() {
		xmlText.setText(StringUtil.EMPTY);
		lineNameText.setText(StringUtil.EMPTY);
		trainNoText.setText(StringUtil.EMPTY);
		carAmountCombo.setText(StringUtil.EMPTY);
		doorAmountCombo.setText(StringUtil.EMPTY);
		localIPText.setText(StringUtil.EMPTY);
		oppositeIPText.setText(StringUtil.EMPTY);
		wirelessIPText_1.setText(StringUtil.EMPTY);
		wirelessIPText_2.setText(StringUtil.EMPTY);
	}

	/**
	 * 刷新表示存储空间状态的图形
	 */
	private void refreshStorageCanvas() {
		final DecimalFormat df = new DecimalFormat("#.00");
		final String totolSpaceString = df.format(storageState.getTotalSpace() / 1024d / 1024d / 1024d);
		final String usedSpace = df.format((storageState.getUsedSpace()) / 1024d / 1024d / 1024d);
		final double usedPercent = storageState.getUsedSpace() * 1.0d / (storageState.getTotalSpace() * 1.0d);
		final String usedSpacePercent = NumberFormat.getPercentInstance().format(usedPercent);
		totalSpace_lab.setText("数据存储空间大小： " + totolSpaceString + " GB");
		usedSpace_Lab.setText("已用空间： " + usedSpace + " GB ( " + usedSpacePercent + " )");
		totalSpace_lab.getParent().layout();
		usedSpace_Lab.getParent().layout();
		StorageFigure.getFigure(storageState).refresh();
	}

	@Override
	public void doorChecked(ICar car, int doorIndex) {
		DoorAddressConfigDialog doorAddressConfigDialog = new DoorAddressConfigDialog(Display.getDefault().getActiveShell(), car, doorIndex);
		int open = doorAddressConfigDialog.open();
		if (open == Window.OK) {
			setButtonEnable(true);
			List<ICar> cars = customizeTrain.getCars();
			for (ICar iCar : cars) {
				if (iCar.getIndex() == car.getIndex()) {
					iCar.setDoors(car.getDoors());
				}
			}
		}
	}

	@Override
	public void mdcuChecked(ICar car) {
		MDCUConfigDialog doorAddressConfigDialog = new MDCUConfigDialog(Display.getDefault().getActiveShell(), car, customizeTrain);
		int open = doorAddressConfigDialog.open();
		if (open == Window.OK) {
			setButtonEnable(true);
			checkInfoCorrect();
			if (customizeTrain != null) {
				List<ICar> cars = customizeTrain.getCars();
				for (ICar iCar : cars) {
					if (iCar.getIndex() == car.getIndex()) {
						iCar.setMdcus(car.getMdcus());
					}
				}
			}
		}
	}

	@Override
	public void carChecked(ICar car) {
		List<ICar> cars = customizeTrain.getCars();
		ICar customizeCar = null;
		for (ICar iCar : cars) {
			if (iCar.getIndex() == car.getIndex()) {
				customizeCar = iCar;
			}
		}
		int open = new CarNameConfigDialog(Display.getDefault().getActiveShell(), car, customizeTrain).open();
		if (open == Window.OK) {
			setButtonEnable(true);
			checkInfoCorrect();
			if (customizeCar != null) {
				customizeCar.setName(car.getName());
				customizeCar.setIndex(car.getIndex());
			}
		}
	}

	/**
	 * 设置应用，确定，导出按钮是否使能
	 * 
	 * @param enable
	 */
	public void setButtonEnable(boolean enable) {
		applicationSetBtn.setEnabled(enable);
		sureBtn.setEnabled(enable);
		exportBtn.setEnabled(enable);
	}
}
