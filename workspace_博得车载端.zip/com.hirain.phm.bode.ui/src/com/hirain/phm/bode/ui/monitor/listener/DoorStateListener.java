package com.hirain.phm.bode.ui.monitor.listener;

import com.hirain.phm.bode.core.dataframe.DoorStatus;

public interface DoorStateListener {

	void refresh(DoorStatus doorStatus);
}
