package com.hirain.phm.bode.server.client;

import com.hirain.phm.bode.server.comm.IPost;

public interface IHeartPost extends IPost {

	void heart(String ip);

}
