package com.hirain.phm.bode.server.query;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;

import org.junit.Test;

import com.hirain.phm.bode.server.TestConstant;
import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ServerClientMock;

public class TestClientCount {

	public static InetSocketAddress address = new InetSocketAddress(TestConstant.LOCALHOST, 17257);

	public static void setUp() {
		ServerClientMock mock = new ServerClientMock();
		mock.start();
	}

	@Test
	public void test() throws IOException {
		setUp();
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);

			TestConstant.login1(client);

			String sql = "select count(id) from t_fault_record";
			byte[] sqlBs = sql.getBytes();
			ByteBuffer buffer = ByteBuffer.allocate(sqlBs.length + 3);
			buffer.put((byte) 0x0b);
			buffer.putShort((short) sqlBs.length);
			buffer.put(sqlBs);
			byte[] bs = buffer.array();
			send(client, bs, address);
			System.out.println("send");

			DatagramPacket receive = new DatagramPacket(new byte[1024], 1024);
			client.receive(receive);
			byte[] data = receive.getData();
			ByteBuffer result = ByteBuffer.wrap(data);
			assertEquals(ClientConstants.DATA_STATISTICS_RESPONSE, result.get());
			assertEquals(8, result.getShort());
			assertEquals(5, result.getLong());
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	public void send(DatagramSocket socket, byte[] data, InetSocketAddress address) throws IOException {
		DatagramPacket send = new DatagramPacket(data, data.length, address);
		socket.send(send);
	}
}
