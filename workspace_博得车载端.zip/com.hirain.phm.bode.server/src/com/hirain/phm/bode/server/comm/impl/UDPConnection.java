package com.hirain.phm.bode.server.comm.impl;

import java.net.InetSocketAddress;
import java.util.List;

import com.hirain.phm.bode.server.comm.IConnection;
import com.hirain.phm.bode.server.comm.ITransportPacket;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.FixedRecvByteBufAllocator;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioDatagramChannel;

public class UDPConnection implements IConnection {

	private final InetSocketAddress address;

	private Channel channel;

	private EventLoopGroup group;

	private List<ChannelHandlerAdapter> handlers;

	public UDPConnection(InetSocketAddress addr) {
		address = addr;
	}

	public UDPConnection(InetSocketAddress addr, List<ChannelHandlerAdapter> handlers) {
		this(addr);
		this.handlers = handlers;
	}

	@Override
	public int bind() {
		return start();
	}

	private int start() {
		final Bootstrap bootstrap = new Bootstrap();
		group = new NioEventLoopGroup();
		bootstrap.group(group);

		bootstrap.channel(NioDatagramChannel.class);
		bootstrap.option(ChannelOption.RCVBUF_ALLOCATOR, new FixedRecvByteBufAllocator(65535));
		bootstrap.handler(new ChannelInitializer<NioDatagramChannel>() {

			@Override
			protected void initChannel(NioDatagramChannel ch) throws Exception {
				if (handlers != null) {
					for (final ChannelHandlerAdapter handler : handlers) {
						ch.pipeline().addLast(handler.getClass().getName(), handler);
					}
				}
			}
		});

		try {
			final ChannelFuture future = bootstrap.bind(address).sync().await();
			channel = future.channel();
			System.out.println("bind:" + channel.localAddress());
		} catch (final Exception e) {
			e.printStackTrace();
			return -1;
		}
		return 0;
	}

	@Override
	public int disconnect() {
		group.shutdownGracefully();
		return 0;
	}

	@Override
	public int send(ITransportPacket packet) {
		if (group == null || group.isShutdown()) {
			if (start() == -1) {
				return -1;
			}
		}
		channel.writeAndFlush(packet);
		return 0;
	}

}
