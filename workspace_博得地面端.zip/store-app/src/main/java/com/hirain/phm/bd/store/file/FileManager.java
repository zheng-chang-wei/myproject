package com.hirain.phm.bd.store.file;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.hirain.phm.bd.store.domain.StoreBuffer;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class FileManager implements IFileManager {

	@Autowired
	private StoreProperties properties;

	private String folder;

	private FileChannel fileChannel;

	private String path;

	private FileOutputStream stream;

	private ReentrantLock lock = new ReentrantLock();

	@Setter
	private String header;

	@Override
	public void write(StoreBuffer buffer) {
		lock.lock();
		try {
			FileChannel fileChannel = getChannel(buffer.getFilename());
			fileChannel.write(buffer.getBuffer());
			log.info(String.valueOf(fileChannel.position()));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			lock.unlock();
		}
	}

	private FileChannel getChannel(String filename) {
		if (filename.equals(path) && fileChannel != null) {
			return fileChannel;
		}
		try {
			close();
			path = filename;
			File file = new File(folder, path + properties.getExtension());
			System.out.println(file.getAbsolutePath());
			File parentFile = file.getParentFile();
			if (!parentFile.exists()) {
				parentFile.mkdirs();
			}
			boolean create = false;
			if (!file.exists()) {
				file.createNewFile();
				create = true;
			}
			File temp = new File(file.getParentFile(), "~" + file.getName());
			if (!temp.exists()) {
				temp.createNewFile();
			}
			stream = new FileOutputStream(file, true);
			fileChannel = stream.getChannel();
			if (create) {
				ByteBuffer buffer = ByteBuffer.wrap(header.getBytes(Charset.forName("utf-8")));
				fileChannel.write(buffer);
			}
			System.out.println("create file:" + path);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return fileChannel;
	}

	/**
	 * @throws IOException
	 */
	private void close() throws IOException {
		if (fileChannel != null) {
			fileChannel.close();
		}
		if (stream != null) {
			stream.close();
		}
		if (path != null) {
			File file = new File(folder, path + properties.getExtension());
			File temp = new File(file.getParentFile(), "~" + file.getName());
			System.out.println(temp.getAbsolutePath());
			if (temp.exists()) {
				temp.delete();
			}
		}
	}

	/**
	 * @see com.hirain.phm.bd.store.file.IFileManager#init(java.lang.String, java.lang.String)
	 */
	@Override
	public void init(String project, String train) {
		folder = getPath(properties.getRoot(), properties.getFolder(), project, train);
		lock.lock();
		try {
			List<File> lockFiles = getLockFiles(folder);
			lockFiles.stream().forEach(f -> {
				if (f.exists()) {
					f.delete();
				}
			});
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			lock.unlock();
		}
	}

	private List<File> getLockFiles(String folder) {
		List<File> files = new ArrayList<>();
		File container = new File(folder);
		File[] subFolders = container.listFiles();
		if (subFolders == null) {
			return files;
		}
		for (File subFolder : subFolders) {
			if (subFolder.isDirectory()) {
				File[] subFiles = subFolder.listFiles((FilenameFilter) (dir, name) -> name.startsWith("~"));
				if (subFiles != null) {
					files.addAll(Arrays.asList(subFiles));
				}
			}
		}
		return files;
	}

	private String getPath(String... names) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < names.length; i++) {
			sb.append(names[i]);
			if (i < names.length - 1) {
				sb.append(File.separator);
			}
		}
		return sb.toString();
	}
}
