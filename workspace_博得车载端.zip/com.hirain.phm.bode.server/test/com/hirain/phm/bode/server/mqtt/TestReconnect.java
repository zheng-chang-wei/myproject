package com.hirain.phm.bode.server.mqtt;

import java.util.concurrent.TimeUnit;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class TestReconnect {

	private static MqttConnection connection;

	public static void main(String[] args) {
		connection = new MqttConnectionImpl("tcp://127.0.0.1:61613", "testreconnect", new MqttCallbackExtended() {

			@Override
			public void messageArrived(String topic, MqttMessage message) throws Exception {
				System.out.println("topic:" + topic + ";message:" + message);
			}

			@Override
			public void deliveryComplete(IMqttDeliveryToken token) {

			}

			@Override
			public void connectionLost(Throwable cause) {
				System.out.println("connection lost");
			}

			@Override
			public void connectComplete(boolean reconnect, String serverURI) {
				System.out.println("connection reconnect");
			}
		});
		while (true) {
			try {
				connection.connect();
				connection.subscribe("hello");
				break;
			} catch (final Exception e) {
				e.printStackTrace();
			}
			try {
				TimeUnit.SECONDS.sleep(2);
			} catch (final InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
