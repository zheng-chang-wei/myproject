package com.hirain.phm.bode.ui.monitor.figure.door;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;

public class FrameFigure extends Figure implements StatusListener {

	private final int width = 224, height = 33;

	HeaderFigure h1 = new HeaderFigure(DoorContent.LEFT);

	HeaderFigure h2 = new HeaderFigure(DoorContent.RIGHT);

	public FrameFigure() {
		setLayoutManager(new XYLayout());
		createFigure();
		this.setOpaque(false);
	}

	private void createFigure() {
		RectangleFigure leftF = new RectangleFigure();
		add(leftF, new Rectangle(10, 0, 20, 8));
		RectangleFigure rightF = new RectangleFigure();
		add(rightF, new Rectangle(width - 14, 0, 20, 8));

		RectangleFigure hf1 = new RectangleFigure();
		add(hf1, new Rectangle(28, 10, width - 40, 5));
		RectangleFigure hf2 = new RectangleFigure();
		add(hf2, new Rectangle(28, 19, width - 40, 5));
		RectangleFigure hf3 = new RectangleFigure();
		add(hf3, new Rectangle(28, 29, width - 40, 5));

		RectangleFigure vf1 = new RectangleFigure();
		add(vf1, new Rectangle(21, 3, 8, height - 1));
		RectangleFigure vf2 = new RectangleFigure();
		add(vf2, new Rectangle(width - 13, 3, 8, height - 1));

		RectangleFigure top = new RectangleFigure();
		add(top, new Rectangle(width / 2 - 2, 6, 17, 7));

		RectangleFigure center = new RectangleFigure();
		add(center, new Rectangle(width / 2 + 4, 12, 5, 24));

		RectangleFigure l1 = new RectangleFigure();
		add(l1, new Rectangle(28, 17, 17, 9));

		RectangleFigure l2 = new RectangleFigure();
		add(l2, new Rectangle(39, 14, 20, 14));

		add(h1, new Rectangle(3, height - 25, 180, 30));

		add(h2, new Rectangle(width / 2 + 8, height - 25, 180, 30));
	}

	@Override
	public void reset() {
	}

	@Override
	public void update(int operation, int step) {
		h1.update(operation, step);
		h2.update(operation, step);
	}
}
