package com.hirain.phm.bode.server;

import java.net.InetSocketAddress;
import java.util.List;

import org.apache.log4j.Logger;

import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ClientService;
import com.hirain.phm.bode.server.config.ConfigurationService;
import com.hirain.phm.bode.server.log.LogEvent;
import com.hirain.phm.bode.server.log.LogService;
import com.hirain.phm.bode.server.message.PreProcessor;
import com.hirain.phm.bode.server.server.AbstractServerService;
import com.hirain.phm.bode.server.server.SingleServerService;

public class SimpleServerMock {

	static Logger logger = Logger.getLogger(ServerApp.class.getName());

	public static void main(String[] args) {
		final ITrain train = ConfigurationService.getInstance().getTrain();
		final PreProcessor processor = new PreProcessor();
		processor.init();
		final List<String> locahosts = Utils.locahosts();

		logger.info("Client module starting");
		for (final String localhost : locahosts) {
			final ClientService client = new ClientService(localhost, processor);
			client.init();
			final InetSocketAddress localClient = new InetSocketAddress(localhost, ClientConstants.LOCAL_CLIENT_PORT);
			final InetSocketAddress localHeart = new InetSocketAddress(localhost, ClientConstants.LOCAL_HEART_PORT);
			final InetSocketAddress localUpload = new InetSocketAddress(localhost, ClientConstants.LOCAL_UPLOAD_PORT);
			client.start(localClient, localHeart, localUpload);
		}
		logger.info("Client module started");

		final AbstractServerService server = new SingleServerService();
		server.init();
		logger.info("Single Server module initialized");
		logger.info("Check the system configuration");
		if (train != null && Utils.validateSetting(train) == 0) {
			LogService.instance().log(LogEvent.ofTrain(train));
			InnerEventBus.getInstance().post(new ConfigEvent(train, null));
		}
	}
}
