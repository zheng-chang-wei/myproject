/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.dataframe;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 10, 2019 4:59:09 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 10, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DataFrameD4 {

	/**
	 * 秒
	 */
	private int second;

	/**
	 * 毫秒
	 */
	private int millisecond;

	/**
	 * 温度
	 */
	private int temperature;

	/**
	 * CRC校验
	 */
	private short verifyCRC;

	/**
	 * @return the second
	 */
	public int getSecond() {
		return second;
	}

	/**
	 * @param second
	 *            the second to set
	 */
	public void setSecond(int second) {
		this.second = second;
	}

	/**
	 * @return the millisecond
	 */
	public int getMillisecond() {
		return millisecond;
	}

	/**
	 * @param millisecond
	 *            the millisecond to set
	 */
	public void setMillisecond(int millisecond) {
		this.millisecond = millisecond;
	}

	/**
	 * @return the temperature
	 */
	public int getTemperature() {
		return temperature;
	}

	/**
	 * @param temperature
	 *            the temperature to set
	 */
	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}

	/**
	 * @return the verifyCRC
	 */
	public short getVerifyCRC() {
		return verifyCRC;
	}

	/**
	 * @param verifyCRC
	 *            the verifyCRC to set
	 */
	public void setVerifyCRC(short verifyCRC) {
		this.verifyCRC = verifyCRC;
	}

}
