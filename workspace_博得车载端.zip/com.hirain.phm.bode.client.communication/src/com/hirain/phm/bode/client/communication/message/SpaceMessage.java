/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.message;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 16, 2019 11:42:19 AM
 * @Description
 *              <p>
 *              存储空间查询回复
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 16, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class SpaceMessage extends AbstractMessage {

	private long totalSpace;

	private long usedSpace;

	public SpaceMessage() {

	}

	/**
	 * @return the totalSpace
	 */
	public long getTotalSpace() {
		return totalSpace;
	}

	/**
	 * @param totalSpace
	 *            the totalSpace to set
	 */
	public void setTotalSpace(long totalSpace) {
		this.totalSpace = totalSpace;
	}

	/**
	 * @return the usedSpace
	 */
	public long getUsedSpace() {
		return usedSpace;
	}

	/**
	 * @param usedSpace
	 *            the usedSpace to set
	 */
	public void setUsedSpace(long usedSpace) {
		this.usedSpace = usedSpace;
	}

}
