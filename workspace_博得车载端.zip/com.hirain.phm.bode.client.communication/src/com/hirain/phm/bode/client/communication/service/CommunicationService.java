/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.service;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.TimeUnit;

import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.client.communication.codec.DefaultCommandDecoder;
import com.hirain.phm.bode.client.communication.message.DebugMessage;
import com.hirain.phm.bode.client.communication.message.DownloadMessage;
import com.hirain.phm.bode.client.communication.message.HeartMessage;
import com.hirain.phm.bode.client.communication.message.LoginMessage;
import com.hirain.phm.bode.client.communication.message.SpaceMessage;
import com.hirain.phm.bode.client.communication.message.SystemInfoConfigMessage;
import com.hirain.phm.bode.client.communication.message.SystemInfoMessage;
import com.hirain.phm.bode.client.communication.parse.DoorInfoParseHandler;
import com.hirain.phm.bode.client.communication.transport.ICommunication;
import com.hirain.phm.bode.client.communication.transport.IDecoder;
import com.hirain.phm.bode.client.communication.transport.impl.CommunicationImpl;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 15, 2019 1:32:59 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 15, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class CommunicationService implements ICommunicationService {

	/**
	 * 等待心跳回复的时间，超过该时间，则认为心跳断开（单位ms）
	 */
	private int HEARTBEAT_PERIOD = 5000;

	/**
	 * 普通指令报文超时时间（单位：s）
	 */
	private final int timeout = 2;

	private static ICommunicationService INSTANCE = null;

	private ICommunication communication = null;

	private InetSocketAddress socketAddress = null;

	private InetSocketAddress heartSocketAddress = null;

	private final EventBus eventBus = new EventBus("Distributer");

	private final IDecoder decoder = new DefaultCommandDecoder();

	private CommunicationService() {
	}

	public static ICommunicationService getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new CommunicationService();
		}
		return INSTANCE;
	}

	public ICommunication getCommunication() {
		return communication;
	}

	@Override
	public EventBus getEventBus() {
		return eventBus;
	}

	@Override
	public int start(String ip) {
		communication = new CommunicationImpl(new ServiceConnectionFactory(decoder));
		socketAddress = new InetSocketAddress(ip, ServiceConstant.HOST_PORT);
		heartSocketAddress = new InetSocketAddress(ip, ServiceConstant.HEART_PORT);
		return communication.bind(ServiceConstant.LOCAL_PORT);
	}

	@Override
	public int stop() {
		return communication.stop(ServiceConstant.LOCAL_PORT);
	}

	@Override
	public boolean inquireHeartBeat() {
		final SyncSubscriber<HeartMessage> subscriber = new SyncSubscriber<HeartMessage>() {

			@Subscribe
			void on(final HeartMessage message) {
				setResponse(message);
			}
		};
		eventBus.register(subscriber);
		communication.send(heartSocketAddress, ServiceConstant.LOCAL_PORT, ServiceConstant.PID_HEART_INQUIRY, ServiceConstant.EMPTY_DATA);
		try {
			final HeartMessage message = subscriber.get(HEARTBEAT_PERIOD, TimeUnit.MILLISECONDS);
			if (message == null) {
				System.out.println("心跳未回复");
				return false;
			}
			// System.out.println("心跳回复");
			return true;
		} catch (final InterruptedException e) {
			e.printStackTrace();
		} finally {
			eventBus.unregister(subscriber);
		}
		return false;
	}

	@Override
	public boolean login(String str) {
		final SyncSubscriber<LoginMessage> subscriber = new SyncSubscriber<LoginMessage>() {

			@Subscribe
			void on(final LoginMessage message) {
				setResponse(message);
			}
		};
		eventBus.register(subscriber);
		communication.send(socketAddress, ServiceConstant.LOCAL_PORT, ServiceConstant.PID_LOGIN, str.getBytes());
		try {
			final LoginMessage message = subscriber.get(timeout, TimeUnit.SECONDS);
			if (message == null) {
				System.out.println("登录未回复");
				return false;
			} else if (message.getError() != null) {
				System.out.println("登录回复———— 用户名或密码错误");
				return false;
			}
			System.out.println("登录回复———— 登录成功");
			DoorInfoParseHandler.getInstance().initialize();
			return true;
		} catch (final InterruptedException e) {
			e.printStackTrace();
		} finally {
			eventBus.unregister(subscriber);
		}
		return false;
	}

	@Override
	public SystemInfoMessage inquireSystemInfo() {
		SystemInfoMessage message = null;
		final SyncSubscriber<SystemInfoMessage> subscriber = new SyncSubscriber<SystemInfoMessage>() {

			@Subscribe
			void on(final SystemInfoMessage message) {
				setResponse(message);
			}
		};
		eventBus.register(subscriber);
		communication.send(socketAddress, ServiceConstant.LOCAL_PORT, ServiceConstant.PID_SYSTEMINFO_INQUIRY, ServiceConstant.EMPTY_DATA);
		try {
			message = subscriber.get(timeout, TimeUnit.SECONDS);
			if (message == null) {
				System.out.println("查询系统信息 未回复");
			} else if (message.getError() != null) {
				System.out.println("查询系统信息 回复———— 配置不完整");
			} else {
				System.out.println("查询系统信息 回复———— 配置完整");
			}
		} catch (final InterruptedException e) {
			e.printStackTrace();
		} finally {
			eventBus.unregister(subscriber);
		}
		return message;
	}

	@Override
	public SpaceMessage inquireStorageSpace() {
		SpaceMessage message = null;
		final SyncSubscriber<SpaceMessage> subscriber = new SyncSubscriber<SpaceMessage>() {

			@Subscribe
			void on(final SpaceMessage message) {
				setResponse(message);
			}
		};
		eventBus.register(subscriber);
		communication.send(socketAddress, ServiceConstant.LOCAL_PORT, ServiceConstant.PID_SPACE_INQUIRY, ServiceConstant.EMPTY_DATA);
		try {
			message = subscriber.get(timeout, TimeUnit.SECONDS);
			if (message == null) {
				System.out.println("查询空间信息 未回复");
			} else {
				System.out.println("查询空间信息 回复");
			}
		} catch (final InterruptedException e) {
			e.printStackTrace();
		} finally {
			eventBus.unregister(subscriber);
		}
		return message;
	}

	@Override
	public boolean commandDownload() {
		final SyncSubscriber<DownloadMessage> subscriber = new SyncSubscriber<DownloadMessage>() {

			@Subscribe
			void on(final DownloadMessage message) {
				setResponse(message);
			}
		};
		eventBus.register(subscriber);
		communication.send(socketAddress, ServiceConstant.LOCAL_PORT, ServiceConstant.PID_DOWNLOAD, ServiceConstant.EMPTY_DATA);
		try {
			final DownloadMessage message = subscriber.get(timeout, TimeUnit.SECONDS);
			if (message == null) {
				System.out.println("下载操作指令 未回复");
				return false;
			}
			System.out.println("下载操作指令 回复");
			return true;
		} catch (final InterruptedException e) {
			e.printStackTrace();
		} finally {
			eventBus.unregister(subscriber);
		}
		return false;

	}

	@Override
	public boolean commandDebug(byte type) {
		final SyncSubscriber<DebugMessage> subscriber = new SyncSubscriber<DebugMessage>() {

			@Subscribe
			void on(final DebugMessage message) {
				setResponse(message);
			}
		};
		eventBus.register(subscriber);
		communication.send(socketAddress, ServiceConstant.LOCAL_PORT, ServiceConstant.PID_DEBUGMODE, new byte[] { type });
		try {
			final DebugMessage message = subscriber.get(timeout, TimeUnit.SECONDS);
			if (message == null) {
				System.out.println("调试指令 未回复");
				return false;
			}
			System.out.println("调试指令 回复");
			return true;
		} catch (final InterruptedException e) {
			e.printStackTrace();
		} finally {
			eventBus.unregister(subscriber);
		}
		return false;
	}

	@Override
	public boolean logout() {
		final SyncSubscriber<LoginMessage> subscriber = new SyncSubscriber<LoginMessage>() {

			@Subscribe
			void on(final LoginMessage message) {
				setResponse(message);
			}
		};
		eventBus.register(subscriber);
		communication.send(socketAddress, ServiceConstant.LOCAL_PORT, ServiceConstant.PID_LOGOUT, ServiceConstant.EMPTY_DATA);
		try {
			final LoginMessage message = subscriber.get(timeout, TimeUnit.SECONDS);
			if (message == null) {
				System.out.println("登出   未回复");
				return false;
			}
			System.out.println("登出   回复");
			DoorInfoParseHandler.getInstance().shutDown();
			return true;
		} catch (final InterruptedException e) {
			e.printStackTrace();
		} finally {
			eventBus.unregister(subscriber);
		}
		return false;
	}

	@Override
	public boolean configSystemInfo(byte[] bytes) {
		final SyncSubscriber<SystemInfoConfigMessage> subscriber = new SyncSubscriber<SystemInfoConfigMessage>() {

			@Subscribe
			void on(final SystemInfoConfigMessage message) {
				setResponse(message);
			}
		};
		eventBus.register(subscriber);
		communication.send(socketAddress, ServiceConstant.LOCAL_PORT, ServiceConstant.PID_SYSTEMINFO_CONFIG, bytes);
		try {
			final SystemInfoConfigMessage message = subscriber.get(timeout, TimeUnit.SECONDS);
			if (message == null) {
				System.out.println("系统信息配置     未回复");
				return false;
			}
			System.out.println("系统信息配置     回复");
			return true;
		} catch (final InterruptedException e) {
			e.printStackTrace();
		} finally {
			eventBus.unregister(subscriber);
		}
		return false;
	}

	@Override
	public void select(byte pid, byte sid, String sql) {
		byte[] sqlBytes = sql.getBytes();
		ByteBuffer buffer = null;
		if (sid != 0) {
			buffer = ByteBuffer.allocate(sqlBytes.length + 1).order(ByteOrder.LITTLE_ENDIAN);
			buffer.put(sid);
		} else {
			buffer = ByteBuffer.allocate(sqlBytes.length).order(ByteOrder.LITTLE_ENDIAN);
		}
		buffer.put(sqlBytes);
		communication.send(socketAddress, ServiceConstant.LOCAL_PORT, pid, buffer.array());
	}

	@Override
	public void notifyDoorAddr(int carNo, int doorAddr) {
		DoorInfoParseHandler.getInstance().setCarNo(carNo);
		DoorInfoParseHandler.getInstance().setDoorAddr(doorAddr);
	}

	@Override
	public void download(byte[] bytes) {
		communication.send(socketAddress, ServiceConstant.LOCAL_PORT, ServiceConstant.DATA_DOWNLOAD_ID, bytes);
	}
}
