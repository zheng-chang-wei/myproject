package com.hirain.phm.bode.server.query;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ISender;
import com.hirain.phm.bode.server.client.Token;
import com.hirain.phm.bode.server.client.data.DataQueryHandler;

public class TestQuery {

	@Test
	public void testRecord() throws InterruptedException {
		final String sql = "select start_time,end_time,debug from t_carriage2_record where door_id=1";
		new DataQueryHandler(new TestSender(), sql, ClientConstants.COMMON_TAG, null).work();
		TimeUnit.SECONDS.sleep(5);
	}

	@Test
	public void testFaultList() throws InterruptedException {
		final String sql = "select * from t_fault";
		new DataQueryHandler((address, pid, datas) -> {
			System.out.println(Integer.toHexString(pid));
			final ByteBuffer buffer = ByteBuffer.wrap(datas);
			buffer.get();
			final byte num = buffer.get();
			System.out.println(num);
			for (int i = 0; i < num; i++) {
				final byte code = buffer.get();
				final int length = buffer.get() & 0xff;
				final byte[] bs = new byte[length];
				buffer.get(bs);
				String fname;
				fname = new String(bs);
				System.out.println(code + ":" + fname);
			}
		}, sql, ClientConstants.FAULT_LIST, null).work();
		TimeUnit.SECONDS.sleep(5);
	}

	@Test
	public void testLogRecord() throws InterruptedException {
		final String sql = "select * from t_log";
		new DataQueryHandler((address, pid, datas) -> {
			System.out.println(Integer.toHexString(pid));
			final ByteBuffer buffer = ByteBuffer.wrap(datas);
			buffer.get();
			final byte num = buffer.get();
			System.out.println(num);
			for (int i = 0; i < num; i++) {
				final int year = buffer.get() + 2000;
				final int month = buffer.get();
				final int day = buffer.get();
				System.out.println(year + "-" + month + "-" + day);
			}
		}, sql, ClientConstants.LOG_TAG, new Token("", null)).work();
		TimeUnit.SECONDS.sleep(100);
	}

	@Test
	public void testFaultRecord() throws InterruptedException {
		final String sql = "select fault_id,timestamp,start_time,end_time,debug from t_fault_record where carriage_id=2 and door_id=1";
		new DataQueryHandler(new TestSender(), sql, ClientConstants.FAULT_TAG, null).work();
		TimeUnit.SECONDS.sleep(5);
	}

	private class TestSender implements ISender {

		@Override
		public void send(InetSocketAddress address, int pid, byte[] datas) {
			System.out.print(Integer.toHexString(pid));
			System.out.print(" ");
			for (int i = 0; i < datas.length; i++) {
				System.out.print(datas[i]);
				System.out.print(" ");
			}
			System.out.println();
		}

	}
}
