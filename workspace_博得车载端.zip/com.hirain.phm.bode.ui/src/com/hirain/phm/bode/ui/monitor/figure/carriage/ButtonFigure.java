package com.hirain.phm.bode.ui.monitor.figure.carriage;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;

import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月11日 下午1:45:02
 * @Description
 *              <p>
 *              MDCU设置按钮
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月11日 changwei.zheng@hirain.com 1.0 create file
 */
public class ButtonFigure extends Figure {

	public ButtonFigure() {
		setLayoutManager(new XYLayout());
		Label label = new Label();
		RectangleFigure rectangleFigure = new RectangleFigure();
		add(rectangleFigure, new Rectangle(0, 0, CarriageConstants.buttonWidth, CarriageConstants.doorWidth));
		label.setText("MDCU设置");
		label.setFont(CarriageConstants.font);
		add(label, new Rectangle(0, 0, CarriageConstants.buttonWidth, CarriageConstants.doorWidth));
		setBackgroundColor(CarriageConstants.color_light_gray);
	}
}
