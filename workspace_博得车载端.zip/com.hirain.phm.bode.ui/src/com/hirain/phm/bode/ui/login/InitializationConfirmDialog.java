/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.login;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.wb.swt.SWTResourceManager;

import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.BodeUIPlugin;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 7, 2019 11:13:51 AM
 * @Description
 *              <p>
 *              登陆后的初始化确认对话框
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 7, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class InitializationConfirmDialog extends AbstractDialog {

	private Button okBtn;

	private Button cancelBtn;

	private Link linkExit;

	private Link linkInitialSet;

	private Label infoLb;

	public InitializationConfirmDialog(Shell parentShell) {
		super(parentShell);
		addHeartbeatListener();
	}

	@Override
	protected Control createContents(Composite parent) {
		Composite composite = new Composite(parent, 0);
		GridLayout layout = new GridLayout();
		layout.marginHeight = 0;
		layout.marginWidth = 0;
		layout.verticalSpacing = 0;
		composite.setLayout(layout);
		composite.setLayoutData(new GridData(GridData.FILL_BOTH));
		applyDialogFont(composite);
		// initialize the dialog units
		initializeDialogUnits(composite);
		// create the dialog area and button bar
		dialogArea = createDialogArea(composite);
		return composite;
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		Composite composite = new Composite(parent, SWT.NONE);
		GridLayout gl_com = new GridLayout(1, false);
		composite.setLayout(gl_com);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		composite.setBackgroundImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/LoginBackground.png"));
		composite.setBackgroundMode(SWT.INHERIT_DEFAULT);// 设置子控件背景透明

		creatToolBarCom(composite);
		createMainCom(composite);

		initListener();

		return parent;

	}

	@Override
	protected boolean isResizable() {
		return false;
	}

	@Override
	protected Point getInitialSize() {
		return new Point(1400, 700);
	}

	private void creatToolBarCom(Composite parent) {
		Composite toolBarCom = new Composite(parent, SWT.NONE);
		GridData gd_toolBarCom = new GridData();
		gd_toolBarCom.horizontalAlignment = GridData.END;
		toolBarCom.setLayoutData(gd_toolBarCom);
		GridLayout gl_toolBarCom = new GridLayout(3, false);
		toolBarCom.setLayout(gl_toolBarCom);
		linkInitialSet = new Link(toolBarCom, SWT.NONE);
		linkInitialSet.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		linkInitialSet.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkInitialSet.setLinkForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkInitialSet.setText("<a>初始化设置</a>");
		linkInitialSet.setEnabled(false);

		Label labelExit = new Label(toolBarCom, SWT.NONE);
		labelExit.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/signout-24.png"));
		linkExit = new Link(toolBarCom, SWT.NONE);
		linkExit.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		linkExit.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkExit.setLinkForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkExit.setText("<a>登出</a>");
	}

	private void createMainCom(Composite parent) {
		Composite mainCom = new Composite(parent, SWT.NONE);
		GridLayout gl_main = new GridLayout(1, false);
		gl_main.marginLeft = 500;
		gl_main.marginTop = 200;
		mainCom.setLayout(gl_main);
		mainCom.setLayoutData(new GridData(GridData.FILL_BOTH));

		Composite composite_1 = new Composite(mainCom, SWT.NONE);
		GridData gd_composite_1 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_composite_1.widthHint = 400;
		gd_composite_1.heightHint = 100;
		composite_1.setLayoutData(gd_composite_1);
		GridLayout gl_composite_1 = new GridLayout(2, false);
		gl_composite_1.marginTop = 15;
		composite_1.setLayout(gl_composite_1);
		composite_1.setBackground(SWTResourceManager.getColor(181, 181, 181));

		infoLb = new Label(composite_1, SWT.NONE);
		infoLb.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 13, SWT.NORMAL));
		infoLb.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		infoLb.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 2, 1));
		infoLb.setBackground(SWTResourceManager.getColor(181, 181, 181));
		infoLb.setText("该服务端未初始化，是否现在设置？");

		okBtn = new Button(composite_1, SWT.NONE);
		okBtn.setLayoutData(new GridData(SWT.FILL, GridData.VERTICAL_ALIGN_END, true, false, 1, 1));
		okBtn.setText("确认");

		cancelBtn = new Button(composite_1, SWT.NONE);
		cancelBtn.setLayoutData(new GridData(SWT.FILL, GridData.VERTICAL_ALIGN_END, true, false, 1, 1));
		cancelBtn.setText("取消");

		messageLab = new Label(composite_1, SWT.NONE);
		messageLab.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		messageLab.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		messageLab.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
	}

	private void initListener() {
		okBtn.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			okPressed();
		}));
		cancelBtn.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			showInfo();
			linkInitialSet.setEnabled(true);
		}));
		linkInitialSet.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			okPressed();
		}));
		linkExit.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			close();
			CommunicationService.getInstance().stop();// 取消netty端口绑定
			LoginDialog.getInstance().open();
		}));
	}

	private void showInfo() {
		okBtn.dispose();
		cancelBtn.dispose();
		infoLb.setText("系统未初始化，请点击右上方“初始化设置”标签");
		Composite parent = infoLb.getParent();
		GridLayout gl = new GridLayout();
		gl.marginTop = 30;
		parent.setLayout(gl);
		infoLb.getParent().layout();
	}

	@Override
	public void updateEnable(boolean enable) {
		Display.getDefault().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (!enable) {
					messageLab.setText("与服务端通信异常");
					linkInitialSet.setEnabled(false);
				} else {
					messageLab.setText(StringUtil.EMPTY);
				}
				if (okBtn != null && !okBtn.isDisposed()) {
					okBtn.setEnabled(enable);
				}
				if (cancelBtn != null && !cancelBtn.isDisposed()) {
					cancelBtn.setEnabled(enable);
				}
				if (okBtn.isDisposed() && cancelBtn.isDisposed() && linkInitialSet != null && !linkInitialSet.isDisposed()) {
					linkInitialSet.setEnabled(enable);
				}
			}
		});
	}
}
