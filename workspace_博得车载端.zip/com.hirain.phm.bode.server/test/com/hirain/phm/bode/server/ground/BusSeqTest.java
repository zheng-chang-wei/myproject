package com.hirain.phm.bode.server.ground;

import org.junit.Test;

import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.config.ConfigurationService;
import com.hirain.phm.bode.server.server.ServerService;

public class BusSeqTest {

	@Test
	public void test() {
		final ServerService serverService = new ServerService();
		serverService.init();
		final GroundService groundService = new GroundService();
		groundService.init();

		final ITrain train = ConfigurationService.getInstance().getTrain();
		InnerEventBus.getInstance().post(new ConfigEvent(train, this));
	}

}
