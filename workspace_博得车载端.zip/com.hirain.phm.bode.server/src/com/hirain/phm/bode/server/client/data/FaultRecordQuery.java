package com.hirain.phm.bode.server.client.data;

import java.util.Date;

public class FaultRecordQuery {

	private Long id;

	private Integer carriageId;

	private Integer doorId;

	private Date timestamp;

	private Date startTime;

	private Date endTime;

	private Boolean debug;

	private Integer faultId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getCarriageId() {
		return carriageId;
	}

	public void setCarriageId(Integer carriageId) {
		this.carriageId = carriageId;
	}

	public Integer getDoorId() {
		return doorId;
	}

	public void setDoorId(Integer doorId) {
		this.doorId = doorId;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Boolean getDebug() {
		return debug;
	}

	public void setDebug(Boolean debug) {
		this.debug = debug;
	}

	public Integer getFaultId() {
		return faultId;
	}

	public void setFaultId(Integer faultId) {
		this.faultId = faultId;
	}
}