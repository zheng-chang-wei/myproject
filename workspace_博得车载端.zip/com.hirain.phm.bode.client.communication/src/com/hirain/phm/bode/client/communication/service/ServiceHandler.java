package com.hirain.phm.bode.client.communication.service;

import com.hirain.phm.bode.client.communication.message.AbstractMessage;
import com.hirain.phm.bode.client.communication.transport.IDecoder;
import com.hirain.phm.bode.client.communication.transport.ITransportPacket;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 14, 2019 2:52:36 PM
 * @Description
 *              <p>
 *              处理客户端消息和各种消息事件的类
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 14, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class ServiceHandler extends ChannelInboundHandlerAdapter {

	IDecoder decoder;

	public ServiceHandler(IDecoder decoder) {
		this.decoder = decoder;
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		if (msg instanceof ITransportPacket) {
			AbstractMessage message = decoder.decode((ITransportPacket) msg);
			CommunicationService.getInstance().getEventBus().post(message);
		}
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		System.out.println("ServiceHandler.exceptionCaught()");
		cause.printStackTrace();
	}

	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		System.out.println("ServiceHandler.channelActive()");
		super.channelActive(ctx);
	}
}
