package com.hirain.phm.bode.server.db;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.ibatis.session.SqlSession;

import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.bus.StorageEvent;
import com.hirain.phm.bode.server.db.dao.ManageMapper;

public class DBStorageService {

	private final ScheduledExecutorService executor;

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

	public DBStorageService() {
		executor = Executors.newSingleThreadScheduledExecutor();
	}

	public void start() {
		executor.scheduleAtFixedRate(() -> {
			checkSpaceAndPost();
		}, 0, 1, TimeUnit.HOURS);
	}

	public void checkSpaceAndPost() {
		SqlSession session = null;
		try {
			session = DBService.getInstance().getSession(false);
			final ManageMapper mapper = session.getMapper(ManageMapper.class);
			final double faultSpace = mapper.selectFaultSpace();
			final double total = Utils.getTotalSpace();
			final double used = mapper.selectSpace();
			final Date startDate = mapper.faultStartTime();
			final Date updateData = mapper.faultUpdateTime();
			final StorageEvent event = new StorageEvent();
			event.setTotal(total);
			event.setUsed(used);
			event.setFaultSpace(faultSpace);
			if (startDate != null) {
				event.setFaultStart(sdf.format(startDate));
			}
			if (startDate != null) {
				event.setFaultUpdate(sdf.format(updateData));
			}
			InnerEventBus.getInstance().post(event);
		} catch (final Exception e) {
			e.printStackTrace();
		} finally {
			DBService.getInstance().disconnect(session);
		}
	}

}
