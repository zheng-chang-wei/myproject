package com.hirain.phm.bd.decode;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DecodeAppApplicationTests {

	@Test
	public void contextLoads() {
	}

}
