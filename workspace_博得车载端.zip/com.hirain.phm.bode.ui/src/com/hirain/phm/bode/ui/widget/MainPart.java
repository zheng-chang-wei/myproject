/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.widget;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.InstanceScope;
import org.eclipse.e4.ui.css.swt.theme.IThemeEngine;
import org.eclipse.e4.ui.internal.workbench.E4Workbench;
import org.eclipse.e4.ui.services.IServiceConstants;
import org.eclipse.e4.ui.services.IStylingEngine;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.internal.ProductProperties;
import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.wb.swt.SWTResourceManager;

import com.hirain.phm.bode.client.communication.message.SpaceMessage;
import com.hirain.phm.bode.client.communication.message.SystemInfoMessage;
import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.core.util.SystemInfoUtil;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.datamanager.DataManagerPart;
import com.hirain.phm.bode.ui.fault.FaultReplayPart;
import com.hirain.phm.bode.ui.listener.HeartbeatListenerManager;
import com.hirain.phm.bode.ui.listener.IHeartbeatListener;
import com.hirain.phm.bode.ui.listener.ITopShowListener;
import com.hirain.phm.bode.ui.listener.TopShowListenerManager;
import com.hirain.phm.bode.ui.log.LogPart;
import com.hirain.phm.bode.ui.login.LoginDialog;
import com.hirain.phm.bode.ui.monitor.OnlineMonitorPart;
import com.hirain.phm.bode.ui.monitor.TrainManager;
import com.hirain.phm.bode.ui.monitor.listener.HandlerDoorCheckedManager;
import com.hirain.phm.bode.ui.systemsetting.SystemSettingPart;
import com.hirain.phm.bode.ui.util.ShowModuleEnum;
import com.hirain.phm.bode.ui.util.UIConstants;
import com.hirain.phm.bode.ui.util.UIUtilMethod;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 4, 2019 11:35:06 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 4, 2019 zepei.tao@hirain.com 1.0 create file
 */
@SuppressWarnings("restriction")
public class MainPart implements ITopShowListener, IHeartbeatListener {

	// IStylingEngine is injected
	@Inject
	IStylingEngine engine;

	@Inject
	IThemeEngine themeEngine;

	private final String DEFAULT_FONT = "Microsoft YaHei UI";

	private boolean offline = false;

	private boolean debugFlag = false;

	private Composite switchComposite;

	private StackLayout stackLayout;

	private Composite systemConfigComposite;

	private Composite monitorComposite;

	private Composite faultComposite;

	private Composite dataManagerComposite;

	private Composite logManagerComposite;

	private SashForm contentSF;

	private Composite navigator;

	private Label systemTimeLab;

	private final Timer timer = new Timer();

	private TimerTask timerTask;

	private CLabel btnMonitor;

	private CLabel btnFault;

	private CLabel btnDataManager;

	private CLabel btnLogManager;

	private CLabel btnOnTop;

	private Composite toolbarControl;

	private Label titleLab;

	private Label messageLab;

	private Label lblSetting;

	private Link linkSetting;

	private Label lblDebug;

	private Link linkDebug;

	private Label lblHelp;

	private Link linkHelp;

	private Label labelExit;

	private Link linkExit;

	private final Color toolbarBackgroundColor_orange = SWTResourceManager.getColor(255, 153, 51);

	private final Color toolbarBackgroundColor_darkBlue = SWTResourceManager.getColor(0, 102, 153);

	private final Color buttonBackgroundColor_black = SWTResourceManager.getColor(0, 0, 0);

	private static Shell mainShell;

	public static Shell getShell() {
		return mainShell;
	}

	@Inject
	public MainPart() {
		TopShowListenerManager.getInstance().addListener(this);
		HeartbeatListenerManager.getInstance().addListener(this);
	}

	@PostConstruct
	public void postConstruct(Composite parent) {
		GridLayout gl_composite = new GridLayout(1, false);
		gl_composite.verticalSpacing = 0;
		gl_composite.horizontalSpacing = 0;
		gl_composite.marginWidth = 0;
		gl_composite.marginHeight = 0;
		parent.setLayout(gl_composite);

		createToolBarCom(parent);
		createMainCom(parent);

		showSystemTime();
		initListener();
	}

	/**
	 * 创建上方工具栏条
	 */
	private void createToolBarCom(Composite parent) {
		Composite topCom = new Composite(parent, SWT.NONE);
		topCom.setLayout(new GridLayout(2, false));
		topCom.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		topCom.setBackground(toolbarBackgroundColor_darkBlue);

		Composite left_logoCom = new Composite(topCom, SWT.NONE);
		GridLayout gl_logoControl = new GridLayout();
		gl_logoControl.marginWidth = 32;// 左上角logo区域的宽度
		left_logoCom.setLayout(gl_logoControl);
		left_logoCom.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, true, 1, 1));

		Label lblLogo = new Label(left_logoCom, SWT.NONE);
		lblLogo.setLayoutData(new GridData(GridData.FILL_BOTH));
		lblLogo.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/Bode.ico"));
		lblLogo.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblLogo.setBackground(toolbarBackgroundColor_darkBlue);

		toolbarControl = new Composite(topCom, SWT.NONE);
		GridLayout gl_toolbarControl = new GridLayout(11, false);
		gl_toolbarControl.marginHeight = 14;
		toolbarControl.setLayout(gl_toolbarControl);
		toolbarControl.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		toolbarControl.setBackground(toolbarBackgroundColor_darkBlue);

		engine.setClassname(toolbarControl, "logo-label");

		titleLab = new Label(toolbarControl, SWT.NONE);
		titleLab.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 17, SWT.BOLD));
		titleLab.setBackground(toolbarControl.getBackground());
		titleLab.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		titleLab.setText(ProductProperties.getAboutText(Platform.getProduct()));
		titleLab.setLayoutData(new GridData(GridData.BEGINNING, SWT.CENTER, true, false, 1, 1));

		messageLab = new Label(toolbarControl, SWT.NONE);
		messageLab.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 13, SWT.BOLD));
		messageLab.setBackground(toolbarControl.getBackground());
		messageLab.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		messageLab.setLayoutData(new GridData(GridData.BEGINNING, SWT.CENTER, true, false, 1, 1));

		systemTimeLab = new Label(toolbarControl, SWT.NONE);
		systemTimeLab.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		systemTimeLab.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 13, SWT.BOLD));

		lblSetting = new Label(toolbarControl, SWT.NONE);
		lblSetting.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/systemsetting-24.png"));
		lblSetting.setBackground(toolbarControl.getBackground());

		linkSetting = new Link(toolbarControl, SWT.NONE);
		linkSetting.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 13, SWT.NORMAL));
		linkSetting.setLinkForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkSetting.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkSetting.setText("<a>系统配置</a>");
		linkSetting.setBackground(toolbarControl.getBackground());

		lblDebug = new Label(toolbarControl, SWT.NONE);
		lblDebug.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/debug-24.png"));
		lblDebug.setBackground(toolbarControl.getBackground());

		linkDebug = new Link(toolbarControl, SWT.NONE);
		linkDebug.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 13, SWT.NORMAL));
		linkDebug.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkDebug.setLinkForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkDebug.setText("<a>调试模式</a>");
		linkDebug.setBackground(toolbarControl.getBackground());

		lblHelp = new Label(toolbarControl, SWT.NONE);
		lblHelp.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/help-24.png"));
		lblHelp.setBackground(toolbarControl.getBackground());

		linkHelp = new Link(toolbarControl, SWT.NONE);
		linkHelp.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 13, SWT.NORMAL));
		linkHelp.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkHelp.setLinkForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkHelp.setText("<a>软件帮助</a>");
		fillControl(linkHelp);

		labelExit = new Label(toolbarControl, SWT.NONE);
		labelExit.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 13, SWT.NORMAL));
		labelExit.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/signout-24.png"));
		fillControl(labelExit);

		linkExit = new Link(toolbarControl, SWT.NONE);
		linkExit.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 13, SWT.NORMAL));
		linkExit.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkExit.setLinkForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		linkExit.setText("<a>登出</a>");
		fillControl(linkExit);
	}

	/**
	 * 创建下方区域，包括左侧导航栏和右侧内容区域
	 * 
	 * @param parent
	 */
	private void createMainCom(Composite parent) {
		contentSF = new SashForm(parent, SWT.HORIZONTAL);
		contentSF.SASH_WIDTH = 0;
		contentSF.setLayoutData(new GridData(GridData.FILL_BOTH));

		createNavigatorCom(contentSF);
		createArrowCom(contentSF);
		createContentPartCom(contentSF);

		contentSF.setWeights(new int[] { 9, 1, 90 });
	}

	private void createArrowCom(Composite parent) {
		final SashForm sashForm = new SashForm(parent, SWT.VERTICAL);
		sashForm.SASH_WIDTH = 0;
		sashForm.setLayoutData(new GridData(GridData.FILL_BOTH));

		Composite com1 = new Composite(sashForm, SWT.NONE);
		com1.setBackgroundImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/arrow_left.png"));
		com1.addPaintListener(new PaintListener() {

			@Override
			public void paintControl(PaintEvent e) {
				Point size = com1.getSize();
				Point pos = com1.getLocation();
				e.gc.drawImage(com1.getBackgroundImage(), 0, 0, 16, 23, pos.x, pos.y, size.x, size.y);
			}
		});
		com1.setToolTipText("隐藏导航栏");
		@SuppressWarnings("unused")
		Composite com2 = new Composite(sashForm, SWT.NONE);

		com1.addMouseListener(new MouseListener() {

			@Override
			public void mouseUp(MouseEvent e) {
				if (navigator.isVisible()) {
					navigator.setVisible(false);
					contentSF.setWeights(new int[] { 0, 1, 99 });
					com1.setToolTipText("显示导航栏");
					com1.setBackgroundImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/arrow_right.png"));
				} else {
					navigator.setVisible(true);
					contentSF.setWeights(new int[] { 9, 1, 90 });
					com1.setToolTipText("隐藏导航栏");
					com1.setBackgroundImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/arrow_left.png"));
				}
				contentSF.layout();
			}

			@Override
			public void mouseDown(MouseEvent e) {
			}

			@Override
			public void mouseDoubleClick(MouseEvent e) {
			}
		});

		sashForm.setWeights(new int[] { 4, 96 });
	}

	/**
	 * 创建下方左侧，导航区域
	 */
	private void createNavigatorCom(Composite parent) {
		navigator = new Composite(parent, SWT.NONE);
		navigator.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, true, 1, 1));
		navigator.setBackground(toolbarBackgroundColor_darkBlue);
		navigator.setLayout(new GridLayout(1, false));

		engine.setClassname(navigator, "logo-label");

		btnMonitor = new CLabel(navigator, SWT.NONE);
		btnMonitor.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnMonitor.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 11, SWT.NORMAL));
		btnMonitor.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/monitor-32.png"));
		btnMonitor.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnMonitor.setText("实时监控");
		btnMonitor.setBackground(btnMonitor.getParent().getBackground());

		btnFault = new CLabel(navigator, SWT.NONE);
		btnFault.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnFault.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 11, SWT.NORMAL));
		btnFault.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnFault.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/faultplayback-32.png"));
		btnFault.setText("故障回放");
		btnFault.setBackground(btnFault.getParent().getBackground());

		btnDataManager = new CLabel(navigator, SWT.NONE);
		btnDataManager.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnDataManager.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 11, SWT.NORMAL));
		btnDataManager.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnDataManager.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/datamanager-32.png"));
		btnDataManager.setText("数据管理");
		btnDataManager.setBackground(btnDataManager.getParent().getBackground());

		btnLogManager = new CLabel(navigator, SWT.NONE);
		btnLogManager.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnLogManager.setFont(SWTResourceManager.getFont(DEFAULT_FONT, 11, SWT.NORMAL));
		btnLogManager.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/logplayback-32.png"));
		btnLogManager.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnLogManager.setText("日志管理");
		btnLogManager.setBackground(btnLogManager.getParent().getBackground());
	}

	/**
	 * 创建下方右侧，内容显示区域
	 */
	private void createContentPartCom(Composite parent) {
		Composite right_composite = new Composite(parent, SWT.NONE);
		GridLayout gl_right_composite = new GridLayout(1, false);
		gl_right_composite.verticalSpacing = 0;
		gl_right_composite.marginWidth = 0;
		gl_right_composite.marginHeight = 0;
		gl_right_composite.horizontalSpacing = 0;
		right_composite.setLayout(gl_right_composite);
		right_composite.setLayoutData(new FillLayout());

		switchComposite = new Composite(right_composite, SWT.NONE);
		stackLayout = new StackLayout();
		switchComposite.setLayout(stackLayout);
		switchComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		systemConfigComposite = new Composite(switchComposite, SWT.NONE);
		systemConfigComposite.setLayout(new GridLayout(1, false));

		monitorComposite = new Composite(switchComposite, SWT.NONE);
		monitorComposite.setLayout(new GridLayout(1, false));

		faultComposite = new Composite(switchComposite, SWT.NONE);
		faultComposite.setLayout(new GridLayout(1, false));

		dataManagerComposite = new Composite(switchComposite, SWT.NONE);
		dataManagerComposite.setLayout(new GridLayout(1, false));

		logManagerComposite = new Composite(switchComposite, SWT.NONE);
		logManagerComposite.setLayout(new GridLayout(1, false));

		if (isInitialization()) {
			showTopComposite(ShowModuleEnum.ONLINE_MONITOR);
		} else {
			showTopComposite(ShowModuleEnum.SETTING);
		}
		switchComposite.layout();
	}

	private void initListener() {
		linkSetting.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			SystemInfoMessage systemInfoMessage = CommunicationService.getInstance().inquireSystemInfo();
			if (systemInfoMessage != null) {
				ITrain train;
				try {
					train = SystemInfoUtil.convertXmlBytes2SystemInfo(systemInfoMessage.getData());
					TrainManager.getInstance().setTrain(train);
					showTopComposite(ShowModuleEnum.SETTING);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			} else {
				UIUtilMethod.showCommunicationException();
			}
		}));
		linkDebug.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			byte debugMode = debugFlag ? (byte) 0x00 : (byte) 0x01;
			boolean commandDebug = CommunicationService.getInstance().commandDebug(debugMode);
			if (commandDebug) {
				debugFlag = !debugFlag;
				if (debugFlag) {
					linkDebug.setText("<a>退出调试</a>");
					setToolbarBackgroundColor(toolbarBackgroundColor_orange);
					MessageDialog.openInformation(Display.getDefault().getActiveShell(), "提示", "调试指令发送成功");
				} else {
					linkDebug.setText("<a>调试模式</a>");
					setToolbarBackgroundColor(toolbarBackgroundColor_darkBlue);
					MessageDialog.openInformation(Display.getDefault().getActiveShell(), "提示", "调试模式已退出");
				}
			} else {
				MessageDialog.openError(Display.getDefault().getActiveShell(), "错误", "调试指令发送失败");
				return;
			}
		}));
		linkHelp.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			// TODO 打开帮助文档

		}));
		linkExit.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			CommunicationService.getInstance().logout();// 发送登出指令
			CommunicationService.getInstance().stop();// 取消netty端口绑定
			mainShell = (Shell) E4Workbench.getServiceContext().getActive(IServiceConstants.ACTIVE_SHELL);
			mainShell.setVisible(false);
			LoginDialog loginDialog = LoginDialog.getInstance();
			if (loginDialog.open() != Window.OK) {
				System.exit(0);
			}
		}));
		btnMonitor.addMouseListener(new MouseListener() {

			@Override
			public void mouseUp(MouseEvent e) {
			}

			@Override
			public void mouseDown(MouseEvent e) {
				if (btnOnTop != null)
					showTopComposite(ShowModuleEnum.ONLINE_MONITOR);
			}

			@Override
			public void mouseDoubleClick(MouseEvent e) {
			}
		}
		// initOnlineMonitorPart();
		);
		btnFault.addMouseListener(new MouseListener() {

			@Override
			public void mouseDoubleClick(MouseEvent e) {
			}

			@Override
			public void mouseDown(MouseEvent e) {
				if (btnOnTop != null)
					showTopComposite(ShowModuleEnum.FAULT);
			}

			@Override
			public void mouseUp(MouseEvent e) {
			}
		}
		// showTopComposite(ShowModuleEnum.FAULT);
		// initFaultPart();
		);
		btnDataManager.addMouseListener(new MouseListener() {

			@Override
			public void mouseDoubleClick(MouseEvent e) {
			}

			@Override
			public void mouseDown(MouseEvent e) {
				if (btnOnTop != null)
					showTopComposite(ShowModuleEnum.DATA_MANAGER);
			}

			@Override
			public void mouseUp(MouseEvent e) {
			}
		}
		// showTopComposite(ShowModuleEnum.DATA_MANAGER);
		// initDataManagerPart();
		);
		btnLogManager.addMouseListener(new MouseListener() {

			@Override
			public void mouseDoubleClick(MouseEvent e) {
			}

			@Override
			public void mouseDown(MouseEvent e) {
				if (btnOnTop != null)
					showTopComposite(ShowModuleEnum.LOG);
			}

			@Override
			public void mouseUp(MouseEvent e) {
			}
		}
		// showTopComposite(ShowModuleEnum.LOG);
		// initLogPart();
		// if (!themeEngine.getActiveTheme().getId().equals("com.hirain.phm.bode.ui.default")) {
		// themeEngine.setTheme("com.hirain.phm.bode.ui.default", true);
		// } else {
		// themeEngine.setTheme("com.hirain.phm.bode.ui.rainbow", true);
		// }
		);
	}

	private void setToolbarBackgroundColor(Color color) {
		toolbarControl.setBackground(color);
		titleLab.setBackground(color);
		lblSetting.setBackground(color);
		linkSetting.setBackground(color);
		lblDebug.setBackground(color);
		linkDebug.setBackground(color);
		lblHelp.setBackground(color);
		linkHelp.setBackground(color);
		labelExit.setBackground(color);
		linkExit.setBackground(color);
	}

	/**
	 * 向服务端发送系统信息查询指令，初始化“系统配置”界面
	 */
	private void initSystemInfoPart() {
		SystemSettingPart scPart = SystemSettingPart.getInstance();
		SpaceMessage spaceMessage = CommunicationService.getInstance().inquireStorageSpace();
		if (spaceMessage.getErrorCode() == (byte) 0) {
			scPart.getStorageState().setTotalSpace(spaceMessage.getTotalSpace());
			scPart.getStorageState().setUsedSpace(spaceMessage.getUsedSpace());
		}
		HandlerDoorCheckedManager.getInstatnce().add(scPart);
		if (!scPart.isInit()) {
			scPart.postConstruct(systemConfigComposite);
		} else {
			scPart.clearUIInfo();
			ITrain train = TrainManager.getInstance().getTrain();
			if (train != null) {
				scPart.refreshFigure(train);
				scPart.refreshTextInfo(train);
				scPart.setButtonEnable(false);
			}
		}
		stackLayout.topControl = systemConfigComposite;
		systemConfigComposite.layout();
		switchComposite.layout();
	}

	/**
	 * 初始化“实时监控”界面
	 */
	private void initOnlineMonitorPart() {
		ITrain train = TrainManager.getInstance().getTrain();
		if (train != null) {
			OnlineMonitorPart instance = OnlineMonitorPart.getInstance();
			HandlerDoorCheckedManager.getInstatnce().add(instance);
			instance.setTrain(train);
			if (!instance.isInit()) {
				instance.postConstruct(monitorComposite);
			} else {
				instance.refreshFigure();
			}
			btnOnTop = btnMonitor;
			btnOnTop.setBackground(buttonBackgroundColor_black);
			stackLayout.topControl = monitorComposite;
			monitorComposite.layout();
			switchComposite.layout();
		}
	}

	/**
	 * 初始化故障回放界面
	 */
	private void initFaultPart() {
		ITrain train = TrainManager.getInstance().getTrain();
		if (train != null) {
			FaultReplayPart instance = FaultReplayPart.getInstance();
			HandlerDoorCheckedManager.getInstatnce().add(instance);
			instance.setTrain(train);
			if (!instance.isInit()) {
				instance.postConstruct(faultComposite);
			} else {
				instance.refreshFigure();
				// instance.refreshCarNumAndDoorAddr();
				instance.refreshTable();
			}
			btnOnTop = btnFault;
			btnOnTop.setBackground(buttonBackgroundColor_black);
			stackLayout.topControl = faultComposite;
			faultComposite.layout();
			switchComposite.layout();
		}
	}

	/**
	 * 初始化日志管理界面
	 */
	private void initLogPart() {
		ITrain train = TrainManager.getInstance().getTrain();
		if (train != null) {
			LogPart instance = LogPart.getInstance();
			HandlerDoorCheckedManager.getInstatnce().add(instance);
			instance.setTrain(train);
			if (!instance.isInit()) {
				instance.postConstruct(logManagerComposite);
			} else {
				instance.refreshFigure();
				instance.refreshTable();
			}
			btnOnTop = btnLogManager;
			btnOnTop.setBackground(buttonBackgroundColor_black);
			stackLayout.topControl = logManagerComposite;
			logManagerComposite.layout();
			switchComposite.layout();
		}
	}

	/**
	 * 初始化数据管理界面
	 */
	private void initDataManagerPart() {
		ITrain train = TrainManager.getInstance().getTrain();
		if (train != null) {
			DataManagerPart instance = DataManagerPart.getInstance();
			HandlerDoorCheckedManager.getInstatnce().add(instance);
			instance.setTrain(train);
			if (!instance.isInit()) {
				instance.postConstruct(dataManagerComposite);
			} else {
				instance.refreshFigure();
				// instance.refreshCarNumAndDoorAddr();
				instance.refreshTable();
			}
			btnOnTop = btnDataManager;
			btnOnTop.setBackground(buttonBackgroundColor_black);
			stackLayout.topControl = dataManagerComposite;
			dataManagerComposite.layout();
			switchComposite.layout();
		}
	}

	private void showSystemTime() {
		timerTask = new TimerTask() {

			@Override
			public void run() {
				Date nowTime = new Date(System.currentTimeMillis());
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy年 MM月 dd日   HH:mm:ss  ");
				refreshTime(formatter.format(nowTime));

			}
		};
		timer.scheduleAtFixedRate(timerTask, 0, 1000);
	}

	private void refreshTime(final String time) {
		Display.getDefault().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (systemTimeLab != null && !systemTimeLab.isDisposed() && time != null) {
					systemTimeLab.setText(time);
					systemTimeLab.getParent().layout();
				}
			}
		});
	}

	private void fillControl(Control control) {
		control.setBackground(control.getParent().getBackground());
	}

	/**
	 * 检测是否有初始化
	 */
	private boolean isInitialization() {
		// 向服务端发送系统信息查询指令,收到的回复报文
		// 错误码 0，则表示配置完整；错误码 1，则表示配置不完整
		SystemInfoMessage systemInfoMessage = CommunicationService.getInstance().inquireSystemInfo();
		ITrain train;
		try {
			train = SystemInfoUtil.convertXmlBytes2SystemInfo(systemInfoMessage.getData());
			TrainManager.getInstance().setTrain(train);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemInfoMessage.getErrorCode() == (byte) 0;// 0表示服务端配置信息网完整；1表示服务端配置信息不完整
	}

	@Override
	public void showTopComposite(ShowModuleEnum showModule) {
		if (btnOnTop != null) {
			btnOnTop.setBackground(btnOnTop.getParent().getBackground());
			btnOnTop = null;
		}
		switch (showModule) {
		case SETTING:
			initSystemInfoPart();
			break;
		case ONLINE_MONITOR:
			initOnlineMonitorPart();
			break;
		case FAULT:
			initFaultPart();
			break;
		case LOG:
			initLogPart();
			break;
		case DATA_MANAGER:
			initDataManagerPart();
			break;
		default:
			return;
		}
	}

	@Override
	public synchronized void updateEnable(boolean enable) {
		Display.getDefault().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (messageLab != null && !messageLab.isDisposed()) {
					if (!enable) {
						offline = true;
						messageLab.setText("与服务端通信异常");
					}
					if (enable) {
						messageLab.setText(StringUtil.EMPTY);
						IEclipsePreferences node = InstanceScope.INSTANCE.getNode(BodeUIPlugin.PLUGIN_ID);
						if (offline) {
							if (!CommunicationService.getInstance().login(node.get(UIConstants.PREFERENCE_LOGININFO, StringUtil.EMPTY))) {
								MessageDialog.openInformation(Display.getDefault().getActiveShell(), "提示", "尝试重新登录服务器失败，建议重启客户端软件！");
								offline = false;
							} else {
								offline = false;
							}
						}
					}
				}
			}
		});
	}
}
