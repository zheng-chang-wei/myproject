package com.hirain.phm.bode.server.ground;

import java.nio.charset.Charset;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import com.hirain.phm.bd.message.ground.DeleteTrainDataMessage;
import com.hirain.phm.bd.message.ground.RegisterResponse;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.ground.message.MessageHeader;

public class CommonMqttCallback implements MqttCallbackExtended {

	private final String clientId;

	private final GroundService service;

	public CommonMqttCallback(String clientId, GroundService service) {
		this.clientId = clientId;
		this.service = service;
	}

	@Override
	public void connectionLost(Throwable cause) {
		System.out.println(clientId + " connection lost");
	}

	@Override
	public void messageArrived(String topic, MqttMessage message) throws Exception {
		final byte[] payload = message.getPayload();
		final String json = new String(payload, Charset.forName("utf-8"));
		System.out.println(topic + "," + json);
		final MessageHeader header = Utils.fromJsonString(json, MessageHeader.class);
		System.out.println(header.sid);
		switch (header.sid) {
		case GroundConstant.REGISTER_RESPONSE_ID:
			System.out.println("register received");
			final RegisterResponse response = Utils.fromJsonString(json, RegisterResponse.class);
			InnerEventBus.getInstance().post(response);
			break;
		case GroundConstant.DATA_DELETE_COMMOND:
			System.out.println("[delete received]" + json);
			final DeleteTrainDataMessage deleteMessage = Utils.fromJsonString(json, DeleteTrainDataMessage.class);
			InnerEventBus.getInstance().post(deleteMessage);
			break;
		case GroundConstant.TRAINSTATE_UPDATE_COMMAND:
		case GroundConstant.USERLIST_UPDATE_COMMAND:
		case GroundConstant.GROUND_ONOFF_ID:
			service.post(header.sid, json);
			break;

		default:
			break;
		}
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken token) {
		// do nothing
	}

	@Override
	public void connectComplete(boolean reconnect, String serverURI) {
		GroundService.logger.info(clientId + " connecion connected");
		service.reconnected(clientId);
	}
}
