package com.hirain.phm.bode.server.query;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ISender;
import com.hirain.phm.bode.server.client.data.DataDownloadHandler;

public class TestDownload {

	@Test
	public void test() throws InterruptedException {
		String sql = "select datas from t_carriage2_message where door_id=1";
		new DataDownloadHandler(new TestSender(), sql, ClientConstants.COMMON_TAG, null).work();

		TimeUnit.SECONDS.sleep(5);
	}

	@Test
	public void testFault() throws InterruptedException {
		String sql = "select datas from t_fault_message where door_id=1 and carriage_id=1";
		new DataDownloadHandler(new TestSender(), sql, ClientConstants.FAULT_TAG, null).work();

		TimeUnit.SECONDS.sleep(5);
	}

	public String convertBytes2Line(byte[] bs) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < bs.length; i++) {
			byte b = bs[i];
			String hex = Integer.toHexString(b & 0xff);
			if (hex.length() < 2) {
				sb.append("0");
			}
			sb.append(hex.toUpperCase()).append(" ");
		}
		return sb.toString();
	}

	private class TestSender implements ISender {

		@Override
		public void send(InetSocketAddress address, int pid, byte[] datas) {
			System.out.println(Integer.toHexString(pid));
			ByteBuffer buffer = ByteBuffer.wrap(datas);
			byte type = buffer.get();
			System.out.println(type);
			if (type == ClientConstants.EOF) {
				System.out.println("EOF");
				return;
			}
			byte num = buffer.get();
			System.out.println(num);
			for (int i = 0; i < num; i++) {
				byte[] bs = new byte[32];
				buffer.get(bs);
				System.out.println(convertBytes2Line(bs));
			}
			System.out.println();
		}

	}
}
