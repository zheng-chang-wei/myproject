/**
 * Created by ASen on 2017/8/18.
 */
export const SET_HARDWARE = 'SET_HARDWARE'

export const SET_TEMPLATE = 'SET_TEMPLATE'

export const SET_APP = 'SET_APP'

export const SET_IMAGE = 'SET_IMAGE'

export const SET_APP_NAME = 'SET_APP_NAME'

export const SET_APP_TYPE = 'SET_APP_TYPE'

export const SET_APP_HARDWARE = 'SET_APP_HARDWARE'

export const SET_LOGO_URL = 'SET_LOGO_URL'

export const SET_IFRAME = 'SET_IFRAME'

export const SET_BERFORE_PAGE = 'SET_BERFORE_PAGE'

export const SET_APP_ID = 'SET_APP_ID'

export const SET_COMPANYID = 'SET_COMPANYID'

export const SET_APPID = 'SET_APPID'

export const SET_APPTYPEID = 'SET_APPTYPEID'
