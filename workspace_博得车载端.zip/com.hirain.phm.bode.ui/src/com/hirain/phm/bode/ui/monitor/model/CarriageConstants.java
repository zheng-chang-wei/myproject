package com.hirain.phm.bode.ui.monitor.model;

import java.util.Locale;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;

public class CarriageConstants {

	/**
	 * 车厢高度
	 */
	public static int carriageHeight = 100;

	/**
	 * 按钮的上下间距
	 */
	public static int buttonSpacing = 10;

	/**
	 * 车头宽度
	 */
	public static int carriageHeadWidth = 100;

	/**
	 * 车厢水平间距
	 */
	public static int carriageHorizontalSpacing = 5;

	/**
	 * 车厢垂直间距
	 */
	public static int carriageVerticalSpacing = 5;

	/**
	 * 车门宽度
	 */
	public static int doorWidth = 25;

	/**
	 * 按钮宽度
	 */
	public static int buttonWidth = 100;

	public static Font font;
	static {
		String OS_VERSION = System.getProperty("os.version").toLowerCase(Locale.US);
		if (OS_VERSION.equals("10.0")) {
			font = new Font(Display.getDefault(), "微软雅黑", 9, SWT.NORMAL);
		} else {
			font = new Font(Display.getDefault(), "微软雅黑", 11, SWT.NORMAL);
		}

	}

	/**
	 * 字体风格和大小
	 */
	// public static Font font = null;
	public static Font getFont() {
		Font font = null;
		String OS_VERSION = System.getProperty("os.version").toLowerCase(Locale.US);
		if (OS_VERSION.equals("10.0")) {
			font = new Font(Display.getDefault(), "微软雅黑", 9, SWT.NORMAL);
		} else {
			font = new Font(Display.getDefault(), "微软雅黑", 11, SWT.NORMAL);
		}
		return font;
	}

	/**
	 * 字体风格和大小
	 */
	public static Font title_font = new Font(Display.getDefault(), "微软雅黑", 12, SWT.BOLD);

	public static Font bold_font = new Font(Display.getDefault(), "微软雅黑", 10, SWT.BOLD);

	/**
	 * 灰色
	 */
	public static Color color_gray = new Color(null, 204, 204, 204);

	/**
	 * 浅灰色
	 */
	public static Color color_light_gray = new Color(null, 249, 249, 249);

	/**
	 * 门信息配置背景颜色
	 */
	public static Color doorInfoConfigBackgroundColor = new Color(null, 240, 240, 240);

	public static RGB[] DEFAULT_TRACES_COLOR = new RGB[] { new RGB(21, 21, 196), new RGB(242, 26, 26), new RGB(33, 179, 33), new RGB(0, 0, 0),
			new RGB(128, 0, 255), new RGB(255, 170, 0), new RGB(255, 0, 240), new RGB(243, 132, 132), new RGB(0, 255, 11), new RGB(0, 214, 255),
			new RGB(114, 40, 3), new RGB(219, 128, 4) };

	/**
	 * 车辆信号属性名称
	 */
	public static String[] carSignalAttrs = { "door_PreventExtrusion", "door_Isolation", "door_EmergencyUnlock", "door_Open", "door_Close",
			"door_Action", "door_NoSpeed", "door_Enable", "door_ControlChoose", "feedback_SwitchAgain", "detectObstacles", "feedback_doorClose",
			"feedback_doorOpen", "fault_DoorExist", "signal_ServiceButton", "signal_SwitchDoorCentralControl", "signal_CloseDoorCentralControl",
			"signal_OpenCloseAgain", "signal_ZeroSpeed", "signal_Isolation", "signal_EmergencyUnlock", "signal_UnlockSwitch",
			"signal_leftDoorOpenClose", "signal_rightDoorOpenClose", "closeDoorTime", "process_openDoor", "process_closeDoor",
			"process_PreventExtrusion", "PreventExtrusionStop" };

	/**
	 * 输入信号属性名称
	 */
	public static String[] inputSignalAttrs = { "door_CodeAddr1", "door_CodeAddr2", "door_CodeAddr3", "door_CodeAddr4" };

	/**
	 * 输出信号属性名称
	 */
	public static String[] outputSignaleAttrs = { "openDoorLightOutput", "buzzerOutput" };

	public static String[] inputAndOutputSignaleAttrs = { "door_CodeAddr1", "door_CodeAddr2", "door_CodeAddr3", "door_CodeAddr4",
			"openDoorLightOutput", "buzzerOutput" };

	/**
	 * 电机与指令信号属性名称
	 */
	public static String[] electromechanicalSignalAttrs = { "motorVoltage", "motorCurrent", "Encoder" };

	public static String[] doorStatusAttrs = { "outputShortCircuit", "switchTimeOut", "encoder", "lockSwitch", "greenLoop", "doorSwitch",
			"motorOverCurrent", "motorOpenCircuit" };

	public static String[] faultNames = { "输出短路故障", "开关门超时故障", "编码器故障", "锁闭开关故障", "绿色环线故障", "门板开关故障", "电机过流故障", "电机开路故障" };

}
