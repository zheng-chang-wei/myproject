package com.hirain.phm.bode.server.message;

import java.util.Date;

public class TimestampHandler {

	private long lastSecond = -1;

	private int lastSeq;

	private int milli = -1;

	public int nextMilli(Date date, int seq) {
		final long second = date.getTime() / 1000;
		if (second == lastSecond) {
			if (milli != -1) {
				final int devide = between(seq, lastSeq);
				milli = devide * 50 + milli;
			}
		} else if (second - lastSecond == 1) {
			milli = 0;
		} else {
			milli = -1;
		}
		lastSecond = second;
		lastSeq = seq;
		// System.out.println(seq + ":" + second + ":" + milli);
		return milli;
	}

	public int between(int seq, int last) {
		if (seq > last) {
			return seq - last;
		} else {
			return seq + 16 - last;
		}
	}
}
