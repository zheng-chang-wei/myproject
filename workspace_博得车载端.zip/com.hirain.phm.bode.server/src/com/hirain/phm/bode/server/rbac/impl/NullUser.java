package com.hirain.phm.bode.server.rbac.impl;

import com.hirain.phm.bode.server.rbac.IUser;

public class NullUser implements IUser {

	@Override
	public String getUsername() {
		return "null";
	}

	@Override
	public String getPassword() {
		return "null";
	}

}
