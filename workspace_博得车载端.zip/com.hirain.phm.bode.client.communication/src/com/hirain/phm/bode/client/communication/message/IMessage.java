/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.message;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 16, 2019 4:34:05 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 16, 2019 zepei.tao@hirain.com 1.0 create file
 */
public interface IMessage {

	byte getPid();

	void setPid(byte pid);

	/**
	 * 整条报文的长度
	 * 
	 * @return
	 */
	int getLength();

	void setLength(int length);

	byte getErrorCode();

	void setErrorCode(final byte errorCode);

	String getError();

	void setError(String error);
}
