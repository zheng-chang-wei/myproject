package com.hirain.phm.bode.server.mqtt;

import org.eclipse.paho.client.mqttv3.MqttException;

public interface MqttConnection extends MqttSubscriber, MqttPublisher {

	void connect() throws Exception;

	void connect(String caCrtFile, String crtFile, String keyFile, String password) throws Exception;

	void disconnect() throws MqttException;

}
