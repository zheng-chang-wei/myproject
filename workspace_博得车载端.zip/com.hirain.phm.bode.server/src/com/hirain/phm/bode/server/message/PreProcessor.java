package com.hirain.phm.bode.server.message;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.bus.MessageEvent;
import com.hirain.phm.bode.server.bus.MessageListEvent;

public class PreProcessor implements IPreProcessor {

	static Logger logger = Logger.getLogger(PreProcessor.class);

	private final DoorMessageDecoder decoder = new DoorMessageDecoder();

	private final EventBus bus = new EventBus("pre processor");

	private final Map<Integer, MessageSorter> sorterMap = new HashMap<>();

	public void init() {
		InnerEventBus.getInstance().register(this);
	}

	@Subscribe
	public void on(MessageEvent event) {
		final byte[] datas = event.getDatas();
		final boolean res = checkData(datas);
		if (!res) {
			return;
		}
		final DoorMessage message = decoder.decode(datas);
		final MessageSorter sorter = sorterMap.get(message.getCarriageId());
		if (sorter != null) {
			sorter.push(message);
		}
	}

	private boolean checkData(byte[] datas) {
		final byte id1 = datas[0];
		final byte id2 = datas[8];
		final byte id3 = datas[16];
		final byte id4 = datas[24];
		if (id1 >= 0 && id1 <= 0xf) {
			if (id1 == id2 && id1 == id3 && id1 == id4) {
				return true;
			}
		}
		return false;
	}

	@Subscribe
	public void on(ConfigEvent event) {
		InnerEventBus.getInstance().unregister(this);
		final ITrain train = event.getTrain();
		final List<ICar> cars = train.getCars();
		final Set<Integer> idSet = new HashSet<>();
		for (final ICar car : cars) {
			if (car.getType() == 0) {
				continue;
			}
			final int carriageId = car.getIndex();
			MessageSorter sorter = sorterMap.get(carriageId);
			if (sorter == null) {
				sorter = new MessageSorter(this, carriageId, car.getDoors());
				sorter.work();
				sorterMap.put(carriageId, sorter);
			}
			idSet.add(carriageId);
		}
		for (final Integer key : sorterMap.keySet()) {
			if (!idSet.contains(key)) {
				MessageSorter sorter = sorterMap.get(key);
				sorter.stop();
				sorter = null;
				sorterMap.remove(key);
			}
		}
		InnerEventBus.getInstance().register(this);
	}

	public void post(List<DoorMessage> messages) {
		bus.post(new MessageListEvent(messages));
	}

	@Override
	public void register(Object object) {
		bus.register(object);
	}

	@Override
	public void unregister(Object object) {
		bus.unregister(object);
	}
}
