package com.hirain.phm.bode.server.comm.impl;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;

import com.hirain.phm.bode.server.comm.ITransportPacket;

public class TransportPacketImpl implements ITransportPacket {

	private InetSocketAddress address;

	private int port;

	private int pid;

	private int length;

	private byte[] data;

	@Override
	public InetSocketAddress getAddress() {
		return address;
	}

	@Override
	public void setAddress(InetSocketAddress address) {
		this.address = address;
	}

	@Override
	public int getPid() {
		return pid;
	}

	@Override
	public void setPid(int pid) {
		this.pid = pid;
	}

	@Override
	public int getLength() {
		return length;
	}

	@Override
	public void setLength(int length) {
		this.length = length;
	}

	@Override
	public byte[] getData() {
		return data;
	}

	@Override
	public void setData(byte[] data) {
		this.data = data;
	}

	@Override
	public byte[] toByte() {
		ByteBuffer buffer = ByteBuffer.allocate(1 + 2 + data.length);
		buffer.put((byte) pid);
		buffer.putShort((short) length);
		buffer.put(data);
		return buffer.array();
	}

	@Override
	public int localPort() {
		return port;
	}

	@Override
	public void setLocalPort(int port) {
		this.port = port;
	}

}
