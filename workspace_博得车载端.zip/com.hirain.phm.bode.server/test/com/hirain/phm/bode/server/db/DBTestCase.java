package com.hirain.phm.bode.server.db;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.AfterClass;
import org.junit.BeforeClass;

public class DBTestCase {

	protected static SqlSession session;

	@BeforeClass
	public static void before() {
		String resource = "mybatis-config.xml";
		Reader reader;
		try {
			reader = Resources.getResourceAsReader(resource);
			SqlSessionFactory ssf = new SqlSessionFactoryBuilder().build(reader);
			session = ssf.openSession();
		} catch (IOException e) {
			e.printStackTrace();
			if (session != null) {
				session.close();
			}
		}
	}

	public <T> T getMapper(Class<T> clz) {
		return session.getMapper(clz);
	}

	@AfterClass
	public static void afterClass() {
		session.close();
	}
}
