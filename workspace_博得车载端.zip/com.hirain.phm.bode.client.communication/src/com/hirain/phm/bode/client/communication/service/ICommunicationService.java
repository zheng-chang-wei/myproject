/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.service;

import com.google.common.eventbus.EventBus;
import com.hirain.phm.bode.client.communication.message.SpaceMessage;
import com.hirain.phm.bode.client.communication.message.SystemInfoMessage;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 16, 2019 1:42:02 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 16, 2019 zepei.tao@hirain.com 1.0 create file
 */
public interface ICommunicationService {

	/**
	 * 启动通信服务
	 *
	 * @param ip
	 * @return
	 */
	int start(String ip);

	/**
	 * 停止通信
	 *
	 * @return
	 */
	int stop();

	/**
	 * 查询心跳
	 * 
	 * @return
	 */
	boolean inquireHeartBeat();

	/**
	 * 登录指令
	 * 
	 * @param str
	 *            用户名和密码组成的字符串
	 * @return
	 */
	boolean login(String str);

	/**
	 * 登出指令
	 * 
	 * @return
	 */
	boolean logout();

	/**
	 * 查询系统信息
	 */
	SystemInfoMessage inquireSystemInfo();

	/**
	 * 配置系统信息
	 * 
	 * @param bytes
	 *            ITrain对象按照协议转换得到的byte数组
	 * @return
	 */
	boolean configSystemInfo(byte[] bytes);

	/**
	 * 查询存储空间
	 */
	SpaceMessage inquireStorageSpace();

	/**
	 * 下载操作通知
	 */
	boolean commandDownload();

	/**
	 * 查询数据库
	 * 
	 * @param sid
	 *            查询的数据类型
	 * @param sql
	 *            查询的sql语句
	 * @return
	 */
	void select(byte pid, byte sid, String sql);

	/**
	 * 调试模式指令
	 * 
	 * @param type
	 *            1：开启调试模式 2：关闭调试模式
	 * @return
	 */
	boolean commandDebug(byte type);

	/**
	 * 通知解析模块，当前选择的车厢号和车门地址
	 * 
	 * @param carNo
	 *            车厢号
	 * @param doorAddr
	 *            门地址
	 */
	void notifyDoorAddr(int carNo, int doorAddr);

	/**
	 * 下载故障数据或实时数据
	 * 
	 * @param bytes
	 *            协议中有效数据
	 */
	void download(byte[] bytes);

	EventBus getEventBus();

}
