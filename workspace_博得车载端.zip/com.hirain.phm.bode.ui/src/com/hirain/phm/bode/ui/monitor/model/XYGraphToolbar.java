/*******************************************************************************
 * Copyright (c) 2010, 2017 Oak Ridge National Laboratory and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 ******************************************************************************/
package com.hirain.phm.bode.ui.monitor.model;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.draw2d.ActionEvent;
import org.eclipse.draw2d.ActionListener;
import org.eclipse.draw2d.Button;
import org.eclipse.draw2d.ButtonGroup;
import org.eclipse.draw2d.ChangeEvent;
import org.eclipse.draw2d.ChangeListener;
import org.eclipse.draw2d.Clickable;
import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.ImageFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.ToggleButton;
import org.eclipse.draw2d.ToggleModel;
import org.eclipse.nebula.visualization.internal.xygraph.toolbar.WrappableToolbarLayout;
import org.eclipse.nebula.visualization.xygraph.figures.IXYGraph;
import org.eclipse.nebula.visualization.xygraph.figures.XYGraphFlags;
import org.eclipse.nebula.visualization.xygraph.figures.ZoomType;
import org.eclipse.nebula.visualization.xygraph.util.XYGraphMediaFactory;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;

/**
 * The toolbar for an xy-graph.
 * �޸ģ����ƹ�����
 *
 * @author Xihui Chen
 * @author Kay Kasemir (some zoom operations)
 */
public class XYGraphToolbar extends Figure {

	private final static int BUTTON_SIZE = 25;

	final private IXYGraph xyGraph;

	final private ButtonGroup zoomGroup;

	final private Map<ZoomType, ToggleModel> zoomButtonModelMap = new HashMap<ZoomType, ToggleModel>();

	private ToolbarLabelDescriptor descriptor;

	/**
	 * Initialize
	 *
	 * @param xyGraph
	 *            XYGraph on which this toolbar operates
	 * @param flags
	 *            Bitwise 'or' of flags
	 * @see XYGraphFlags#COMBINED_ZOOM
	 * @see XYGraphFlags#SEPARATE_ZOOM
	 */
	public XYGraphToolbar(final IXYGraph xyGraph, final int flags) {
		this.xyGraph = xyGraph;
		descriptor = new ToolbarLabelDescriptor();
		setLayoutManager(new WrappableToolbarLayout());

		// final Button configButton = new Button(XYGraphMediaFactory.getInstance().getImage("images/Configure.png"));
		// configButton.setToolTip(new Label("Configure Settings..."));
		// addButton(configButton);
		// configButton.addActionListener(new ActionListener() {
		//
		// @Override
		// public void actionPerformed(final ActionEvent event) {
		// final XYGraphConfigDialog dialog = new XYGraphConfigDialog(Display.getCurrent().getActiveShell(), xyGraph);
		// dialog.open();
		// }
		// });

		// final ToggleButton showLegend = new ToggleButton("", XYGraphMediaFactory.getInstance().getImage("images/ShowLegend.png"));
		// showLegend.setToolTip(new Label("Show Legend"));
		// addButton(showLegend);
		// showLegend.addActionListener(new ActionListener() {
		//
		// @Override
		// public void actionPerformed(final ActionEvent event) {
		// xyGraph.setShowLegend(!xyGraph.isShowLegend());
		// }
		// });
		//
		// showLegend.setSelected(xyGraph.isShowLegend());

		// addSeparator();
		// final Button addAnnotationButton = new Button(XYGraphMediaFactory.getInstance().getImage("images/Add_Annotation.png"));
		// addAnnotationButton.setToolTip(new Label("Add Annotation..."));
		// addButton(addAnnotationButton);
		// addAnnotationButton.addActionListener(new ActionListener() {
		//
		// @Override
		// public void actionPerformed(final ActionEvent event) {
		// final AddAnnotationDialog dialog = new AddAnnotationDialog(Display.getCurrent().getActiveShell(), xyGraph);
		// if (dialog.open() == Window.OK) {
		// xyGraph.addAnnotation(dialog.getAnnotation());
		// xyGraph.getOperationsManager().addCommand(new AddAnnotationCommand(xyGraph, dialog.getAnnotation()));
		// }
		// }
		// });

		// final Button delAnnotationButton = new Button(XYGraphMediaFactory.getInstance().getImage("images/Del_Annotation.png"));
		// delAnnotationButton.setToolTip(new Label("Remove Annotation..."));
		// addButton(delAnnotationButton);
		// delAnnotationButton.addActionListener(new ActionListener() {
		//
		// @Override
		// public void actionPerformed(final ActionEvent event) {
		// final RemoveAnnotationDialog dialog = new RemoveAnnotationDialog(Display.getCurrent().getActiveShell(), xyGraph);
		// if (dialog.open() == Window.OK && dialog.getAnnotation() != null) {
		// xyGraph.removeAnnotation(dialog.getAnnotation());
		// xyGraph.getOperationsManager().addCommand(new RemoveAnnotationCommand(xyGraph, dialog.getAnnotation()));
		// }
		// }
		// });

		// addSeparator();
		if ((flags & XYGraphFlags.STAGGER) > 0) { // stagger axes button
			final Button staggerButton = new Button(XYGraphMediaFactory.getInstance().getImage("images/stagger.png"));
			staggerButton.setToolTip(new Label("Stagger axes so they don't overlap"));
			addButton(staggerButton);
			staggerButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(final ActionEvent event) {
					xyGraph.performStagger();
				}
			});
		} else { // auto scale button
			final Button autoScaleButton = new Button(XYGraphMediaFactory.getInstance().getImage("images/AutoScale.png"));
			autoScaleButton.setToolTip(new Label("还原"));
			addButton(autoScaleButton);
			autoScaleButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(final ActionEvent event) {
					xyGraph.performAutoScale();
				}
			});
		}

		// zoom buttons
		zoomGroup = new ButtonGroup();
		createZoomButtons(flags);

	}


	/**
	 * Create buttons enumerated in <code>ZoomType</code>
	 *
	 * @param flags
	 *            Bitwise 'or' of flags
	 * @see XYGraphFlags#COMBINED_ZOOM
	 * @see XYGraphFlags#SEPARATE_ZOOM
	 */
	private void createZoomButtons(final int flags) {
		for (final ZoomType zoomType : ZoomType.values()) {
			if (ZoomType.DYNAMIC_ZOOM == zoomType) {
				continue;
			}
			if (!zoomType.useWithFlags(flags)) {
				continue;
			}
			final ImageFigure imageFigure = new ImageFigure(zoomType.getIconImage());
			final Label tip = new Label(descriptor.getCNLabel(zoomType.getDescription()));
			final ToggleButton button = new ToggleButton(imageFigure);
			button.setBackgroundColor(ColorConstants.button);
			button.setOpaque(true);
			final ToggleModel model = new ToggleModel();
			model.addChangeListener(new ChangeListener() {

				@Override
				public void handleStateChanged(final ChangeEvent event) {
					if (event.getPropertyName().equals("selected") && button.isSelected()) {
						xyGraph.setZoomType(zoomType);
					}
				}
			});

			button.setModel(model);
			zoomButtonModelMap.put(zoomType, model);
			button.setToolTip(tip);
			addButton(button);
			zoomGroup.add(model);

			if (zoomType == ZoomType.NONE) {
				zoomGroup.setDefault(model);
			}
		}
		xyGraph.addPropertyChangeListener(IXYGraph.PROPERTY_ZOOMTYPE, new PropertyChangeListener() {

			@Override
			public void propertyChange(final PropertyChangeEvent evt) {
				zoomGroup.setSelected(zoomButtonModelMap.get(evt.getNewValue()));
			}
		});
	}

	public void addButton(final Clickable button) {
		button.setPreferredSize(BUTTON_SIZE, BUTTON_SIZE);
		add(button);
	}

	public void addSeparator() {
		final ToolbarSeparator separator = new ToolbarSeparator();
		separator.setPreferredSize(BUTTON_SIZE / 2, BUTTON_SIZE);
		add(separator);
	}

	private static class ToolbarSeparator extends Figure {

		private final Color GRAY_COLOR = XYGraphMediaFactory.getInstance().getColor(new RGB(130, 130, 130));

		@Override
		protected void paintClientArea(final Graphics graphics) {
			super.paintClientArea(graphics);
			graphics.setForegroundColor(GRAY_COLOR);
			graphics.setLineWidth(1);
			graphics.drawLine(bounds.x + bounds.width / 2, bounds.y, bounds.x + bounds.width / 2, bounds.y + bounds.height);
		}
	}
}
