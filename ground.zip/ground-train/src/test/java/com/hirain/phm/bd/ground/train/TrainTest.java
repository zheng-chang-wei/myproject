package com.hirain.phm.bd.ground.train;


import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.hirain.phm.bd.ground.train.dao.TrainMapper;
import com.hirain.phm.bd.ground.train.domain.Train;
import com.hirain.phm.bd.ground.train.service.impl.TrainServiceImpl;


//@RunWith(MockitoJUnitRunner.class)
public class TrainTest {

	@Mock
	TrainMapper trainMapper;

	@InjectMocks
	TrainServiceImpl trainService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void test() {
		Train train = new Train();
		train.setTrainNo("01");
		when(trainMapper.selectByProjectAndNo("aa", "bb")).thenReturn(train);
		Train select = trainService.select("aa", "bb");
		Assert.assertEquals(train, select);
	}


}