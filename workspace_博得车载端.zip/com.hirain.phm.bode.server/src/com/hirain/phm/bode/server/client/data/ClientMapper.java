package com.hirain.phm.bode.server.client.data;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface ClientMapper {

	List<RecordQuery> queryRecord(@Param("querySql") String sql);

	List<Fault> queryFault(@Param("querySql") String sql);

	List<FaultRecordQuery> queryFaultRecord(@Param("querySql") String sql);

	List<Message> downloadMessage(@Param("querySql") String sql);

	Long count(@Param("querySql") String sql);
}
