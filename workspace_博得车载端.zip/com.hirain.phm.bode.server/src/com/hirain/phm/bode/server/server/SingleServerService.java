package com.hirain.phm.bode.server.server;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IMdcu;
import com.hirain.phm.bode.core.IServer;
import com.hirain.phm.bode.core.IServerIp;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.impl.ServerIpType;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.bus.MacResultEvent;
import com.hirain.phm.bode.server.bus.SendEvent;
import com.hirain.phm.bode.server.comm.ITransportPacket;

public class SingleServerService extends AbstractServerService {

	private Set<String> antiMulti1 = new HashSet<>();

	private Set<String> antiMulti2 = new HashSet<>();

	private int cacheSize = 400;

	@Override
	public void post(ITransportPacket packet) {
		if (packet.getPid() == ServerConstant.DOOR_MESSAGE_PID) {
			processMessage(packet);
		}
	}

	@Subscribe
	public void on(SendEvent event) {
		System.out.println(event);
		if (event.getPid() == ServerConstant.ASK_MAC_ID) {
			final String mac = "FF-FF-FF-FF-FF-FF";
			InnerEventBus.getInstance().post(new MacResultEvent(mac.getBytes()));
		}
	}

	@Subscribe
	public void on(ConfigEvent event) {
		configChanged(event);
	}

	private void configChanged(ConfigEvent event) {
		final ITrain train = event.getTrain();
		final List<IServer> servers = train.getServers();
		final List<String> locahosts = Utils.locahosts();
		int index = -1;
		for (int i = 0; i < servers.size(); i++) {
			final IServer server = servers.get(i);
			final List<IServerIp> list = server.getServesIps();
			for (final IServerIp sIP : list) {
				if (sIP.getType().equals(ServerIpType.Type1)) {
					final String ip = sIP.getIp();
					if (locahosts.contains(ip)) {
						restart(ip);
						index = i;
					}
				}
			}
		}
		if (index == -1) {
			return;
		}
		if (liveHandler != null) {
			liveHandler.stop();
		}
		liveHandler = new MDCULiveHandler(this);
		int doorCount = 0;
		final List<ICar> cars = train.getCars();
		for (final ICar car : cars) {
			final List<IMdcu> mdcus = car.getMdcus();
			for (final IMdcu mdcu : mdcus) {
				sendOk(mdcu.getIp());
				liveHandler.addMdcu(mdcu.getIp());
			}
			doorCount += car.getDoors().size();
		}
		cacheSize = doorCount * 4;
		liveHandler.start();
	}

	@Override
	protected boolean doProcessMessage(byte[] data) {
		final String key = generateKey(data);
		if (antiMulti2.contains(key)) {
			return false;
		}
		if (antiMulti1.contains(key)) {
			return false;
		}
		if (antiMulti2.size() > cacheSize) {
			final Set<String> temp = antiMulti1;
			antiMulti1 = antiMulti2;
			antiMulti2 = temp;
			antiMulti2.clear();
		}
		if (antiMulti1.size() > cacheSize) {
			antiMulti2.add(key);
		} else {
			antiMulti1.add(key);
		}
		return true;
	}

	private String generateKey(byte[] datas) {
		final StringBuilder builder = new StringBuilder();
		builder.append(byte2Hex(datas[0]));
		builder.append(byte2Hex(datas[12]));
		builder.append(byte2Hex(datas[21]));
		builder.append(byte2Hex(datas[22]));
		builder.append(byte2Hex(datas[23]));
		builder.append(byte2Hex(datas[25]));
		builder.append(byte2Hex(datas[26]));
		builder.append(byte2Hex(datas[27]));
		return builder.toString();
	}

	private String byte2Hex(byte b) {
		final String hex = Integer.toHexString(b);
		if (hex.length() < 2) {
			return "0" + hex;
		}
		return hex;
	}
}
