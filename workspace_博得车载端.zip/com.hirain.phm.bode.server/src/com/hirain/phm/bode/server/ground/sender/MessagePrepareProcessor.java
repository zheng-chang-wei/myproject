package com.hirain.phm.bode.server.ground.sender;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.hirain.phm.bd.message.CarriagePacket;
import com.hirain.phm.bd.message.DoorPacket;
import com.hirain.phm.bd.message.TrainPacket;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.ZipUtil;
import com.hirain.phm.bode.server.message.DoorMessage;
import com.hirain.phm.bode.server.mqtt.MqttPublisher;

import lombok.Setter;

public class MessagePrepareProcessor {

	private final Map<Integer, CarriageCache> realtimeMap = new ConcurrentHashMap<>();

	private int index = 0;

	private String city;

	private String line;

	private String train;

	private ScheduledExecutorService executorService;

	@Setter
	private RealtimeMessageSender realTimeSender;

	@Setter
	private HistoryMessageSender historySender;

	public MessagePrepareProcessor() {
		realTimeSender = new RealtimeMessageSender();
		historySender = new HistoryMessageSender();
	}

	public void start() {
		historySender.start();
		executorService = Executors.newSingleThreadScheduledExecutor(r -> new Thread(r, MessagePrepareProcessor.class.getName()));
		executorService.scheduleAtFixedRate(() -> {
			final List<CarriagePacket> packets = new ArrayList<>();
			for (final Integer key : realtimeMap.keySet()) {
				final CarriageCache carriageCache = realtimeMap.get(key);
				final List<DoorPacket> list = carriageCache.get(16);
				if (!list.isEmpty()) {
					packets.add(new CarriagePacket(key, list));
				}
			}
			if (packets.isEmpty()) {
				return;
			}
			final TrainPacket packet = new TrainPacket(index, packets);
			packet.set(city, line, train);
			final String string = Utils.toJsonString(packet);
			byte[] bytes = string.getBytes(Charset.forName("utf-8"));
			final byte[] payload = ZipUtil.compress(bytes);
			send(payload);
		}, 800, 800, TimeUnit.MILLISECONDS);
	}

	public void stop() {
		if (executorService != null) {
			executorService.shutdown();
			executorService = null;
		}
		historySender.stop();
	}

	public void add(List<DoorMessage> messages, boolean debug) {
		final Integer carriageId = messages.get(0).getCarriageId();
		CarriageCache carriageCache = realtimeMap.get(carriageId);
		if (carriageCache == null) {
			carriageCache = new CarriageCache();
			realtimeMap.put(carriageId, carriageCache);
		}
		carriageCache.add(messages.get(0).getDoorId(), messages, debug);
	}

	private void send(final byte[] payload) {
		System.out.println("send");
		realTimeSender.send(payload);
		historySender.send(payload);
	}

	public void set(String city, String line, String train) {
		this.city = city;
		this.line = line;
		this.train = train;
		realTimeSender.setTopic("realtime/" + city + "/" + line + "/" + train);
		historySender.setTopic("test/" + city + "/" + line + "/" + train);
	}

	public void set(int index) {
		this.index = index;
	}

	public void setPublisher(MqttPublisher publisher) {
		realTimeSender.setPublisher(publisher);
		historySender.setPublisher(publisher);
	}
}
