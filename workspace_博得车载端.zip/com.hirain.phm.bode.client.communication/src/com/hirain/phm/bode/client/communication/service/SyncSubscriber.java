/*******************************************************************************
 * Copyright (c) 2018, 2018 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.service;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2018年11月9日 下午1:47:33
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2018年11月9日 jianwen.xin@hirain.com 1.0 create file
 */
abstract class SyncSubscriber<T> {

	private T response;

	private final CountDownLatch latch = new CountDownLatch(1);

	public boolean isDone() {
		return response != null;
	}

	public T get() throws InterruptedException {
		latch.await();
		return response;
	}

	public T get(final long timeout, final TimeUnit unit) throws InterruptedException {
		if (latch.await(timeout, unit)) {
			return response;
		}
		return null;
	}

	/**
	 * @param response
	 *            the response to set
	 */
	protected void setResponse(final T response) {
		this.response = response;
		latch.countDown();
	}
}
