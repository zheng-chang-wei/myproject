<template>
  <div id="life-list">
    <el-row class="life-panel home-card">
      <!-- <div class="card-border card-border-top-left"></div>
      <div class="card-border card-border-top-right"></div>
      <div class="card-border card-border-bottom-left"></div>
      <div class="card-border card-border-bottom-right"></div> -->
      <el-col :span="24">
        <div class="card-panel">
          <div class="card-title">今日寿命预警</div>
          <el-table
            :data="lifeList"
            :header-cell-style="{background:'#0f1741',color:'#fff',padding:'3px',borderColor:'#0f1741'}"
            :row-style="{background:'#394761',color:'#fff'}"
            :cell-style="{padding:'2px',borderColor:'#0f1741'}"
            class="fault-table"
          >
            <el-table-column prop="project" label="项目" align="center" width="80px" />
            <el-table-column prop="train" label="车号" align="center" width="80px" />
            <el-table-column prop="faultContent" label="预警描述" align="center" width="160px" />
            <el-table-column prop="faultTime" label="发生时间" align="center" />
          </el-table>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
export default {
  props: {
    lifeList: {
      type: Array,
      default: null
    }
  },
  data() {
    return {}
  }
}

</script>
<style scoped>
  #life-list {
    margin: 2px;
    background-color: #0f1741;
    height: 230px;
  }

  .life-panel {
    height: 100%;
  }

  .life-panel .card-panel {
    height: 100%;
    position: relative;
    overflow: hidden;
  }

  .life-panel .card-title {
    color: #fff;
    text-align: center;
    background-color: #FF9900;
    font-weight: bold;
  }

</style>
