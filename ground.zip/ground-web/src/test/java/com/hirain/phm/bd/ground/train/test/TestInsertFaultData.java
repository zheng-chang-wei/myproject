/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.ground.train.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hirain.phm.bd.ground.GroundWebApplication;
import com.hirain.phm.bd.ground.fault.dao.FaultDetailMapper;
import com.hirain.phm.bd.ground.fault.domain.FaultDetail;
import com.hirain.phm.bd.ground.fault.service.FaultDataService;
import com.hirain.phm.bd.message.train.FaultMessage;
import com.hirain.phm.bd.message.train.FaultRawData;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2020年1月7日 上午9:50:35
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2020年1月7日 changwei.zheng@hirain.com 1.0 create file
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = GroundWebApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TestInsertFaultData {

	@Autowired
	private FaultDetailMapper faultDetailMapper;

	@Autowired
	FaultDataService faultDataService;


	@Test
	public void test() {
		List<FaultDetail> faultDetails = faultDetailMapper.selectAll();
		for (FaultDetail faultDetail : faultDetails) {
			FaultMessage faultMessage=new FaultMessage();
			// 电机电压，电机电流，编码器值
			faultMessage.setKeys(Arrays.asList(new String[] { "电机电压", "电机电流", "编码器值" }));
			faultMessage.setState(0);
			List<FaultRawData> datas = new ArrayList<>();
			for (int i = 0; i < 50; i++) {
				FaultRawData data = new FaultRawData();
				data.setTimestamp(new Date());
				List<String> list = new ArrayList<>();
				for (int j = 0; j < 3; j++) {
					list.add(String.valueOf(new Random().nextInt(100)));
				}
				data.setValues(list);
				datas.add(data);
			}
			faultMessage.setDatas(datas);
			faultDataService.saveFaultData(faultDetail.getId(), faultMessage);
		}
	}

}
