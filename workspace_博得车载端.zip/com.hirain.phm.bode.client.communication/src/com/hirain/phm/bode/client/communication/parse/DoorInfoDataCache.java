/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.parse;

import java.util.HashMap;
import java.util.Map;

import com.hirain.phm.bode.core.dataframe.DoorStatus;
import com.hirain.phm.bode.core.dataframe.IDataFrame;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 29, 2019 6:36:16 PM
 * @Description
 *              <p>
 *              服务器上传车门信息数据的缓存对象
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 29, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DoorInfoDataCache {

	private static Map<Byte, Map<IDataFrame, DoorStatus>> map = new HashMap<Byte, Map<IDataFrame, DoorStatus>>();

	public static Map<Byte, Map<IDataFrame, DoorStatus>> getMap() {
		return map;
	}

}
