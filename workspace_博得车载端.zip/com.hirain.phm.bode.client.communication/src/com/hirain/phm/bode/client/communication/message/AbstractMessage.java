/*******************************************************************************
 * Copyright (c) 2018, 2018 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.message;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2018年11月8日 下午2:46:11
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2018年11月8日 jianwen.xin@hirain.com 1.0 create file
 */
public class AbstractMessage implements IMessage {

	private byte pid;

	/**
	 * 整条报文的长度
	 */
	private int length;

	private byte errorCode;

	private String error;

	@Override
	public byte getPid() {
		return pid;
	}

	@Override
	public void setPid(byte pid) {
		this.pid = pid;
	}

	@Override
	public int getLength() {
		return length;
	}

	@Override
	public void setLength(int length) {
		this.length = length;
	}

	@Override
	public byte getErrorCode() {
		return errorCode;
	}

	@Override
	public void setErrorCode(byte errorCode) {
		this.errorCode = errorCode;
	}

	@Override
	public String getError() {
		return error;
	}

	@Override
	public void setError(String error) {
		this.error = error;
	}

}
