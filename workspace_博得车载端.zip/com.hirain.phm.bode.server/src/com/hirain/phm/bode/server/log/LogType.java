package com.hirain.phm.bode.server.log;

public enum LogType {

	CARINFO("车辆信息记录"),

	LOGIN("登录记录"),

	LOGOUT("登出记录"),

	SYSTEM("系统设置记录"),

	FAULT_DOWNLOAD("下载故障记录"),

	COMMON_DOWNLOAD("下载普通数据记录"),

	DEBUG("调试记录");

	private String desc;

	LogType(String desc) {
		this.desc = desc;
	}

	public String desc() {
		return desc;
	}
}
