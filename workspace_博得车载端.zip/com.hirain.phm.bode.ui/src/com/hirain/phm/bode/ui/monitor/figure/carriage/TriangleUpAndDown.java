package com.hirain.phm.bode.ui.monitor.figure.carriage;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.geometry.PointList;
import org.eclipse.draw2d.geometry.Rectangle;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月11日 下午1:50:03
 * @Description
 *              <p>
 *              防挤压标识的上下两个三角形
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月11日 changwei.zheng@hirain.com 1.0 create file
 */
public class TriangleUpAndDown extends Figure {

	@Override
	protected void paintFigure(Graphics g) {
		Rectangle r = bounds;
		PointList pointList = new PointList();
		pointList.addPoint(r.x, r.y);
		pointList.addPoint(r.x + r.width, r.y);
		pointList.addPoint(r.x + r.width / 2, r.y + r.height / 2);
		pointList.addPoint(r.x, r.y + r.height);
		pointList.addPoint(r.x + r.width, r.y + r.height);
		g.fillPolygon(pointList);
		setBackgroundColor(ColorConstants.yellow);

	}
}
