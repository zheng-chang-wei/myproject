/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.util;

import java.io.File;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.impl.Train;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 11, 2019 2:45:26 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 11, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class MarshalUtil {

	private static final String JAXB_ENCODING_VALUE = "UTF-8";

	private static final boolean JAXB_FORMATTED_OUTPUT_VALUE = true;

	// private static Set<String> uniqueStrs = new HashSet<String>();

	public static void marshalToXml(final ITrain train, final String filePath) throws Exception {
		// preMarshal(systemInfo);
		marshal(train, filePath);
	}

	public static ITrain unmarshalToSystemInfo(final String filePath) throws Exception {
		final ITrain train = (ITrain) unmarshal(Train.class, filePath);
		// root.setXmlPath(filePath);
		// updateCacheModelStructure(root);
		return train;
	}

	public static ITrain unmarshalXmlstr2SystemInfo(String xmlStr) throws Exception {
		if (StringUtil.isEmpty(xmlStr)) {
			return null;
		}
		final JAXBContext context = JAXBContext.newInstance(Train.class);
		final Unmarshaller unmarshaller = context.createUnmarshaller();
		StringReader sr = new StringReader(xmlStr);
		return (ITrain) unmarshaller.unmarshal(sr);
	}

	public static byte[] marshalSystemInfo2XmlBytes(ITrain train) throws Exception {
		// 创建输出流
		StringWriter sw = new StringWriter();

		// 利用jdk中自带的转换类实现
		JAXBContext context = JAXBContext.newInstance(train.getClass());

		Marshaller marshaller = context.createMarshaller();
		// 格式化xml输出的格式
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, JAXB_FORMATTED_OUTPUT_VALUE);
		// 去掉生成xml的默认报文头
		marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
		marshaller.setProperty(Marshaller.JAXB_ENCODING, JAXB_ENCODING_VALUE);
		// 将对象转换成输出流形式的xml
		marshaller.marshal(train, sw);

		return sw.toString().getBytes("UTF-8");
	}

	public static void marshal(final Object object, final String filePath) throws Exception {
		final File file = new File(filePath);
		if (!file.exists()) {
			final File parentFile = file.getParentFile();
			if (!parentFile.exists()) {
				parentFile.mkdirs();
			}
			file.createNewFile();
		}
		final JAXBContext context = JAXBContext.newInstance(object.getClass());
		final Marshaller marshaller = context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_ENCODING, JAXB_ENCODING_VALUE);
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, JAXB_FORMATTED_OUTPUT_VALUE);
		marshaller.marshal(object, file);
	}

	@SuppressWarnings("rawtypes")
	private static Object unmarshal(final Class clazz, final String filePath) throws Exception {
		final File file = new File(filePath);
		if (!file.exists()) {
			throw new Exception("file is not exist: " + filePath);
		}
		final JAXBContext context = JAXBContext.newInstance(clazz);
		final Unmarshaller unmarshaller = context.createUnmarshaller();
		return unmarshaller.unmarshal(file);
	}
}
