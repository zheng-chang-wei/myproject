/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.ground.maintenance.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;

import com.hirain.phm.bd.ground.common.config.CommonMapper;
import com.hirain.phm.bd.ground.maintenance.domain.WorkSheet;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年5月29日 下午4:24:27
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年5月29日 jianwen.xin@hirain.com 1.0 create file
 */
public interface WorkSheetMapper extends CommonMapper<WorkSheet> {

	@Select("select * from t_worksheet where id=#{id} for update")
	WorkSheet selectWithLock(Long id);

	@SelectProvider(type = SheetMapperProvider.class, method = "selectByLines")
	List<WorkSheet> selectByLines(List<Integer> trainIds);

	@Select("select * from t_worksheet where user_id=#{userId} order by create_time desc")
	List<WorkSheet> selectByUserId(Long userId);

	@SelectProvider(type = SheetMapperProvider.class, method = "selectEditSheet")
	List<WorkSheet> selectEditSheet(@Param("ids") List<Long> ids);

	class SheetMapperProvider {

		public String selectByLines(List<Integer> trainIds) {
			String sql = "select * from t_worksheet where state in ('创建工单','关闭')  ";
			StringBuilder sb = new StringBuilder();
			sb.append(sql);
			if (trainIds != null) {
				sb.append("and train_id in");
				sb.append(" (");
				trainIds.forEach(t -> {
					sb.append(t).append(",");
				});
				sb.deleteCharAt(sb.length() - 1);
				sb.append(") ");
			}
			System.err.println(sb.toString());
			return sb.toString();
		}

		public String selectEditSheet(List<Long> ids) {
			String sql = "select t_worksheet.*,t_project.name project from t_worksheet" +

					" left join t_project on t_project.id=t_worksheet.project_id" +

					" where state='创建工单' and project_id in ";
			StringBuilder sb = new StringBuilder();
			ids.forEach(t -> {
				sb.append(t).append(",");
			});
			String in = sb.substring(0, sb.length() - 1);
			String out = sql + "(" + in + ")";
			System.err.println(out);
			return out;
		}
	}
}
