package com.hirain.phm.bode.server.bus;

public class MessageEvent {

	byte[] datas;

	public MessageEvent(byte[] datas) {
		this.datas = datas;
	}

	public byte[] getDatas() {
		return datas;
	}

}
