package com.hirain.phm.bode.ui.monitor.model;

public enum SignalState {
	// 信号正常
	signal_ok(0, "icons/green.ico"),
	// 信号异常
	signal_error(1, "icons/red.ico"),
	// 无信号
	signal_null(2, "icons/gray.ico");

	private int code;

	private String imagePath;

	SignalState(int code, String imagePath) {
		this.code = code;
		this.imagePath = imagePath;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

}
