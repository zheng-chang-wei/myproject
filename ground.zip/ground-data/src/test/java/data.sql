insert into t_project(id,name,city,line,remarks)
values(1,'深圳地铁7号线','深圳','7','');

insert into t_train(id,project_id,train_no,train_status)
values(1,1,'717',1);

insert into t_big values
(1,100,500);

insert into t_big_train values
(1,1,'2019-11-10','2019-11-11');

insert into t_big_project values
('深圳地铁7号线',100);