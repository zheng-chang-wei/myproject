package com.hirain.phm.bd.store.domain;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class StoreEntry {

	LocalDateTime time;

	byte[] datas;
}