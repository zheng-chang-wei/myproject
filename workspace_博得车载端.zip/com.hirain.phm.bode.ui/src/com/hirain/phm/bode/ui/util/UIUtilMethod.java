/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.SWTResourceManager;

import com.hirain.phm.bode.core.util.RegularUtil;
import com.hirain.phm.bode.core.util.StringUtil;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 23, 2019 4:39:42 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 23, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class UIUtilMethod {

	private static Font DEFAULT_FONT = SWTResourceManager.getFont("Malgun Gothic Semilight", 12, SWT.BOLD);

	public static void setErrorMessage(Label label, String message) {
		if (label == null) {
			return;
		}
		label.setText(message);
		label.setForeground(Display.getDefault().getSystemColor(SWT.COLOR_RED));
		label.setFont(DEFAULT_FONT);
	}

	public static void setCommonMessage(Label label, String message) {
		if (label == null) {
			return;
		}
		if (message == null) {
			label.setText(StringUtil.EMPTY);
			return;
		}
		label.setText(message);
		label.setForeground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
		label.setFont(DEFAULT_FONT);
	}

	public static boolean verfityIp(String IPValue) {
		final Pattern pattern = Pattern.compile(RegularUtil.HOST_IP);
		final Matcher matcher = pattern.matcher(IPValue);
		if (!matcher.matches()) {
			return false;
		} else {
			return true;
		}
	}

	public static void showCommunicationException() {
		MessageDialog.openError(Display.getDefault().getActiveShell(), "错误", "与服务端通信异常！");
	}
}
