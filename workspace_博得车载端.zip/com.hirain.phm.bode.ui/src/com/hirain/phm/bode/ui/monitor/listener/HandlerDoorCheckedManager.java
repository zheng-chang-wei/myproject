package com.hirain.phm.bode.ui.monitor.listener;

import java.util.ArrayList;
import java.util.List;

import com.hirain.phm.bode.core.ICar;

public class HandlerDoorCheckedManager {

	private final List<DoorCheckedListener> listeners = new ArrayList<DoorCheckedListener>();

	private static HandlerDoorCheckedManager instance = null;

	private HandlerDoorCheckedManager() {

	}

	public static HandlerDoorCheckedManager getInstatnce() {
		if (instance == null) {
			instance = new HandlerDoorCheckedManager();
		}
		return instance;
	}

	public void add(DoorCheckedListener listener) {
		listeners.removeAll(listeners);
		listeners.add(listener);
	}

	public void remove(DoorCheckedListener listener) {
		listeners.remove(listener);
	}

	public void doorChecked(ICar car, int doorIndex) {
		for (DoorCheckedListener listener : listeners) {
			listener.doorChecked(car, doorIndex);
		}
	}

	public void mdcuChecked(ICar car) {
		for (DoorCheckedListener listener : listeners) {
			listener.mdcuChecked(car);
		}
	}

	public void carChecked(ICar car) {
		for (DoorCheckedListener listener : listeners) {
			listener.carChecked(car);
		}
	}
}
