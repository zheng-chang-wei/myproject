package com.hirain.phm.bode.server.ground;

public class MockGround {

	// private static String host = "tcp://10.40.2.34:1883";
	//
	// private static String sslHost = "ssl://10.40.2.34:8883";
	//
	// private static String clientId = "mock ground";
	//
	// private final ExecutorService executorService;
	//
	// private MqttConnection connection;
	//
	// private MqttConnection connection1;
	//
	// public MockGround() {
	// executorService = Executors.newFixedThreadPool(5);
	// }
	//
	// public static void main(String[] args) {
	// final MockGround ground = new MockGround();
	// ground.start1();
	// ground.start2();
	// }
	//
	// public void start1() {
	// connection = new MqttConnectionImpl(host, clientId, new MqttCallback() {
	//
	// @Override
	// public void messageArrived(String topic, MqttMessage message) throws Exception {
	// process(topic, message);
	// }
	//
	// @Override
	// public void deliveryComplete(IMqttDeliveryToken token) {
	//
	// }
	//
	// @Override
	// public void connectionLost(Throwable cause) {
	//
	// }
	// });
	// try {
	// connection.connect();
	// System.out.println("public client start");
	// connection.subscribe("train/register", 1);
	// } catch (final Exception e) {
	// }
	// }
	//
	// public void start2() {
	// connection1 = new MqttConnectionImpl(sslHost, clientId + "w", new MqttCallback() {
	//
	// @Override
	// public void messageArrived(String topic, MqttMessage message) throws Exception {
	// System.out.println("message arrived");
	// process(topic, message);
	// }
	//
	// @Override
	// public void deliveryComplete(IMqttDeliveryToken token) {
	//
	// }
	//
	// @Override
	// public void connectionLost(Throwable cause) {
	//
	// }
	// });
	// try {
	// connection1.connect("F:\\ssl\\ca.crt", "F:\\ssl\\client.crt", "F:\\ssl\\client.key", "123456");
	// System.out.println("encrypted client start");
	// connection1.subscribe("train-ground", 1);
	// } catch (final Exception e) {
	// }
	// }
	//
	// protected void process(String topic, MqttMessage message) {
	// executorService.submit(() -> {
	// final String string = new String(message.getPayload());
	// System.out.println("topic:" + topic + "," + string);
	// if (topic.equals("train/register")) {
	// final String topic2 = getTopic(string);
	// System.out.println("topic2:" + topic2);
	// try {
	// final String resp = getRegisterResp();
	// connection.send(topic2, resp.getBytes());
	// if (connection1 != null && connection1.isConnected()) {
	// connection1.subscribe(getMsgTopic(string), 1);
	// }
	// } catch (final IOException e) {
	// e.printStackTrace();
	// } catch (final Exception e) {
	// e.printStackTrace();
	// }
	// }
	// });
	// }
	//
	// public String getTopic(String json) {
	// final Gson gson = new Gson();
	// final RegisterMessage message = gson.fromJson(json, RegisterMessage.class);
	// return "ca/" + message.getCity() + "/" + message.getLine() + "/" + message.getTrain();
	// }
	//
	// public String getMsgTopic(String json) {
	// final Gson gson = new Gson();
	// final RegisterMessage message = gson.fromJson(json, RegisterMessage.class);
	// return "message/" + message.getCity() + "/" + message.getLine() + "/" + message.getTrain();
	// }
	//
	// public String getRegisterResp() throws IOException {
	// final Map<String, Object> map = new HashMap<>();
	// map.put("success", true);
	// map.put("caCert", FileUtils.readFileToString(new File("F:\\ssl\\ca.crt"), Charset.defaultCharset()));
	// map.put("cert", FileUtils.readFileToString(new File("F:\\ssl\\client.crt"), Charset.defaultCharset()));
	// map.put("key", FileUtils.readFileToString(new File("F:\\ssl\\client.key"), Charset.defaultCharset()));
	// map.put("password", "123456");
	// map.put("state", 1);
	// map.put("sid", 0x11);
	// final Gson gson = new Gson();
	// final String json = gson.toJson(map);
	// return json;
	// }
}
