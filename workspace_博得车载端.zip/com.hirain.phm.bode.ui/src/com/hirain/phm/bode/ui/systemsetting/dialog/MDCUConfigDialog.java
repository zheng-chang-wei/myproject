/*******************************************************************************
 * Copyright (c) 2018, 2018 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.systemsetting.dialog;

import java.util.List;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IMdcu;
import com.hirain.phm.bode.core.impl.Train;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.util.UIUtilMethod;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created Jul 2, 2018 3:23:37 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jul 2, 2018 jianwen.xin@hirain.com 1.0 create file
 */
public class MDCUConfigDialog extends AbstractDialog {

	private final ICar car;

	private final Train train;

	private Text txtMDCU1;

	private Text txtMDCU2;

	private String ip1;

	private String ip2;

	public MDCUConfigDialog(final Shell parentShell, ICar car, Train train) {
		super(parentShell);
		this.car = car;
		this.train = train;
	}

	@Override
	protected void createContent(Composite parent) {

		Label labTitle = new Label(parent, SWT.NONE);
		String name = car.getName();
		if (StringUtil.isEmpty(name)) {
			labTitle.setText("MDCU设置");
		} else {
			labTitle.setText("MDCU设置：" + name + "车厢");
		}
		labTitle.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, false));
		labTitle.setBackground(DEFAULT_BGCOLOR);
		labTitle.setForeground(ColorConstants.white);

		Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout(2, false));
		composite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, true));
		composite.setBackground(DEFAULT_BGCOLOR);

		Label labMDCU1 = new Label(composite, SWT.None);
		labMDCU1.setText("MDCU1 ip：");
		labMDCU1.setForeground(ColorConstants.white);
		labMDCU1.setBackground(DEFAULT_BGCOLOR);

		txtMDCU1 = new Text(composite, SWT.BORDER);
		GridData txtLayoutData = new GridData(SWT.FILL, SWT.CENTER, true, true);
		txtLayoutData.widthHint = 120;
		txtMDCU1.setLayoutData(txtLayoutData);

		Label labMDCU2 = new Label(composite, SWT.None);
		labMDCU2.setText("MDCU2 ip：");
		labMDCU2.setForeground(ColorConstants.white);
		labMDCU2.setBackground(DEFAULT_BGCOLOR);

		txtMDCU2 = new Text(composite, SWT.BORDER);
		txtMDCU2.setLayoutData(txtLayoutData);
		List<IMdcu> mdcus = car.getMdcus();
		if (mdcus != null && mdcus.size() == 2) {
			ip1 = mdcus.get(0).getIp();
			if (ip1 != null) {
				txtMDCU1.setText(ip1);
			}
			ip2 = mdcus.get(1).getIp();
			if (ip2 != null) {
				txtMDCU2.setText(ip2);
			}
		}
		txtMDCU1.setSelection(0, txtMDCU1.getText().length());

		messageLab = new Label(composite, SWT.NONE);
		messageLab.setLayoutData(new GridData(GridData.FILL_HORIZONTAL, SWT.FILL, true, true, 2, 1));
		messageLab.setBackground(DEFAULT_BGCOLOR);

		Composite btnComposite = new Composite(parent, SWT.NONE);
		btnComposite.setLayout(new GridLayout(2, false));
		btnComposite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, true));
		btnComposite.setBackground(DEFAULT_BGCOLOR);

		btnOk = new Button(btnComposite, SWT.NONE);
		GridData btnLayoutData1 = new GridData(SWT.CENTER, SWT.CENTER, true, true);
		btnLayoutData1.widthHint = 80;
		btnOk.setLayoutData(btnLayoutData1);
		btnOk.setText("应用");
		btnCancel = new Button(btnComposite, SWT.NONE);
		GridData btnLayoutData2 = new GridData(SWT.CENTER, SWT.CENTER, true, true);
		btnLayoutData2.widthHint = 80;
		btnCancel.setLayoutData(btnLayoutData2);
		btnCancel.setText("取消");
	}

	@Override
	protected void initListener() {
		super.initListener();
		txtMDCU1.addModifyListener(e -> {
			String message = verifyIp1();
			if (message == null) {
				message = verifyIp2();
			}
			setErrorMessage(message);
		});
		txtMDCU2.addModifyListener(e -> {
			String message = verifyIp2();
			if (message == null) {
				message = verifyIp1();
			}
			setErrorMessage(message);
		});
	}

	@Override
	protected void clickOk() {
		List<IMdcu> mdcus = car.getMdcus();
		if (!StringUtil.isEmpty(txtMDCU1.getText())) {
			mdcus.get(0).setIp(txtMDCU1.getText());
		}
		if (!StringUtil.isEmpty(txtMDCU2.getText())) {
			mdcus.get(1).setIp(txtMDCU2.getText());
		}
	}

	private String verifyIp1() {
		String MDCU1 = txtMDCU1.getText();
		String MDCU2 = txtMDCU2.getText();
		if (StringUtil.isEmpty(MDCU1)) {
			return "MDCU1 地址不能为空";
		} else if (!UIUtilMethod.verfityIp(MDCU1.trim())) {
			return "MDCU1 地址格式有误";
		}
		List<ICar> cars = train.getCars();
		for (ICar iCar : cars) {
			List<IMdcu> mdcus = iCar.getMdcus();
			for (IMdcu mdcu : mdcus) {
				if (MDCU1.equals(mdcu.getIp()) && !MDCU1.equals(ip1) || MDCU1.equals(MDCU2)) {
					return "MDCU1 地址重复";
				}
			}
		}
		return null;
	}

	private String verifyIp2() {
		String MDCU1 = txtMDCU1.getText();
		String MDCU2 = txtMDCU2.getText();
		if (StringUtil.isEmpty(MDCU2)) {
			return "MDCU2地址不能为空";
		} else if (!UIUtilMethod.verfityIp(MDCU2.trim())) {
			return "MDCU2 地址格式有误";
		}
		List<ICar> cars = train.getCars();
		for (ICar iCar : cars) {
			List<IMdcu> mdcus = iCar.getMdcus();
			for (IMdcu mdcu : mdcus) {
				if (MDCU2.equals(mdcu.getIp()) && !MDCU2.equals(ip2) || MDCU2.equals(MDCU1)) {
					return "MDCU2 地址重复";
				}

			}
		}
		return null;
	}

}
