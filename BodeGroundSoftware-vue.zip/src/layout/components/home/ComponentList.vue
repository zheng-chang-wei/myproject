<template>
  <div id="Component-list">
    <el-row class="Component-panel home-card">
      <!-- <div class="card-border card-border-top-left"></div>
      <div class="card-border card-border-top-right"></div>
      <div class="card-border card-border-bottom-left"></div>
      <div class="card-border card-border-bottom-right"></div> -->
      <el-col :span="24">
        <div class="card-panel">
          <div class="card-title">部件损耗数量统计</div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
export default {

}

</script>
<style scoped>
  #Component-list {
    margin: 2px;
    background-color: #0f1741;
    height: 208px;
  }

  .Component-panel {
    height: 100%;
  }

  .Component-panel .card-panel {
    height: 100%;
    position: relative;
    overflow: hidden;
  }

  .Component-panel .card-title {
    color: #fff;
    text-align: center;
    background-color: #00CCCC;
    font-weight: bold;
  }

</style>
