/*******************************************************************************
 * Copyright (c) 2018, 2018 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.systemsetting.dialog;

import java.util.List;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.util.StringUtil;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created Jul 2, 2018 3:23:37 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jul 2, 2018 jianwen.xin@hirain.com 1.0 create file
 */
public class DoorAddressConfigDialog extends AbstractDialog {

	private final ICar car;

	private final int doorIndex;

	private Text text;

	public DoorAddressConfigDialog(final Shell parentShell, ICar car, int doorIndex) {
		super(parentShell);
		this.car = car;
		this.doorIndex = doorIndex;
	}

	@Override
	protected void initListener() {
		super.initListener();
		text.addModifyListener(e -> {
			setErrorMessage(verifyDoorAddr());
		});
		addVerifyListener(text);
	}

	@Override
	protected void createContent(Composite parent) {

		Label labTitle = new Label(parent, SWT.NONE);
		String name = car.getName();
		if (StringUtil.isEmpty(name)) {
			labTitle.setText("门地址设置：" + (doorIndex + 1) + "号门");
		} else {
			labTitle.setText("门地址设置：" + name + "车厢/" + (doorIndex + 1) + "号门");
		}
		labTitle.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, false));
		labTitle.setBackground(DEFAULT_BGCOLOR);
		labTitle.setForeground(ColorConstants.white);

		Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout(2, false));
		composite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, true));
		composite.setBackground(DEFAULT_BGCOLOR);

		Label label = new Label(composite, SWT.None);
		label.setText("门地址：");
		label.setForeground(ColorConstants.white);
		label.setBackground(DEFAULT_BGCOLOR);

		text = new Text(composite, SWT.BORDER);
		GridData txtLayoutData = new GridData(SWT.FILL, SWT.CENTER, true, true);
		txtLayoutData.widthHint = 120;
		text.setLayoutData(txtLayoutData);
		List<IDoor> doors = car.getDoors();
		if (doors != null && doors.size() > doorIndex) {
			IDoor iDoor = doors.get(doorIndex);
			int addr = iDoor.getAddr();
			if (addr != 0) {
				text.setText(String.valueOf(addr));
			}
		}
		text.setSelection(0, text.getText().length());
		text.setTextLimit(2);

		messageLab = new Label(composite, SWT.NONE);
		messageLab.setLayoutData(new GridData(GridData.FILL_HORIZONTAL, SWT.FILL, true, true, 2, 1));
		messageLab.setBackground(DEFAULT_BGCOLOR);

		Composite btnComposite = new Composite(parent, SWT.NONE);
		btnComposite.setLayout(new GridLayout(2, false));
		btnComposite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, true));
		btnComposite.setBackground(DEFAULT_BGCOLOR);

		btnOk = new Button(btnComposite, SWT.NONE);
		GridData btnLayoutData1 = new GridData(SWT.CENTER, SWT.CENTER, true, true);
		btnLayoutData1.widthHint = 80;
		btnOk.setLayoutData(btnLayoutData1);
		btnOk.setText("应用");
		btnCancel = new Button(btnComposite, SWT.NONE);
		GridData btnLayoutData2 = new GridData(SWT.CENTER, SWT.CENTER, true, true);
		btnLayoutData2.widthHint = 80;
		btnCancel.setLayoutData(btnLayoutData2);
		btnCancel.setText("取消");
	}

	@Override
	protected void clickOk() {
		IDoor iDoor = car.getDoors().get(doorIndex);
		if (!StringUtil.isEmpty(text.getText())) {
			iDoor.setAddr(Integer.valueOf(text.getText()));
		}
	}

	private String verifyDoorAddr() {
		if (StringUtil.isEmpty(text.getText())) {
			return "门地址不能为空";
		}
		List<IDoor> doors = car.getDoors();
		IDoor iDoor = doors.get(doorIndex);
		int selfAddr = iDoor.getAddr();
		for (IDoor door : doors) {
			int addr = door.getAddr();
			if (addr == Integer.valueOf(text.getText()) && addr != selfAddr) {
				return "门地址不能重复";
			}
			if (!text.getText().matches("^(?:1[0-2]|[1-9])$")) {
				return "门地址范围为[1,12]";
			}
		}
		return null;
	}

}
