package com.hirain.phm.bode.client.communication.test;

import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.client.communication.service.ServiceHandler;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioDatagramChannel;

public class TestServer {

	private static String localHost = "127.0.0.1";

	public static void main(String[] args) throws InterruptedException {
		Bootstrap bootstrap = new Bootstrap();
		EventLoopGroup group = new NioEventLoopGroup();
		bootstrap.group(group);

		bootstrap.channel(NioDatagramChannel.class);
		bootstrap.handler(new ChannelInitializer<NioDatagramChannel>() {

			@Override
			protected void initChannel(NioDatagramChannel ch) throws Exception {
				ch.pipeline().addLast(TestMessageCodec.class.getName(), new TestMessageCodec());
				ch.pipeline().addLast(ServiceHandler.class.getName(), new TestServiceHandler());
			}
		});

		try {
			ChannelFuture future1 = bootstrap.bind(localHost, ServiceConstant.HEART_PORT).sync().await();
			Channel channel1 = future1.channel();
			System.out.println("bind:" + channel1.localAddress());
			ChannelFuture future2 = bootstrap.bind(localHost, ServiceConstant.HOST_PORT).sync().await();
			Channel channel2 = future2.channel();
			System.out.println("bind:" + channel2.localAddress());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}
