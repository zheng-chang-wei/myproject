/*******************************************************************************
 * Copyright (c) 2018, 2018 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.monitor;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.util.MarshalUtil;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月11日 下午1:51:02
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月11日 changwei.zheng@hirain.com 1.0 create file
 */
public class TrainManager {

	private static TrainManager instance = new TrainManager();

	private ITrain train;

	private ICar currentCar;

	private int doorIndex;

	private TrainManager() {
	}

	public static TrainManager getInstance() {
		return instance;
	}

	public ITrain load(final String filePath) throws Exception {
		train = MarshalUtil.unmarshalToSystemInfo(filePath);
		if (train != null) {
			List<ICar> cars = train.getCars();
			Collections.sort(cars, new Comparator<ICar>() {

				@Override
				public int compare(ICar car1, ICar car2) {
					if (car1.getIndex() > car2.getIndex()) {
						return 0;
					} else {
						return -1;
					}
				}
			});
		}

		return train;
	}

	public ITrain getTrain() {
		return train;
	}

	public void setTrain(ITrain train) {
		this.train = train;
		if (train != null) {
			List<ICar> cars = train.getCars();
			if (cars != null && cars.size() > 2) {
				ICar iCar = cars.get(2);
				List<IDoor> doors = iCar.getDoors();
				if (doors != null && doors.size() > 0) {
					setCurrentCarAndDoorIndex(iCar, 0);
				}
			}
		}
	}

	public ICar getCurrentCar() {
		return currentCar;
	}

	public int getDoorIndex() {
		return doorIndex;
	}

	public void setCurrentCarAndDoorIndex(ICar currentCar, int doorIndex) {
		this.currentCar = currentCar;
		this.doorIndex = doorIndex;
	}

	public void setDoorIndex(int doorIndex) {
		this.doorIndex = doorIndex;
	}

	public void setCurrentCar(ICar currentCar) {
		this.currentCar = currentCar;
	}

}
