/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.server.life;

import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

import com.hirain.phm.bd.message.train.LifeMessage;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.server.message.DoorMessage;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created May 30, 2019 3:37:57 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               May 30, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class LifeDetector {

	private final Map<Integer, DoorLifeProcessor> cache = new ConcurrentHashMap<>();

	private final Map<Integer, LifeMessage> lifeMessageMap;

	private final BlockingQueue<List<DoorMessage>> queue = new LinkedBlockingQueue<>();

	private ExecutorService detectExecutor;

	private final int carriageId;

	public LifeDetector(int carriageId, Map<Integer, LifeMessage> lifeMessageMap, List<IDoor> doors) {
		this.carriageId = carriageId;
		this.lifeMessageMap = lifeMessageMap;
		for (final IDoor door : doors) {
			final DoorLifeProcessor doorLife = new DoorLifeProcessor();
			cache.put(door.getAddr(), doorLife);
		}
		detectExecutor = Executors.newSingleThreadExecutor(r -> new Thread(r, "life detactor-" + carriageId));
	}

	public void work() {
		System.out.println("life detector- " + carriageId);
		detectExecutor.submit(() -> {
			while (true) {
				final List<DoorMessage> list = queue.take();
				for (final DoorMessage message : list) {
					Integer doorId = message.getDoorId();

					LifeMessage lifeMessage = lifeMessageMap.get(doorId);
					if (lifeMessage == null) {
						lifeMessage = new LifeMessage();
					}
					lifeMessage.setDoorAddr(doorId);
					lifeMessage.setCarNo(carriageId);

					final DoorLifeProcessor doorLife = cache.get(doorId);
					final byte[] datas = message.getDatas();
					int openedBit = LifeInfoBitDecoder.getDoorOpenedBit(datas);
					if (doorLife.checkDoorOpend(openedBit)) {
						Integer doorOpenFrequency = lifeMessage.getDoorOpenFrequency();
						lifeMessage.setDoorOpenFrequency(++doorOpenFrequency);
					}
					int closedBit = LifeInfoBitDecoder.getDoorClosedBit(datas);
					if (doorLife.checkClosed(closedBit)) {
						Integer doorCloseFrequency = lifeMessage.getDoorCloseFrequency();
						lifeMessage.setDoorCloseFrequency(++doorCloseFrequency);
					}
					int emergencyUnlockBit = LifeInfoBitDecoder.getEmergencyUnlockBit(datas);
					if (doorLife.checkEmergencyUnlock(emergencyUnlockBit)) {
						Integer emergencyUnlockFrequency = lifeMessage.getEmergencyUnlockFrequency();
						lifeMessage.setEmergencyUnlockFrequency(++emergencyUnlockFrequency);
					}
					int isolationBit = LifeInfoBitDecoder.getDoorIsolationBit(datas);
					if (doorLife.checkIsulated(isolationBit)) {
						Integer doorIsolationFrequency = lifeMessage.getDoorIsolationFrequency();
						lifeMessage.setDoorIsolationFrequency(++doorIsolationFrequency);
					}
					int lockSwitchBit = LifeInfoBitDecoder.getLockSwitchBit(datas);
					if (doorLife.checkLockSwitch(lockSwitchBit)) {
						Integer lockSwitchFrenquency = lifeMessage.getLockSwitchFrenquency();
						lifeMessage.setLockSwitchFrenquency(++lockSwitchFrenquency);
					}
					short doorOpenTime = LifeInfoBitDecoder.getDoorOpenTime(datas);
					lifeMessage.setDoorOpenTime(doorOpenTime + lifeMessage.getDoorOpenTime());
					short doorCloseTime = LifeInfoBitDecoder.getDoorCloseTime(datas);
					lifeMessage.setDoorCloseTime(doorCloseTime + lifeMessage.getDoorCloseTime());

					cache.put(message.getDoorId(), doorLife);
					lifeMessageMap.put(doorId, lifeMessage);
				}
			}
		});
	}

	public void stop() {
		if (detectExecutor != null) {
			detectExecutor.shutdown();
			detectExecutor = null;
		}
	}

	public void push(List<DoorMessage> messages) {
		try {
			queue.put(messages);
		} catch (final InterruptedException e) {
			e.printStackTrace();
		}
	}
}
