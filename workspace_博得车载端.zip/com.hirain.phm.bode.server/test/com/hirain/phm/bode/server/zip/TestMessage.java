package com.hirain.phm.bode.server.zip;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TestMessage {

	byte did;

	byte cid;

	byte[] datas;

	int milli;

	boolean debug;
}
