<template>
  <section id="repairhistory" class="app-container">
    <!--查询-->
    <trainSelect @query="query" />
    <!-- <el-row class="center" style="margin-top:20px;background-color:#575757; color:white;height:30px">
      故障维修记录</el-row> -->
    <!--故障维修记录table-->
    <el-table v-loading="listLoading" :data="tableData" stripe :max-height="tableMaxHeight" border @row-click="getAllDetails">
      <el-table-column prop="project" label="项目名称" width="150px" align="center" sortable />
      <el-table-column prop="trainId" label="列车编号" align="center" sortable />
      <el-table-column prop="doorId" label="车门编号" align="center" sortable />
      <el-table-column prop="faultMode" label="故障模式" align="center" sortable />
      <el-table-column prop="faultTime" label="故障时间" :formatter="formatFaultTime" width="170px" align="center" sortable />
      <el-table-column prop="state" label="当前状态" align="center" sortable />
      <el-table-column prop="stepId" label="当前所处步骤ID" align="center" sortable />
    </el-table>
    <!--添加维修记录按钮-->
    <el-col :span="10" style="position:absolute;bottom:10px;">
      <el-button size="small" @click="addWorkSheet">添加维修记录</el-button>
    </el-col>
    <!--分页  工具条-->
    <el-col :span="14" class="toolbar" style="position:absolute;bottom:10px;right:3%">
      <el-pagination
        :current-page.sync="currentPage"
        :page-sizes="[10, 20, 30, 50, 100]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        style="float: right;"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-col>
  </section>
</template>

<script>
import app from '@/common/js/app'
import util from '@/common/js/util'
import trainSelect from '@/components/systemsetting/trainSelect'
export default {
  components: {
    trainSelect
  },
  data() {
    return {
      cityName: '',
      // 所有城市名称
      cityNames: [],
      lineName: '',
      // 所有线路
      lineNames: [],
      // 列车信息 trainNo：列车编号 state:列车状态
      trianList: [],
      trainNo: '',
      // 故障表格数据
      tableData: [],
      // 分页信息
      pageNum: 1,
      pageSize: 20,
      currentPage: 1,
      total: 0,
      listLoading: false,
      tableMaxHeight: document.body.offsetHeight - 160
    }
  },
  mounted() {
    this.getAllWorkSheet()
    // 页面改变时,更改尺寸
    window.addEventListener('resize', this.changeTableHeight)
    this.changeTableHeight()
  },
  methods: {
    changeTableHeight() {
      this.tableMaxHeight = document.body.offsetHeight - 160
    },
    query(formObject) {
      this.cityName = formObject.city
      this.lineName = formObject.line
      this.trainNo = formObject.train
      this.currentPage = 1
      this.handleCurrentChange(1)
    },
    // 分页触发
    handleCurrentChange(val) {
      this.pageNum = val
      this.getAllWorkSheet()
    },
    // 改变页码
    handleSizeChange(val) {
      this.pageSize = val
      this.getAllWorkSheet()
    },
    // table的点击事件
    getAllDetails(row, column, event) {
      // 跳转到addFault界面，该界面只对填写的信息进行展示。 可以通过query传递参数。在
      // addFault通过this.$route.query.proName 取参。
      this.$router.push({
        path: '/addFaultInformation/addFault',
        query: {
          detailID: row.detailId + '',
          sheetID: row.id + '',
          state: row.state,
          jump: true
        }
      })
    },
    addWorkSheet() {
      this.$router.push({
        path: '/repairhistory/addFault'
      })
    },
    // 获取所有的workSheet
    getAllWorkSheet() {
      var vm = this
      const param = {
        cityName: vm.cityName,
        lineName: vm.lineName,
        trainNo: vm.trainNo,
        pageNum: vm.pageNum,
        pageSize: vm.pageSize
      }
      app.get('get_all_workSheet', param).then(data => {
        if (data.msg) {
          vm.tableData = []
          for (let index = 0; index < data.data.length; index++) {
            const element = data.data[index]
            element.sheet.project = element.sheet.project.replace('_', '')
            vm.tableData.push(element.sheet)
          }
          vm.total = data.total
        }
      })
    },
    formatFaultTime(row, column) {
      return (row.faultTime = row.faultTime
        ? util.formatDate(new Date(row.faultTime), 'yyyy-MM-dd hh:mm:ss')
        : '')
    }
  }
}

</script>

<style>
	#repairhistory {
		width: 100%;
		height: 100%;
	}

	#repairhistory .center {
		display: flex;
		-webkit-align-items: center;
		align-items: center;
		-webkit-justify-content: center;
		justify-content: center;
	}

</style>
