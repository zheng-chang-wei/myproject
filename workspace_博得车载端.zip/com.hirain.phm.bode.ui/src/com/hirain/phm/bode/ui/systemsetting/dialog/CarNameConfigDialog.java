/*******************************************************************************
 * Copyright (c) 2018, 2018 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.systemsetting.dialog;

import java.util.List;
import java.util.regex.Pattern;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.impl.Train;
import com.hirain.phm.bode.core.util.StringUtil;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created Jul 2, 2018 3:23:37 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jul 2, 2018 jianwen.xin@hirain.com 1.0 create file
 */
public class CarNameConfigDialog extends AbstractDialog {

	private final ICar car;

	private final Train train;

	private Text txtCarName;

	private Text txtCarIndex;

	public CarNameConfigDialog(final Shell parentShell, ICar car, Train train) {
		super(parentShell);
		this.car = car;
		this.train = train;
	}

	@Override
	protected void createContent(Composite parent) {

		Label labTitle = new Label(parent, SWT.NONE);
		labTitle.setText("车厢名称设置");
		labTitle.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, false));
		labTitle.setBackground(DEFAULT_BGCOLOR);
		labTitle.setForeground(ColorConstants.white);

		Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout(2, false));
		composite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, true));
		composite.setBackground(DEFAULT_BGCOLOR);

		Label labCarIndex = new Label(composite, SWT.None);
		labCarIndex.setText("车 厢 号 ：");
		labCarIndex.setForeground(ColorConstants.white);
		labCarIndex.setBackground(DEFAULT_BGCOLOR);

		txtCarIndex = new Text(composite, SWT.BORDER);
		GridData txtCarIndexLayoutData = new GridData(SWT.FILL, SWT.CENTER, true, true);
		txtCarIndexLayoutData.widthHint = 120;
		txtCarIndex.setLayoutData(txtCarIndexLayoutData);
		int index = car.getIndex();
		txtCarIndex.setText(String.valueOf(index));
		txtCarIndex.setSelection(0, txtCarIndex.getText().length());
		txtCarIndex.setTextLimit(2);

		Label labCarName = new Label(composite, SWT.None);
		labCarName.setText("车厢名称：");
		labCarName.setForeground(ColorConstants.white);
		labCarName.setBackground(DEFAULT_BGCOLOR);

		txtCarName = new Text(composite, SWT.BORDER);
		GridData txtLayoutData = new GridData(SWT.FILL, SWT.CENTER, true, true);
		txtLayoutData.widthHint = 120;
		txtCarName.setLayoutData(txtLayoutData);
		txtCarName.setTextLimit(4);
		String name = car.getName();
		if (name != null) {
			txtCarName.setText(name);
		}
		txtCarName.setSelection(0, txtCarName.getText().length());

		messageLab = new Label(composite, SWT.NONE);
		messageLab.setLayoutData(new GridData(GridData.FILL_HORIZONTAL, SWT.FILL, true, true, 2, 1));
		messageLab.setBackground(DEFAULT_BGCOLOR);

		Composite btnComposite = new Composite(parent, SWT.NONE);
		btnComposite.setLayout(new GridLayout(2, false));
		btnComposite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, true));
		btnComposite.setBackground(DEFAULT_BGCOLOR);

		btnOk = new Button(btnComposite, SWT.NONE);
		GridData btnLayoutData1 = new GridData(SWT.CENTER, SWT.CENTER, true, true);
		btnLayoutData1.widthHint = 80;
		btnOk.setLayoutData(btnLayoutData1);
		btnOk.setText("应用");
		btnCancel = new Button(btnComposite, SWT.NONE);
		GridData btnLayoutData2 = new GridData(SWT.CENTER, SWT.CENTER, true, true);
		btnLayoutData2.widthHint = 80;
		btnCancel.setLayoutData(btnLayoutData2);
		btnCancel.setText("取消");
	}

	@Override
	protected void initListener() {
		super.initListener();
		txtCarName.addModifyListener(e -> {
			String message = verifyCarIndex();
			message = verifyCarName();
			setErrorMessage(message);
		});
		txtCarIndex.addModifyListener(e -> {
			String message = verifyCarName();
			message = verifyCarIndex();
			setErrorMessage(message);
		});
		txtCarName.addVerifyListener(carNameVerifyListener);
		addVerifyListener(txtCarIndex);
	}

	/**
	 * 限制车厢名称只能输入数据和字母
	 */
	protected VerifyListener carNameVerifyListener = e -> {
		e.doit = Pattern.compile("([A-Za-z0-9])*").matcher(e.text).matches();
	};

	@Override
	protected void clickOk() {
		car.setName(txtCarName.getText());
		car.setIndex(Integer.valueOf(txtCarIndex.getText()));
	}

	private String verifyCarIndex() {
		String carIndex = txtCarIndex.getText();

		if (StringUtil.isEmpty(carIndex)) {
			return "车厢号不能为空";
		}
		List<ICar> cars = train.getCars();
		int index = car.getIndex();
		for (ICar iCar : cars) {
			if (Integer.valueOf(carIndex) == iCar.getIndex() && iCar.getIndex() != index) {
				return "车厢号不能重复";
			}
		}
		return null;
	}

	private String verifyCarName() {
		String carName = txtCarName.getText();

		if (StringUtil.isEmpty(carName)) {
			return "车厢名称不能为空";
		}
		if (carName.getBytes().length > 4) {
			return "车厢名称不能大于四个字节";
		}
		List<ICar> cars = train.getCars();
		String name = car.getName();
		for (ICar iCar : cars) {
			if (carName.equals(iCar.getName()) && !iCar.getName().equals(name)) {
				return "车厢名称不能重复";
			}
		}
		return null;
	}

}
