package com.hirain.phm.bode.ui.log.utils;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import com.hirain.phm.bode.client.communication.message.LogResultMessage;
import com.hirain.phm.bode.core.util.FileUtil;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.log.model.LogTable;

public class LogDecodeUtil {

	public static List<LogTable> getLogs(LogResultMessage message) {
		List<LogTable> logs = new ArrayList<>();
		if (message != null) {
			byte[] data = message.getData();
			if (data != null) {
				ByteBuffer buffer = ByteBuffer.wrap(data);
				// sid
				buffer.get();
				// 数量
				byte count = buffer.get();
				for (int i = 0; i < count; i++) {
					String date = getDate(buffer);
					LogTable logTable = new LogTable();
					logTable.setLogTime(date);
					// 去掉中划线
					date = date.replace(StringUtil.MID_LINE, StringUtil.EMPTY);
					logTable.setLogName("SysLog" + StringUtil.MID_LINE + date);
					logs.add(logTable);
				}
			}
		}
		return logs;
	}

	private static String getDate(ByteBuffer buffer) {
		StringBuilder builder = new StringBuilder();

		// 年
		builder.append(buffer.get() + 2000);
		builder.append(StringUtil.MID_LINE);
		// 月
		int month = Byte.toUnsignedInt(buffer.get());
		if (month < 10) {
			builder.append("0");
		}
		builder.append(month);
		builder.append(StringUtil.MID_LINE);
		// 日
		int day = Byte.toUnsignedInt(buffer.get());
		if (day < 10) {
			builder.append("0");
		}
		builder.append(day);
		return builder.toString();
	}

	public static void saveLogMessages(LogResultMessage message, String filePath) {
		if (message != null) {
			byte[] data = message.getData();
			if (data != null) {
				ByteBuffer buffer = ByteBuffer.wrap(data);
				buffer.get();
				byte[] contentBytes = new byte[data.length - 1];
				buffer.get(contentBytes);
				try {
					String content = new String(contentBytes, "utf-8");
					if (StringUtil.isNotEmpty(content)) {
						FileUtil.appendFile(content, filePath);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}
}
