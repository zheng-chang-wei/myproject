package com.hirain.phm.bd.store.service.impl;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.hirain.phm.bd.store.domain.StoreBuffer;
import com.hirain.phm.bd.store.domain.StoreEntry;
import com.hirain.phm.bd.store.file.IFileManager;
import com.hirain.phm.bd.store.service.IMessageEncoder;
import com.hirain.phm.bd.store.service.IMessageStorager;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@NoArgsConstructor
public class MessageStorager implements IMessageStorager {

	@Value("${store.file.buffer.capacity}")
	private int bufferCapacity;// 0.5m

	@Value("${store.file.write.period}")
	private int period;

	@Value("${store.file.interval}")
	private int timeInterval;

	@Autowired
	private IFileManager fileManager;

	@Autowired
	private IMessageEncoder encoder;

	private BlockingQueue<StoreBuffer> readyList;

	private StoreBuffer buffer;

	private ExecutorService pushExecutor;

	// private LocalDateTime time;

	private ScheduledExecutorService executor;

	private boolean hasHeader = false;

	private static final String TIME_PATTERN = "yyyyMMdd" + File.separator + "HHmmss";

	@PostConstruct
	public void postConstruct() {
		readyList = new LinkedBlockingQueue<>();
		buffer = getEmptyBuffer();
		pushExecutor = Executors.newSingleThreadExecutor(r -> new Thread(r, MessageStorager.class.getName()));
	}

	/**
	 * @see com.hirain.phm.bd.store.service.IMessageStorager#init(java.lang.String, java.lang.String)
	 */
	@Override
	public void init(String project, String train) {
		fileManager.init(project, train);
		startScheduleJob(project, train);
	}

	@Override
	public void push(byte[] message) {
		pushExecutor.submit(() -> {
			try {
				List<StoreEntry> entries = encoder.encode(message);
				if (entries == null) {
					return;
				}
				entries.stream().forEach(entry -> {
					LocalDateTime nowTime = getTime(entry);
					String filename = nowTime.format(DateTimeFormatter.ofPattern(TIME_PATTERN));
					if (buffer.getFilename() == null) {
						buffer.setFilename(filename);
						System.out.println(buffer.getFilename());
					}
					if (!filename.equals(buffer.getFilename())) {
						buffer.flip();
						readyList.offer(buffer);
						buffer = getEmptyBuffer();
						buffer.setFilename(filename);
						System.out.println(buffer.getFilename());
					}
					if (buffer.getBuffer().remaining() < entry.getDatas().length) {
						buffer.flip();
						readyList.offer(buffer);
						buffer = getEmptyBuffer();
						buffer.setFilename(filename);
						System.out.println(buffer.getFilename());
						System.out.println(readyList.size());
					}
					buffer.put(entry.getDatas());
				});
			} catch (Throwable e) {
				log.error(e.getMessage(), e);
			}
		});
	}

	public void write() {
		while (true) {
			StoreBuffer bf = getReadyBuffer();
			if (bf != null) {
				if (!hasHeader) {
					String header = encoder.getHeader();
					fileManager.setHeader(header);
					hasHeader = true;
				}
				fileManager.write(bf);
			} else {
				break;
			}
		}
	}

	private StoreBuffer getReadyBuffer() {
		if (readyList.isEmpty()) {
			return null;
		}
		return readyList.poll();
	}

	private StoreBuffer getEmptyBuffer() {
		return new StoreBuffer(bufferCapacity);
	}

	private LocalDateTime getTime(StoreEntry entry) {
		LocalDateTime timestamp = entry.getTime();
		// if (time == null) {
		// time = LocalDateTime.of(timestamp.getYear(), timestamp.getMonth(), timestamp.getDayOfMonth(), timestamp.getHour(), 0, 0);
		// }
		LocalDateTime integral = LocalDateTime.of(timestamp.getYear(), timestamp.getMonth(), timestamp.getDayOfMonth(), timestamp.getHour(), 0, 0);// 获取整点
		// LocalDateTime nextTime = time.plusHours(timeInterval);// 下一个整点
		// if (integral.compareTo(nextTime) < 0) {// 小于下一个整点
		// return time;
		// } else {
		// time = integral;
		return integral;// 返回当前时间的整点
		// }
	}

	private void startScheduleJob(String project, String train) {
		executor = Executors.newSingleThreadScheduledExecutor(r -> new Thread(r, "write-" + project + "-" + train));
		executor.scheduleAtFixedRate(() -> {
			write();
			log.info("write file");
		}, period, period, TimeUnit.SECONDS);
	}
}
