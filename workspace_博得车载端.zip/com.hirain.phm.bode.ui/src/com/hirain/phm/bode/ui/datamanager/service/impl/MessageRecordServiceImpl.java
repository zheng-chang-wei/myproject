package com.hirain.phm.bode.ui.datamanager.service.impl;

import java.text.DateFormat;
import java.util.Date;

import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.core.message.MessageQuery;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.datamanager.service.MessageRecordService;

public class MessageRecordServiceImpl implements MessageRecordService {

	private static MessageRecordServiceImpl messageRecordServiceImpl = null;

	private MessageRecordServiceImpl() {
	}

	public static MessageRecordServiceImpl getInstance() {
		if (messageRecordServiceImpl == null) {
			messageRecordServiceImpl = new MessageRecordServiceImpl();
		}
		return messageRecordServiceImpl;
	}

	@Override
	public void selectByPage(MessageQuery messageQuery, int pageNum, int pageSize) {
		StringBuilder sql = new StringBuilder("select * from t_carriage" + messageQuery.getCarriageId() + "_record where true");
		DateFormat dateFormat = DateFormat.getDateTimeInstance();
		Integer doorId = messageQuery.getDoorId();
		if (doorId != null) {
			sql.append(" and door_id=" + doorId);
		}
		Date start = messageQuery.getStartTime();
		if (start != null) {
			sql.append(" and start_time>='" + dateFormat.format(start) + "'");
		}
		Date end = messageQuery.getEndTime();
		if (end != null) {
			sql.append(" and start_time<='" + dateFormat.format(end) + "'");
		}
		Boolean debug = messageQuery.getDebug();
		if (debug != null) {
			sql.append(" and debug=" + (debug ? 1 : 0));
		}
		sql.append(" order by start_time desc limit " + (pageNum - 1) * pageSize + "," + pageSize);
		try {
			CommunicationService.getInstance().select(ServiceConstant.PID_DATA_QUERY, ServiceConstant.COMMON_TAG, sql.toString());
		} catch (Exception e) {
			e.printStackTrace();
			BodeUIPlugin.log(e);
		}
	}

	@Override
	public void getSelectPageNum(MessageQuery messageQuery) {
		StringBuilder sql = new StringBuilder("select count(id) from t_carriage" + messageQuery.getCarriageId() + "_record where true");
		DateFormat dateFormat = DateFormat.getDateTimeInstance();
		Integer doorId = messageQuery.getDoorId();
		if (doorId != null) {
			sql.append(" and door_id=" + doorId);
		}
		Date start = messageQuery.getStartTime();
		if (start != null) {
			sql.append(" and start_time>='" + dateFormat.format(start) + "'");
		}
		Date end = messageQuery.getEndTime();
		if (end != null) {
			sql.append(" and start_time<='" + dateFormat.format(end) + "'");
		}
		Boolean debug = messageQuery.getDebug();
		if (debug != null) {
			sql.append(" and debug=" + (debug ? 1 : 0));
		}
		try {
			CommunicationService.getInstance().select(ServiceConstant.PID_DATA_COUNT, ServiceConstant.MESSAGE_COUNT_SID, sql.toString());
		} catch (Exception e) {
			e.printStackTrace();
			BodeUIPlugin.log(e);
		}
	}

}
