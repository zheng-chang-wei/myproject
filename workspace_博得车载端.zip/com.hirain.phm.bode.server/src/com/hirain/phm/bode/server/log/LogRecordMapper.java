package com.hirain.phm.bode.server.log;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface LogRecordMapper {

	int deleteByPrimaryKey(String day);

	int insert(LogRecord record);

	LogRecord selectByPrimaryKey(String day);

	List<LogRecord> select(@Param("querySql") String sql);
}