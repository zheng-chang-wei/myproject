/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core;

import java.util.List;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 3:42:18 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
public interface IServer {

	void setServerIps(List<IServerIp> serverIps);

	List<IServerIp> getServesIps();

	void setGateWay(String gateWay);

	String getGateWay();
}
