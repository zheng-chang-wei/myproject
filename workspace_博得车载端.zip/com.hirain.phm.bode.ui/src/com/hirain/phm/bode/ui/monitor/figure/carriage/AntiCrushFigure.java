package com.hirain.phm.bode.ui.monitor.figure.carriage;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.LineBorder;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;

import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created Jan 7, 2019 5:34:58 PM
 * @Description
 *              <p>
 *              防挤压
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 7, 2019 changwei.zheng@hirain.com 1.0 create file
 */
public class AntiCrushFigure extends Figure {

	public AntiCrushFigure() {
		setLayoutManager(new XYLayout());
		TriangleUpAndDown triangleUpAndDown = new TriangleUpAndDown();
		triangleUpAndDown.setBorder(new LineBorder(2));
		TriangleLeftAndRight triangleLeftAndRight = new TriangleLeftAndRight();
		add(triangleUpAndDown, new Rectangle(0, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
		add(triangleLeftAndRight, new Rectangle(0, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
	}
}
