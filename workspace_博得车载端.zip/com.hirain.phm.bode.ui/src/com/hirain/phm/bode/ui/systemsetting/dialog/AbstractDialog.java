/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.systemsetting.dialog;

import java.util.regex.Pattern;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.util.UIConstants;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 31, 2019 5:16:10 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 31, 2019 zepei.tao@hirain.com 1.0 create file
 */
public abstract class AbstractDialog extends Dialog {

	protected Label messageLab;

	protected Button btnOk;

	protected Button btnCancel;

	protected Color DEFAULT_BGCOLOR = new Color(Display.getDefault(), 102, 102, 102);

	public AbstractDialog(Shell parentShell) {
		super(parentShell);
	}

	/**
	 * 限制text的输入只能为数字，且第一个数字不为零
	 * 
	 * @param text
	 */
	protected void addVerifyListener(Text text) {
		text.addVerifyListener(e -> {
			if (StringUtil.isEmpty(text.getText()) && e.text.equals("0")) {
				e.doit = false;
			} else {
				e.doit = Pattern.compile("([0-9])*").matcher(e.text).matches();
			}
		});
	}

	@Override
	protected void configureShell(Shell newShell) {
		newShell.setImage(BodeUIPlugin.getImage(UIConstants.DIALOGIMAGEPATH));
		super.configureShell(newShell);
	}

	@Override
	protected Control createContents(Composite parent) {
		parent.setLayout(new GridLayout(1, false));
		parent.setBackground(DEFAULT_BGCOLOR);
		createContent(parent);
		initListener();
		return parent;
	}

	@Override
	protected boolean isResizable() {
		return true;
	}

	protected abstract void clickOk();

	protected abstract void createContent(Composite composite);

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(300, 180);
	}

	protected void initListener() {
		btnOk.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			clickOk();
			okPressed();
		}));
		btnCancel.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			cancelPressed();
		}));
	}

	public void setErrorMessage(String error) {
		if (error != null) {
			messageLab.setForeground(Display.getDefault().getSystemColor(SWT.COLOR_RED));
			messageLab.setText(error);
		} else {
			messageLab.setForeground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
			messageLab.setText(StringUtil.EMPTY);
		}
		messageLab.getParent().layout();
		btnOk.setEnabled(error == null ? true : false);
	}

}
