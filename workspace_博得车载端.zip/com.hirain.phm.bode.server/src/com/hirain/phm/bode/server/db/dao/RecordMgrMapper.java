package com.hirain.phm.bode.server.db.dao;

import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface RecordMgrMapper {

	/**
	 * check if table 't_carriage{carriageId}_record' exists
	 * 
	 * @param carriageId
	 * @return
	 */
	int existRecordTable(@Param("carriageId") int carriageId);

	/**
	 * create Message record table, the format of table name is
	 * 't_carriage{carriageId}_record'<br/>
	 * <code>
	 * create table `t_carrialge${carriageId}_record`(
	 * 		id bigint not null auto_increment,
	 * 		door_id int not null,
	 * 		start_time datetime not null,
	 * 		end_time datetime not null,
	 * 		debug boolean default false,
	 * 		primary key(id,start_time)
	 * )ENGINE=InnoDB default charset=utf8
	 * PARTITION BY RANGE(year(start_time))
	 * (
	 * 		partition p1 values less than(to_years(start_time)+1),
	 * 		......
	 * )
	 * </code>
	 * 
	 * @param map
	 *            key:carriageId value:int key:list value:List<Integer>
	 * @return
	 */
	int createRecordTable(Map<String, Object> map);

	/**
	 * add partitions to record table
	 * 
	 * @param map
	 *            key:carriageId value:int key:list value:List<Integer>
	 * @return
	 */
	int addPartitionsToRecord(Map<String, Object> map);

	/**
	 * remove partitions from record table
	 * 
	 * @return
	 */
	int dropPartitionFromRecord(@Param("tableName") String tableName, @Param("year") String year);

	/**
	 * remove records <code>
	 * 	delete from t_carriage${carriageId}_record
	 * 	where to_days(start_time)=#{day}
	 * 
	 * </code>
	 * 
	 * @param carriageId
	 * @param day
	 * @return
	 */
	int deleteRecords(@Param("tableName") String tableName, @Param("day") String day);

	/**
	 * remove records <code>
	 * 	delete from t_carriage${carriageId}_record
	 * 	where to_days(start_time)<=#{day}
	 * 
	 * </code>
	 * 
	 * @param carriageId
	 * @param day
	 * @return
	 */
	int deleteRecordsBeforeDay(@Param("tableName") String tableName, @Param("day") String day);

}
