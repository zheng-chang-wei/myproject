INSERT INTO phm_bd_ground.t_ground_role (GROUND_ROLE_ID, ROLE_NAME, REMARK, CREATE_TIME, MODIFY_TIME)
VALUES
(3, '业主', '业主', '2019-09-19 19:00:00.000', NULL);

INSERT INTO phm_bd_ground.t_menu (MENU_ID, PARENT_ID, MENU_NAME, URL, PERMS, ICON, `TYPE`, ORDER_NUM, CREATE_TIME, MODIFY_TIME)
VALUES
(1, 0, '实时监控', '/realtimemonitor/realtimemonitor', NULL, NULL, '0', NULL, '2019-09-19 19:00:00.000', NULL),
(2, 0, '故障信息', '/faultinformation/showFaultInformation', NULL, NULL, '0', NULL, '2019-09-19 19:00:00.000', NULL),
(3, 0, '亚健康预警', '/unhealthymonitor/unhealthymonitor', NULL, NULL, '0', NULL, '2019-09-19 19:00:00.000', NULL),
(4, 0, '寿命预警', '/lifemonitor/lifemonitor', NULL, NULL, '0', NULL, '2019-09-19 19:00:00.000', NULL);

INSERT INTO phm_bd_ground.t_ground_role_menu (GROUND_ROLE_ID, MENU_ID)
VALUES
(3, 1),
(3, 2),
(3, 4),
(3, 3);
-- 密码：admin
INSERT INTO phm_bd_ground.t_user (USER_ID, USER_NAME, PASSWORD, NAME,CREATE_TIME)
VALUES(1, 'admin', 'YWRtaW4=', 'admin','2019-09-20 11:00:00');

INSERT INTO phm_bd_ground.t_ground_user_role (USER_ID, GROUND_ROLE_ID)
VALUES(1, 3);

INSERT INTO t_fault
(id, fault_name, fault_code, fault_num, `level`)
values
(1, '门电机开路故障', 1, 21, 3),
(2, '门电机过流故障', 2, 29, 3),
(3, '门门板开关故障', 3, 26, 3),
(4, '门绿色环线故障', 4, 40, 3),
(5, '门锁闭开关故障', 5, 25, 3),
(6, '门编码器故障', 6, 23, 3),
(7, '门开关门超时故障', 7, 24, 3),
(8, '门输出短路故障', 8, 31, 3),
(9, '外网通讯故障', 9, 50, 2),
(10, '内网通讯故障', 10, 30, 3),
(11, '隔离信号', 11, 11, 2),
(12, '防挤压信号', 12, 15, 3),
(13, '紧急解锁信号', 13, 12, 2);

insert into t_subhealth_type (subhealth_name,subhealth_code)
values
('电机工况异常',1),
('闭锁组件异常',2),
('行程开关异常',3),
('车门V型',4),
('开关门阻力过大',5),
('尺带张紧力过紧',6),
('尺带张紧力过松',7);