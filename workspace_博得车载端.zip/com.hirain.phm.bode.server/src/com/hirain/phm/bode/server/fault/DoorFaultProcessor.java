package com.hirain.phm.bode.server.fault;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.db.DBService;
import com.hirain.phm.bode.server.fault.dao.FaultMapper;
import com.hirain.phm.bode.server.message.DoorMessage;

class DoorFaultProcessor {

	static Logger logger = Logger.getLogger(DoorFaultProcessor.class);

	private final int doorId;

	private final int carriageId;

	private Date startTime1;

	private Date startTime2;

	private final List<DoorFaultCache> cacheList = new CopyOnWriteArrayList<>();

	private final Map<Integer, Byte> faultMap = new ConcurrentHashMap<>();

	private int lastOpenBit = 1;

	private int lastClosedBit = 1;

	private Date lastStoreEndTime;

	private ExecutorService insertExecutor;

	private ExecutorService transferExecutor;

	private int lastInsulateBit = 1;

	public DoorFaultProcessor(int doorId, int carriageId, Date startTime) {
		this.doorId = doorId;
		this.carriageId = carriageId;
		startTime1 = startTime;
	}

	public void setStartTime2(Date startTime2) {
		this.startTime2 = startTime2;
	}

	public void updateState(DoorMessage message, boolean debug) {
		final byte[] datas = message.getDatas();
		final int[] state = MessageBitDecoder.getDoorState(datas);
		for (int i = 0; i < state.length; i++) {
			final int s = state[i];
			final byte last = faultMap.getOrDefault(i + 11, (byte) 0);
			if (last == 0 && s == 1) {
				System.out.println("state:" + (i + 11) + "-carriage:" + carriageId + "-door:" + doorId);
				final FaultRecord record = new FaultRecord();
				record.setCarriageId(carriageId);
				record.setDoorId(doorId);
				record.setFaultId(i + 11);
				record.setTimestamp(message.getTimestamp());
				record.setStartTime(message.getTimestamp());
				record.setEndTime(message.getTimestamp());
				record.setDebug(debug);
				insertFaultRecord(record);
			}
			faultMap.put(i + 11, (byte) s);
		}
	}

	public void update(DoorMessage message, boolean debug) {
		final byte[] datas = message.getDatas();
		final byte fault = datas[4];
		for (int i = 0; i < 8; i++) {
			final int action = getActionState(datas);
			final byte b = (byte) (fault >> i & 1);
			final Byte last = faultMap.getOrDefault(i, (byte) 0);
			if (last == 0 && b == 1) {
				System.out.println("fault:" + (8 - i) + "-carriage:" + carriageId + "-door:" + doorId);
				addFault(i, message.getTimestamp(), debug, action);
			}
			faultMap.put(i, b);
		}
	}

	private int getActionState(byte[] data) {
		final byte b = data[2];
		return b >> 5 & 1;
	}

	public void addFault(int faultId, Date timestamp, boolean debug, int action) {
		final FaultRecord record = new FaultRecord();
		record.setCarriageId(carriageId);
		record.setDoorId(doorId);
		record.setStartTime(startTime1);
		record.setFaultId(8 - faultId);
		record.setTimestamp(timestamp);
		record.setDebug(debug);
		InnerEventBus.getInstance().post(record);
		cacheList.add(new DoorFaultCache(record, action));
	}

	public boolean checkOpen(int openBit) {
		if (lastOpenBit == 0 && openBit == 1) {
			lastOpenBit = openBit;
			return true;
		}
		lastOpenBit = openBit;
		return false;
	}

	public boolean checkClosed(int closeBit) {
		if (lastClosedBit == 0 && closeBit == 1) {
			lastClosedBit = closeBit;
			return true;
		}
		lastClosedBit = closeBit;
		return false;
	}

	public boolean checkIsulated(int insulateBit) {
		if (lastInsulateBit == 0 && insulateBit == 1) {
			lastInsulateBit = insulateBit;
			return true;
		}
		lastInsulateBit = insulateBit;
		return false;
	}

	public void updateRecord(Date timestamp) {
		if (startTime2 != null) {
			startTime1 = startTime2;
		}
		for (final DoorFaultCache cache : cacheList) {
			if (cache.getAction() == 0) {
				insert(timestamp, cache);
			} else if (cache.getAction() == 1) {
				if (cache.increaseAndGet() > 1) {
					insert(timestamp, cache);
				}
			}
		}
	}

	public void insert(Date timestamp, final DoorFaultCache cache) {
		cacheList.remove(cache);
		final FaultRecord record = cache.getRecord();
		record.setEndTime(timestamp);
		insertFaultRecord(record);
		transfer(record);
	}

	public void stop() {
		if (insertExecutor != null) {
			insertExecutor.shutdown();
			insertExecutor = null;
		}
		if (transferExecutor != null) {
			transferExecutor.shutdown();
			transferExecutor = null;
		}
	}

	private void insertFaultRecord(FaultRecord record) {
		if (insertExecutor == null) {
			insertExecutor = Executors.newSingleThreadExecutor(r -> new Thread(r, "insert fault record-" + carriageId + doorId));
		}
		insertExecutor.submit(() -> {
			SqlSession session = null;
			try {
				session = DBService.getInstance().getSession(true);
				final FaultMapper mapper = session.getMapper(FaultMapper.class);
				mapper.insert(record);
				System.out.println(String.format("[%tT] insert fault-carriageId:%d,doorId:%d,faultId:%d", new Date(), record.getCarriageId(),
						record.getDoorId(), record.getFaultId()));
			} catch (final Exception e) {
				logger.error(e.getMessage(), e);
			} finally {
				DBService.getInstance().disconnect(session);
			}
		});
	}

	private void transfer(FaultRecord record) {
		if (transferExecutor == null) {
			transferExecutor = Executors.newSingleThreadExecutor(r -> new Thread(r, "transfer fault-" + carriageId + doorId));
		}
		transferExecutor.submit(() -> {
			final FaultRecord query = new FaultRecord();
			query.setCarriageId(record.getCarriageId());
			query.setDoorId(record.getDoorId());
			query.setEndTime(record.getEndTime());
			Date startTime = record.getStartTime();
			if (lastStoreEndTime != null && lastStoreEndTime.compareTo(startTime) > 0) {
				startTime = lastStoreEndTime;
			}
			query.setStartTime(startTime);
			SqlSession session = null;
			try {
				int offset = 0;
				final int length = 1000;
				session = DBService.getInstance().getSession(true);
				final FaultMapper mapper = session.getMapper(FaultMapper.class);
				while (true) {
					final List<DoorMessage> messages = mapper.findMessage(query, offset, length);
					if (messages == null || messages.isEmpty()) {
						break;
					}
					System.out.println(messages.get(0).getTimestamp().getTime());
					mapper.insertMessage(messages, carriageId);
					if (messages.size() < length) {
						break;
					}
					offset += length;
				}
			} catch (final Exception e) {
				logger.error(e.getMessage(), e);
			} finally {
				DBService.getInstance().disconnect(session);
			}
			if (lastStoreEndTime == null || lastStoreEndTime.compareTo(record.getEndTime()) < 0) {
				lastStoreEndTime = record.getEndTime();
			}
		});
	}
}
