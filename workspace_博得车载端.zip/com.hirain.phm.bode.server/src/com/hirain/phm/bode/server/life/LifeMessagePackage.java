/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.server.life;

import java.util.List;

import com.hirain.phm.bd.message.train.LifeMessage;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created May 31, 2019 4:17:36 PM
 * @Description
 *              <p>
 *              为避免List<LifeMessage> 和 List<DoorMessage>在EventBus接收的时候混淆，
 *              特将List<LifeMessage>封装了一层
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               May 31, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class LifeMessagePackage {

	private List<LifeMessage> lifeMessages;

	public LifeMessagePackage(List<LifeMessage> lifeMessages) {
		super();
		this.lifeMessages = lifeMessages;
	}

	public List<LifeMessage> getLifeMessages() {
		return lifeMessages;
	}

	public void setLifeMessages(List<LifeMessage> lifeMessages) {
		this.lifeMessages = lifeMessages;
	}

}
