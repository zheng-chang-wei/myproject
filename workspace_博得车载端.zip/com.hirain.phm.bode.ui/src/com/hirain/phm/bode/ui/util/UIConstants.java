/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.util;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 12, 2019 2:03:45 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 12, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class UIConstants {

	public static String PREFERENCE_SERVERIP = "serverIp";

	public static String PREFERENCE_LOGININFO = "loginInfo";

	public static String DEFAULT_CONFIG_FILENAME = "phm_config.xml";

	public static String DIALOGIMAGEPATH = "icons/logo48.png";

	public static String[] CAR_AMOUNTS = new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" };

	public static String[] DOOR_AMOUNTS = new String[] { "2", "4", "6", "8", "10", "12" };

	public static String[] CITYNAMES = new String[] { "深圳", "北京", "上海", "广州", "天津", "成都", "武汉", "长沙", "南京", "合肥", "苏州", "杭州", "青岛", "长春", "西安", "福州",
			"厦门", "济南" };

	public static char PASSWORD_SHOWSTYLE = '●';

	/**
	 * 连接登录名和密码的特殊字符
	 */
	public static String LOGIN_COMPOSE = "##";

	/**
	 * 心跳查询周期，单位ms
	 */
	public static long HEARTBEAT_PERIOD = 5000;

	/**
	 * 刷新频率
	 */
	public static String PREFERENCE_REFRESHFREQUENCY = "refreshFrequency";

}
