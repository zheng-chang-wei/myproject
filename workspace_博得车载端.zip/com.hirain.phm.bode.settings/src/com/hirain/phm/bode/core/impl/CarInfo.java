/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.hirain.phm.bode.core.ICarInfo;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 4:28:56 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
@XmlRootElement(name = "CarInfo")
@XmlType(propOrder = { "carNum", "gateNum" })
@XmlAccessorType(XmlAccessType.FIELD)
public class CarInfo implements ICarInfo {

	@XmlElement(name = "carNum", required = true)
	private int carNum;

	@XmlElement(name = "gateNum", required = true)
	private int gateNum;

	@Override
	public void setCarNum(int carNum) {
		this.carNum = carNum;
	}

	@Override
	public int getCarNum() {
		return carNum;
	}

	@Override
	public void setGateNum(int gateNum) {
		this.gateNum = gateNum;
	}

	@Override
	public int getGateNum() {
		return gateNum;
	}

}
