package com.hirain.phm.bode.server.client.data;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.ibatis.session.SqlSession;

import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ClientService;
import com.hirain.phm.bode.server.client.ISender;
import com.hirain.phm.bode.server.client.Token;
import com.hirain.phm.bode.server.db.DBService;
import com.hirain.phm.bode.server.log.LogRecord;
import com.hirain.phm.bode.server.log.LogRecordMapper;

public class DataQueryHandler {

	private ExecutorService pool;

	private final String sql;

	private final ISender sender;

	private final int type;

	private final Token token;

	public DataQueryHandler(ISender sender, String sql, int type, Token token) {
		pool = Executors.newSingleThreadExecutor(r -> new Thread(r, "data-query-thread" + type));
		this.sender = sender;
		this.type = type;
		this.sql = sql;
		this.token = token;
	}

	public void work() {
		switch (type) {
		case ClientConstants.COMMON_TAG:
			queryMessageRecord();
			break;
		case ClientConstants.FAULT_TAG:
			queryFaultRecord();
			break;
		case ClientConstants.FAULT_LIST:
			queryFaultList();
			break;
		case ClientConstants.LOG_TAG:
			queryLogRecord();
			break;
		default:
			break;
		}
	}

	private void queryMessageRecord() {
		pool.submit(() -> {
			SqlSession session = null;
			List<RecordQuery> records = new ArrayList<>();
			try {
				session = DBService.getInstance().getSession(false);
				final ClientMapper mapper = DBService.getInstance().getMapper(ClientMapper.class, session);
				records = mapper.queryRecord(sql);
				DBService.getInstance().disconnect(session);
			} catch (final Exception e) {
				ClientService.logger.error(e.getMessage(), e);
				DBService.getInstance().disconnect(session);
			}
			final ByteBuffer buffer = ByteBuffer.allocate(records.size() * 13 + 2);
			buffer.put(ClientConstants.COMMON_TAG);
			buffer.put((byte) records.size());
			for (final RecordQuery record : records) {
				buffer.put(split(record.getStartTime()));
				Date endTime = record.getEndTime();
				if (endTime == null) {
					endTime = new Date();
				}
				buffer.put(split(endTime));
				buffer.put((byte) (record.getDebug() ? 1 : 0));
			}
			sender.send(token.getAddress(), ClientConstants.DATA_QUERY_RESPONSE, buffer.array());
			pool.shutdown();
			pool = null;
		});
	}

	private void queryFaultList() {
		pool.submit(() -> {
			SqlSession session = null;
			List<Fault> faults = new ArrayList<>();
			try {
				session = DBService.getInstance().getSession(false);
				final ClientMapper mapper = DBService.getInstance().getMapper(ClientMapper.class, session);
				faults = mapper.queryFault(sql);
				DBService.getInstance().disconnect(session);
			} catch (final Exception e) {
				ClientService.logger.error(e.getMessage(), e);
				DBService.getInstance().disconnect(session);
			}

			final ByteBuffer buffer = ByteBuffer.allocate(65535);
			buffer.put(ClientConstants.FAULT_LIST);
			buffer.put((byte) faults.size());
			for (final Fault fault : faults) {
				buffer.put(fault.getId().byteValue());
				byte[] bytes;
				bytes = fault.getCname().getBytes();
				buffer.put((byte) bytes.length);
				buffer.put(bytes);
			}
			final int position = buffer.position();
			final byte[] data = new byte[position];
			buffer.flip();
			buffer.get(data);
			sender.send(token.getAddress(), ClientConstants.DATA_QUERY_RESPONSE, data);
		});
	}

	private void queryFaultRecord() {
		pool.submit(() -> {
			SqlSession session = null;
			List<FaultRecordQuery> records = new ArrayList<>();
			try {
				session = DBService.getInstance().getSession(false);
				final ClientMapper mapper = DBService.getInstance().getMapper(ClientMapper.class, session);
				records = mapper.queryFaultRecord(sql);
				DBService.getInstance().disconnect(session);
			} catch (final Exception e) {
				ClientService.logger.error(e.getMessage(), e);
				DBService.getInstance().disconnect(session);
			}
			final ByteBuffer buffer = ByteBuffer.allocate(records.size() * 20 + 2);
			buffer.put(ClientConstants.FAULT_TAG);
			buffer.put((byte) records.size());
			for (final FaultRecordQuery record : records) {
				buffer.put(record.getFaultId().byteValue());
				buffer.put(split(record.getTimestamp()));
				buffer.put(split(record.getStartTime()));
				buffer.put(split(record.getEndTime()));
				buffer.put((byte) (record.getDebug() ? 1 : 0));
			}
			sender.send(token.getAddress(), ClientConstants.DATA_QUERY_RESPONSE, buffer.array());
		});
	}

	private void queryLogRecord() {
		pool.submit(() -> {
			SqlSession session = null;
			List<LogRecord> records = new ArrayList<>();
			try {
				session = DBService.getInstance().getSession(false);
				final LogRecordMapper mapper = DBService.getInstance().getMapper(LogRecordMapper.class, session);
				records = mapper.select(sql);
				DBService.getInstance().disconnect(session);
			} catch (final Exception e) {
				ClientService.logger.error(e.getMessage(), e);
				DBService.getInstance().disconnect(session);
			}
			final ByteBuffer buffer = ByteBuffer.allocate(records.size() * 3 + 2);
			buffer.put(ClientConstants.LOG_TAG);
			buffer.put((byte) records.size());
			for (final LogRecord record : records) {
				final String day = record.getDay();
				final String[] split = day.split("-");
				buffer.put((byte) (Integer.parseInt(split[0]) - 2000));
				buffer.put((byte) Integer.parseInt(split[1]));
				buffer.put((byte) Integer.parseInt(split[2]));
			}
			sender.send(token.getAddress(), ClientConstants.DATA_QUERY_RESPONSE, buffer.array());
		});
	}

	private byte[] split(Date date) {
		final byte[] result = new byte[] { 0, 0, 0, 0, 0, 0 };
		if (date == null) {
			return result;
		}
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		result[0] = (byte) (calendar.get(Calendar.YEAR) - 2000);
		result[1] = (byte) calendar.get(Calendar.MONTH);
		result[2] = (byte) calendar.get(Calendar.DAY_OF_MONTH);
		result[3] = (byte) calendar.get(Calendar.HOUR_OF_DAY);
		result[4] = (byte) calendar.get(Calendar.MINUTE);
		result[5] = (byte) calendar.get(Calendar.SECOND);
		return result;
	}

}
