/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.fault;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.nebula.widgets.cdatetime.CDT;
import org.eclipse.nebula.widgets.cdatetime.CDateTime;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.ResourceManager;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.client.communication.message.FaultResultMessage;
import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.fault.Fault;
import com.hirain.phm.bode.core.fault.FaultRecord;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.fault.provider.TableViewerlabelProvider;
import com.hirain.phm.bode.ui.fault.service.impl.FaultMessageServiceImpl;
import com.hirain.phm.bode.ui.fault.service.impl.FaultRecordServiceImpl;
import com.hirain.phm.bode.ui.fault.service.impl.FaultServiceImpl;
import com.hirain.phm.bode.ui.fault.utils.FaultDecodeUtil;
import com.hirain.phm.bode.ui.listener.IRefreshCarNumAndDoorAddressListener;
import com.hirain.phm.bode.ui.listener.RefreshCarNumAndDoorAddressListenerManager;
import com.hirain.phm.bode.ui.monitor.TrainManager;
import com.hirain.phm.bode.ui.monitor.provider.TableViewerContentProvider;
import com.hirain.phm.bode.ui.monitor.utils.Util;
import com.hirain.phm.bode.ui.util.PlotUtil;
import com.hirain.phm.bode.ui.widget.CommonPart;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 7, 2019 10:51:59 AM
 * @Description
 *              <p>
 *              故障回放界面
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 7, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class FaultReplayPart extends CommonPart implements IRefreshCarNumAndDoorAddressListener {

	private static FaultReplayPart faultReplayPart;

	private TableViewer tv;

	private CDateTime cdtEnd;

	private CDateTime cdtStart;

	private Combo cmbFauleName;

	private Combo cmbFauleCode;

	private Combo cmbCarNum;

	private Combo cmbDoorAddress;

	private Combo cmbIsDebug;

	private Button btnQuery;

	private List<Fault> faults;

	private List<String[]> doorList;

	private Text txtCurrentPage;

	private Button btnPreviousPage;

	private Button btnNextPage;

	private Button btnFirstPage;

	private Button btnLastPage;

	private int currentPage = 1;

	private long pageCount;

	private int pageSize = 10;

	private Button btnDownloadSelected;

	/**
	 * isDownload为true时表示下载，为false时表示回放
	 */
	private boolean isDownload = false;

	private volatile int downloadCount = 0;

	private String filePath;

	private BlockingQueue<FaultResultMessage> queue = new LinkedBlockingDeque<>();

	private PlotUtil plotUtil;

	private FaultReplayPart() {
		CommunicationService.getInstance().getEventBus().register(this);
		RefreshCarNumAndDoorAddressListenerManager.getInstatnce().add(this);
	}

	public static FaultReplayPart getInstance() {
		if (faultReplayPart == null) {
			faultReplayPart = new FaultReplayPart();
		}
		return faultReplayPart;
	}

	@Override
	public void postConstruct(final Composite parent) {
		super.postConstruct(parent);
		scrolledComposite.setMinSize(1000, 1650);
		createQueryConditionArea(coreComposite);
		createTableArea(coreComposite);
		createToolbarArea(coreComposite);
		plotUtil = new PlotUtil();
		plotUtil.createPlotArea(coreComposite);
		linkToScroll(coreComposite);
		initListener();

		decodeMessage();
	}

	/**
	 * 开启线程解析数据
	 */
	private void decodeMessage() {
		new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {
					try {
						FaultResultMessage message = queue.take();
						Display.getDefault().syncExec(new Runnable() {

							@Override
							public void run() {
								byte pid = message.getPid();
								// 统计结果
								if (pid == ServiceConstant.PID_DATA_COUNT_ACK) {
									long count = FaultDecodeUtil.getFaultsCount(message);
									pageCount = (count + pageSize - 1) / pageSize;
									if (pageCount != 0) {
										selectByPage(currentPage, pageSize);
									} else {
										currentPage = 0;
										List<FaultRecord> list = new ArrayList<>();
										FaultRecord faultRecord = new FaultRecord();
										list.add(faultRecord);
										tv.setInput(list);
										btnDownloadSelected.setEnabled(false);
									}
									updatePageInfo();
								} else if (pid == ServiceConstant.PID_DATA_QUERY_ACK) {
									if (message.getSid() == ServiceConstant.FAULT_SID) {// 查询故障列表结果
										faults = FaultDecodeUtil.getFaults(message);
										tv.setLabelProvider(new TableViewerlabelProvider(faults));
										if (faults != null && faults.size() > 0) {
											int faultSize = faults.size();
											String[] faultNames = new String[faultSize + 1];
											String[] faultIds = new String[faultSize + 1];
											for (int i = 0; i < faultSize; i++) {
												Fault fault = faults.get(i);
												faultNames[i] = fault.getCname();
												faultIds[i] = String.valueOf(fault.getId());
											}
											// 添加空白
											faultNames[faultSize] = StringUtil.EMPTY;
											faultIds[faultSize] = StringUtil.EMPTY;
											cmbFauleName.setItems(faultNames);
											cmbFauleCode.setItems(faultIds);
										}

									} else if (message.getSid() == ServiceConstant.FAULT_RECORD_SID) {// 查询故障记录结果
										List<FaultRecord> list = FaultDecodeUtil.getFaultRecord(message);

										for (FaultRecord faultRecord : list) {
											String carriageId = cmbCarNum.getText();
											if (StringUtil.isNotEmpty(carriageId)) {
												faultRecord.setCarriageId(carriageId);
											}
											String doorId = cmbDoorAddress.getText();
											if (StringUtil.isNotEmpty(doorId)) {
												faultRecord.setDoorId(doorId);
											}
										}
										if (list.size() != 0) {
											updatePageInfo();
											btnDownloadSelected.setEnabled(true);
										} else {
											btnDownloadSelected.setEnabled(false);
										}
										tv.setInput(list);
									}
								} else if (pid == ServiceConstant.PID_DATA_DOWNLOAD_ACK) {
									byte sid = message.getSid();
									if (sid == ServiceConstant.FAULT_DOWNLOAD_COMPLETE_SID) {
										System.out.println("下载完成");
										downloadCount--;
										// if (monitor != null) {
										// monitor.done();
										// monitor = null;
										// // File file = new File(filePath);
										// // if (!file.exists()) {
										// // MessageDialog.openInformation(Display.getDefault().getActiveShell(), "", "没数据");
										// // }
										// }

									} else if (sid == ServiceConstant.FAULT_RECORD_DOWNLOAD_SID) {
										if (isDownload) {
											System.out.println("下载");
											FaultDecodeUtil.saveFaultMessages(message, filePath);
										} else {
											// long currentTimeMillis2 = System.currentTimeMillis();
											if (message != null) {
												plotUtil.decodeResultMessage(message.getData());
											}
											// System.out.println(System.currentTimeMillis() - currentTimeMillis2);
										}
									}
								}

							}
						});
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		}).start();
	}

	private void createToolbarArea(Composite parent) {
		Composite tableToolBarComposite = new Composite(parent, SWT.FILL | SWT.NONE);
		tableToolBarComposite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, false));
		tableToolBarComposite.setLayout(new GridLayout(7, false));
		btnFirstPage = new Button(tableToolBarComposite, SWT.FLAT);
		btnFirstPage.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/u2261.png"));
		btnFirstPage.setToolTipText("第一页");
		btnPreviousPage = new Button(tableToolBarComposite, SWT.FLAT | SWT.ARROW | SWT.LEFT);
		btnPreviousPage.setToolTipText("上一页");
		txtCurrentPage = new Text(tableToolBarComposite, SWT.SINGLE | SWT.CENTER | SWT.BORDER);
		btnNextPage = new Button(tableToolBarComposite, SWT.FLAT | SWT.ARROW | SWT.RIGHT);
		btnNextPage.setToolTipText("下一页");
		btnLastPage = new Button(tableToolBarComposite, SWT.FLAT);
		btnLastPage.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/u2263.png"));
		btnLastPage.setToolTipText("最后一页");
		btnDownloadSelected = new Button(tableToolBarComposite, SWT.NONE);
		btnDownloadSelected.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/u2641.png"));
		btnDownloadSelected.setText("下载所选条目");
		linkToScroll(tableToolBarComposite);

	}

	/**
	 * 查询条件界面
	 * 
	 * @param parent
	 */
	private void createQueryConditionArea(Composite parent) {
		Composite composite = new Composite(parent, SWT.BORDER);
		composite.setLayout(new GridLayout(15, false));
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		new Label(composite, SWT.None).setText("起始时间");
		cdtStart = new CDateTime(composite, CDT.BORDER | CDT.DROP_DOWN | CDT.DATE_MEDIUM | CDT.TIME_MEDIUM);
		cdtStart.setNullText("");
		GridData layoutData = new GridData(SWT.FILL, SWT.FILL, false, true);
		layoutData.widthHint = 150;
		cdtStart.setLayoutData(layoutData);
		new Label(composite, SWT.None).setText("结束时间");
		cdtEnd = new CDateTime(composite, CDT.BORDER | CDT.DROP_DOWN | CDT.DATE_MEDIUM | CDT.TIME_MEDIUM);
		cdtEnd.setNullText("");
		cdtEnd.setLayoutData(layoutData);
		new Label(composite, SWT.None).setText("故障名称");
		cmbFauleName = new Combo(composite, SWT.BORDER | SWT.READ_ONLY);
		cmbFauleName.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		new Label(composite, SWT.None).setText("故障代码");
		cmbFauleCode = new Combo(composite, SWT.BORDER | SWT.READ_ONLY);
		cmbFauleCode.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		new Label(composite, SWT.None).setText("车厢号");
		cmbCarNum = new Combo(composite, SWT.BORDER | SWT.READ_ONLY);
		cmbCarNum.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		new Label(composite, SWT.None).setText("门地址");
		cmbDoorAddress = new Combo(composite, SWT.BORDER | SWT.READ_ONLY);
		cmbDoorAddress.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		new Label(composite, SWT.None).setText("是否调试");
		cmbIsDebug = new Combo(composite, SWT.BORDER | SWT.READ_ONLY);
		cmbIsDebug.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		btnQuery = new Button(composite, SWT.None);
		btnQuery.setText("确认搜索");
		btnQuery.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		initQueryConditionArea();
		selectCount();
	}

	private void initListener() {
		cmbCarNum.addModifyListener((e) -> {
			int index = cmbCarNum.getSelectionIndex();
			if (index != -1) {
				Util.setDoorAddressItems(doorList.get(index), cmbDoorAddress);
			}
		});
		cmbFauleCode.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			int index = cmbFauleCode.getSelectionIndex();
			cmbFauleName.select(index);
		}));
		btnPreviousPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPage--;
			selectByPage(currentPage, pageSize);
		}));
		btnNextPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPage++;
			selectByPage(currentPage, pageSize);

		}));
		btnFirstPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPage = 1;
			selectByPage(currentPage, pageSize);
		}));
		btnLastPage.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPage = (int) pageCount;
			selectByPage(currentPage, pageSize);
		}));
		btnDownloadSelected.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {

			downloadFaultMessage();
		}));
		cmbFauleName.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			int index = cmbFauleName.getSelectionIndex();
			cmbFauleCode.select(index);
		}));
		btnQuery.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			currentPage = 1;
			selectCount();
		}));
		tv.addDoubleClickListener((e) -> {
			downloadCount = 1;
			addProgressMonitorDialog("正在加载数据。。。");

			IStructuredSelection selection = (IStructuredSelection) tv.getSelection();
			Iterator<?> iterator = selection.iterator();
			// 双击表示回放，isDownloas为false
			isDownload = false;
			while (iterator.hasNext()) {
				FaultRecord faultRecord = (FaultRecord) iterator.next();
				FaultMessageServiceImpl.getInstance().select(faultRecord);
				plotUtil.clearXYGraphViewer();
			}
		});
	}

	private void downloadFaultMessage() {
		FileDialog directoryDialog = new FileDialog(Display.getDefault().getActiveShell(), SWT.SAVE);
		directoryDialog.setFilterExtensions(new String[] { "*.txt" });
		filePath = directoryDialog.open();
		if (StringUtil.isEmpty(filePath)) {
			return;
		}
		File file = new File(filePath);
		while (file.exists()) {
			boolean confirm = MessageDialog.openConfirm(Display.getDefault().getActiveShell(), "文件已存在", filePath + "文件已存在，是否覆盖原文件？");
			if (confirm) {
				file.delete();
			} else {
				directoryDialog.setFileName(null);
				filePath = directoryDialog.open();
				if (StringUtil.isEmpty(filePath)) {
					return;
				}
				file = new File(filePath);
			}
		}
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (!StringUtil.isEmpty(filePath)) {
			isDownload = true;
			IStructuredSelection selection = (IStructuredSelection) tv.getSelection();
			downloadCount = tv.getTable().getSelectionCount();
			addProgressMonitorDialog("正在下载数据。。。");
			Iterator<?> iterator = selection.iterator();
			while (iterator.hasNext()) {
				FaultRecord faultRecord = (FaultRecord) iterator.next();
				FaultMessageServiceImpl.getInstance().download(faultRecord);
			}
		}
	}

	/**
	 * 添加进度条对话框
	 */
	private void addProgressMonitorDialog(String message) {
		Display.getDefault().asyncExec(new Runnable() {

			@Override
			public void run() {
				final ProgressMonitorDialog progress = new ProgressMonitorDialog(null);
				final IRunnableWithProgress runnableWithProgress = (m) -> {
					m.beginTask(message, IProgressMonitor.UNKNOWN);
					int countHis = downloadCount;
					int waitSec = 0;
					while (downloadCount > 0) {
						if (countHis != downloadCount) {
							waitSec = 0;
							countHis = downloadCount;
						} else {
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
							waitSec++;
						}
						if (waitSec > 5) {
							m.done();
							return;
						}
					}
					m.done();
					return;
				};
				try {
					progress.run(true, false, runnableWithProgress);
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
	}

	@Subscribe
	void on(FaultResultMessage message) {
		queue.add(message);
	}

	private void updatePageInfo() {
		if (pageCount > 0) {
			txtCurrentPage.setText(currentPage + "/" + pageCount);
		} else {
			txtCurrentPage.setText("");
		}
		btnFirstPage.setEnabled(currentPage > 1);
		btnPreviousPage.setEnabled(currentPage > 1);
		btnNextPage.setEnabled(currentPage < pageCount);
		btnLastPage.setEnabled(currentPage < pageCount);
	}

	/**
	 * 分页查询
	 * 
	 * @param currentPage
	 * @param pageSize
	 * @return
	 */
	private void selectByPage(int currentPage, int pageSize) {
		FaultRecord faultQuery = getQueryCondition();
		FaultRecordServiceImpl.getInstance().selectByPage(faultQuery, currentPage, pageSize);
	}

	/**
	 * 获取查询条件
	 * 
	 * @return
	 */
	private FaultRecord getQueryCondition() {
		FaultRecord faultQuery = new FaultRecord();
		String carriageId = cmbCarNum.getText();
		if (StringUtil.isNotEmpty(carriageId)) {
			faultQuery.setCarriageId(carriageId);
		}
		String doorId = cmbDoorAddress.getText();
		if (StringUtil.isNotEmpty(doorId)) {
			faultQuery.setDoorId(doorId);
		}
		String isDebug = cmbIsDebug.getText();
		if (StringUtil.isNotEmpty(isDebug)) {
			faultQuery.setDebug("是".equals(isDebug));
		}
		String faultId = cmbFauleCode.getText();
		if (StringUtil.isNotEmpty(faultId)) {
			faultQuery.setFaultId(faultId);
		}
		String startTime = cdtStart.getText();
		String endTime = cdtEnd.getText();
		if (StringUtil.isNotEmpty(startTime)) {
			faultQuery.setStartTime(startTime);
		}
		if (StringUtil.isNotEmpty(endTime)) {
			faultQuery.setEndTime(endTime);
		}
		return faultQuery;
	}

	private void selectCount() {
		FaultRecord queryCondition = getQueryCondition();
		try {
			FaultRecordServiceImpl.getInstance().selectCount(queryCondition);
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}

	/**
	 * 初始化条件查询数据
	 */
	private void initQueryConditionArea() {
		FaultServiceImpl.getInstance().selectAll();
		cmbIsDebug.setItems(new String[] { "是", "否", StringUtil.EMPTY });
		refreshCarNumAndDoorAddr();
	}

	private void createTableArea(Composite parent) {
		tv = new TableViewer(parent, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL);
		Table table = tv.getTable();
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableLayout tableLayout = new TableLayout();
		table.setLayout(tableLayout);
		GridData layoutData = new GridData(SWT.FILL, SWT.FILL, true, true);
		layoutData.heightHint = 150;
		table.setLayoutData(layoutData);

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnFaultTime = new TableColumn(table, SWT.CENTER);
		tableColumnFaultTime.setText("故障时间");

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnFaultName = new TableColumn(table, SWT.CENTER);
		tableColumnFaultName.setText("故障名称");

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnFaultCode = new TableColumn(table, SWT.CENTER);
		tableColumnFaultCode.setText("故障代码");

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnCarNum = new TableColumn(table, SWT.CENTER);
		tableColumnCarNum.setText("车厢号");

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnDoorAddress = new TableColumn(table, SWT.CENTER);
		tableColumnDoorAddress.setText("门地址");

		tableLayout.addColumnData(new ColumnWeightData(1));
		TableColumn tableColumnDebug = new TableColumn(table, SWT.CENTER);
		tableColumnDebug.setText("是否调试");
		tv.setFilters(new ViewerFilter[] {});

		tv.setContentProvider(new TableViewerContentProvider());

	}

	@Override
	public void doorChecked(ICar car, int doorIndex) {
		IDoor iDoor = car.getDoors().get(doorIndex);
		cmbCarNum.setText(String.valueOf(car.getIndex()));
		cmbDoorAddress.setText(String.valueOf(iDoor.getAddr()));
	}

	@Override
	public void refreshCarNumAndDoorAddr() {
		TrainManager instance = TrainManager.getInstance();
		train = instance.getTrain();
		if (train != null) {
			List<ICar> cars = train.getCarriages();
			if (cars != null) {
				int carSize = cars.size();
				String[] carNums = new String[carSize];
				if (doorList == null) {
					doorList = new ArrayList<>();
				} else {
					doorList.clear();
				}
				for (int i = 0; i < carSize; i++) {
					ICar car = cars.get(i);
					carNums[i] = String.valueOf(car.getIndex());
					Util.getDoorItems(car, doorList);
				}
				cmbCarNum.setItems(carNums);
				cmbCarNum.setText(String.valueOf(carNums[0]));
				Util.setDoorAddressItems(doorList.get(0), cmbDoorAddress);
			}
		}
	}

	public void refreshTable() {
		selectCount();
	}
}
