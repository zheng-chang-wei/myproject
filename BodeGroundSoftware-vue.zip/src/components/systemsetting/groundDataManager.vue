<template>
  <section id="groundDataManager" class="app-container">
    <el-col :span="5" class="query">
      <ve-pie :data="chartData" :settings="chartSettings" />
      <el-row style="margin-top:-230px">
        <template v-for="item in citysSpace">
          <el-row :key="item.city" style="padding-bottom: 10px;">
            <el-col :span="8">{{ item.city }}地铁：</el-col>
            <el-col :span="16">
              <el-progress :key="item.city" :percentage="item.used" />
            </el-col>
          </el-row>
        </template>
      </el-row>
    </el-col>
    <el-col :span="19">
      <!--查询-->
      <trainSelect @query="getTrains" />
      <!--工具条-->
      <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
        <el-form :inline="true">
          <el-form-item>
            <el-button type="primary" @click="downloadTrainData">
              下载标记项</el-button>
            <el-button type="danger" @click="deleteTrainData">
              删除标记项</el-button>
          </el-form-item>
        </el-form>
      </el-col>
      <!--列表-->

      <el-table
        v-loading="listLoading"
        :data="trains"
        border
        :max-height="tableMaxHeight"
        highlight-current-row
        style="width: 98%;margin-left:15px"
        @selection-change="selsChange"
      >
        <el-table-column type="selection" width="40" align="center" />
        <el-table-column prop="city" label="城市" align="center" sortable />
        <el-table-column prop="line" label="线路" align="center" sortable />
        <el-table-column prop="train" label="车辆" align="center" sortable />
        <el-table-column prop="startDay" label="起始时间" align="center" sortable />
        <el-table-column prop="endDay" label="终止时间" align="center" sortable />
      </el-table>
      <!--分页  工具条-->
      <el-row class="toolbar" style="position:absolute;bottom:10px;right:0">
        <el-pagination
          :current-page="currentPage"
          :page-sizes="[20, 50, 100]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          style="float: right;"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </el-row>
    </el-col>
    <el-dialog title="删除数据" :visible.sync="deleteFormVisible" :close-on-click-modal="false">
      <el-form :inline="true" class="query">
        <el-form-item label="删除的截止日期：">
          <el-date-picker v-model="deleteDate" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" :editable="false" :picker-options="pickerOptions" />
        </el-form-item>
      </el-form>
      <div>
        <p v-if="deleteDate!=null" style="color:red">点击“提交”后，系统将删除{{ deleteDate }}之前的数据</p>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" :disabled="deleteDate==null" @click.native="deleteGroundData">提交</el-button>
        <el-button type="cancel" @click.native="deleteFormVisible=false">取消</el-button>
      </div>
    </el-dialog>
  </section>
</template>

<script>
import app from '@/common/js/app'
import VePie from 'v-charts/lib/pie.common'
import trainSelect from './trainSelect'
export default {
  components: {
    VePie,
    trainSelect
  },
  data() {
    this.chartSettings = {
      radius: 50,
      offsetY: 95
    }
    return {
      chartData: {
        columns: ['city', 'used'],
        rows: []
      },
      citysSpace: [],
      sels: [], // 列表选中的选项
      trains: [],
      total: 0,
      pageNum: 1,
      pageSize: 20,
      currentPage: 1,
      listLoading: false,
      addLoading: false,
      // 查询时验证
      retrieveRules: {},
      tableMaxHeight: document.body.offsetHeight - 230,
      deleteFormVisible: false,
      deleteDate: null,
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() >= Date.now()
        }
      }
    }
  },
  mounted() {
    this.getDataSpace()
    this.getCitySpace()
    this.getTrains()
    // 页面改变时,更改尺寸
    window.addEventListener('resize', this.changeSectionHeight)
    this.changeSectionHeight()
  },
  methods: {
    // 动态更改表格最大高度
    changeSectionHeight() {
      this.tableMaxHeight = document.body.offsetHeight - 230
      // var sectionHeight = document.body.offsetHeight - 180 + 'px'
      // document.getElementById('groundDataManager').style.height = sectionHeight
    },
    // 列表选中的选项
    selsChange(sels) {
      this.sels = sels
    },
    downloadTrainData() { },
    deleteTrainData() {
      if (this.sels.length === 0) {
        this.$message({
          message: '请至少勾选一个用户删除',
          type: 'error'
        })
        return
      }
      this.deleteDate = null
      this.deleteFormVisible = true
    },
    deleteGroundData() {
      const param = {
        date: this.deleteDate,
        params: this.sels
      }
      this.deleteFormVisible = false
      this.listLoading = true
      app.postData('delete_groundDataManager_info', param).then(data => {
        this.listLoading = false
        this.$message({
          message: data.msg,
          type: 'success'
        })
        this.getTrains()
      })
    },

    getDataSpace() {
      const vm = this
      app.get('get_data_space').then(d => {
        if (d) {
          vm.$set(vm.chartData.rows, 0, {
            'city': '已用空间',
            'used': d.msg
          })
          vm.$set(vm.chartData.rows, 1, {
            'city': '可用空间',
            'used': 100 - d.msg
          })
        }
      })
    },
    getCitySpace() {
      const vm = this
      app.get('get_city_space').then(d => {
        if (d.msg) {
          vm.citysSpace = d.msg
        }
      })
    },
    getTrains(formObject) {
      this.listLoading = true
      const vm = this
      const param = {
        // city: vm.retrieveForm.city,
        // line: vm.retrieveForm.line,
        // train: vm.retrieveForm.train,
        pageNum: vm.pageNum,
        pageSize: vm.pageSize
      }
      if (formObject) {
        param.city = formObject.city
        param.line = formObject.line
        param.train = formObject.train
      }
      app.get('get_groundDataManager_info', param).then(d => {
        if (d) {
          vm.trains = d.msg.rows
          vm.total = d.msg.total
          this.listLoading = false
        }
      })
    },
    // 分页触发
    handleCurrentChange(val) {
      this.pageNum = val
      this.getTrains()
    },
    // 改变页码
    handleSizeChange(val) {
      this.pageSize = val
      this.getTrains()
    }
  }
}
</script>
<style>
	#groundDataManager .query {
		padding: 16px 0px 0px;
	}

	#groundDataManager .query .el-input {
		width: 150px;
	}

	#groundDataManager .toolbar {
		padding: 0px 15px;
		border-bottom: 1px solid transparent;
		border-top-right-radius: 3px;
		border-top-left-radius: 3px;
	}

	#groundDataManager .el-form-item__label {
		text-align: right;
	}
</style>
