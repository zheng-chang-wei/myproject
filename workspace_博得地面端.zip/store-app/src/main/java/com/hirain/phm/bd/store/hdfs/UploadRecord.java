/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.store.hdfs;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年6月10日 下午4:07:06
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年6月10日 jianwen.xin@hirain.com 1.0 create file
 */
@Data
@AllArgsConstructor
public class UploadRecord {

	private List<String> pathList;
}
