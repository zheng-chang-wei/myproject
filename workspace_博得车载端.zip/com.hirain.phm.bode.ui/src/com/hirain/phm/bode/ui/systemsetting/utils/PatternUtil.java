package com.hirain.phm.bode.ui.systemsetting.utils;

import java.util.regex.Pattern;

import org.eclipse.swt.events.VerifyListener;

public class PatternUtil {

	public static VerifyListener numVerifyListener = e -> {
		e.doit = Pattern.compile("([0-9])*").matcher(e.text).matches();
	};

	public static VerifyListener ipVerifyListener = e -> {
		e.doit = Pattern.compile("([0-9]|\\.)*").matcher(e.text).matches();
	};
}
