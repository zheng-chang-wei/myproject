package com.hirain.phm.bode.ui.monitor.figure.carriage;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.geometry.Rectangle;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月11日 下午1:46:11
 * @Description
 *              <p>
 *              紧急解锁
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月11日 changwei.zheng@hirain.com 1.0 create file
 */
public class EmergencyUnlockFigure extends Figure {

	@Override
	protected void paintFigure(Graphics g) {
		Rectangle r = bounds;
		g.setLineWidth(2);
		g.fillRectangle(r.x, r.y, r.width, r.height);
		// |
		g.drawLine(r.x, r.y, r.x, r.y + r.height);
		// ——
		g.drawLine(r.x, r.y, r.x + r.width, r.y);
		// |
		g.drawLine(r.x + r.width, r.y, r.x + r.width, r.y + r.height);
		// ——
		g.drawLine(r.x, r.y + r.height, r.x + r.width, r.y + r.height);
		// ——
		g.drawLine(r.x + r.width / 12, r.y + r.height * 4 / 12, r.x + r.width * 10 / 12, r.y + r.height * 4 / 12);
		g.drawLine(r.x + r.width / 12, r.y + r.height * 7 / 12, r.x + r.width * 10 / 12, r.y + r.height * 7 / 12);
		// |
		g.drawLine(r.x + r.width * 5 / 12, r.y + r.height * 1 / 12, r.x + r.width * 5 / 12, r.y + r.height * 10 / 12);
		g.drawLine(r.x + r.width * 8 / 12, r.y + r.height * 2 / 12, r.x + r.width * 8 / 12, r.y + r.height * 11 / 12);
		setBackgroundColor(ColorConstants.red);

	}
}
