package com.hirain.phm.bode.ui.datamanager.service;

import com.hirain.phm.bode.core.message.MessageRecord;

public interface MessageService {

	void selectMessages(MessageRecord messageRecord);

	void downloadMessages(MessageRecord messageRecord);
}
