package com.hirain.phm.bode.server.db;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.log4j.Logger;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年1月7日 上午10:05:40
 * @Description
 *              <p>
 *              DataBase Module
 * @Singleton
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月7日 jianwen.xin@hirain.com 1.0 create file
 */
public class DBService {

	private static DBService instance = new DBService();

	private SqlSessionFactory ssf;

	static Logger logger = Logger.getLogger(DBService.class);

	private DBService() {
		final String resource = "mybatis-config.xml";
		Reader reader;
		try {
			reader = Resources.getResourceAsReader(resource);
			ssf = new SqlSessionFactoryBuilder().build(reader);
		} catch (final IOException e) {
			logger.error(e.getMessage(), e);
		}
	}

	public static DBService getInstance() {
		return instance;
	}

	public SqlSession getSession(boolean autoCommit) {
		return ssf.openSession(autoCommit);
	}

	public void disconnect(SqlSession session) {
		if (session != null) {
			session.close();
			session = null;
		}
	}

	/**
	 * @param session
	 * @param Mapper.class
	 * @return Mapper instance
	 */
	public <T> T getMapper(Class<T> clz, SqlSession session) {
		if (session != null) {
			return session.getMapper(clz);
		}
		return null;
	}

}
