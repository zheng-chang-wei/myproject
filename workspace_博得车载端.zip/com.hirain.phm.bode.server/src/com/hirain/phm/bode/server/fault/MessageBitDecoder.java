package com.hirain.phm.bode.server.fault;

public class MessageBitDecoder {

	public static int getOpenBit(byte[] data) {
		final byte b = data[9];
		return b >> 0 & 1;
	}

	public static int getCloseBit(byte[] data) {
		final byte b = data[2];
		return b >> 4 & 1;
	}

	public static int[] getDoorState(byte[] data) {
		final int[] state = new int[3];
		state[0] = getInsulateBit(data);
		state[1] = getAntiExtrusionBit(data);
		state[2] = getUnlockBit(data);
		return state;
	}

	public static int getInsulateBit(byte[] data) {
		final byte b = data[2];
		return b >> 1 & 1;
	}

	public static int getAntiExtrusionBit(byte[] data) {
		final byte b = data[2];
		return b >> 0 & 1;
	}

	public static int getUnlockBit(byte[] data) {
		final byte b = data[2];
		return b >> 2 & 1;
	}

	public static void main(String[] args) {
		final byte[] data = new byte[] { 01, 16, 50 };
		data[2] = 0x48;
		for (int i = 7; i >= 0; i--) {
			System.out.println(data[2] >> i & 1);
		}
	}
}
