/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.store.original;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.hirain.phm.bd.message.big.DataRecord;
import com.hirain.phm.bd.store.original.record.RecordSender;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created Nov 1, 2019 3:25:29 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Nov 1, 2019 jianwen.xin@hirain.com 1.0 create file
 */
public class TestSplit {

	@Test
	public void test() {
		String filepath = "D:\\data\\rt\\深圳7号线\\717\\20190820\\170000.rt";
		DataRecord record = RecordSender.of(filepath);
		System.out.println(record);
		assertEquals(create("深圳7号线", "717", "20190820"), record);
	}

	public static DataRecord create(String project, String train, String date) {
		DataRecord record = new DataRecord();
		record.setProject(project);
		record.setTrain(train);
		record.setDate(date);
		return record;
	}

	@Test
	public void test1() {
		String filepath = "D:\\data\\rt\\北京1号线\\02\\20190726\\190000.rt";
		DataRecord record = RecordSender.of(filepath);
		System.out.println(record);
		assertEquals(create("北京1号线", "02", "20190726"), record);
	}

}
