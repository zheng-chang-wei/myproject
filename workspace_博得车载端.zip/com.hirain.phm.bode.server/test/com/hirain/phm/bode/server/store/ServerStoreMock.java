package com.hirain.phm.bode.server.store;

import com.hirain.phm.bode.server.message.PreProcessor;
import com.hirain.phm.bode.server.server.ServerService;

public class ServerStoreMock {

	private PreProcessor processor;

	private StoreService storeService;

	public void start() {
		processor = new PreProcessor();
		processor.init();

		storeService = new StoreService(processor);
		storeService.init();
		ServerService serverService = new ServerService();
		serverService.init();

	}

}
