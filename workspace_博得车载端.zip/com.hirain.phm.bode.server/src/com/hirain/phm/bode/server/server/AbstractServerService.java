package com.hirain.phm.bode.server.server;

import java.net.InetSocketAddress;
import java.time.LocalDateTime;

import org.apache.log4j.Logger;

import com.hirain.phm.bode.server.PrefsUtil;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.bus.MessageEvent;
import com.hirain.phm.bode.server.comm.ICommunication;
import com.hirain.phm.bode.server.comm.IPost;
import com.hirain.phm.bode.server.comm.ITransportPacket;
import com.hirain.phm.bode.server.comm.impl.CommunicationImpl;

public abstract class AbstractServerService implements IPost {

	static Logger logger = Logger.getLogger(SingleServerService.class);

	protected final ICommunication communication;

	protected boolean timestamp;

	private InetSocketAddress[] onlines;

	private String host;

	private boolean isStart;

	protected MDCULiveHandler liveHandler;

	public AbstractServerService() {
		communication = new CommunicationImpl(new ServerConnectionFactory(this));
	}

	public void init() {
		InnerEventBus.getInstance().register(this);
		timestamp = PrefsUtil.instance().getBooleanValue("timestamp");
	}

	private int start() {
		final InetSocketAddress toMdcu = new InetSocketAddress(host, ServerConstant.LOCAL_MDCU_PORT);
		final InetSocketAddress toServer = new InetSocketAddress(host, ServerConstant.TO_OTHER_PORT);
		final InetSocketAddress toServer_lostdata = new InetSocketAddress(host, ServerConstant.TO_LOSTDATA_PORT);
		onlines = new InetSocketAddress[] { toMdcu, toServer, toServer_lostdata };
		return bind(onlines);
	}

	private int bind(InetSocketAddress... address) {
		final int res = communication.bind(address);
		return res;
	}

	protected void restart(String ip) {
		if (!isStart) {
			host = ip;
			final int res = start();
			if (res == 0) {
				isStart = true;
			}
		} else {
			if (ip.equals(host)) {
				return;
			} else {
				isStart = false;
				stop();
				host = ip;
				final int res = start();
				if (res == 0) {
					isStart = true;
				}
			}
		}
	}

	public void stop() {
		if (onlines != null) {
			communication.stop(onlines);
		}
	}

	protected void processMessage(ITransportPacket packet) {
		byte[] data = packet.getData();
		if (!timestamp) {
			data = addTimestamp(data);
		}
		if (liveHandler != null) {
			liveHandler.update(packet.getAddress().getAddress().getHostAddress());
		}
		final boolean send = doProcessMessage(data);
		if (send) {
			InnerEventBus.getInstance().post(new MessageEvent(data));
		}
	}

	protected boolean doProcessMessage(byte[] data) {
		return true;
	}

	void sendOk(String ip) {
		final InetSocketAddress address = new InetSocketAddress(ip, ServerConstant.TO_MDCU_PORT);
		communication.send(address, ServerConstant.LOCAL_MDCU_PORT, ServerConstant.DOOR_MESSAGE_PID, "ok".getBytes());
	}

	protected byte[] addTimestamp(byte[] data) {
		final LocalDateTime dateTime = LocalDateTime.now();
		data[21] = (byte) dateTime.getDayOfMonth();
		data[22] = (byte) dateTime.getHour();
		data[23] = (byte) dateTime.getMinute();
		data[25] = (byte) dateTime.getSecond();
		// final ByteBuffer buffer = ByteBuffer.allocate(2);
		// buffer.putShort((short) (dateTime.getNano() / 1000000));
		// buffer.flip();
		// data[26] = buffer.get();
		// data[27] = buffer.get();
		return data;
	}

	public String getHost() {
		return host;
	}

}
