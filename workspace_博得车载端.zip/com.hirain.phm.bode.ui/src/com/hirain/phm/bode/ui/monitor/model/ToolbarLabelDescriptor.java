package com.hirain.phm.bode.ui.monitor.model;

import java.util.HashMap;
import java.util.Map;

public class ToolbarLabelDescriptor {

	private Map<String, String> labelMap = new HashMap<String, String>();

	public ToolbarLabelDescriptor() {
		labelMap.put("Rubberband Zoom", "框选缩放");
		labelMap.put("Horizontal Zoom", "水平缩放");
		labelMap.put("Vertical Zoom", "垂直缩放");
		labelMap.put("Zoom In", "点击放大");
		labelMap.put("Zoom Out", "点击缩小");
		labelMap.put("Panning", "移动");
		labelMap.put("None", "常规");
	}

	public String getCNLabel(String des) {
		return labelMap.get(des);
	}
}
