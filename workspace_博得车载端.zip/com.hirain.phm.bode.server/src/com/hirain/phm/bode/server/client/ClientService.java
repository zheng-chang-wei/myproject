package com.hirain.phm.bode.server.client;

import java.io.File;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.util.SystemInfoUtil;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.DebugEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.bus.MessageEvent;
import com.hirain.phm.bode.server.bus.MessageListEvent;
import com.hirain.phm.bode.server.client.data.DataDownloadHandler;
import com.hirain.phm.bode.server.client.data.DataQueryHandler;
import com.hirain.phm.bode.server.client.data.DataStatisticeHandler;
import com.hirain.phm.bode.server.client.data.LogDataDownloadHandler;
import com.hirain.phm.bode.server.comm.ICommunication;
import com.hirain.phm.bode.server.comm.ITransportPacket;
import com.hirain.phm.bode.server.comm.impl.CommunicationImpl;
import com.hirain.phm.bode.server.config.ConfigurationService;
import com.hirain.phm.bode.server.db.DBManageService;
import com.hirain.phm.bode.server.log.LogEvent;
import com.hirain.phm.bode.server.log.LogService;
import com.hirain.phm.bode.server.log.LogType;
import com.hirain.phm.bode.server.message.DoorMessage;
import com.hirain.phm.bode.server.message.PreProcessor;
import com.hirain.phm.bode.server.rbac.impl.UserService;

public class ClientService implements IHeartPost, ISender {

	public static Logger logger = Logger.getLogger(ClientService.class);

	private final ICommunication communication;

	private final Map<String, Token> clientMap = new ConcurrentHashMap<>();

	// private final AtomicInteger carriageId = new AtomicInteger(-1);

	// private final AtomicInteger doorId = new AtomicInteger(-1);

	private final ExecutorService pool;

	private ScheduledExecutorService heartExecutor;

	private boolean debug = false;

	private final PreProcessor processor;

	public ClientService(String host, PreProcessor processor) {
		this.processor = processor;
		communication = new CommunicationImpl(new ClientConnectionFactory(this));
		pool = Executors.newCachedThreadPool(r -> new Thread(r, "client thread pool"));
	}

	public void init() {
		InnerEventBus.getInstance().register(this);
		processor.register(this);
		heartExecutor = Executors.newSingleThreadScheduledExecutor(r -> new Thread(r, "client heart thread"));
		heartExecutor.scheduleAtFixedRate(() -> {
			for (final String ip : clientMap.keySet()) {
				final Token token = clientMap.get(ip);
				if (!token.on.get()) {
					final int breakCount = token.breakCount.incrementAndGet();
					if (breakCount > 3) {
						if (debug) {
							debug = false;
							InnerEventBus.getInstance().post(new DebugEvent(debug, this));
						}
						clientMap.remove(ip);
					}
				}
				token.on.set(false);
			}
		}, 4, 4, TimeUnit.SECONDS);
	}

	public void start(InetSocketAddress... address) {
		communication.bind(address);
	}

	// @Subscribes
	public void on(MessageEvent event) {
		final byte[] datas = event.getDatas();
		sendMessage(datas);
	}

	public void sendMessage(final byte[] datas) {
		for (final Token token : clientMap.values()) {
			communication.send(token.address, ClientConstants.LOCAL_UPLOAD_PORT, ClientConstants.SPECIFY_DOOR_RESPONSE, datas);
		}
	}

	@Subscribe
	public void on(MessageListEvent event) {
		final List<DoorMessage> messages = event.getMessages();
		for (final DoorMessage message : messages) {
			final ByteBuffer buffer = ByteBuffer.wrap(message.getDatas()).order(ByteOrder.LITTLE_ENDIAN);
			buffer.putShort(26, (short) message.getMilli());
			sendMessage(buffer.array());
		}
	}

	@Override
	public void heart(String ip) {
		final Token token = clientMap.get(ip);
		if (token != null) {
			token.on.set(true);
			token.breakCount.set(0);
		}
	}

	@Override
	public void send(InetSocketAddress address, int pid, byte[] datas) {
		communication.send(address, ClientConstants.LOCAL_CLIENT_PORT, pid, datas);
	}

	@Override
	public void post(ITransportPacket packet) {
		final int pid = packet.getPid();
		switch (pid) {
		case ClientConstants.SYSTEM_CONFIG_QUERY:
			getSystemConfig(packet);
			break;
		case ClientConstants.SYSTEM_CONFIG_UPDATE:
			updateSystemConfig(packet);
			break;
		case ClientConstants.STORAGE_SPACE_QUERY:
			getStorage(packet);
			break;
		case ClientConstants.DEBUG_COMMAND_ID:
			final byte[] bs = packet.getData();
			debug = bs[0] == 1;
			logger.info(debug ? "调试模式" : "取消调试");
			LogService.instance().log(LogEvent.ofDebug(debug));
			communication.send(packet.getAddress(), ClientConstants.LOCAL_CLIENT_PORT, ClientConstants.DEBUG_CONFIRM_ID, new byte[] { 0 });
			InnerEventBus.getInstance().post(new DebugEvent(bs[0] == 1, this));
			break;
		case ClientConstants.LOGIN_COMMAND_ID:
			login(packet);
			break;
		case ClientConstants.LOGOUT_COMMAND_ID:
			final String username = getUsername(packet.getAddress());
			LogService.instance().log(LogEvent.ofLogout(username));
			communication.send(packet.getAddress(), ClientConstants.LOCAL_CLIENT_PORT, ClientConstants.LOGOUT_CONFIRM_ID, new byte[] { 0 });
			break;
		case ClientConstants.DATA_QUERY_ID:
			System.out.println("query list");
			queryData(packet);
			break;
		case ClientConstants.DATA_REPLAY_ID:
			replay(packet);
			break;
		case ClientConstants.DATA_STATISTICS_ID:
			System.out.println("query count");
			count(packet);
			break;
		case ClientConstants.DATA_DOWNLOAD_ID:
			download(packet);
			break;
		default:
			break;
		}
	}

	private void login(ITransportPacket packet) {
		pool.submit(() -> {
			final String hostAddress = packet.getAddress().getAddress().getHostAddress();
			clientMap.remove(hostAddress);
			final String str = new String(packet.getData());
			final String[] split = str.split("##");
			String username = null;
			String password = null;
			if (split.length > 0) {
				username = split[0];
			}
			if (split.length > 1) {
				password = split[1];
			}
			boolean result = true;
			if (username == null || password == null) {
				result = false;
			} else {
				result = UserService.getInstance().login(username, password);
			}
			if (result) {
				logger.info("登录");
				clientMap.put(hostAddress, new Token(username, packet.getAddress()));
				LogService.instance().log(LogEvent.ofLogin(username));
			}
			communication.send(packet.getAddress(), ClientConstants.LOCAL_CLIENT_PORT, ClientConstants.LOGIN_CONFIRM_ID,
					new byte[] { (byte) (result ? 0 : 1) });
		});
	}

	private void getStorage(ITransportPacket packet) {
		if (!checkToken(packet.getAddress())) {
			return;
		}
		pool.submit(() -> {
			final long[] storage = getStorage();
			final ByteBuffer buffer = ByteBuffer.allocate(17);
			buffer.put((byte) 0);
			buffer.putLong(storage[0]);
			buffer.putLong(storage[1]);
			communication.send(packet.getAddress(), ClientConstants.LOCAL_CLIENT_PORT, ClientConstants.STORAGE_SPACE_RESPONSE, buffer.array());
		});
	}

	private void updateSystemConfig(ITransportPacket packet) {
		if (!checkToken(packet.getAddress())) {
			return;
		}
		logger.info("更新系统配置");
		pool.submit(() -> {
			final byte[] data = packet.getData();
			ITrain train = null;
			try {
				final String xml = new String(data, "UTF-8");
				logger.info(xml);
				train = SystemInfoUtil.convertXmlBytes2SystemInfo(data);
			} catch (final Exception e) {
				logger.error(e.getMessage(), e);
			}
			if (train == null) {
				communication.send(packet.getAddress(), ClientConstants.LOCAL_CLIENT_PORT, ClientConstants.SYSTEM_CONFIG_CONFIRM, new byte[] { 1 });
				return;
			}
			ConfigurationService.getInstance().save(train);
			if (Utils.validateSetting(train) == 0) {
				communication.send(packet.getAddress(), ClientConstants.LOCAL_CLIENT_PORT, ClientConstants.SYSTEM_CONFIG_CONFIRM, new byte[] { 0 });
				DBManageService.getInstance().init(train.getCars());
				LogService.instance().log(new LogEvent("", LogType.SYSTEM));
				LogService.instance().log(LogEvent.ofTrain(train));
				InnerEventBus.getInstance().post(new ConfigEvent(train, this));
			} else {
				communication.send(packet.getAddress(), ClientConstants.LOCAL_CLIENT_PORT, ClientConstants.SYSTEM_CONFIG_CONFIRM, new byte[] { 1 });
			}
		});
	}

	private void getSystemConfig(ITransportPacket packet) {
		if (!checkToken(packet.getAddress())) {
			return;
		}
		logger.info("请求系统配置");
		pool.submit(() -> {
			final ITrain train = ConfigurationService.getInstance().getTrain();
			if (train != null) {
				byte[] bytes;
				try {
					bytes = SystemInfoUtil.convertSystemInfo2XmlBytes(train);
					final ByteBuffer buffer = ByteBuffer.allocate(1 + bytes.length);
					buffer.put(Utils.validateSetting(train));
					buffer.put(bytes);
					communication.send(packet.getAddress(), ClientConstants.LOCAL_CLIENT_PORT, ClientConstants.SYSTEM_CONFIG_RESPONSE,
							buffer.array());
				} catch (final Exception e) {
					logger.error(e.getMessage(), e);
					communication.send(packet.getAddress(), ClientConstants.LOCAL_CLIENT_PORT, ClientConstants.SYSTEM_CONFIG_RESPONSE,
							new byte[] { 1 });
				}
			} else {
				communication.send(packet.getAddress(), ClientConstants.LOCAL_CLIENT_PORT, ClientConstants.SYSTEM_CONFIG_RESPONSE, new byte[] { 1 });
			}
		});
	}

	private void queryData(ITransportPacket packet) {
		if (!checkToken(packet.getAddress())) {
			return;
		}
		logger.info("查询数据");
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		final byte type = buffer.get();
		final byte[] sqlBs = new byte[packet.getLength() - 1];
		buffer.get(sqlBs);
		final String sql = new String(sqlBs);
		System.out.println(sql);
		new DataQueryHandler(this, sql, type, clientMap.get(packet.getAddress().getAddress().getHostAddress())).work();
	}

	private void replay(ITransportPacket packet) {
		if (!checkToken(packet.getAddress())) {
			return;
		}
		logger.info("请求数据");
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		final byte type = buffer.get();
		final byte[] sqlBs = new byte[packet.getLength() - 1];
		buffer.get(sqlBs);
		final String sql = new String(sqlBs);
		new DataDownloadHandler(this, sql, type, clientMap.get(packet.getAddress().getAddress().getHostAddress())).work();
	}

	private void download(ITransportPacket packet) {
		pool.submit(() -> {
			final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
			final byte type = buffer.get();
			if (type == ClientConstants.LOG_TAG) {
				final int year = buffer.get() + 2000;
				final int month = buffer.get();
				final int day = buffer.get();
				final LocalDate date = LocalDate.of(year, month, day);
				new LogDataDownloadHandler(this, date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")), type,
						clientMap.get(packet.getAddress().getAddress().getHostAddress())).work();
			} else {
				if (type == ClientConstants.COMMON_TAG) {
					logCommon(buffer);
				} else if (type == ClientConstants.FAULT_TAG) {
					logFault(buffer);
				}
				final byte[] sqlBs = new byte[buffer.remaining()];
				buffer.get(sqlBs);
				final String sql = new String(sqlBs);
				new DataDownloadHandler(this, sql, type, clientMap.get(packet.getAddress().getAddress().getHostAddress())).work();
			}
		});
	}

	private void logFault(ByteBuffer buffer) {
		final byte[] info = new byte[12];
		buffer.get(info);
		LogService.instance().log(LogEvent.ofFault(info));
	}

	private void logCommon(ByteBuffer buffer) {
		final byte[] info = new byte[14];
		buffer.get(info);
		LogService.instance().log(LogEvent.ofCommon(info));
	}

	private void count(ITransportPacket packet) {
		if (!checkToken(packet.getAddress())) {
			return;
		}
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		final byte type = buffer.get();
		final byte[] sqlBs = new byte[packet.getLength() - 1];
		buffer.get(sqlBs);
		final String sql = new String(sqlBs);
		System.out.println(sql);
		new DataStatisticeHandler(this, type, sql, clientMap.get(packet.getAddress().getAddress().getHostAddress())).work();
	}

	private long[] getStorage() {
		long total = 0l;
		long free = 0l;
		final File[] roots = File.listRoots();
		for (final File root : roots) {
			total += root.getTotalSpace();
			free += root.getFreeSpace();
		}
		return new long[] { total, total - free };
	}

	private boolean checkToken(InetSocketAddress address) {
		return clientMap.get(address.getAddress().getHostAddress()) != null;
	}

	private String getUsername(InetSocketAddress address) {
		final String host = address.getAddress().getHostAddress();
		final Token token = clientMap.get(host);
		return token.username;
	}
}
