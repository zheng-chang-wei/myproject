/*******************************************************************************
 * Copyright (c) 2017, 2017 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.fault.dialog;

import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月11日 下午1:43:56
 * @Description
 *              <p>
 *              故障日期选择
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月11日 changwei.zheng@hirain.com 1.0 create file
 */
public class FaultDateFilterDialog extends TitleAreaDialog {

	private DateTime dateTimeStart;

	private DateTime dateTimeEnd;

	private Date dateStart;

	private final Date dateEnd;

	public FaultDateFilterDialog(final Shell parentShell, Date dateEnd) {
		super(parentShell);
		this.dateEnd = dateEnd;
	}

	@Override
	protected Control createDialogArea(final Composite parent) {
		final Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout(3, false));
		composite.setLayoutData(new GridData(GridData.FILL_BOTH));
		dateTimeStart = new DateTime(composite, SWT.CALENDAR);

		Label label = new Label(composite, SWT.None);
		label.setText("到");
		label.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, true));
		dateTimeEnd = new DateTime(composite, SWT.CALENDAR);
		dateTimeEnd.setDate(dateEnd.getYear(), dateEnd.getMonth(), dateEnd.getDay());
		getShell().setText("故障日期选择");
		setTitle("故障日期选择");
		initListener();
		return composite;
	}

	private void initListener() {
		dateTimeStart.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			getDate();
		}));
		dateTimeEnd.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			getDate();
		}));

	}

	private void getDate() {
		int yearStart = dateTimeStart.getYear();
		int monthStart = dateTimeStart.getMonth() + 1;
		int dayStart = dateTimeStart.getDay();

		int yearEnd = dateTimeEnd.getYear();
		int monthEnd = dateTimeEnd.getMonth() + 1;
		int dayEnd = dateTimeEnd.getDay();
		dateStart = DateManager.getDateStart();
		dateStart.setDate(yearStart, monthStart, dayStart);
		dateEnd.setDate(yearEnd, monthEnd, dayEnd);
		setMessage(dateStart.toDate() + " 到 " + dateEnd.toDate());
	}

	@Override
	protected Point getInitialSize() {
		return new Point(500, 400);
	}

	/**
	 * @see org.eclipse.jface.dialogs.Dialog#createButtonsForButtonBar(org.eclipse.swt.widgets.Composite)
	 */
	@Override
	protected void createButtonsForButtonBar(final Composite parent) {
		super.createButtonsForButtonBar(parent);
	}

	@Override
	protected void okPressed() {
		super.okPressed();
	}

	public Date getDateStart() {
		return dateStart;
	}

	public Date getDateEnd() {
		return dateEnd;
	}

}
