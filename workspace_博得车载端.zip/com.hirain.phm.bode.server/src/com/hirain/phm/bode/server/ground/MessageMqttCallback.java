package com.hirain.phm.bode.server.ground;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MessageMqttCallback implements MqttCallbackExtended {

	private final String clientId;

	public MessageMqttCallback(String clientId) {
		this.clientId = clientId;
	}

	@Override
	public void connectionLost(Throwable cause) {
		System.out.println(clientId + " connection lost");
	}

	@Override
	public void messageArrived(String topic, MqttMessage message) throws Exception {
		// do nothing
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken token) {
	}

	@Override
	public void connectComplete(boolean reconnect, String serverURI) {
		GroundService.logger.info(clientId + " connection connected");
	}
}
