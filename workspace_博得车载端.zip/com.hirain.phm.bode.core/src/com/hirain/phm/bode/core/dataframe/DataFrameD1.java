/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.dataframe;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 10, 2019 4:58:25 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 10, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DataFrameD1 {

	/**
	 * 软件版本
	 */
	int version;

	/**
	 * 门防挤压 1 关门障碍物检测停
	 */
	boolean door_PreventExtrusion;

	/**
	 * 门隔离 1 隔离开关激活 0 未激活
	 */
	boolean door_Isolation;

	/**
	 * 门紧急解锁 1 紧急解锁未激活 0 紧急解锁激活
	 */
	boolean door_EmergencyUnlock;

	/**
	 * 门开好 1 开门到位 0 开门未到位
	 */
	boolean door_Open;

	/**
	 * 门关好 1 关闭 0 未关闭
	 */
	boolean door_Close;

	/**
	 * 门动作中 1 开关门过程中 0 未在开关门过程中
	 */
	boolean door_Action;

	/**
	 * 门零速 1 零速信号激活 0 零速信号未激活
	 */
	boolean door_NoSpeed;

	/**
	 * 门使能 1 车门使能激活 0 车门使能未激活
	 */
	boolean door_Enable;

	/**
	 * 门控制选择信号 1=网络位 0=硬线
	 */
	boolean door_ControlChoose;

	/**
	 * 再开闭信号反馈 1=再开闭信号 0=无效
	 */
	boolean feedback_SwitchAgain;//

	/**
	 * 检测到障碍物 1=检测到障碍物 0=无效
	 */
	boolean detectObstacles;//

	/**
	 * 关门信号反馈 1=关门 0=无效
	 */
	boolean feedback_doorClose;

	/**
	 * 开门信号反馈 1=开门 0=无效
	 */
	boolean feedback_doorOpen;//

	/**
	 * 门存在故障 1=门存在故障 0=无效
	 */
	boolean fault_DoorExist;//

	/**
	 * 输出短路 1=输出短路 0=没有输出短路
	 */
	boolean fault_OutputShortCircuit;//

	/**
	 * 开关门超时 1=超时 0=未超时
	 */
	boolean door_SwitchTimeOut;//

	/**
	 * 编码器故障 1=故障 0=正常
	 */
	boolean fault_Encoder;//

	/**
	 * 锁闭开关故障 1=电磁铁故障 0=正常
	 */
	boolean fault_LockSwitch;//

	/**
	 * 绿色环线故障 1=绿色环线断开 0=正常
	 */
	boolean fault_GreenLoop;//

	/**
	 * 门板开关故障 1=开关故障 0=正常
	 */
	boolean fault_doorSwitch;//

	/**
	 * 电机过流故障 1=电机过流 0=电动机电路OK
	 */
	boolean fault_MotorOverCurrent;//

	/**
	 * 电机开路故障 1=电机开路 0=电动机电路OK
	 */
	boolean fault_MotorOpenCircuit;//

	/**
	 * 服务按钮信号
	 */
	boolean signal_ServiceButton;//

	/**
	 * 集控开关门信号
	 */
	boolean signal_SwitchDoorCentralControl;//

	/**
	 * 集控关门信号
	 */
	boolean signal_CloseDoorCentralControl;//

	/**
	 * 再开闭信号
	 */
	boolean signal_OpenCloseAgain;//

	/**
	 * 零速信号
	 */
	boolean signal_ZeroSpeed;//

	/**
	 * 隔离信号
	 */
	boolean signal_Isolation;//

	/**
	 * 紧急解锁信号
	 */
	boolean signal_EmergencyUnlock;//

	/**
	 * 闭锁开关信号
	 */
	boolean signal_UnlockSwitch;//

	/**
	 * 左门板开关信号
	 */
	boolean signal_leftDoorOpenClose;//

	/**
	 * 右门板开关信号
	 */
	boolean signal_rightDoorOpenClose;//

	/**
	 * 门地址编码1
	 */
	boolean door_CodeAddr1;//

	/**
	 * 门地址编码2
	 */
	boolean door_CodeAddr2;//

	/**
	 * 门地址编码3
	 */
	boolean door_CodeAddr3;//

	/**
	 * 门地址编码4
	 */
	boolean door_CodeAddr4;//

	/**
	 * 安全互锁输入信号
	 */
	boolean signal_SafetyInterlockInput;//

	/**
	 * 安全互锁输出信号
	 */
	boolean signal_SafetyInterlockOutput;//

	/**
	 * 开关门指示灯输出
	 */
	boolean openDoorLightOutput;//

	/**
	 * 紧急解锁电磁铁输出
	 */
	boolean EmergencyUnlockElectromagnetOutput;//

	/**
	 * 蜂鸣器输出
	 */
	boolean buzzerOutput;//

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version
	 *            the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/**
	 * @return the door_PreventExtrusion
	 */
	public boolean isDoor_PreventExtrusion() {
		return door_PreventExtrusion;
	}

	/**
	 * @param door_PreventExtrusion
	 *            the door_PreventExtrusion to set
	 */
	public void setDoor_PreventExtrusion(boolean door_PreventExtrusion) {
		this.door_PreventExtrusion = door_PreventExtrusion;
	}

	/**
	 * @return the door_Isolation
	 */
	public boolean isDoor_Isolation() {
		return door_Isolation;
	}

	/**
	 * @param door_Isolation
	 *            the door_Isolation to set
	 */
	public void setDoor_Isolation(boolean door_Isolation) {
		this.door_Isolation = door_Isolation;
	}

	/**
	 * @return the door_EmergencyUnlock
	 */
	public boolean isDoor_EmergencyUnlock() {
		return door_EmergencyUnlock;
	}

	/**
	 * @param door_EmergencyUnlock
	 *            the door_EmergencyUnlock to set
	 */
	public void setDoor_EmergencyUnlock(boolean door_EmergencyUnlock) {
		this.door_EmergencyUnlock = door_EmergencyUnlock;
	}

	/**
	 * @return the door_Open
	 */
	public boolean isDoor_Open() {
		return door_Open;
	}

	/**
	 * @param door_Open
	 *            the door_Open to set
	 */
	public void setDoor_Open(boolean door_Open) {
		this.door_Open = door_Open;
	}

	/**
	 * @return the door_Close
	 */
	public boolean isDoor_Close() {
		return door_Close;
	}

	/**
	 * @param door_Close
	 *            the door_Close to set
	 */
	public void setDoor_Close(boolean door_Close) {
		this.door_Close = door_Close;
	}

	/**
	 * @return the door_Action
	 */
	public boolean isDoor_Action() {
		return door_Action;
	}

	/**
	 * @param door_Action
	 *            the door_Action to set
	 */
	public void setDoor_Action(boolean door_Action) {
		this.door_Action = door_Action;
	}

	/**
	 * @return the door_NoSpeed
	 */
	public boolean isDoor_NoSpeed() {
		return door_NoSpeed;
	}

	/**
	 * @param door_NoSpeed
	 *            the door_NoSpeed to set
	 */
	public void setDoor_NoSpeed(boolean door_NoSpeed) {
		this.door_NoSpeed = door_NoSpeed;
	}

	/**
	 * @return the door_Enable
	 */
	public boolean isDoor_Enable() {
		return door_Enable;
	}

	/**
	 * @param door_Enable
	 *            the door_Enable to set
	 */
	public void setDoor_Enable(boolean door_Enable) {
		this.door_Enable = door_Enable;
	}

	/**
	 * @return the door_ControlChoose
	 */
	public boolean isDoor_ControlChoose() {
		return door_ControlChoose;
	}

	/**
	 * @param door_ControlChoose
	 *            the door_ControlChoose to set
	 */
	public void setDoor_ControlChoose(boolean door_ControlChoose) {
		this.door_ControlChoose = door_ControlChoose;
	}

	/**
	 * @return the feedback_SwitchAgain
	 */
	public boolean isFeedback_SwitchAgain() {
		return feedback_SwitchAgain;
	}

	/**
	 * @param feedback_SwitchAgain
	 *            the feedback_SwitchAgain to set
	 */
	public void setFeedback_SwitchAgain(boolean feedback_SwitchAgain) {
		this.feedback_SwitchAgain = feedback_SwitchAgain;
	}

	/**
	 * @return the detectObstacles
	 */
	public boolean isDetectObstacles() {
		return detectObstacles;
	}

	/**
	 * @param detectObstacles
	 *            the detectObstacles to set
	 */
	public void setDetectObstacles(boolean detectObstacles) {
		this.detectObstacles = detectObstacles;
	}

	/**
	 * @return the feedback_doorClose
	 */
	public boolean isFeedback_doorClose() {
		return feedback_doorClose;
	}

	/**
	 * @param feedback_doorClose
	 *            the feedback_doorClose to set
	 */
	public void setFeedback_doorClose(boolean feedback_doorClose) {
		this.feedback_doorClose = feedback_doorClose;
	}

	/**
	 * @return the feedback_doorOpen
	 */
	public boolean isFeedback_doorOpen() {
		return feedback_doorOpen;
	}

	/**
	 * @param feedback_doorOpen
	 *            the feedback_doorOpen to set
	 */
	public void setFeedback_doorOpen(boolean feedback_doorOpen) {
		this.feedback_doorOpen = feedback_doorOpen;
	}

	/**
	 * @return the fault_DoorExist
	 */
	public boolean isFault_DoorExist() {
		return fault_DoorExist;
	}

	/**
	 * @param fault_DoorExist
	 *            the fault_DoorExist to set
	 */
	public void setFault_DoorExist(boolean fault_DoorExist) {
		this.fault_DoorExist = fault_DoorExist;
	}

	/**
	 * @return the fault_OutputShortCircuit
	 */
	public boolean isFault_OutputShortCircuit() {
		return fault_OutputShortCircuit;
	}

	/**
	 * @param fault_OutputShortCircuit
	 *            the fault_OutputShortCircuit to set
	 */
	public void setFault_OutputShortCircuit(boolean fault_OutputShortCircuit) {
		this.fault_OutputShortCircuit = fault_OutputShortCircuit;
	}

	/**
	 * @return the door_SwitchTimeOut
	 */
	public boolean isDoor_SwitchTimeOut() {
		return door_SwitchTimeOut;
	}

	/**
	 * @param door_SwitchTimeOut
	 *            the door_SwitchTimeOut to set
	 */
	public void setDoor_SwitchTimeOut(boolean door_SwitchTimeOut) {
		this.door_SwitchTimeOut = door_SwitchTimeOut;
	}

	/**
	 * @return the fault_Encoder
	 */
	public boolean isFault_Encoder() {
		return fault_Encoder;
	}

	/**
	 * @param fault_Encoder
	 *            the fault_Encoder to set
	 */
	public void setFault_Encoder(boolean fault_Encoder) {
		this.fault_Encoder = fault_Encoder;
	}

	/**
	 * @return the fault_LockSwitch
	 */
	public boolean isFault_LockSwitch() {
		return fault_LockSwitch;
	}

	/**
	 * @param fault_LockSwitch
	 *            the fault_LockSwitch to set
	 */
	public void setFault_LockSwitch(boolean fault_LockSwitch) {
		this.fault_LockSwitch = fault_LockSwitch;
	}

	/**
	 * @return the fault_GreenLoop
	 */
	public boolean isFault_GreenLoop() {
		return fault_GreenLoop;
	}

	/**
	 * @param fault_GreenLoop
	 *            the fault_GreenLoop to set
	 */
	public void setFault_GreenLoop(boolean fault_GreenLoop) {
		this.fault_GreenLoop = fault_GreenLoop;
	}

	/**
	 * @return the fault_doorSwitch
	 */
	public boolean isFault_doorSwitch() {
		return fault_doorSwitch;
	}

	/**
	 * @param fault_doorSwitch
	 *            the fault_doorSwitch to set
	 */
	public void setFault_doorSwitch(boolean fault_doorSwitch) {
		this.fault_doorSwitch = fault_doorSwitch;
	}

	/**
	 * @return the fault_MotorOverCurrent
	 */
	public boolean isFault_MotorOverCurrent() {
		return fault_MotorOverCurrent;
	}

	/**
	 * @param fault_MotorOverCurrent
	 *            the fault_MotorOverCurrent to set
	 */
	public void setFault_MotorOverCurrent(boolean fault_MotorOverCurrent) {
		this.fault_MotorOverCurrent = fault_MotorOverCurrent;
	}

	/**
	 * @return the fault_MotorOpenCircuit
	 */
	public boolean isFault_MotorOpenCircuit() {
		return fault_MotorOpenCircuit;
	}

	/**
	 * @param fault_MotorOpenCircuit
	 *            the fault_MotorOpenCircuit to set
	 */
	public void setFault_MotorOpenCircuit(boolean fault_MotorOpenCircuit) {
		this.fault_MotorOpenCircuit = fault_MotorOpenCircuit;
	}

	/**
	 * @return the signal_ServiceButton
	 */
	public boolean isSignal_ServiceButton() {
		return signal_ServiceButton;
	}

	/**
	 * @param signal_ServiceButton
	 *            the signal_ServiceButton to set
	 */
	public void setSignal_ServiceButton(boolean signal_ServiceButton) {
		this.signal_ServiceButton = signal_ServiceButton;
	}

	/**
	 * @return the signal_SwitchDoorCentralControl
	 */
	public boolean isSignal_SwitchDoorCentralControl() {
		return signal_SwitchDoorCentralControl;
	}

	/**
	 * @param signal_SwitchDoorCentralControl
	 *            the signal_SwitchDoorCentralControl to set
	 */
	public void setSignal_SwitchDoorCentralControl(boolean signal_SwitchDoorCentralControl) {
		this.signal_SwitchDoorCentralControl = signal_SwitchDoorCentralControl;
	}

	/**
	 * @return the signal_CloseDoorCentralControl
	 */
	public boolean isSignal_CloseDoorCentralControl() {
		return signal_CloseDoorCentralControl;
	}

	/**
	 * @param signal_CloseDoorCentralControl
	 *            the signal_CloseDoorCentralControl to set
	 */
	public void setSignal_CloseDoorCentralControl(boolean signal_CloseDoorCentralControl) {
		this.signal_CloseDoorCentralControl = signal_CloseDoorCentralControl;
	}

	/**
	 * @return the signal_OpenCloseAgain
	 */
	public boolean isSignal_OpenCloseAgain() {
		return signal_OpenCloseAgain;
	}

	/**
	 * @param signal_OpenCloseAgain
	 *            the signal_OpenCloseAgain to set
	 */
	public void setSignal_OpenCloseAgain(boolean signal_OpenCloseAgain) {
		this.signal_OpenCloseAgain = signal_OpenCloseAgain;
	}

	/**
	 * @return the signal_ZeroSpeed
	 */
	public boolean isSignal_ZeroSpeed() {
		return signal_ZeroSpeed;
	}

	/**
	 * @param signal_ZeroSpeed
	 *            the signal_ZeroSpeed to set
	 */
	public void setSignal_ZeroSpeed(boolean signal_ZeroSpeed) {
		this.signal_ZeroSpeed = signal_ZeroSpeed;
	}

	/**
	 * @return the signal_Isolation
	 */
	public boolean isSignal_Isolation() {
		return signal_Isolation;
	}

	/**
	 * @param signal_Isolation
	 *            the signal_Isolation to set
	 */
	public void setSignal_Isolation(boolean signal_Isolation) {
		this.signal_Isolation = signal_Isolation;
	}

	/**
	 * @return the signal_EmergencyUnlock
	 */
	public boolean isSignal_EmergencyUnlock() {
		return signal_EmergencyUnlock;
	}

	/**
	 * @param signal_EmergencyUnlock
	 *            the signal_EmergencyUnlock to set
	 */
	public void setSignal_EmergencyUnlock(boolean signal_EmergencyUnlock) {
		this.signal_EmergencyUnlock = signal_EmergencyUnlock;
	}

	/**
	 * @return the signal_UnlockSwitch
	 */
	public boolean isSignal_UnlockSwitch() {
		return signal_UnlockSwitch;
	}

	/**
	 * @param signal_UnlockSwitch
	 *            the signal_UnlockSwitch to set
	 */
	public void setSignal_UnlockSwitch(boolean signal_UnlockSwitch) {
		this.signal_UnlockSwitch = signal_UnlockSwitch;
	}

	/**
	 * @return the signal_leftDoorOpenClose
	 */
	public boolean isSignal_leftDoorOpenClose() {
		return signal_leftDoorOpenClose;
	}

	/**
	 * @param signal_leftDoorOpenClose
	 *            the signal_leftDoorOpenClose to set
	 */
	public void setSignal_leftDoorOpenClose(boolean signal_leftDoorOpenClose) {
		this.signal_leftDoorOpenClose = signal_leftDoorOpenClose;
	}

	/**
	 * @return the signal_rightDoorOpenClose
	 */
	public boolean isSignal_rightDoorOpenClose() {
		return signal_rightDoorOpenClose;
	}

	/**
	 * @param signal_rightDoorOpenClose
	 *            the signal_rightDoorOpenClose to set
	 */
	public void setSignal_rightDoorOpenClose(boolean signal_rightDoorOpenClose) {
		this.signal_rightDoorOpenClose = signal_rightDoorOpenClose;
	}

	/**
	 * @return the door_CodeAddr1
	 */
	public boolean isDoor_CodeAddr1() {
		return door_CodeAddr1;
	}

	/**
	 * @param door_CodeAddr1
	 *            the door_CodeAddr1 to set
	 */
	public void setDoor_CodeAddr1(boolean door_CodeAddr1) {
		this.door_CodeAddr1 = door_CodeAddr1;
	}

	/**
	 * @return the door_CodeAddr2
	 */
	public boolean isDoor_CodeAddr2() {
		return door_CodeAddr2;
	}

	/**
	 * @param door_CodeAddr2
	 *            the door_CodeAddr2 to set
	 */
	public void setDoor_CodeAddr2(boolean door_CodeAddr2) {
		this.door_CodeAddr2 = door_CodeAddr2;
	}

	/**
	 * @return the door_CodeAddr3
	 */
	public boolean isDoor_CodeAddr3() {
		return door_CodeAddr3;
	}

	/**
	 * @param door_CodeAddr3
	 *            the door_CodeAddr3 to set
	 */
	public void setDoor_CodeAddr3(boolean door_CodeAddr3) {
		this.door_CodeAddr3 = door_CodeAddr3;
	}

	/**
	 * @return the door_CodeAddr4
	 */
	public boolean isDoor_CodeAddr4() {
		return door_CodeAddr4;
	}

	/**
	 * @param door_CodeAddr4
	 *            the door_CodeAddr4 to set
	 */
	public void setDoor_CodeAddr4(boolean door_CodeAddr4) {
		this.door_CodeAddr4 = door_CodeAddr4;
	}

	/**
	 * @return the signal_SafetyInterlockInput
	 */
	public boolean isSignal_SafetyInterlockInput() {
		return signal_SafetyInterlockInput;
	}

	/**
	 * @param signal_SafetyInterlockInput
	 *            the signal_SafetyInterlockInput to set
	 */
	public void setSignal_SafetyInterlockInput(boolean signal_SafetyInterlockInput) {
		this.signal_SafetyInterlockInput = signal_SafetyInterlockInput;
	}

	/**
	 * @return the signal_SafetyInterlockOutput
	 */
	public boolean isSignal_SafetyInterlockOutput() {
		return signal_SafetyInterlockOutput;
	}

	/**
	 * @param signal_SafetyInterlockOutput
	 *            the signal_SafetyInterlockOutput to set
	 */
	public void setSignal_SafetyInterlockOutput(boolean signal_SafetyInterlockOutput) {
		this.signal_SafetyInterlockOutput = signal_SafetyInterlockOutput;
	}

	/**
	 * @return the openDoorLightOutput
	 */
	public boolean isOpenDoorLightOutput() {
		return openDoorLightOutput;
	}

	/**
	 * @param openDoorLightOutput
	 *            the openDoorLightOutput to set
	 */
	public void setOpenDoorLightOutput(boolean openDoorLightOutput) {
		this.openDoorLightOutput = openDoorLightOutput;
	}

	/**
	 * @return the emergencyUnlockElectromagnetOutput
	 */
	public boolean isEmergencyUnlockElectromagnetOutput() {
		return EmergencyUnlockElectromagnetOutput;
	}

	/**
	 * @param emergencyUnlockElectromagnetOutput
	 *            the emergencyUnlockElectromagnetOutput to set
	 */
	public void setEmergencyUnlockElectromagnetOutput(boolean emergencyUnlockElectromagnetOutput) {
		EmergencyUnlockElectromagnetOutput = emergencyUnlockElectromagnetOutput;
	}

	/**
	 * @return the buzzerOutput
	 */
	public boolean isBuzzerOutput() {
		return buzzerOutput;
	}

	/**
	 * @param buzzerOutput
	 *            the buzzerOutput to set
	 */
	public void setBuzzerOutput(boolean buzzerOutput) {
		this.buzzerOutput = buzzerOutput;
	}

}
