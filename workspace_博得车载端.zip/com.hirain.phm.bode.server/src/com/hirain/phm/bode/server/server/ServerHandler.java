package com.hirain.phm.bode.server.server;

import com.hirain.phm.bode.server.comm.IPost;
import com.hirain.phm.bode.server.comm.ITransportPacket;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

class ServerHandler extends ChannelInboundHandlerAdapter {

	private final IPost poster;

	public ServerHandler(IPost poster) {
		this.poster = poster;
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		if (msg instanceof ITransportPacket) {
			poster.post((ITransportPacket) msg);
			if (poster instanceof ServerService) {
				((ServerService) poster).getHeartbeatHandler().getEventBus().post((ITransportPacket) msg);
			}
		}
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		ServerService.logger.error(cause.getMessage(), cause);
	}
}
