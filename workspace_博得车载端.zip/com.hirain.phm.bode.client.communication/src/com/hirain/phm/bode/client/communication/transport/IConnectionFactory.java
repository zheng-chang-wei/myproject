package com.hirain.phm.bode.client.communication.transport;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 */
public interface IConnectionFactory {

	IConnection create(int port);
}
