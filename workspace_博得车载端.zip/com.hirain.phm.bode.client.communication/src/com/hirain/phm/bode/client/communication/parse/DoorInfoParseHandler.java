/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.parse;

import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

import com.google.common.eventbus.EventBus;
import com.hirain.phm.bode.client.communication.listener.DoorInfoMessageListenerManager;
import com.hirain.phm.bode.client.communication.listener.IDoorInfoMessageListener;
import com.hirain.phm.bode.client.communication.message.DoorInfoMessage;
import com.hirain.phm.bode.core.dataframe.DoorStatus;
import com.hirain.phm.bode.core.dataframe.IDataFrame;
import com.hirain.phm.bode.core.dataframe.RunDataFrame;
import com.hirain.phm.bode.core.util.DataFrameDecoder;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 29, 2019 2:37:01 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 29, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DoorInfoParseHandler implements IDoorInfoParse, IDoorInfoMessageListener {

	private static DoorInfoParseHandler INSTANCE;

	IDataFrame dataFrame_newest = null;

	IDataFrame dataFrame_cache = null;

	/**
	 * 当前报文中包含车门数据对象
	 */
	Map<IDataFrame, DoorStatus> newest;

	/**
	 * 缓存的车门数据对象
	 */
	Map<IDataFrame, DoorStatus> cache;

	private EventBus eventBus = new EventBus("doorInfo");

	/**
	 * 由用户操作传过来的指定车厢号
	 */
	private int carNo;

	/**
	 * 由用户操作传过来的指定车门地址
	 */
	private int markDoorAddr;

	private static DataFrameDecoder dataFrameDecoder = new DataFrameDecoder();

	private BlockingQueue<DoorInfoMessage> queue = new LinkedBlockingQueue<>();

	private ExecutorService executor = Executors.newSingleThreadExecutor(r -> new Thread(r, DoorInfoMessage.class.getName()));

	private DoorInfoParseHandler() {
		start();
	}

	public static DoorInfoParseHandler getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new DoorInfoParseHandler();
		}
		return INSTANCE;
	}

	public EventBus getEventBus() {
		return eventBus;
	}

	public void initialize() {
		if (!DoorInfoMessageListenerManager.getInstance().getListeners().contains(this)) {
			DoorInfoMessageListenerManager.getInstance().addListener(this);
		}
	}

	private void start() {
		executor.submit(() -> {
			while (true) {
				try {
					DoorInfoMessage message = queue.take();
					if (message != null) {
						byte[] data = message.getData();
						newest = dataFrameDecoder.convertBytes2DataFrame(data);// 当前报文中包含的帧数据信息和车门状态信息

						for (IDataFrame key : newest.keySet()) {
							postRealTimeData(key);
							postDoorStatusData(newest.get(key));
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	@Override
	public void receive(DoorInfoMessage message) {
		queue.offer(message);
	}

	@Override
	public void postRealTimeData(IDataFrame dataFrame) {
		boolean b1 = carNo == ((RunDataFrame) dataFrame).getDataFrameD2().getCarNo();
		boolean b2 = markDoorAddr == ((RunDataFrame) dataFrame).getDataFrameD2().getDoorAddr();
		if (b1 && b2) {
			eventBus.post(dataFrame);
		}
	}

	@Override
	public void postDoorStatusData(DoorStatus doorStatus) {
		eventBus.post(doorStatus);
	}

	public void shutDown() {
		DoorInfoMessageListenerManager.getInstance().removeListener(this);
	}

	public void setCarNo(int carNo) {
		this.carNo = carNo;
	}

	public void setDoorAddr(int doorAddr) {
		markDoorAddr = doorAddr;
	}
}
