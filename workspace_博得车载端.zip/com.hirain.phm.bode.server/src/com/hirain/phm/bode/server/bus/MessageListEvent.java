package com.hirain.phm.bode.server.bus;

import java.util.List;

import com.hirain.phm.bode.server.message.DoorMessage;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MessageListEvent {

	private List<DoorMessage> messages;
}
