package com.hirain.phm.bode.server.ground.sender;

import java.util.Arrays;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.hirain.phm.bd.message.train.FaultMessage;
import com.hirain.phm.bd.message.train.FaultPacket;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.fault.FaultRecord;
import com.hirain.phm.bode.server.fault.FaultService;
import com.hirain.phm.bode.server.mqtt.MqttPublisher;

public class FaultSender {

	private String city;

	private String line;

	private String train;

	private MqttPublisher publisher;

	private String topic;

	private final Queue<FaultRecord> recordCache = new ConcurrentLinkedQueue<>();

	private ExecutorService executor;

	private boolean stopped = false;

	public FaultSender() {
		executor = Executors.newSingleThreadExecutor();
	}

	public void start() {
		stopped = false;
	}

	public void add(FaultRecord record) {
		if (stopped) {
			return;
		}
		if (executor == null || executor.isShutdown()) {
			executor = Executors.newSingleThreadExecutor();
		}
		executor.submit(() -> {
			final FaultPacket packet = new FaultPacket();
			packet.setCity(city);
			packet.setLine(line);
			packet.setTrain(train);
			packet.setMessages(Arrays.asList(fromRecord(record)));
			final String json = Utils.toJsonString(packet);
			if (publisher != null && publisher.isConnected()) {
				boolean flag = false;
				try {
					publisher.send(topic, json.getBytes(), 1, false);
					flag = true;
				} catch (final Exception e) {
				}
				if (!flag) {
					try {
						publisher.send(topic, json.getBytes(), 1, false);
					} catch (final Exception e) {
						recordCache.add(record);
					}
				}
			} else {
				recordCache.add(record);
			}
		});
	}

	private FaultMessage fromRecord(FaultRecord record) {
		final FaultMessage message = new FaultMessage();
		message.setCarriageId(record.getCarriageId());
		message.setDoorId(record.getDoorId());
		message.setDebug(record.getDebug());
		message.setFaultId(record.getFaultId());
		message.setFaultName(FaultService.FAULT_NAMES.get(message.getFaultId()));
		return message;
	}

	public void reconnected() {
		if (stopped) {
			return;
		}
		final ExecutorService executorService = Executors.newSingleThreadExecutor();
		executorService.submit(() -> {
			final Queue<FaultRecord> records = new ConcurrentLinkedQueue<>(recordCache);
			recordCache.clear();
			while (true) {
				final int size = Math.min(20, records.size());
				final FaultPacket packet = new FaultPacket();
				packet.setCity(city);
				packet.setLine(line);
				packet.setTrain(train);
				for (int i = 0; i < size; i++) {
					packet.setMessages(Arrays.asList(fromRecord(records.poll())));
				}
				final String json = Utils.toJsonString(packet);
				if (publisher != null && publisher.isConnected()) {
					try {
						publisher.send(json, json.getBytes(), 1, false);
					} catch (final Exception e) {
					}
				} // TODO
				if (records.size() == 0) {
					break;
				}
			}
		});
	}

	public void stop() {
		stopped = true;
	}

	public void setPublisher(MqttPublisher publisher) {
		this.publisher = publisher;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public void update(String city, String line, String train) {
		this.city = city;
		this.line = line;
		this.train = train;
	}
}
