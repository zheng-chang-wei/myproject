/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.ground.fault.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.hirain.phm.bd.ground.fault.dao.FaultDataMapper;
import com.hirain.phm.bd.ground.fault.domain.FaultData;
import com.hirain.phm.bd.ground.fault.domain.FaultDataContainer;
import com.hirain.phm.bd.ground.fault.param.FaultDataResponse;
import com.hirain.phm.bd.ground.fault.service.FaultDataService;
import com.hirain.phm.bd.message.train.DoorState;
import com.hirain.phm.bd.message.train.FaultMessage;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created Dec 27, 2019 1:52:15 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Dec 27, 2019 jianwen.xin@hirain.com 1.0 create file
 */
@Service
public class FaultDataServiceImpl implements FaultDataService {

	@Autowired
	private FaultDataMapper mapper;

	/**
	 * @see com.hirain.phm.bd.ground.fault.service.FaultDataService#getFaultData(java.lang.Long)
	 */
	@Override
	public FaultDataResponse getFaultData(Long id) {
		FaultDataContainer container = mapper.selectByPrimaryKey(id);
		FaultDataResponse response = new FaultDataResponse();
		response.setId(id);
		response.setState(DoorState.values()[container.getState()].getMessage());
		List<String> keys = JSONObject.parseArray(container.getKeys(), String.class);
		response.setKeys(keys);
		List<FaultData> datas = JSONObject.parseArray(container.getDatas(), FaultData.class);
		response.setDatas(datas);
		return response;
	}

	/**
	 * @see com.hirain.phm.bd.ground.fault.service.FaultDataService#saveFaultData(java.lang.Long, com.hirain.phm.bd.message.train.FaultMessage)
	 */
	@Override
	public void saveFaultData(Long faultId, FaultMessage faultMessage) {
		FaultDataContainer container = new FaultDataContainer();
		container.setId(faultId);
		container.setState(faultMessage.getState());
		String keys = JSONObject.toJSONString(faultMessage.getKeys());
		container.setKeys(keys);
		String datas = JSONObject.toJSONString(faultMessage.getDatas());
		container.setDatas(datas);
		mapper.insert(container);
	}

}
