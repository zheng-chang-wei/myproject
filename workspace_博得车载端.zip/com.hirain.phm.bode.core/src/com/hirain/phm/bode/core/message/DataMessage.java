package com.hirain.phm.bode.core.message;

public class DataMessage {

	private byte[] data;

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

}
