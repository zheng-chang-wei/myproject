/*******************************************************************************
 * Copyright (c) 2018, 2018 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.monitor.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;

import org.eclipse.nebula.visualization.xygraph.util.XYGraphMediaFactory;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Text;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.dataframe.DataFrameD3;
import com.hirain.phm.bode.core.dataframe.DataFrameD4;
import com.hirain.phm.bode.core.dataframe.DoorStatus;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;
import com.hirain.phm.bode.ui.monitor.model.Position;
import com.hirain.phm.bode.ui.monitor.model.XYSeries;

public class Util {

	/**
	 * 校验输入是否为数字
	 */
	public static VerifyListener addrVerifyListener = e -> {
		Text text = (Text) e.getSource();
		String string = text.getText();
		if (StringUtil.isEmpty(string) && e.text.equals("0")) {
			e.doit = false;
		} else {
			e.doit = Pattern.compile("([0-9])*").matcher(e.text).matches();
		}
	};

	/**
	 * 读取ini配置文件
	 * 
	 * @param configpath
	 * @return
	 */
	public static Properties getProperties(final String configpath) {
		final Properties properties = new Properties();
		InputStreamReader fis = null;
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(new File(configpath));
			fis = new InputStreamReader(inputStream, "gbk");
			properties.load(fis);
		} catch (final FileNotFoundException e) {
			e.printStackTrace();
		} catch (final IOException e) {
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (final IOException e) {
					e.printStackTrace();
				}
			}
			if (fis != null) {
				try {
					fis.close();
				} catch (final IOException e) {
					e.printStackTrace();
				}
			}
		}
		return properties;
	}

	public static List<String> string2List(String[] signalNames) {
		return Arrays.asList(signalNames);
	}

	public static List<XYSeries> getData(String name, Color color) {
		List<XYSeries> list = new ArrayList<XYSeries>();
		XYSeries xySeries = new XYSeries();
		xySeries.setId(name);
		double[] xAxisData = new double[0];
		double[] yAxisData = new double[0];
		xySeries.setxAxisData(xAxisData);
		xySeries.setyAxisData(yAxisData);
		xySeries.setColor(color);
		list.add(xySeries);

		return list;
	}

	public static List<XYSeries> getData(List<String> input) {
		List<XYSeries> list = new ArrayList<XYSeries>();
		for (int i = 0; i < input.size(); i++) {
			String name = input.get(i);
			XYSeries xySeries = new XYSeries();
			xySeries.setId(name);
			double[] xAxisData = new double[0];
			double[] yAxisData = new double[0];
			xySeries.setxAxisData(xAxisData);
			xySeries.setyAxisData(yAxisData);
			Color color = XYGraphMediaFactory.getInstance().getColor(CarriageConstants.DEFAULT_TRACES_COLOR[i % 12]);
			xySeries.setColor(color);
			list.add(xySeries);
		}

		return list;
	}

	/**
	 * 从arrayList中的对象中读取属性名称为attrName的属性值
	 * 
	 * @param arrayList
	 * @param attrName
	 * @return
	 */
	public static Object getValue(List<Object> arrayList, String attrName) {
		for (Object object : arrayList) {
			Object value = getValueByAttr(object, attrName);
			if (value != null) {
				return value;
			}
		}
		return null;
	}

	public static boolean[] getFaultValues(DoorStatus doorStatus) {
		String[] doorStatusAttrs = CarriageConstants.doorStatusAttrs;
		boolean[] faults = new boolean[doorStatusAttrs.length];
		int i = 0;
		for (String attrName : doorStatusAttrs) {
			Object value = getValueByAttr(doorStatus, attrName);
			if (value != null) {
				faults[i] = (boolean) value;
				i++;
			}
		}
		return faults;
	}

	public static Object getValueByAttr(Object object, String attrName) {
		Field[] fields = object.getClass().getDeclaredFields();
		for (Field field : fields) {
			field.setAccessible(true);
			if (field.getName().equals(attrName)) {
				try {
					return field.get(object);
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	public static long getCurrentTimeMillis(DataFrameD3 dataFrameD3, DataFrameD4 dataFrameD4) {
		int day = dataFrameD3.getDate();
		int hour = dataFrameD3.getHour();
		int minute = dataFrameD3.getMinute();
		int second = dataFrameD4.getSecond();
		int millisecond = dataFrameD4.getMillisecond();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		String currentTime = year + StringUtil.MID_LINE + month + StringUtil.MID_LINE + day + " " + hour + StringUtil.COLON + minute
				+ StringUtil.COLON + second + StringUtil.DOAT + millisecond;
		// System.out.println(currentTime);
		try {
			Date parse = dateFormat.parse(currentTime);
			return parse.getTime();
			// 获取本地时间
			// return System.currentTimeMillis();
		} catch (Exception e) {
			e.printStackTrace();
			BodeUIPlugin.log(e);
		}
		return 0;
	}

	public static int getDoorAddrByIndex(ICar car, int doorIndex) {
		if (car != null) {

			List<IDoor> doors = car.getDoors();
			if (doors != null && doors.size() > doorIndex) {
				return doors.get(doorIndex).getAddr();
			}
		}
		return -1;
	}

	public static int getDoorIndexByAddr(ICar iCar, int doorAddr) {
		if (iCar != null) {
			List<IDoor> doors = iCar.getDoors();
			if (doors != null) {
				for (int i = 0; i < doors.size(); i++) {
					if (doors.get(i).getAddr() == doorAddr) {
						return i;
					}
				}
			}
		}
		return -1;
	}

	public static void getDoorItems(ICar car, List<String[]> doorList) {
		List<IDoor> doors = car.getDoors();
		if (doors != null) {
			int doorSize = doors.size();
			String[] doorAddrs = new String[doorSize];
			for (int j = 0; j < doorSize; j++) {
				int addr = doors.get(j).getAddr();
				doorAddrs[j] = String.valueOf(addr);
			}
			doorList.add(doorAddrs);
		}
	}

	public static void setDoorAddressItems(String[] doorAddrs, Combo cmbDoorAddress) {
		if (doorAddrs != null) {
			cmbDoorAddress.setItems(doorAddrs);
			cmbDoorAddress.setText(doorAddrs[0]);
		}
	}

	public static List<XYSeries> getData(String name, List<Position> positions, Color color) {
		List<XYSeries> list = new ArrayList<XYSeries>();
		int size = positions.size();
		XYSeries xySeries = new XYSeries();
		xySeries.setId(name);
		double[] xAxisData = new double[size];
		double[] yAxisData = new double[size];
		for (int i = 0; i < size; i++) {
			xAxisData[i] = positions.get(i).getX();
			yAxisData[i] = positions.get(i).getY();
		}
		xySeries.setxAxisData(xAxisData);
		xySeries.setyAxisData(yAxisData);
		xySeries.setColor(color);
		list.add(xySeries);

		return list;
	}
}
