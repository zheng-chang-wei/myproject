/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.ground.maintenance.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.util.StringUtil;
import com.hirain.phm.bd.ground.authority.controller.RBACGateWay;
import com.hirain.phm.bd.ground.authority.domain.User;
import com.hirain.phm.bd.ground.maintenance.domain.RepairOption;
import com.hirain.phm.bd.ground.maintenance.domain.StepType;
import com.hirain.phm.bd.ground.maintenance.domain.WorkDetail;
import com.hirain.phm.bd.ground.maintenance.domain.WorkSheet;
import com.hirain.phm.bd.ground.maintenance.domain.WorkStep;
import com.hirain.phm.bd.ground.maintenance.param.SheetCountResponse;
import com.hirain.phm.bd.ground.maintenance.param.Suggestion;
import com.hirain.phm.bd.ground.maintenance.param.WorkSheetRecord;
import com.hirain.phm.bd.ground.maintenance.param.WorksheetPacket;
import com.hirain.phm.bd.ground.maintenance.redis.WorksheetRedisMapper;
import com.hirain.phm.bd.ground.maintenance.service.FlowReadService;
import com.hirain.phm.bd.ground.maintenance.service.StepTypeService;
import com.hirain.phm.bd.ground.maintenance.service.WorkDetailService;
import com.hirain.phm.bd.ground.maintenance.service.WorkSheetService;
import com.hirain.phm.bd.ground.maintenance.service.WorkStepService;
import com.hirain.phm.bd.ground.push.domain.PushInfo;
import com.hirain.phm.bd.ground.push.service.SuggestionService;
import com.hirain.phm.bd.ground.train.controller.TrainGateWay;
import com.hirain.phm.bd.ground.train.domain.Project;
import com.hirain.phm.bd.ground.train.domain.Train;
import com.hirain.phm.bd.ground.train.param.TrainParamHeader;
import com.hirain.phm.bd.ground.util.RedisUtil;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年6月3日 下午2:57:05
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年6月3日 jianwen.xin@hirain.com 1.0 create file
 */
@Service
public class FlowReadServiceImpl implements FlowReadService {

	@Autowired
	private WorkSheetService sheetService;

	@Autowired
	private RBACGateWay rbacGW;

	@Autowired
	private WorkDetailService detailService;

	@Autowired
	private WorkStepService stepService;

	@Autowired
	private StepTypeService typeService;

	@Autowired
	private TrainGateWay trainGW;

	@Autowired
	private RedisUtil redisUtil;

	@Autowired
	private SuggestionService suggestionService;

	@Autowired
	private WorksheetRedisMapper redisMapper;

	@Override
	public List<WorkSheetRecord> listWorkSheets(TrainParamHeader trainParam) {
		User user = (User) SecurityUtils.getSubject().getPrincipal();

		List<Integer> roles = rbacGW.getRepairRolesByUserId(user.getUserId());
		List<StepType> types = filter(roles, typeService.selectAll());
		// 工单类型和维修权限ID的Map映射
		Map<String, Integer> typeMap = types.stream().collect(Collectors.toMap(t -> t.getType(), t -> t.getRoleId()));

		List<WorkSheet> sheets = findAllSheets(user, types, trainParam);// 根据用户权限获取工单列表

		List<WorkSheetRecord> records = new ArrayList<>();
		// 判断每个工单可操作范围
		sheets.stream().forEach(sheet -> {
			WorkSheetRecord record = new WorkSheetRecord();
			record.setSheet(sheet);
			boolean option = false;
			if (typeMap.containsKey(sheet.getState())) {
				if (sheet.getState().equals(RepairOption.Resolve.getDesc())) {
					// 工单处于问题解决状态，需要判断用户所处的部门是否有权限，以及所处部门是否已有员工提交解决
					Long deptId = user.getDeptId();
					Object result = redisUtil.hmget(sheet.getId() + "-department", String.valueOf(deptId));
					option = "true".equals(result);
				} else if (sheet.getState().equals(RepairOption.Create.getDesc())) {
					if (sheet.getUserId() == null || user.getUserId().equals(sheet.getUserId())) {
						option = true;
					} else {
						return;
					}
				} else {
					option = true;
				}
			}
			if (sheet.getUserId() != null) {
				User creator = rbacGW.findUserById(sheet.getUserId());
				sheet.setUser(creator.getUserName());
			}
			if (sheet.getProjectId() != null) {
				Project project = trainGW.selectProjectById(sheet.getProjectId());
				sheet.setProject(project.getName());
			}
			record.setOption(option);
			records.add(record);
		});
		return records;
	}

	/**
	 * 根据用户权限获取用户可查看的工单列表
	 * 
	 * @param user
	 * @param stepTypes
	 * @return
	 */
	private List<WorkSheet> findAllSheets(User user, List<StepType> stepTypes, TrainParamHeader trainParam) {
		List<WorkSheet> sheets;
		if (isOnlyAfterSales(stepTypes)) {
			sheets = new ArrayList<>();
			// 根据用户ID查询的WorkSheet
			List<WorkSheet> sheetsUser = new ArrayList<>();
			List<Train> trainList = trainGW.findTrainByUserId(user.getUserId());
			for (Train train : trainList) {
				sheetsUser.addAll(findWorkSheetByTrain(train));
			}
			// 根据查询条件查询的WorkSheet
			List<WorkSheet> sheetsQueryList = findWorkSheetByTrainParam(trainParam);
			for (WorkSheet workSheetQuery : sheetsQueryList) {
				for (WorkSheet workSheetUser : sheetsUser) {
					if (workSheetQuery.getId().equals(workSheetUser.getId())) {
						sheets.add(workSheetQuery);
					}
				}
			}
		} else {
			sheets = findWorkSheetByTrainParam(trainParam);
		}
		Collections.sort(sheets, (s1, s2) -> {
			Date time1 = s1.getFaultTime();
			Date time2 = s2.getFaultTime();
			if (time1 == null || time2 == null) {
				return -1;
			}
			return time2.compareTo(time1);
		});
		return sheets;
	}

	/**
	 * @param trainParam
	 * @return
	 */
	private List<WorkSheet> findWorkSheetByTrainParam(TrainParamHeader trainParam) {
		List<WorkSheet> sheets;
		Example example = new Example(WorkSheet.class);
		Criteria criteria = example.createCriteria();
		Project project = trainGW.selectProjectByName(trainParam.getProject());
		criteria.andEqualTo("projectId", project.getId());
		if (StringUtil.isNotEmpty(trainParam.getTrainNo())) {
			criteria.andEqualTo("trainId", trainParam.getTrainNo());
		}
		sheets = sheetService.selectByExample(example);
		return sheets;
	}

	private List<WorkSheet> findWorkSheetByTrain(Train train) {
		List<WorkSheet> sheets;
		Example example = new Example(WorkSheet.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("projectId", train.getProjectId());
		if (StringUtil.isNotEmpty(train.getTrainNo())) {
			criteria.andEqualTo("trainId", train.getTrainNo());
		}
		sheets = sheetService.selectByExample(example);
		return sheets;
	}

	/**
	 * @param types
	 * @return
	 */
	private boolean isOnlyAfterSales(List<StepType> types) {
		if (types.size() == 1) {
			StepType stepType = types.get(0);
			if (stepType.getType().equals(RepairOption.Create.getDesc())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 过滤出和工单步骤相关的权限
	 * 
	 * @param groundRoleIds
	 * @param stepTypes
	 * @return
	 */
	private List<StepType> filter(List<Integer> roles, List<StepType> stepTypes) {
		List<StepType> types = new ArrayList<>();
		for (StepType type : stepTypes) {
			if (roles.contains(type.getRoleId())) {
				types.add(type);
			}
		}
		return types;
	}

	/**
	 * 获取工单，工单详情以及工单步骤
	 * 
	 * @see com.hirain.phm.bd.ground.maintenance.service.FlowReadService#getWorksheet(java.lang.Long)
	 */
	@Override
	public WorksheetPacket getWorksheet(Long sheetId) {
		WorkSheet sheet = sheetService.selectByKey(sheetId);
		WorkDetail detail = findDetail(sheet.getDetailId());
		Project project = trainGW.selectProjectById(sheet.getProjectId());
		sheet.setProject(project.getName());
		User auditor = rbacGW.findUserById(sheet.getUserId());
		sheet.setUser(auditor.getUserName());
		detail.setProject(project.getName());
		List<WorkStep> steps = findAllSteps(sheetId);
		WorksheetPacket packet = new WorksheetPacket();
		packet.setSheet(sheet);
		packet.setDetail(detail);
		packet.setSteps(steps);
		if (sheet.getFaultCode() != null) {
			packet.setSuggestion(findSuggestion(sheet.getFaultType(), sheet.getFaultCode()));
		}
		User user = (User) SecurityUtils.getSubject().getPrincipal();
		packet.setOption(getRepairOption(sheet, user));
		return packet;
	}

	private WorkDetail findDetail(Long detailId) {
		return detailService.selectByKey(detailId);
	}

	private List<WorkStep> findAllSteps(Long sheetId) {
		List<WorkStep> steps = stepService.findAllSteps(sheetId);
		steps.forEach(step -> {
			Long auditorId = step.getAuditorId();
			if (auditorId != null) {
				User user = rbacGW.findUserByIdWithRole(auditorId);
				step.setAuditor(user.getName());
			}
		});
		return steps;
	}

	private Suggestion findSuggestion(int type, int code) {
		PushInfo pushInfo = suggestionService.findPushInfo(type, code);
		String treatment = suggestionService.findTreatmentSuggestion(pushInfo.getTreatmentId());
		String repair = suggestionService.findRepairSuggestion(pushInfo.getRepairId());
		Suggestion suggestion = new Suggestion();
		suggestion.setTreatment(treatment);
		suggestion.setRepair(repair);
		return suggestion;
	}

	/**
	 * 根据用户权限判断工单的可操作状态
	 * 
	 * @param sheet
	 * @param user
	 * @return
	 */
	private RepairOption getRepairOption(WorkSheet sheet, User user) {
		StepType type = typeService.selectByKey(sheet.getState());
		List<Integer> roles = rbacGW.getRepairRolesByUserId(user.getUserId());
		boolean contains = roles.contains(type.getRoleId());
		if (contains) {
			if (type.getType().equals(RepairOption.Resolve.getDesc())) {
				Object result = redisUtil.hmget(sheet.getId() + "-department", String.valueOf(user.getDeptId()));
				return "true".equals(result) ? RepairOption.Resolve : RepairOption.None;
			} else {
				return Arrays.asList(RepairOption.values()).stream().filter(t -> t.getDesc().equals(type.getType())).findFirst().get();
			}
		}
		return RepairOption.None;
	}

	/**
	 * @see com.hirain.phm.bd.ground.maintenance.service.FlowReadService#findLastSameStep(java.lang.Long, java.lang.String)
	 */
	@Override
	public WorkStep findLastSameStep(Long sheetId, String state) {
		WorkStep step = stepService.findLastSameType(sheetId, state);
		ObjectMapper mapper = new ObjectMapper();
		try {
			// 由于前端接收的content字符串中包含转义符号，故JSON ----> JsonNode
			if (step != null) {
				JsonNode rootNode = mapper.readTree(step.getContent());
				step.setData(rootNode);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return step;
	}

	@Override
	public SheetCountResponse countSheets() {
		Date time = new Date();
		int countNew = redisMapper.countNewSheet(time);
		int countHandled = redisMapper.countHandledSheet(time);
		int countUnHandled = redisMapper.countUnHandled();
		SheetCountResponse response = new SheetCountResponse();
		response.setNewSheets(countNew);
		response.setHandled(countHandled);
		response.setUnHandled(countNew - countHandled);
		response.setUnHandledBeforeMonth(countUnHandled);
		return response;
	}
}
