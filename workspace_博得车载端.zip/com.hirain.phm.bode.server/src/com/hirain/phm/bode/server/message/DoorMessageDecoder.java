package com.hirain.phm.bode.server.message;

import java.nio.ByteBuffer;
import java.util.Calendar;
import java.util.Date;

public class DoorMessageDecoder {

	public DoorMessage decode(byte[] data) {
		final DoorMessage message = new DoorMessage();
		final int[] info = getDoor(data);
		message.setCarriageId(info[0]);
		message.setDoorId(info[1]);
		message.setTimestamp(getTime(data));
		message.setDatas(data);
		return message;
	}

	private Date getTime(byte[] bs) {
		final ByteBuffer buffer = ByteBuffer.wrap(bs);
		final int day = buffer.get(21);
		final int hour = buffer.get(22);
		final int minute = buffer.get(23);
		final int second = buffer.get(25);
		final int milli = Short.toUnsignedInt(buffer.getShort(26));
		final Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);
		calendar.set(Calendar.SECOND, second);
		calendar.set(Calendar.MILLISECOND, milli);
		if (adjustDay(calendar, day) == false) {
			calendar.set(Calendar.DAY_OF_MONTH, day);
			System.err.println("packet date not match: " + calendar.getTime());
		}
		return calendar.getTime();
	}

	private boolean adjustDay(Calendar calendar, int day) {
		if (calendar.get(Calendar.DAY_OF_MONTH) == day) {
			return true;
		} else {
			calendar.add(Calendar.DAY_OF_MONTH, -1);
			if (calendar.get(Calendar.DAY_OF_MONTH) == day) {
				return true;
			} else {
				calendar.add(Calendar.DAY_OF_MONTH, 2);
				if (calendar.get(Calendar.DAY_OF_MONTH) == day) {
					return true;
				} else {
					calendar.add(Calendar.DAY_OF_MONTH, -1);
					return false;
				}
			}
		}
	}

	public int[] getDoor(byte[] bs) {
		final byte b = bs[12];
		final int carriageId = (b & 0xf0) >> 4;
		final int doorId = b & 0x0f;
		return new int[] { carriageId, doorId };
	}
}
