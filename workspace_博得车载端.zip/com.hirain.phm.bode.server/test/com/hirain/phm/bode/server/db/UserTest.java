package com.hirain.phm.bode.server.db;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.hirain.phm.bode.server.rbac.dao.UserMapper;
import com.hirain.phm.bode.server.rbac.impl.UserImpl;

public class UserTest extends DBTestCase {

	@Test
	public void testSelect() {
		UserMapper mapper = session.getMapper(UserMapper.class);
		UserImpl user = mapper.get("admin");
		assertEquals("admin", user.getUsername());
		assertEquals("admin", user.getPassword());
	}
}
