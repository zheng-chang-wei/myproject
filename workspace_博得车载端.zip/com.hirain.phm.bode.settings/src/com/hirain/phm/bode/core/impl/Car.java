/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.impl;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.IMdcu;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 4:30:19 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
@XmlRootElement(name = "Car")
@XmlType(propOrder = { "index", "type", "name", "mdcus", "doors" })
@XmlAccessorType(XmlAccessType.FIELD)
public class Car implements ICar {

	@XmlAttribute(name = "index", required = true)
	private int index;

	@XmlAttribute(name = "type", required = true)
	private byte type;

	@XmlAttribute(name = "name", required = true)
	private String name;

	@XmlElement(name = "mdcu", required = true, type = Mdcu.class)
	private List<IMdcu> mdcus;

	@XmlElementWrapper(name = "doors")
	@XmlElement(name = "door", required = true, type = Door.class)
	private List<IDoor> doors;

	@Override
	public void setIndex(int index) {
		this.index = index;
	}

	@Override
	public int getIndex() {
		return index;
	}

	@Override
	public void setType(byte type) {
		this.type = type;
	}

	@Override
	public byte getType() {
		return type;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public List<IDoor> getDoors() {
		if (doors == null) {
			doors = new ArrayList<IDoor>();
		}
		return this.doors;
	}

	@Override
	public List<IMdcu> getMdcus() {
		if (mdcus == null) {
			mdcus = new ArrayList<IMdcu>();
		}
		return this.mdcus;
	}

	public void setMdcus(List<IMdcu> mdcus) {
		this.mdcus = mdcus;
	}

	public void setDoors(List<IDoor> doors) {
		this.doors = doors;
	}

}
