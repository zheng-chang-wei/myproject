/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.codec;

import java.nio.ByteBuffer;

import com.hirain.phm.bode.client.communication.listener.DoorInfoMessageListenerManager;
import com.hirain.phm.bode.client.communication.message.AbstractMessage;
import com.hirain.phm.bode.client.communication.message.DataResultMessage;
import com.hirain.phm.bode.client.communication.message.DebugMessage;
import com.hirain.phm.bode.client.communication.message.DoorInfoMessage;
import com.hirain.phm.bode.client.communication.message.DownloadMessage;
import com.hirain.phm.bode.client.communication.message.FaultResultMessage;
import com.hirain.phm.bode.client.communication.message.HeartMessage;
import com.hirain.phm.bode.client.communication.message.LogResultMessage;
import com.hirain.phm.bode.client.communication.message.LoginMessage;
import com.hirain.phm.bode.client.communication.message.SpaceMessage;
import com.hirain.phm.bode.client.communication.message.SystemInfoConfigMessage;
import com.hirain.phm.bode.client.communication.message.SystemInfoMessage;
import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.client.communication.transport.IDecoder;
import com.hirain.phm.bode.client.communication.transport.ITransportPacket;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 16, 2019 9:31:55 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 16, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DefaultCommandDecoder implements IDecoder {

	/**
	 * @see com.hirain.phm.bode.client.communication.transport.IDecoder#decode(com.hirain.phm.bode.client.communication.transport.ITransportPacket)
	 */
	@Override
	public AbstractMessage decode(ITransportPacket packet) {
		return decodePacket(packet);
	}

	/**
	 * @param packet
	 * @return
	 */
	private AbstractMessage decodePacket(final ITransportPacket packet) {
		final int pid = packet.getPid();
		switch (pid) {
		case ServiceConstant.PID_HEART_INQUIRY_ACK:// 心跳回复
			return decodeHeart(packet);
		case ServiceConstant.PID_LOGIN_ACK:// 登录回复
			return decodeLogin(packet);
		case ServiceConstant.PID_SYSTEMINFO_INQUIRY_ACK:// 系统信息查询回复
			return decodeSystemInfo(packet);
		case ServiceConstant.PID_SYSTEMINFO_CONFIG_ACK:// 系统信息配置回复
			return decodeSystemInfoConfig(packet);
		case ServiceConstant.PID_SPACE_INQUIRY_ACK:// 存储空间查询回复
			return decodeSpace(packet);
		case ServiceConstant.PID_DOORINFO_INQUIRY_ACK:// 门信息查询回复
			return decodeDoorInfo(packet);
		case ServiceConstant.PID_DOWNLOAD_ACK:// 下载操作指令回复
			return decodeDownload(packet);
		case ServiceConstant.PID_DEBUGMODE_ACK:// 调试指令回复
			return decodeDebug(packet);
		case ServiceConstant.PID_LOGOUT_ACK:// 登出回复
			return decodeLogout(packet);
		case ServiceConstant.PID_DATA_QUERY_ACK:// 数据查询指令回复
			return decodeSelectResult(packet, ServiceConstant.PID_DATA_QUERY_ACK);
		case ServiceConstant.PID_DATA_COUNT_ACK:// 数据count查询指令回复
			return decodeSelectResult(packet, ServiceConstant.PID_DATA_COUNT_ACK);
		case ServiceConstant.PID_DATA_DOWNLOAD_ACK:// 数据下载查询指令回复
			return decodeSelectResult(packet, ServiceConstant.PID_DATA_DOWNLOAD_ACK);
		default:
			break;
		}
		return null;
	}

	/**
	 * 解码 门信息查询指令的回复
	 * 
	 * @param packet
	 * @return
	 */
	private DoorInfoMessage decodeDoorInfo(final ITransportPacket packet) {
		DoorInfoMessage message = new DoorInfoMessage();
		transformBasic(packet, message);
		message.setData(packet.getData());

		DoorInfoMessageListenerManager.getInstance().post(message);
		return message;
	}

	/**
	 * 解码 系统信息配置回复的内容
	 * 
	 * @param packet
	 * @return
	 */
	private SystemInfoConfigMessage decodeSystemInfoConfig(final ITransportPacket packet) {
		SystemInfoConfigMessage message = new SystemInfoConfigMessage();
		transformBasic(packet, message);
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		message.setErrorCode(buffer.get());
		if (message.getErrorCode() != 0) {
			String errorMsg = "系统信息配置失败！";
			message.setError(errorMsg);
		}
		return message;
	}

	/**
	 * 解码调试模式指令的回复
	 * 
	 * @param packet
	 * @return
	 */
	private DebugMessage decodeDebug(final ITransportPacket packet) {
		DebugMessage message = new DebugMessage();
		transformBasic(packet, message);
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		message.setErrorCode(buffer.get());
		if (message.getErrorCode() != 0) {
			String errorMsg = "调试模式响应失败！";
			message.setError(errorMsg);
		}
		return message;
	}

	/**
	 * 解码 下载指令的回复
	 * 
	 * @param packet
	 * @return
	 */
	private DownloadMessage decodeDownload(final ITransportPacket packet) {
		DownloadMessage message = new DownloadMessage();
		transformBasic(packet, message);
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		message.setErrorCode(buffer.get());
		if (message.getErrorCode() != 0) {
			String errorMsg = "下载操作指令响应失败！";
			message.setError(errorMsg);
		}
		return message;
	}

	/**
	 * @param packet
	 * @return
	 */
	private HeartMessage decodeHeart(final ITransportPacket packet) {
		final HeartMessage message = new HeartMessage();
		transformBasic(packet, message);
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		message.setErrorCode(buffer.get());
		if (message.getErrorCode() != 0) {
			String errorMsg = "通信异常，请检查通信配置";
			message.setError(errorMsg);
		}
		return message;
	}

	private LoginMessage decodeLogin(final ITransportPacket packet) {
		LoginMessage message = new LoginMessage();
		transformBasic(packet, message);
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		message.setErrorCode(buffer.get());
		if (message.getErrorCode() != 0) {
			String errorMsg = "用户名或密码不正确，登录失败！";
			message.setError(errorMsg);
		}
		return message;
	}

	private LoginMessage decodeLogout(final ITransportPacket packet) {
		LoginMessage message = new LoginMessage();
		transformBasic(packet, message);
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		message.setErrorCode(buffer.get());
		if (message.getErrorCode() != 0) {
			String errorMsg = "登出指令失败！";
			message.setError(errorMsg);
		}
		return message;
	}

	private SystemInfoMessage decodeSystemInfo(final ITransportPacket packet) {
		SystemInfoMessage message = new SystemInfoMessage();
		transformBasic(packet, message);
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		message.setErrorCode(buffer.get());
		if (message.getErrorCode() != 0) {
			String errorMsg = "服务端系统配置信息不完整！";
			message.setError(errorMsg);
		}
		byte[] data = new byte[packet.getLength() - 4];
		buffer.get(data);
		message.setData(data);
		return message;
	}

	private SpaceMessage decodeSpace(final ITransportPacket packet) {
		SpaceMessage message = new SpaceMessage();
		transformBasic(packet, message);
		final ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
		message.setErrorCode(buffer.get());
		if (message.getErrorCode() != 0) {
			String errorMsg = "查询工作空间失败";
			message.setError(errorMsg);
		}
		byte[] data = new byte[packet.getLength() - 4];
		buffer.get(data);
		final ByteBuffer spaceBuffer = ByteBuffer.wrap(data);
		message.setTotalSpace(spaceBuffer.getLong());
		message.setUsedSpace(spaceBuffer.getLong());
		return message;
	}

	/**
	 * @param packet
	 * @param message
	 */
	private void transformBasic(final ITransportPacket packet, final AbstractMessage message) {
		message.setPid(packet.getPid());
		message.setLength(packet.getLength());
	}

	private AbstractMessage decodeSelectResult(ITransportPacket packet, byte pid) {
		byte[] data = packet.getData();
		ByteBuffer buffer = ByteBuffer.wrap(data);
		// 查询结果类型
		byte type = buffer.get();
		// 报文记录回复
		if (pid == ServiceConstant.PID_DATA_QUERY_ACK) {
			if (type == ServiceConstant.COMMON_TAG) {
				DataResultMessage dataResultMessage = new DataResultMessage();
				dataResultMessage.setData(data);
				dataResultMessage.setSid(type);
				dataResultMessage.setPid(pid);
				return dataResultMessage;
			} else if (type == ServiceConstant.FAULT_RECORD_SID || type == ServiceConstant.FAULT_SID) {
				FaultResultMessage message = new FaultResultMessage();
				message.setData(data);
				message.setPid(pid);
				message.setSid(type);
				return message;
			} else if (type == ServiceConstant.LOG_SID) {
				LogResultMessage message = new LogResultMessage();
				message.setData(data);
				message.setPid(pid);
				message.setSid(type);
				return message;
			}
		} else if (pid == ServiceConstant.PID_DATA_COUNT_ACK) {
			if (type == ServiceConstant.MESSAGE_COUNT_SID) {
				DataResultMessage dataResultMessage = new DataResultMessage();
				dataResultMessage.setData(data);
				dataResultMessage.setSid(type);
				dataResultMessage.setPid(pid);
				return dataResultMessage;
			} else if (type == ServiceConstant.FAULT_RECORD_COUNT_SID) {
				FaultResultMessage message = new FaultResultMessage();
				message.setData(data);
				message.setPid(pid);
				message.setSid(type);
				return message;
			} else if (type == ServiceConstant.LOG_SID) {
				LogResultMessage message = new LogResultMessage();
				message.setData(data);
				message.setPid(pid);
				message.setSid(type);
				return message;
			}
		} else if (pid == ServiceConstant.PID_DATA_DOWNLOAD_ACK) {
			if (type == ServiceConstant.MESSAGE_DOWNLOAD_SID || type == ServiceConstant.MESSAGE_DOWNLOAD_COMPLETE_SID) {
				DataResultMessage dataResultMessage = new DataResultMessage();
				dataResultMessage.setData(data);
				dataResultMessage.setSid(type);
				dataResultMessage.setPid(pid);
				return dataResultMessage;
			} else if (type == ServiceConstant.FAULT_RECORD_DOWNLOAD_SID || type == ServiceConstant.FAULT_DOWNLOAD_COMPLETE_SID) {
				FaultResultMessage message = new FaultResultMessage();
				message.setData(data);
				message.setPid(pid);
				message.setSid(type);
				return message;
			} else if (type == ServiceConstant.LOG_SID || type == ServiceConstant.LOG_DOWNLOAD_COMPLETE_SID) {
				LogResultMessage message = new LogResultMessage();
				message.setData(data);
				message.setPid(pid);
				message.setSid(type);
				return message;
			}
		}
		return null;
	}

}
