package com.hirain.phm.bd.ground.authority.service;

import com.hirain.phm.bd.ground.authority.domain.RepairRole;
import com.hirain.phm.bd.ground.common.service.IService;

public interface ApprovalRoleService extends IService<RepairRole> {
}
