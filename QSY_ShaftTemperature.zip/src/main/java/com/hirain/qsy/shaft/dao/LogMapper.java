package com.hirain.qsy.shaft.dao;

import com.hirain.qsy.shaft.common.config.MyMapper;
import com.hirain.qsy.shaft.model.SysLog;

public interface LogMapper extends MyMapper<SysLog> {
}