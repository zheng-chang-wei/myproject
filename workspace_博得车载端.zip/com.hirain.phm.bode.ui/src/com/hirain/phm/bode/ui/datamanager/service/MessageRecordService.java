package com.hirain.phm.bode.ui.datamanager.service;

import com.hirain.phm.bode.core.message.MessageQuery;

public interface MessageRecordService {

	void selectByPage(MessageQuery messageQuery, int pageNum, int pageSize);

	void getSelectPageNum(MessageQuery messageQuery);

}
