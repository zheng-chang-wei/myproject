<template>
  <div id="annual-fault">
    <el-row class="fault-panel home-card">
      <!-- <div class="card-border card-border-top-left"></div>
      <div class="card-border card-border-top-right"></div>
      <div class="card-border card-border-bottom-left"></div>
      <div class="card-border card-border-bottom-right"></div> -->
      <el-col :span="24">
        <div class="card-panel">
          <div class="card-title" :style="titleStyle">{{title}}数量趋势</div>
          <ve-line :data="annualFault" :height="chartHeight" :settings="settings" :extend="extend" :grid="grid" :colors="colors"></ve-line>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
  import VeLine from 'v-charts/lib/line.common'
  export default {
    components: {
      VeLine
    },
    props: {
      annualFault: Object,
      chartHeight: String,
      title: String,
      titleStyle: String,
    },
    data() {
      this.colors = [
        '#FF9AB2',
        '#87F9D0'
      ]
      this.settings = {
        labelMap: {
          month: '月份',
          thisYear: '今年',
          lastYear: '去年'
        }
      },
      xAxis: {
        type: 'category',
        axisLine: {
          show: 'true',
          lineStyle: {
            color: 'white'
          }
        },
        boundaryGap: false,
        axisLabel: {
          formatter: function(value, idx) {
            return value + '月'
          }
        }
      },
      yAxis: {
        type: 'value',
        axisLine: {
          // show: 'true',
          lineStyle: {
            color: 'white'
          }
        },
        series: {
          smooth: false,
          // symbol: 'none',
        },
      };
      this.grid = {
        top: '40px',
        bottom: '20px',
        right: '20px'
      }
    }
    this.grid = {
      top: '30px',
      bottom: '10px',
      right: '20px'
    }
    return {}
  }
}

</script>
<style scoped>
  #annual-fault {
    margin: 2px;
    background-color: #0f1741;
    height: 100%;
  }

  .fault-panel {
    height: 100%;
  }

  .fault-panel .card-panel {
    height: 100%;
    position: relative;
    overflow: hidden;
  }

  .fault-panel .card-title {
    color: #fff;
    text-align: center;
    /* background-color: #00CCCC; */
    font-weight: bold;
  }

</style>
