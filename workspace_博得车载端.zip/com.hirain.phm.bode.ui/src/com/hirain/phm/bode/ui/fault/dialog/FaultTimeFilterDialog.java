/*******************************************************************************
 * Copyright (c) 2017, 2017 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.fault.dialog;

import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月11日 下午1:43:56
 * @Description
 *              <p>
 *              故障日期选择
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月11日 changwei.zheng@hirain.com 1.0 create file
 */
public class FaultTimeFilterDialog extends TitleAreaDialog {

	private DateTime dateTimeStart;

	private DateTime dateTimeEnd;

	private Date dateStart;

	private Date dateEnd;

	public FaultTimeFilterDialog(final Shell parentShell) {
		super(parentShell);
	}

	@Override
	protected Control createDialogArea(final Composite parent) {
		final Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout(3, false));
		composite.setLayoutData(new GridData(GridData.FILL_BOTH));
		dateTimeStart = new DateTime(composite, SWT.TIME);
		dateTimeStart.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true));

		Label label = new Label(composite, SWT.None);
		label.setText("到");
		label.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, true));

		dateTimeEnd = new DateTime(composite, SWT.TIME);
		dateTimeEnd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true));
		getShell().setText("故障时间选择");
		setTitle("故障时间选择");
		initListener();
		return composite;
	}

	private void initListener() {
		dateTimeStart.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			getDate();
		}));
		dateTimeEnd.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			getDate();
		}));

	}

	private void getDate() {
		int hourStart = dateTimeStart.getHours();
		int minuteStart = dateTimeStart.getMinutes();
		int secondStart = dateTimeStart.getSeconds();

		int hourEnd = dateTimeEnd.getHours();
		int minuteEnd = dateTimeEnd.getMinutes();
		int secondEnd = dateTimeEnd.getSeconds();
		dateStart = DateManager.getDateStart();
		if (!dateStart.isDateEmpty()) {
			dateStart.setTime(hourStart, minuteStart, secondStart);

			dateEnd = DateManager.getDateEnd();
			dateEnd.setTime(hourEnd, minuteEnd, secondEnd);
			setMessage(dateStart + " 到 " + dateEnd);
		} else {
			setErrorMessage("请先选择日期");
		}
	}

	@Override
	protected Point getInitialSize() {
		return new Point(250, 200);
	}

	/**
	 * @see org.eclipse.jface.dialogs.Dialog#createButtonsForButtonBar(org.eclipse.swt.widgets.Composite)
	 */
	@Override
	protected void createButtonsForButtonBar(final Composite parent) {
		super.createButtonsForButtonBar(parent);
	}

	@Override
	protected void okPressed() {
		super.okPressed();
	}

	public Date getDateStart() {
		return dateStart;
	}

	public Date getDateEnd() {
		return dateEnd;
	}

}
