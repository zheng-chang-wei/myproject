/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.monitor;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.InstanceScope;
import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.FigureCanvas;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.nebula.visualization.xygraph.util.XYGraphMediaFactory;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseTrackListener;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.osgi.service.prefs.BackingStoreException;

import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.IMdcu;
import com.hirain.phm.bode.core.dataframe.DataFrameD1;
import com.hirain.phm.bode.core.dataframe.DataFrameD2;
import com.hirain.phm.bode.core.dataframe.DataFrameD3;
import com.hirain.phm.bode.core.dataframe.DataFrameD4;
import com.hirain.phm.bode.core.dataframe.DoorStatus;
import com.hirain.phm.bode.core.dataframe.IDataFrame;
import com.hirain.phm.bode.core.dataframe.RunDataFrame;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.monitor.dialog.FaultListDialog;
import com.hirain.phm.bode.ui.monitor.figure.door.DoorAnimationFigure;
import com.hirain.phm.bode.ui.monitor.figure.door.DoorContent;
import com.hirain.phm.bode.ui.monitor.model.AnimationCache;
import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;
import com.hirain.phm.bode.ui.monitor.model.Position;
import com.hirain.phm.bode.ui.monitor.model.Signal;
import com.hirain.phm.bode.ui.monitor.model.SignalState;
import com.hirain.phm.bode.ui.monitor.model.XYGraphViewer;
import com.hirain.phm.bode.ui.monitor.provider.DoorStateTableViewerLabelProvider;
import com.hirain.phm.bode.ui.monitor.provider.TableViewerContentProvider;
import com.hirain.phm.bode.ui.monitor.provider.TableViewerLabelProvider;
import com.hirain.phm.bode.ui.monitor.utils.Util;
import com.hirain.phm.bode.ui.monitor.utils.ViewUtil;
import com.hirain.phm.bode.ui.util.PlotUtil;
import com.hirain.phm.bode.ui.util.UIConstants;
import com.hirain.phm.bode.ui.widget.CommonPart;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 7, 2019 10:49:36 AM
 * @Description
 *              <p>
 *              实时（在线）监控页面
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 7, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class OnlineMonitorPart extends CommonPart {

	private static OnlineMonitorPart onlineMonitorPart;

	private Label labCarNum;

	private Label labDoorNum;

	private Label labDoorAddress;

	private Label labMDCU;

	private Composite switchComposite;

	private StackLayout stackLayout;

	private DoorAnimationFigure panel;

	private Label labDoorState;

	private Label labOpenTime;

	private Label labCurrent;

	private final List<XYGraphViewer> graphViewerList = new ArrayList<>();

	private final List<CheckboxTableViewer> checkboxTableViewerList = new ArrayList<>();

	private final List<Composite> signalTableComposites = new ArrayList<>();

	private final List<CLabel> signaleTitleLabels = new ArrayList<>();

	private String configFilePath = System.getProperty("user.dir") + "\\signal.ini";

	/**
	 * 车辆信号名称
	 */
	private String[] carSignal;

	/**
	 * 输入信号名称
	 */
	private String[] inputSignal;

	/**
	 * 输出信号名称
	 */
	private String[] outputSignal;

	/**
	 * 电机与指令信号名称
	 */
	private String[] electromechanicalSignal;

	private Map<String, List<Position>> dataCacheMap = new LinkedHashMap<>();

	private Map<Integer, Timer> timerMap = new HashMap<>();

	private List<XYGraphViewer> checkedXYGraphViewers = new ArrayList<>();

	private List<Object> dataFrameList = new ArrayList<>();

	private List<String> faultList = new ArrayList<>();

	private List<TableViewer> tableViewers = new ArrayList<>();

	private CLabel labFault;

	private List<String> inputAndOutputSignals;

	private Label labOpenTimeTitle;

	private boolean[] faultValues = { false, false, false, false, false, false, false, false };

	private Map<String, boolean[]> faultValuesMap = new HashMap<>();

	private List<TableItem> tableItems = new ArrayList<>();

	private List<Button> btnSelectAllList = new ArrayList<>();

	private LinkedList<AnimationCache> animationCacheList = new LinkedList<>();

	private ScheduledExecutorService animationExecutor = Executors
			.newSingleThreadScheduledExecutor(r -> new Thread(r, OnlineMonitorPart.class.getName() + "-animation"));

	private long lastTime = 0;

	/**
	 * 刷新频率
	 */
	private int refreshFrequency = 50;

	private List<String[]> signalList;

	private List<String[]> signalAttrList;

	private OnlineMonitorPart() {
	}

	public static OnlineMonitorPart getInstance() {
		if (onlineMonitorPart == null) {
			onlineMonitorPart = new OnlineMonitorPart();
		}
		return onlineMonitorPart;
	}

	@Override
	public void postConstruct(final Composite parent) {
		setCurrentDoorAddr();
		super.postConstruct(parent);
		scrolledComposite.setMinSize(1000, 1700);
		createDoorStateArea(coreComposite);
		createPlotArea(coreComposite);

		initDoorAnimation();
	}

	private void initDoorAnimation() {
		animationExecutor.scheduleAtFixedRate(() -> {
			if (animationCacheList.isEmpty()) {
				return;
			}
			AnimationCache first = animationCacheList.peek();
			if (first == null) {
				return;
			}
			if (lastTime == 0) {
				Display.getDefault().asyncExec(() -> {
					updateDoorAnimation(first);
					refreshDoorCloseStateInfo(first.getDataFrameList());
				});
				lastTime = first.getTime();
				animationCacheList.remove();
			} else {
				long devation = first.getTime() - lastTime;
				if (devation <= 50) {
					Display.getDefault().asyncExec(() -> {
						updateDoorAnimation(first);
						refreshDoorCloseStateInfo(first.getDataFrameList());
					});
					lastTime = first.getTime();
					animationCacheList.remove();
				} else {
					lastTime += 50;
				}
				// System.out.println(devation);
			}
		}, 0, 50, TimeUnit.MILLISECONDS);
	}

	/**
	 * 启动时设值接收哪个门的数据
	 */
	private void setCurrentDoorAddr() {
		ICar car = TrainManager.getInstance().getCurrentCar();
		int doorIndex = TrainManager.getInstance().getDoorIndex();
		int addr = Util.getDoorAddrByIndex(car, doorIndex);
		if (addr != -1) {
			CommunicationService.getInstance().notifyDoorAddr(car.getIndex(), addr);
		}
	}

	@Override
	protected void createWarningArea(Composite titleComposite) {
		labFault = new CLabel(titleComposite, SWT.NONE);
		GridData layoutData = new GridData(SWT.CENTER, SWT.CENTER, true, false);
		layoutData.verticalSpan = 10;
		labFault.setLayoutData(layoutData);
		labFault.setBackground(ColorConstants.red);
		labFault.setForeground(ColorConstants.white);
		labFault.setFont(CarriageConstants.title_font);
		labFault.setVisible(false);
		labFault.addMouseListener(new MouseListener() {

			@Override
			public void mouseUp(MouseEvent e) {

			}

			@Override
			public void mouseDown(MouseEvent e) {
				FaultListDialog dialog = new FaultListDialog(Display.getDefault().getActiveShell(), faultList);
				dialog.open();
			}

			@Override
			public void mouseDoubleClick(MouseEvent e) {

			}
		});
		labFault.addMouseTrackListener(MouseTrackListener.mouseExitAdapter(t -> {
			Display.getDefault().getActiveShell().setCursor(null);
		}));
		labFault.addMouseTrackListener(MouseTrackListener.mouseEnterAdapter(t -> {
			Display.getDefault().getActiveShell().setCursor(Display.getDefault().getSystemCursor(SWT.CURSOR_HAND));
		}));
	}

	@Override
	protected void createRefreshFrequencyArea(Composite parent) {
		Composite refreshFrequencyComposite = new Composite(parent, SWT.NONE);
		refreshFrequencyComposite.setLayout(new GridLayout(4, false));
		refreshFrequencyComposite.setLayoutData(new GridData(SWT.RIGHT, SWT.FILL, true, false));
		Label label = new Label(refreshFrequencyComposite, SWT.NONE);
		label.setText("刷新频率(ms):");
		label.setToolTipText("刷新频率范围为[50,2000]");
		Text text = new Text(refreshFrequencyComposite, SWT.BORDER);
		GridData layoutData = new GridData(SWT.FILL, SWT.CENTER, true, false);
		layoutData.widthHint = 50;
		text.setLayoutData(layoutData);
		text.setToolTipText("刷新频率范围为[50,2000]");
		// 从首选项中读取刷新频率
		IEclipsePreferences node = InstanceScope.INSTANCE.getNode(BodeUIPlugin.PLUGIN_ID);
		String string = node.get(UIConstants.PREFERENCE_REFRESHFREQUENCY, StringUtil.EMPTY);
		if (StringUtil.isEmpty(string)) {
			text.setText(String.valueOf(refreshFrequency));
		} else {
			text.setText(string);
		}
		text.addVerifyListener(Util.addrVerifyListener);
		text.setTextLimit(4);
		Button button = new Button(refreshFrequencyComposite, SWT.None);
		button.setText("确定");
		button.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			refreshFrequency = Integer.valueOf(text.getText());
			// 将刷新频率保存到首选项中
			node.put(UIConstants.PREFERENCE_REFRESHFREQUENCY, String.valueOf(refreshFrequency));
			try {
				node.flush();
			} catch (BackingStoreException e) {
				e.printStackTrace();
				BodeUIPlugin.log(e);
			}
			for (int index = 0; index < graphViewerList.size(); index++) {
				refreshFrequency(index);
			}
		}));
		text.addModifyListener(e -> {
			if (StringUtil.isEmpty(text.getText())) {
				button.setEnabled(false);
			} else {
				button.setEnabled(Integer.valueOf(text.getText()) >= 50 && Integer.valueOf(text.getText()) <= 2000);
			}
		});
	}

	private void refreshFrequency(int index) {
		Timer timerOld = timerMap.get(index);
		if (timerOld != null) {
			timerOld.cancel();
			updatePlot(index);
		}
	}

	private void createDoorStateArea(Composite parent) {
		Composite doorStateComposite = new Composite(parent, SWT.BORDER);
		doorStateComposite.setLayout(new GridLayout(2, false));
		GridData layoutData = new GridData(SWT.FILL, SWT.FILL, true, false);
		layoutData.heightHint = 340;
		doorStateComposite.setLayoutData(layoutData);
		linkToScroll(doorStateComposite);
		createLeftArea(doorStateComposite);

		createRightArea(doorStateComposite);

	}

	private void createLeftArea(Composite doorStateComposite) {
		Composite leftComposite = new Composite(doorStateComposite, SWT.NONE);
		leftComposite.setLayout(new GridLayout());
		leftComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, true));

		createBasicInfoGroup(leftComposite);

		createDoorCloseStateGroup(leftComposite);
	}

	/**
	 * 基本信息
	 * 
	 * @param leftComposite
	 */
	private void createBasicInfoGroup(Composite leftComposite) {
		ICar currentCar = TrainManager.getInstance().getCurrentCar();
		int doorIndex = TrainManager.getInstance().getDoorIndex();
		List<IMdcu> mdcus = currentCar.getMdcus();
		IDoor currentDoor = currentCar.getDoors().get(doorIndex);
		Group group = new Group(leftComposite, SWT.NONE);
		group.setBackground(ColorConstants.white);
		group.setText("基本信息");
		group.setLayout(new GridLayout(2, false));
		group.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		linkToScroll(group);

		Composite carComposite = new Composite(group, SWT.NONE);
		carComposite.setLayout(new GridLayout(4, false));
		carComposite.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 2, 1));
		carComposite.setBackground(ColorConstants.white);
		linkToScroll(carComposite);
		labCarNum = new Label(carComposite, SWT.NONE);

		labCarNum.setText(currentCar.getName());
		labCarNum.setFont(CarriageConstants.title_font);
		labCarNum.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, false, true));
		labCarNum.setBackground(ColorConstants.white);
		Label labCar = new Label(carComposite, SWT.NONE);
		labCar.setText("车厢");
		labCar.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, false, true));
		labCar.setBackground(ColorConstants.white);

		labDoorNum = new Label(carComposite, SWT.NONE);
		labDoorNum.setText(String.valueOf(TrainManager.getInstance().getDoorIndex() + 1));
		labDoorNum.setFont(CarriageConstants.title_font);
		labDoorNum.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, false, true));
		labDoorNum.setBackground(ColorConstants.white);
		Label labDoor = new Label(carComposite, SWT.NONE);
		labDoor.setText("号车门");
		labDoor.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, false, true));
		labDoor.setBackground(ColorConstants.white);

		Label labDoorAddressTitle = new Label(group, SWT.NONE);
		labDoorAddressTitle.setText(" 门地址:");
		labDoorAddressTitle.setBackground(ColorConstants.white);
		labDoorAddress = new Label(group, SWT.NONE);
		labDoorAddress.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		labDoorAddress.setText(String.valueOf(currentDoor.getAddr()));
		labDoorAddress.setBackground(ColorConstants.white);

		Label labMDCUTitle = new Label(group, SWT.NONE);
		labMDCUTitle.setText(" MDCU:");
		labMDCUTitle.setBackground(ColorConstants.white);
		labMDCU = new Label(group, SWT.NONE);
		labMDCU.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false));
		labMDCU.setText(mdcus.get(0).getIp() + "," + mdcus.get(1).getIp());
		labMDCU.setBackground(ColorConstants.white);
	}

	/**
	 * 开关门状态
	 * 
	 * @param leftComposite
	 */
	private void createDoorCloseStateGroup(Composite leftComposite) {
		Group group = new Group(leftComposite, SWT.NONE);
		group.setBackground(ColorConstants.white);
		group.setText("开关门状态");
		group.setLayout(new GridLayout(2, false));
		group.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		linkToScroll(group);
		Composite compositeDoorState = new Composite(group, SWT.NONE);
		compositeDoorState.setLayout(new GridLayout());
		compositeDoorState.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		compositeDoorState.setBackground(ColorConstants.white);
		linkToScroll(compositeDoorState);
		labDoorState = new Label(compositeDoorState, SWT.None);
		labDoorState.setFont(CarriageConstants.title_font);
		labDoorState.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, true));
		labDoorState.setBackground(ColorConstants.white);
		labDoorState.setText("                ");
		Composite compositeData = new Composite(group, SWT.NONE);
		compositeData.setLayout(new GridLayout(3, false));
		compositeData.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true));
		compositeData.setBackground(ColorConstants.white);
		linkToScroll(compositeData);
		labOpenTimeTitle = new Label(compositeData, SWT.NONE);
		labOpenTimeTitle.setText("开门时间：");
		labOpenTimeTitle.setBackground(ColorConstants.white);
		labOpenTime = new Label(compositeData, SWT.NONE);
		labOpenTime.setFont(CarriageConstants.title_font);
		labOpenTime.setBackground(ColorConstants.white);
		labOpenTime.setText("        ");
		Label labSecond = new Label(compositeData, SWT.NONE);
		labSecond.setText("秒");
		labSecond.setBackground(ColorConstants.white);

		Label labCurrentTitle = new Label(compositeData, SWT.NONE);
		labCurrentTitle.setText("电机电流：");
		labCurrentTitle.setBackground(ColorConstants.white);
		labCurrent = new Label(compositeData, SWT.NONE);
		labCurrent.setFont(CarriageConstants.title_font);
		labCurrent.setBackground(ColorConstants.white);
		labCurrent.setText("   ");
		Label labAmpere = new Label(compositeData, SWT.NONE);
		labAmpere.setText("安培");
		labAmpere.setBackground(ColorConstants.white);

	}

	private void createRightArea(Composite parent) {
		Composite rightComposite = new Composite(parent, SWT.NONE);
		rightComposite.setLayout(new GridLayout(2, false));
		rightComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		linkToScroll(rightComposite);
		createDoorAnimationArea(rightComposite);
		createDoorStartTableViewer(rightComposite);

	}

	/**
	 * 门动画
	 * 
	 * @param rightComposite
	 */

	private void createDoorAnimationArea(Composite rightComposite) {

		FigureCanvas topologicalCanvas = new FigureCanvas(rightComposite) {

			@Override
			public boolean setFocus() {
				return false;
			}
		};
		panel = new DoorAnimationFigure();
		topologicalCanvas.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, true));
		topologicalCanvas.setContents(panel);
		linkToScroll(topologicalCanvas);
	}

	/**
	 * 门信号状态
	 * 
	 * @param compositeRight
	 */
	private void createDoorStartTableViewer(Composite compositeRight) {
		Composite composite = new Composite(compositeRight, SWT.BORDER);
		composite.setLayout(new GridLayout(2, false));
		GridData gridData = new GridData(SWT.FILL, SWT.FILL, false, false);
		composite.setLayoutData(gridData);
		readIni();
		createTableArea(composite);
		creatTitleArea(composite);
		initSignal();
	}

	private void initSignal() {
		signalList = new ArrayList<>();
		signalList.add(carSignal);
		signalList.add(inputAndOutputSignals.toArray(new String[0]));
		signalList.add(electromechanicalSignal);
		signalAttrList = new ArrayList<>();
		signalAttrList.add(CarriageConstants.carSignalAttrs);
		signalAttrList.add(CarriageConstants.inputAndOutputSignaleAttrs);
		signalAttrList.add(CarriageConstants.electromechanicalSignalAttrs);
	}

	private void readIni() {
		final Properties properties = Util.getProperties(configFilePath);
		for (final Map.Entry<Object, Object> propertie : properties.entrySet()) {
			String key = (String) propertie.getKey();
			String value = (String) propertie.getValue();
			switch (key) {
			case "车厢信号":
				carSignal = value.split(StringUtil.COMMA);
				break;
			case "输入信号":
				inputSignal = value.split(StringUtil.COMMA);
				break;
			case "输出信号":
				outputSignal = value.split(StringUtil.COMMA);
				break;
			case "电机与指令信号":
				electromechanicalSignal = value.split(StringUtil.COMMA);
				break;
			default:
				break;
			}

		}
	}

	private void createTableArea(Composite parent) {
		switchComposite = new Composite(parent, SWT.None);
		stackLayout = new StackLayout();
		switchComposite.setLayout(stackLayout);
		switchComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, true));

		// 车辆
		Composite carSignalComposite = new Composite(switchComposite, SWT.NONE);
		carSignalComposite.setLayout(new GridLayout(1, false));
		createSignalTable(carSignalComposite, carSignal);
		// 输入
		Composite inputComposite = new Composite(switchComposite, SWT.NONE);
		inputComposite.setLayout(new GridLayout(1, false));
		inputAndOutputSignals = new ArrayList<>();
		inputAndOutputSignals.addAll(Util.string2List(inputSignal));
		inputAndOutputSignals.addAll(Util.string2List(outputSignal));
		createSignalTable(inputComposite, inputAndOutputSignals.toArray(new String[0]));
		// 电机指令
		Composite motorCommandComposite = new Composite(switchComposite, SWT.NONE);
		motorCommandComposite.setLayout(new GridLayout(1, false));
		createSignalTable(motorCommandComposite, electromechanicalSignal);
		// 门故障
		Composite doorFaultComposite = new Composite(switchComposite, SWT.NONE);
		doorFaultComposite.setLayout(new GridLayout(1, false));
		createSignalTable(doorFaultComposite, CarriageConstants.faultNames);
		signalTableComposites.add(carSignalComposite);
		signalTableComposites.add(inputComposite);
		signalTableComposites.add(motorCommandComposite);
		signalTableComposites.add(doorFaultComposite);
		stackLayout.topControl = carSignalComposite;
		carSignalComposite.layout();
		switchComposite.layout();
	}

	private void createSignalTable(Composite carComposite, String[] signalNames) {
		TableViewer tableViewerDevice = new TableViewer(carComposite, SWT.BORDER | SWT.FULL_SELECTION | SWT.MULTI | SWT.V_SCROLL);
		final Table table = tableViewerDevice.getTable();
		table.setLinesVisible(true);
		TableLayout layoutDevice = new TableLayout();
		table.setLayout(layoutDevice);
		GridData layoutData = new GridData(SWT.FILL, SWT.FILL, false, false);
		layoutData.heightHint = 275;
		layoutData.widthHint = 250;
		table.setLayoutData(layoutData);

		layoutDevice.addColumnData(new ColumnWeightData(3));
		new TableColumn(table, SWT.None);

		layoutDevice.addColumnData(new ColumnWeightData(2));
		new TableColumn(table, SWT.None);
		tableViewerDevice.setContentProvider(new TableViewerContentProvider());
		tableViewerDevice.setLabelProvider(new DoorStateTableViewerLabelProvider());
		List<Signal> list = new ArrayList<>();

		for (String name : signalNames) {
			Signal signal = new Signal();
			signal.setSignalName(name);
			list.add(signal);
		}
		tableViewerDevice.setInput(list);
		tableViewers.add(tableViewerDevice);
	}

	private void creatTitleArea(Composite parent) {
		Composite composite = new Composite(parent, SWT.None);
		composite.setLayout(new GridLayout());
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, true, 1, 2));

		composite.setBackground(ViewUtil.color);

		signaleTitleLabels.add(ViewUtil.createCLabel(composite, " 车 \r\n 辆"));
		signaleTitleLabels.add(ViewUtil.createCLabel(composite, " 输 \r\n 入\r\n 输\r\n 出"));
		signaleTitleLabels.add(ViewUtil.createCLabel(composite, " 电 \r\n 机\r\n 指\r\n 令"));
		signaleTitleLabels.add(ViewUtil.createCLabel(composite, " 车 \r\n 门\r\n 故\r\n 障"));
		for (int i = 0; i < signaleTitleLabels.size(); i++) {
			CLabel label = signaleTitleLabels.get(i);
			Composite cs = signalTableComposites.get(i);

			label.addMouseTrackListener(MouseTrackListener.mouseExitAdapter(t -> {
				label.setBackground(ViewUtil.color);
			}));
			label.addMouseTrackListener(MouseTrackListener.mouseEnterAdapter(t -> {
				label.setBackground(ColorConstants.white);
			}));
			label.addMouseListener(MouseListener.mouseDownAdapter(t -> {
				stackLayout.topControl = cs;
				cs.layout();
				switchComposite.layout();
			}));
		}

	}

	/**
	 * 信号波形图
	 * 
	 * @param parent
	 */
	private void createPlotArea(Composite parent) {
		Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout(4, false));
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		createDeviceTableViewer(composite, "车\r\n辆\r\n信\r\n号", Util.string2List(carSignal));
		createAPlot(composite);
		createDeviceTableViewer(composite, "车\r\n辆\r\n信\r\n号", Util.string2List(carSignal));
		createAPlot(composite);
		createDeviceTableViewer(composite, "输\r\n入\r\n输\r\n出\r\n信\r\n号", inputAndOutputSignals);
		createAPlot(composite);
		createDeviceTableViewer(composite, "输\r\n入\r\n输\r\n出\r\n信\r\n号", inputAndOutputSignals);
		createAPlot(composite);
		createDeviceTableViewer(composite, "电\r\n机\r\n与\r\n指\r\n令\r\n信\r\n号", Util.string2List(electromechanicalSignal));
		createAPlot(composite);
		createDeviceTableViewer(composite, "电\r\n机\r\n与\r\n指\r\n令\r\n信\r\n号", Util.string2List(electromechanicalSignal));
		createAPlot(composite);
	}

	private void createDeviceTableViewer(Composite parent, String title, List<String> input) {
		Composite composite = new Composite(parent, SWT.None);
		composite.setLayout(new GridLayout(2, false));
		GridData gridData = new GridData(SWT.FILL, SWT.FILL, false, false);
		composite.setLayoutData(gridData);
		Color color = ViewUtil.color;
		composite.setBackground(color);

		Composite compositeTitle = new Composite(composite, SWT.NONE);
		compositeTitle.setLayout(new GridLayout());
		compositeTitle.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, true, 1, 2));
		compositeTitle.setBackground(color);
		Label labTitle = new Label(compositeTitle, SWT.VERTICAL);
		labTitle.setText(title);
		labTitle.setBackground(color);
		labTitle.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, true));

		TableViewer tableViewerDevice = new TableViewer(composite, SWT.BORDER | SWT.CHECK | SWT.V_SCROLL);
		final Table table = tableViewerDevice.getTable();
		table.setLinesVisible(true);
		CheckboxTableViewer checkboxTableViewerDevice = new CheckboxTableViewer(table);
		TableLayout layoutDevice = new TableLayout();
		table.setLayout(layoutDevice);
		GridData layoutData = new GridData(SWT.FILL, SWT.FILL, false, false);
		layoutData.heightHint = 230;
		layoutData.widthHint = 160;
		table.setLayoutData(layoutData);
		layoutDevice.addColumnData(new ColumnWeightData(3));
		new TableColumn(table, SWT.None);
		layoutDevice.addColumnData(new ColumnWeightData(1));
		new TableColumn(table, SWT.None);
		checkboxTableViewerDevice.setContentProvider(new TableViewerContentProvider());
		checkboxTableViewerDevice.setLabelProvider(new TableViewerLabelProvider());
		checkboxTableViewerDevice.setInput(input);
		checkboxTableViewerList.add(checkboxTableViewerDevice);
		Composite compositeSelectAll = new Composite(composite, SWT.BORDER);
		compositeSelectAll.setLayout(new GridLayout());
		compositeSelectAll.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false));
		compositeSelectAll.setBackground(color);
		Button btnSelectAll = new Button(compositeSelectAll, SWT.None);
		btnSelectAll.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		btnSelectAll.setText("全选");
		btnSelectAll.setBackground(color);
		btnSelectAllList.add(btnSelectAll);
		btnSelectAll.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			TableItem[] items = table.getItems();

			String text = btnSelectAll.getText();
			int checkboxIndex = checkboxTableViewerList.indexOf(checkboxTableViewerDevice);
			XYGraphViewer xyGraphViewer = graphViewerList.get(checkboxIndex);
			if (text.equals("全选")) {
				Object[] checkedElements = checkboxTableViewerDevice.getCheckedElements();
				checkboxTableViewerDevice.setAllChecked(true);
				btnSelectAll.setText("清除");

				for (int i = 0; i < items.length; i++) {
					TableItem item = items[i];
					if (isContent(checkedElements, item.getText())) {
						continue;
					}
					tableItems.add(item);
					// 线的颜色
					Color lineColor = XYGraphMediaFactory.getInstance().getColor(CarriageConstants.DEFAULT_TRACES_COLOR[i % 12]);
					item.setBackground(1, lineColor);
					String attrName = getAttrsName(checkboxIndex, i);
					xyGraphViewer.setInput(Util.getData(attrName, lineColor));
					// key由第几个table和属性名组成
					String key = checkboxIndex + StringUtil.COMMA + attrName;
					if (!dataCacheMap.containsKey(key)) {
						List<Position> list = new ArrayList<>();
						dataCacheMap.put(key, list);
					}
				}

				if (!checkedXYGraphViewers.contains(xyGraphViewer)) {
					checkedXYGraphViewers.add(xyGraphViewer);
					updatePlot(checkboxIndex);
				}
			} else {
				checkboxTableViewerDevice.setAllChecked(false);
				btnSelectAll.setText("全选");
				xyGraphViewer.clearTrace();
				for (int i = 0; i < items.length; i++) {
					TableItem item = items[i];
					item.setBackground(1, ColorConstants.white);
					tableItems.remove(item);
					String attrName = getAttrsName(checkboxIndex, i);
					dataCacheMap.remove(checkboxIndex + StringUtil.COMMA + attrName);
				}
				if (checkboxTableViewerDevice.getCheckedElements().length == 0) {
					checkedXYGraphViewers.remove(xyGraphViewer);
					timerMap.get(checkboxIndex).cancel();
					timerMap.remove(checkboxIndex);
				}
			}
		}));
		checkboxTableViewerDevice.addCheckStateListener(event -> {
			PlotUtil.checkAllChanged(checkboxTableViewerDevice, input, btnSelectAll);
			String element = (String) event.getElement();
			int itemIndex = input.indexOf(element);
			TableItem item = table.getItem(itemIndex);
			boolean checked = event.getChecked();
			// 第几个tableViewer
			int checkboxIndex = checkboxTableViewerList.indexOf(checkboxTableViewerDevice);
			XYGraphViewer xyGraphViewer = graphViewerList.get(checkboxIndex);
			String attrName = getAttrsName(checkboxIndex, itemIndex);
			if (checked) {
				Color color1 = XYGraphMediaFactory.getInstance().getColor(CarriageConstants.DEFAULT_TRACES_COLOR[itemIndex % 12]);
				item.setBackground(1, color1);
				tableItems.add(item);
				xyGraphViewer.setInput(Util.getData(attrName, color1));
				List<Position> list = new ArrayList<>();
				// key由第几个table和属性名组成
				dataCacheMap.put(checkboxIndex + StringUtil.COMMA + attrName, list);

				if (!checkedXYGraphViewers.contains(xyGraphViewer)) {
					checkedXYGraphViewers.add(xyGraphViewer);
					updatePlot(checkboxIndex);
				}
			} else {
				xyGraphViewer.removeTrace(attrName);
				item.setBackground(1, ColorConstants.white);
				tableItems.remove(item);
				if (checkboxTableViewerDevice.getCheckedElements().length == 0) {
					checkedXYGraphViewers.remove(xyGraphViewer);
					timerMap.get(checkboxIndex).cancel();
					timerMap.remove(checkboxIndex);
				}
				dataCacheMap.remove(checkboxIndex + StringUtil.COMMA + attrName);
			}
		});
	}

	private boolean isContent(Object[] objects, String text) {
		for (Object object : objects) {
			if (object.toString().equals(text)) {
				return true;
			}
		}
		return false;
	}

	private String getAttrsName(int checkboxIndex, int itemIndex) {
		switch (checkboxIndex) {
		case 0:
			return CarriageConstants.carSignalAttrs[itemIndex];
		case 1:
			return CarriageConstants.carSignalAttrs[itemIndex];
		case 2:
			return CarriageConstants.inputAndOutputSignaleAttrs[itemIndex];
		case 3:
			return CarriageConstants.inputAndOutputSignaleAttrs[itemIndex];
		case 4:
			return CarriageConstants.electromechanicalSignalAttrs[itemIndex];
		case 5:
			return CarriageConstants.electromechanicalSignalAttrs[itemIndex];
		default:
			return StringUtil.EMPTY;
		}
	}

	/**
	 * 按刷新频率刷新波形图
	 * 
	 * @param xyGraphViewer
	 */
	private void updatePlot(int index) {
		XYGraphViewer xyGraphViewer = graphViewerList.get(index);
		Timer timer = new Timer();
		timerMap.put(index, timer);
		timer.scheduleAtFixedRate(new TimerTask() {

			@Override
			public void run() {
				Display.getDefault().asyncExec(() -> {
					int i = 0;
					for (Map.Entry<String, List<Position>> entry : dataCacheMap.entrySet()) {
						String key = entry.getKey();
						String[] split = key.split(StringUtil.COMMA);
						if (index == Integer.valueOf(split[0])) {
							List<Position> value = entry.getValue();
							xyGraphViewer.update(value, i);
							value.clear();
							i++;
						}
					}
				});
			}
		}, 0, refreshFrequency);

	}

	public void createAPlot(final Composite bottom) {
		XYGraphViewer graphViewerA = new XYGraphViewer(bottom);
		graphViewerA.setBufferSize(300);
		graphViewerList.add(graphViewerA);
		final GridData layoutData = new GridData(GridData.FILL_HORIZONTAL);
		graphViewerA.getContent().setLayoutData(layoutData);
	}

	@Override
	public void doorChecked(ICar car, int doorIndex) {
		if (car != null) {
			TrainManager instance = TrainManager.getInstance();
			refreshBasicInfo(car, doorIndex);
			if (instance.getCurrentCar().getIndex() != car.getIndex() || instance.getDoorIndex() != doorIndex) {
				for (TableItem item : tableItems) {
					item.setBackground(1, ColorConstants.white);
				}
				for (int i = 0; i < btnSelectAllList.size(); i++) {
					btnSelectAllList.get(i).setText("全选");
					checkboxTableViewerList.get(i).setAllChecked(false);
					graphViewerList.get(i).clearTrace();
				}
				colseDoorAnimation();
				labDoorState.setText("                ");
				labOpenTime.setText("        ");
				labCurrent.setText("   ");
				for (int j = 0; j < tableViewers.size() - 1; j++) {

					List<Signal> signals = new ArrayList<>();
					String[] signalNames = signalList.get(j);
					String[] attrs = signalAttrList.get(j);
					for (int i = 0; i < attrs.length; i++) {
						Signal signal = new Signal();
						signal.setSignalName(signalNames[i]);
						signals.add(signal);
					}
					tableViewers.get(j).setInput(signals);
					signals.clear();
					signals = null;
				}
			}
			instance.setCurrentCarAndDoorIndex(car, doorIndex);
		}
	}

	private void refreshBasicInfo(ICar car, int doorIndex) {
		labCarNum.setText(car.getName());
		labDoorNum.setText(String.valueOf(doorIndex + 1));
		List<IDoor> doors = car.getDoors();
		if (doors != null && doors.size() > doorIndex) {
			int addr = doors.get(doorIndex).getAddr();
			CommunicationService.getInstance().notifyDoorAddr(car.getIndex(), addr);
			labDoorAddress.setText(String.valueOf(addr));
		}
		List<IMdcu> mdcus = car.getMdcus();
		if (mdcus != null && mdcus.size() == 2) {
			labMDCU.setText(mdcus.get(0).getIp() + "," + mdcus.get(1).getIp());
		}
		labMDCU.getParent().layout();
		labCarNum.getParent().layout();
	}

	@Override
	protected void refreshDoorState(DoorStatus doorStatus) {
		super.refreshDoorState(doorStatus);
		int carNo = doorStatus.getCarNo();
		int doorAddr = doorStatus.getDoorAddr();
		ICar currentCar = TrainManager.getInstance().getCurrentCar();
		int doorIndex = TrainManager.getInstance().getDoorIndex();
		int doorAddrByIndex = Util.getDoorAddrByIndex(currentCar, doorIndex);
		if (carNo == currentCar.getIndex() && doorAddr == doorAddrByIndex) {
			List<Signal> signals = new ArrayList<>();
			for (int i = 0; i < CarriageConstants.doorStatusAttrs.length; i++) {
				Object currentValue = Util.getValueByAttr(doorStatus, CarriageConstants.doorStatusAttrs[i]);
				Signal signal = new Signal();
				signal.setSignalName(CarriageConstants.faultNames[i]);
				if (currentValue instanceof Boolean) {
					Boolean vBoolean = (Boolean) currentValue;
					signal.setSignalState(vBoolean ? SignalState.signal_ok : SignalState.signal_error);
				} else {
					signal.setValue(String.valueOf(currentValue));
				}
				signals.add(signal);
			}

			TableViewer tableViewer = tableViewers.get(3);
			if (!tableViewer.getTable().isDisposed()) {
				tableViewer.setInput(signals);
			}
			signals.clear();
			signals = null;
		}

		boolean[] currentFaultValues = Util.getFaultValues(doorStatus);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
		String format = dateFormat.format(new Date());
		boolean[] oldFaultValues = faultValuesMap.get(carNo + StringUtil.UNDER_LINE + doorAddr);
		for (int i = 0; i < currentFaultValues.length; i++) {

			if (currentFaultValues != null && oldFaultValues != null && currentFaultValues[i] && !oldFaultValues[i]) {
				String falutDescription = format + StringUtil.MID_LINE + doorStatus.getDate() + " " + doorStatus.getHour() + StringUtil.COLON
						+ doorStatus.getMinute() + StringUtil.COLON + doorStatus.getSecond() + " " + doorStatus.getCarNo() + "号车厢" + doorAddr + "号门"
						+ CarriageConstants.faultNames[i];
				faultList.add(falutDescription);
				if (faultList.size() > 2000) {
					faultList.remove(0);
				}
				if (!labFault.isDisposed()) {
					labFault.setVisible(true);
					labFault.setText(falutDescription);
					labFault.getParent().layout();
				}
				break;
			}
		}
		faultValuesMap.put(carNo + StringUtil.UNDER_LINE + doorAddr, currentFaultValues);

	}

	@Override
	public void receivedRealtimeData(IDataFrame dataFrame) {

		if (dataFrame instanceof RunDataFrame) {
			RunDataFrame runDataFrame = (RunDataFrame) dataFrame;
			this.dataFrame = runDataFrame;
			Display.getDefault().asyncExec(() -> {
				DataFrameD2 dataFrameD2 = runDataFrame.getDataFrameD2();
				DataFrameD3 dataFrameD3 = runDataFrame.getDataFrameD3();
				// 刷新门动画
				refreshDoorAnimation(runDataFrame);

				DataFrameD1 dataFrameD1 = runDataFrame.getDataFrameD1();
				DataFrameD4 dataFrameD4 = runDataFrame.getDataFrameD4();
				dataFrameList.add(dataFrameD1);
				dataFrameList.add(dataFrameD2);
				dataFrameList.add(dataFrameD3);
				dataFrameList.add(dataFrameD4);
				// 信号被勾选后才会执行
				if (!dataCacheMap.isEmpty()) {
					for (Map.Entry<String, List<Position>> entry : dataCacheMap.entrySet()) {
						String key = entry.getKey();
						String[] split = key.split(StringUtil.COMMA);
						List<Position> positions = entry.getValue();
						Object currentValue = Util.getValue(dataFrameList, split[1]);
						Position position = null;
						long millis = Util.getCurrentTimeMillis(dataFrameD3, dataFrameD4);
						if (currentValue instanceof Boolean) {
							boolean value = (boolean) currentValue;
							position = new Position(millis, value ? 1 : 0);
						} else {
							position = new Position(millis, Double.valueOf(String.valueOf(currentValue)));
						}
						positions.add(position);
					}

				}
				// refreshDoorCloseStateInfo(dataFrameD2);
				// 用完后清空
				dataFrameList.clear();
			});
		}
	}

	/**
	 * 刷新开关门状态信息
	 */
	private void refreshDoorCloseStateInfo(List<Object> dataFrameList) {
		DataFrameD2 dataFrameD2 = (DataFrameD2) dataFrameList.get(1);
		boolean door_Close = dataFrameD2.isDoor_Close();
		boolean process_openDoor = dataFrameD2.isProcess_openDoor();
		boolean process_closeDoor = dataFrameD2.isProcess_closeDoor();
		boolean door_Open = dataFrameD2.isDoor_Open();
		if (!labDoorState.isDisposed()) {
			if (door_Open) {
				labDoorState.setText("门完全打开");
				labOpenTimeTitle.setText("开门时间");
			} else if (door_Close) {
				labDoorState.setText("门完全关闭");
				labOpenTimeTitle.setText("关门时间");
				labOpenTime.setText(getTime(dataFrameList, "closeDoorTime"));
			} else if (process_openDoor) {
				labDoorState.setText("开门中");
				labOpenTimeTitle.setText("开门时间");
				labOpenTime.setText(getTime(dataFrameList, "openDoorTime"));
			} else if (process_closeDoor) {
				labDoorState.setText("关门中");
				labOpenTimeTitle.setText("关门时间");
				labOpenTime.setText(getTime(dataFrameList, "closeDoorTime"));
			}
			labCurrent.setText(String.valueOf(Util.getValue(dataFrameList, "motorCurrent")));
			labCurrent.getParent().layout();
			for (int j = 0; j < tableViewers.size() - 1; j++) {

				List<Signal> signals = new ArrayList<>();
				String[] signalNames = signalList.get(j);
				String[] attrs = signalAttrList.get(j);
				for (int i = 0; i < attrs.length; i++) {
					Object currentValue = Util.getValue(dataFrameList, attrs[i]);
					Signal signal = new Signal();
					signal.setSignalName(signalNames[i]);
					if (currentValue instanceof Boolean) {
						Boolean vBoolean = (Boolean) currentValue;
						signal.setSignalState(vBoolean ? SignalState.signal_ok : SignalState.signal_error);
					} else {
						signal.setValue(String.valueOf(currentValue));
					}
					signals.add(signal);
				}
				tableViewers.get(j).setInput(signals);
				signals.clear();
				signals = null;
			}
		}
	}

	private String getTime(List<Object> dataFrameList, String atr) {
		double d = Double.valueOf(String.valueOf(Util.getValue(dataFrameList, atr))) * 10 / 1000;
		BigDecimal bigDecimal = new BigDecimal(d).setScale(2, BigDecimal.ROUND_HALF_UP);
		return bigDecimal.toString();
	}

	/**
	 * 刷新门动画
	 * 
	 * @param dataFrame
	 */
	private void refreshDoorAnimation(RunDataFrame dataFrame) {
		AnimationCache cache = new AnimationCache();
		short currentEncoder = dataFrame.getDataFrameD3().getEncoder();
		int a = (int) Math.ceil(currentEncoder * 90 / 3590);
		cache.setA(a);
		cache.setProcessOpenDoor(dataFrame.getDataFrameD2().isProcess_openDoor());
		cache.setProcessCloseDoor(dataFrame.getDataFrameD2().isProcess_closeDoor());
		cache.setDoorClose(dataFrame.getDataFrameD2().isDoor_Close());
		cache.setDoorOpen(dataFrame.getDataFrameD2().isDoor_Open());

		long millis = Util.getCurrentTimeMillis(dataFrame.getDataFrameD3(), dataFrame.getDataFrameD4());

		cache.setTime(millis);
		List<Object> dataFrameList = new ArrayList<>();
		dataFrameList.add(dataFrame.getDataFrameD1());
		dataFrameList.add(dataFrame.getDataFrameD2());
		dataFrameList.add(dataFrame.getDataFrameD3());
		dataFrameList.add(dataFrame.getDataFrameD4());
		cache.setDataFrameList(dataFrameList);
		animationCacheList.addLast(cache);
	}

	private void updateDoorAnimation(AnimationCache cache) {
		if (cache.isProcessCloseDoor()) {
			panel.update(DoorContent.CLOSE_OPERATION, cache.getA());
			panel.repaint();
		} else if (cache.isProcessOpenDoor()) {
			panel.update(DoorContent.OPEN_OPERATION, cache.getA());
			panel.repaint();
		}
		if (cache.isDoorClose()) {
			colseDoorAnimation();
		}
		if (cache.isDoorOpen()) {
			panel.update(DoorContent.OPEN_OPERATION, 90);
			panel.repaint();
		}
	}

	/**
	 * 将门动画置为关门状态
	 */
	private void colseDoorAnimation() {
		panel.reset();
		panel.repaint();
	}

	@Override
	public void refreshFigure() {
		super.refreshFigure();
		faultValuesMap.clear();
		List<ICar> carriages = train.getCarriages();
		for (ICar iCar : carriages) {
			List<IDoor> doors = iCar.getDoors();
			for (IDoor door : doors) {
				faultValuesMap.put(iCar.getIndex() + StringUtil.UNDER_LINE + door.getAddr(), faultValues);
			}
		}
	}
}
