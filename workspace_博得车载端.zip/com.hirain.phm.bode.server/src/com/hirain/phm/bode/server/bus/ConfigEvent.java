package com.hirain.phm.bode.server.bus;

import com.hirain.phm.bode.core.ITrain;

public class ConfigEvent {

	private final ITrain train;

	private final Object from;

	public ConfigEvent(ITrain train, Object from) {
		this.train = train;
		this.from = from;
	}

	public ITrain getTrain() {
		return train;
	}

	public Object getFrom() {
		return from;
	}

}
