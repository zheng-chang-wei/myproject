package com.hirain.phm.bode.server.server;

import java.net.InetSocketAddress;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.IMdcu;
import com.hirain.phm.bode.core.IServer;
import com.hirain.phm.bode.core.IServerIp;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.impl.ServerIpType;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.core.util.SystemInfoUtil;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.DebugEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.bus.MacEvent;
import com.hirain.phm.bode.server.bus.MacResultEvent;
import com.hirain.phm.bode.server.bus.SendEvent;
import com.hirain.phm.bode.server.comm.ITransportPacket;
import com.hirain.phm.bode.server.config.ConfigurationService;
import com.hirain.phm.bode.server.db.DBManageService;

public class ServerService extends AbstractServerService {

	static Logger logger = Logger.getLogger(ServerService.class);

	// private final Set<String> antiMulti1 = new HashSet<>();

	// private final Set<String> antiMulti2 = new HashSet<>();

	@SuppressWarnings("unused")
	private final boolean first = false;

	private ServerHeartbeatHandler heartbeatHandler;

	private InetSocketAddress heartBeatSocket;

	private InetSocketAddress lostDataSocket;

	private boolean isMasterServer = false;// 判断当前服务器是否是两个服务器中的主服务器

	private String otherHost;

	public ServerService() {
		super();
	}

	@Override
	public void post(ITransportPacket packet) {
		if (packet.getPid() == ServerConstant.DOOR_MESSAGE_PID) {
			processMessage(packet);
		} else if (packet.getPid() == ServerConstant.DEBUG_COMMAND_ID) {
			confirmDebug(packet.getAddress());
			final byte[] data = packet.getData();
			InnerEventBus.getInstance().post(new DebugEvent(data[0] == 1, this));
		} else if (packet.getPid() == ServerConstant.SETTING_COMMAND_ID) {
			confirmSetting(packet.getAddress());
			final byte[] data = packet.getData();
			ITrain train;
			try {
				train = SystemInfoUtil.convertXmlBytes2SystemInfo(data);
				ConfigurationService.getInstance().save(train);
				DBManageService.getInstance().init(train.getCars());
				InnerEventBus.getInstance().post(new ConfigEvent(train, this));
			} catch (final Exception e) {
				logger.error(e.getMessage(), e);
			}
		} else if (packet.getPid() == ServerConstant.ASK_MAC_ID) {
			InnerEventBus.getInstance().post(new MacEvent(packet.getData()));
		} else if (packet.getPid() == ServerConstant.REPLY_MAC_ID) {
			final MacResultEvent event = new MacResultEvent(packet.getData());
			InnerEventBus.getInstance().post(event);
		} else if (!isMasterServer && packet.getPid() == ServerConstant.SERVER_HEARTBEAT_PID) {
			replayHeartbeat();
		} else if (!isMasterServer && packet.getPid() == ServerConstant.SERVER_LOSTMESSAGEDATA_ID) {
			// 将DoorMessage数据插入数据库
			final Map<Integer, Object> parsePackageData = heartbeatHandler.parseDoorMessageData(packet.getData());
			heartbeatHandler.insertLostMessage(parsePackageData);
		} else if (!isMasterServer && packet.getPid() == ServerConstant.SERVER_LOSTFAULTRECORD_ID) {
			// 将faultRecord数据插入数据库
			heartbeatHandler.insertLostFaultRecord(heartbeatHandler.parseFaultRecordData(packet.getData()));
		} else {
			throw new IllegalArgumentException();
		}
	}

	/**
	 * listening configuration changed event;
	 * send the configuration to another server.
	 * send OK message to MDCUs.
	 * 
	 * @param event
	 */
	@Subscribe
	public void on(ConfigEvent event) {
		final int index = configChanged(event);
		if (index == -1) {
			return;
		}
		if (!equals(event.getFrom())) {
			if (StringUtil.isNotEmpty(otherHost)) {
				sendSetting(otherHost, event.getTrain());
			}
		}
		startServerHeartbeat(index, event.getTrain());
	}

	private int configChanged(ConfigEvent event) {
		final ITrain train = event.getTrain();
		final List<IServer> servers = train.getServers();
		final List<String> locahosts = Utils.locahosts();
		int index = -1;
		for (int i = 0; i < servers.size(); i++) {
			final IServer server = servers.get(i);
			final List<IServerIp> list = server.getServesIps();
			for (final IServerIp sIP : list) {
				if (sIP.getType().equals(ServerIpType.Type1)) {
					final String ip = sIP.getIp();
					if (locahosts.contains(ip)) {
						restart(ip);
						index = i;
					} else {
						otherHost = ip;
					}
				}
			}
		}
		if (index == -1) {
			return index;
		}
		if (liveHandler != null) {
			liveHandler.stop();
		}
		liveHandler = new MDCULiveHandler(this);
		final List<ICar> cars = train.getCars();
		for (final ICar car : cars) {
			final List<IMdcu> mdcus = car.getMdcus();
			// 列表中第一个服务端只向MDCU下第一个IP地址发送ok报文，第二个服务端只向MDCU下第二个IP地址发送OK报文
			if (car.getType() == 1) {
				final IMdcu mdcu = mdcus.get(index);
				sendOk(mdcu.getIp());
				liveHandler.addMdcu(mdcu.getIp());
			}
		}
		liveHandler.start();
		return index;
	}

	private void startServerHeartbeat(int index, ITrain train) {
		heartbeatHandler = new ServerHeartbeatHandler(this, train);
		if (index == 0) {// 配置文件中的第一个server作为心跳的查询者
			isMasterServer = true;
			heartbeatHandler.start();
		}
	}

	public ServerHeartbeatHandler getHeartbeatHandler() {
		return heartbeatHandler;
	}

	/**
	 * listening debug tag changed.
	 * send debug message to another server
	 * 
	 * @param event
	 */
	@Subscribe
	public void on(DebugEvent event) {
		if (event.getFrom().equals(this)) {
			return;
		}
		if (StringUtil.isNotEmpty(otherHost)) {
			sendDebug(new InetSocketAddress(otherHost, ServerConstant.TO_OTHER_PORT), event.isDebug());
		}
	}

	@Subscribe
	public void on(SendEvent event) {
		if (otherHost != null) {
			communication.send(new InetSocketAddress(otherHost, ServerConstant.TO_OTHER_PORT), ServerConstant.TO_OTHER_PORT, event.getPid(),
					event.getDatas());
		}
	}

	/**
	 * 向对端服务器发送心跳查询
	 */
	void inquireHeartbeat() {
		// System.out.println("发送-- 心跳请求");
		if (heartBeatSocket == null) {
			heartBeatSocket = new InetSocketAddress(otherHost, ServerConstant.TO_OTHER_PORT);
		}
		communication.send(heartBeatSocket, ServerConstant.TO_OTHER_PORT, ServerConstant.SERVER_HEARTBEAT_PID, new byte[] { 0 });
	}

	/**
	 * 向对端服务器回复心跳查询请求
	 */
	void replayHeartbeat() {
		// System.out.println("回复-- 心跳请求");
		if (heartBeatSocket == null) {
			heartBeatSocket = new InetSocketAddress(otherHost, ServerConstant.TO_OTHER_PORT);
		}
		communication.send(heartBeatSocket, ServerConstant.TO_OTHER_PORT, ServerConstant.HEARTBEAT_RESPONSE_PID, new byte[] { 0 });
	}

	/**
	 * 向对端服务器发送其掉线期间遗失的数据
	 */
	void sendLostData(byte[] lostData) {
		System.out.println("发送对端服务器丢失的实时数据");
		if (lostDataSocket == null) {
			lostDataSocket = new InetSocketAddress(otherHost, ServerConstant.TO_LOSTDATA_PORT);
		}
		communication.send(lostDataSocket, ServerConstant.TO_LOSTDATA_PORT, ServerConstant.SERVER_LOSTMESSAGEDATA_ID, lostData);
	}

	private void confirmDebug(InetSocketAddress address) {
		communication.send(address, ServerConstant.TO_OTHER_PORT, ServerConstant.DEBUG_RESPONCE_ID, new byte[] { 0 });
	}

	private void sendDebug(InetSocketAddress address, boolean debug) {
		communication.send(address, ServerConstant.TO_OTHER_PORT, ServerConstant.DEBUG_COMMAND_ID, new byte[] { (byte) (debug ? 1 : 2) });
	}

	private void sendSetting(String other, ITrain train) {
		final InetSocketAddress address = new InetSocketAddress(other, ServerConstant.TO_OTHER_PORT);
		byte[] datas;
		try {
			datas = SystemInfoUtil.convertSystemInfo2XmlBytes(train);
			communication.send(address, ServerConstant.TO_OTHER_PORT, ServerConstant.SETTING_COMMAND_ID, datas);
		} catch (final Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}
	}

	private void confirmSetting(InetSocketAddress address) {
		communication.send(address, ServerConstant.TO_OTHER_PORT, ServerConstant.SETTING_RESPONCE_ID, new byte[] { 0 });
	}

	@SuppressWarnings("unused")
	private String generateKey(byte[] datas) {
		final StringBuilder builder = new StringBuilder();
		builder.append(byte2Hex(datas[0]));
		builder.append(byte2Hex(datas[12]));
		builder.append(byte2Hex(datas[21]));
		builder.append(byte2Hex(datas[22]));
		builder.append(byte2Hex(datas[23]));
		builder.append(byte2Hex(datas[25]));
		builder.append(byte2Hex(datas[26]));
		builder.append(byte2Hex(datas[27]));
		return builder.toString();
	}

	private String byte2Hex(byte b) {
		final String hex = Integer.toHexString(b);
		if (hex.length() < 2) {
			return "0" + hex;
		}
		return hex;
	}

}
