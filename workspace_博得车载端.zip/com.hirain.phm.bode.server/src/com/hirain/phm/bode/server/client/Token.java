package com.hirain.phm.bode.server.client;

import java.net.InetSocketAddress;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class Token {

	String username;

	InetSocketAddress address;

	AtomicBoolean on = new AtomicBoolean();

	AtomicInteger breakCount = new AtomicInteger(0);

	public Token(String username, InetSocketAddress address) {
		this.username = username;
		this.address = address;
	}

	public String getUsername() {
		return username;
	}

	public InetSocketAddress getAddress() {
		return address;
	}
}
