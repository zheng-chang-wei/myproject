package com.hirain.phm.bode.ui.monitor.figure.carriage;

import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Display;

import com.hirain.phm.bode.core.dataframe.DoorStatus;
import com.hirain.phm.bode.ui.monitor.listener.DoorDestroyListener;
import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;
import com.hirain.phm.bode.ui.monitor.model.DoorStateEnum;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created Jan 7, 2019 12:54:06 PM
 * @Description
 *              <p>
 *              车门
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 7, 2019 changwei.zheng@hirain.com 1.0 create file
 */
public class DoorFigure extends Figure implements DoorDestroyListener {

	private Label label = new Label();

	private String name;

	/**
	 * 当前值
	 */
	private int currentValue;

	private Timer timer;

	public DoorFigure(String name, boolean isConfig) {
		this.name = name;
		setLayoutManager(new XYLayout());
		addRectangleFigure();
		if (isConfig) {
			setBackgroundColor(CarriageConstants.color_light_gray);
		} else {
			setBackgroundColor(ColorConstants.black);
			label.setForegroundColor(ColorConstants.white);
			timer = new Timer();
			timer.scheduleAtFixedRate(new TimerTask() {

				@Override
				public void run() {
					// 如果1秒钟内currentValue一直等于0，说明门没有刷新过
					if (currentValue == 0) {
						Display.getDefault().syncExec(() -> {
							setLabelColor(ColorConstants.white);
							removeAll();
							addRectangleFigure();
							setBackgroundColor(DoorStateEnum.communication_malfunction.getColor());
						});

					}
					currentValue = 0;
				}

			}, 0, 5000);
		}
	}

	public void addRectangleFigure() {
		RectangleFigure rectangleFigure = new RectangleFigure();
		add(rectangleFigure, new Rectangle(0, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
		label.setText(name);
		label.setFont(CarriageConstants.font);
		add(label, new Rectangle(0, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
	}

	public void addIsolationFigure() {
		IsolationFigure isolationFigure = new IsolationFigure();
		add(isolationFigure, new Rectangle(0, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
		// add(label, new Rectangle(0, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
	}

	public void addAntiCrushFigure() {
		AntiCrushFigure antiCrushFigure = new AntiCrushFigure();
		add(antiCrushFigure, new Rectangle(0, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
		// add(label, new Rectangle(0, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
	}

	public void addEmergencyUnlockFigure() {
		EmergencyUnlockFigure rectangleFigure = new EmergencyUnlockFigure();
		add(rectangleFigure, new Rectangle(0, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
		// add(label, new Rectangle(0, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
		setBackgroundColor(ColorConstants.red);
	}

	public String getName() {
		return name;
	}

	public void setLabelColor(Color color) {
		label.setForegroundColor(color);
	}

	public void refresh(DoorStatus doorStatus) {
		currentValue++;
		if (doorStatus != null) {
			setLabelColor(ColorConstants.black);
			// 优先级 通讯故障>隔离>紧急解锁>门故障>防挤压>门完全打开>动作中>门完全关闭
			if (doorStatus.isIsolation()) {
				removeAll();
				addIsolationFigure();
			} else if (doorStatus.isEmergencyUnlock()) {
				removeAll();
				addEmergencyUnlockFigure();
			} else if (doorStatus.isExistFault()) {
				removeAll();
				addRectangleFigure();
				setBackgroundColor(DoorStateEnum.door_malfunction.getColor());
			} else if (doorStatus.isAnticrush()) {
				removeAll();
				addAntiCrushFigure();
			} else if (doorStatus.isOpenCompletely()) {
				removeAll();
				addRectangleFigure();
				setBackgroundColor(DoorStateEnum.door_open.getColor());
			} else if (doorStatus.isCloseProcess()) {
				removeAll();
				addRectangleFigure();
				setBackgroundColor(DoorStateEnum.door_closing.getColor());
			} else if (doorStatus.isOpenProcess()) {
				removeAll();
				addRectangleFigure();
				setBackgroundColor(DoorStateEnum.door_openning.getColor());
			} else if (doorStatus.isCloseCompletely()) {
				removeAll();
				addRectangleFigure();
				setBackgroundColor(DoorStateEnum.door_close.getColor());
			} else {
				removeAll();
				addRectangleFigure();
				setBackgroundColor(DoorStateEnum.communication_malfunction.getColor());
			}
		} else {
			setLabelColor(ColorConstants.white);
			setBackgroundColor(ColorConstants.black);
		}
	}

	@Override
	public void distroy() {
		if (timer != null) {
			timer.cancel();
			timer = null;
		}

	}
}
