/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.systemsetting;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 10, 2019 9:53:02 AM
 * @Description
 *              <p>
 *              服务端存储空间的对象
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 10, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class StorageState {

	private long usedSpace;

	private long totalSpace;

	/**
	 * @return the totalSpace
	 */
	public long getTotalSpace() {
		return totalSpace;
	}

	/**
	 * @return the usedSpace
	 */
	public long getUsedSpace() {
		return usedSpace;
	}

	/**
	 * @param usedSpace
	 *            the usedSpace to set
	 */
	public void setUsedSpace(long usedSpace) {
		this.usedSpace = usedSpace;
	}

	/**
	 * @param totalSpace
	 *            the totalSpace to set
	 */
	public void setTotalSpace(long totalSpace) {
		this.totalSpace = totalSpace;
	}

}
