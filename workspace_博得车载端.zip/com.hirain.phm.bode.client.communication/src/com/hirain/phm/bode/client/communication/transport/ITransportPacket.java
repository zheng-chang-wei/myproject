package com.hirain.phm.bode.client.communication.transport;

import java.net.InetSocketAddress;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 */
public interface ITransportPacket {

	int localPort();

	void setLocalPort(int port);

	InetSocketAddress getAddress();

	void setAddress(InetSocketAddress address);

	byte getPid();

	void setPid(final byte pid);

	/**
	 * 整条UDP报文的长度
	 * 
	 * @return
	 */
	int getLength();

	void setLength(final int length);

	/**
	 * 有效数据
	 * 
	 * @return
	 */
	byte[] getData();

	void setData(final byte[] data);

	byte[] toByte();

}
