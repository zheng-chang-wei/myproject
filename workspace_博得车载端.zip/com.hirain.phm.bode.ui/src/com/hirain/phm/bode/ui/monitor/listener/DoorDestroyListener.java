package com.hirain.phm.bode.ui.monitor.listener;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月17日 下午7:49:45
 * @Description
 *              <p>
 *              车门销毁事件监听器
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月17日 changwei.zheng@hirain.com 1.0 create file
 */
public interface DoorDestroyListener {

	void distroy();
}
