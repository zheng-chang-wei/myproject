package com.hirain.phm.bode.server.mqtt;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.util.Date;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import org.apache.commons.io.FileUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMReader;

public class SslUtil {

	private static final String SSL_FOLDER = "ssl";

	public static final String SSL_ROOT = System.getProperty("user.dir") + File.separator + SSL_FOLDER + File.separator;

	public static SSLSocketFactory getSocketFactory(final String caCrtFile, final String crtFile, final String keyFile, final String password)
			throws Exception {
		Security.addProvider(new BouncyCastleProvider());

		// load CA certificate
		final byte[] bs1 = FileUtils.readFileToByteArray(new File(caCrtFile));
		PEMReader reader = new PEMReader(new InputStreamReader(new ByteArrayInputStream(/* Files.readAllBytes(Paths.get(caCrtFile)) */bs1)));
		final X509Certificate caCert = (X509Certificate) reader.readObject();
		reader.close();

		// load client certificate
		final byte[] bs2 = FileUtils.readFileToByteArray(new File(crtFile));
		reader = new PEMReader(new InputStreamReader(new ByteArrayInputStream(/* Files.readAllBytes(Paths.get(crtFile)) */bs2)));
		final X509Certificate cert = (X509Certificate) reader.readObject();
		reader.close();

		// load client private key
		final byte[] bs3 = FileUtils.readFileToByteArray(new File(keyFile));
		reader = new PEMReader(new InputStreamReader(new ByteArrayInputStream(/* Files.readAllBytes(Paths.get(keyFile)) */bs3)),
				() -> password.toCharArray());
		final KeyPair key = (KeyPair) reader.readObject();
		reader.close();
		// CA certificate is used to authenticate server
		final KeyStore caKs = KeyStore.getInstance(KeyStore.getDefaultType());
		caKs.load(null, null);
		caKs.setCertificateEntry("ca-certificate", caCert);
		final TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		tmf.init(caKs);

		// client key and certificates are sent to server so it can authenticate us
		final KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
		ks.load(null, null);
		ks.setCertificateEntry("certificate", cert);
		ks.setKeyEntry("private-key", key.getPrivate(), password.toCharArray(), new java.security.cert.Certificate[] { cert });
		final KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		kmf.init(ks, password.toCharArray());

		// finally, create SSL socket factory
		final SSLContext context = SSLContext.getInstance("TLSv1");
		context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

		return context.getSocketFactory();
	}

	public static void update(String filename, String content) throws IOException {
		final String path = SSL_ROOT + filename;
		FileUtils.writeStringToFile(new File(path), content, Charset.defaultCharset());
	}

	public static String content(String filename) throws IOException {
		final String path = SSL_ROOT + filename;
		return FileUtils.readFileToString(new File(path), Charset.defaultCharset());
	}

	public static boolean overtime(final String file) throws IOException {
		Security.addProvider(new BouncyCastleProvider());
		final byte[] bs1 = FileUtils.readFileToByteArray(new File(file));
		final PEMReader reader = new PEMReader(new InputStreamReader(new ByteArrayInputStream(/* Files.readAllBytes(Paths.get(caCrtFile)) */bs1)));
		final X509Certificate crt = (X509Certificate) reader.readObject();
		reader.close();

		final Date before = crt.getNotBefore();
		final Date after = crt.getNotAfter();
		final Date now = new Date();
		return now.compareTo(before) < 0 || now.compareTo(after) > 0;
	}

}
