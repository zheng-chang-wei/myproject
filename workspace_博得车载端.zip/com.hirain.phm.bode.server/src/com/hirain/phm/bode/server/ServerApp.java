package com.hirain.phm.bode.server;

import java.net.InetSocketAddress;
import java.util.List;

import org.apache.log4j.Logger;

import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ClientService;
import com.hirain.phm.bode.server.config.ConfigurationService;
import com.hirain.phm.bode.server.db.DBManageService;
import com.hirain.phm.bode.server.db.DBStorageService;
import com.hirain.phm.bode.server.fault.FaultService;
import com.hirain.phm.bode.server.log.LogEvent;
import com.hirain.phm.bode.server.log.LogService;
import com.hirain.phm.bode.server.message.PreProcessor;
import com.hirain.phm.bode.server.server.AbstractServerService;
import com.hirain.phm.bode.server.server.SingleServerService;
import com.hirain.phm.bode.server.store.StoreService;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年1月4日 下午2:42:50
 * @Description
 *              <p>
 *              Launcher
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月4日 jianwen.xin@hirain.com 1.0 create file
 */
public class ServerApp {

	static Logger logger = Logger.getLogger(ServerApp.class.getName());

	public static void main(String[] args) {
		new ServerApp().start(args);
	}

	public void start(String[] args) {
		System.out.println(System.getProperty("user.dir"));

		final ITrain train = ConfigurationService.getInstance().getTrain();
		logger.info("Initializing database");
		DBManageService.getInstance().checkSpace();
		if (train != null && Utils.validateSetting(train) == 0) {
			DBManageService.getInstance().init(train.getCars());
			DBManageService.getInstance().part(train.getCars());
		}
		DBManageService.getInstance().partFaultTable();
		logger.info("Database initialized");

		final PreProcessor processor = new PreProcessor();
		processor.init();
		final StoreService storeService = new StoreService(processor);
		storeService.init();
		logger.info("Store module initialized");

		final FaultService faultService = new FaultService(processor);
		faultService.init();
		logger.info("Fault module initialized");

		// final LifeService lifeService = new LifeService(processor);
		// lifeService.init();
		// logger.info("Life module initialized");

		final List<String> locahosts = Utils.locahosts();

		logger.info("Client module starting");
		for (final String localhost : locahosts) {
			final ClientService client = new ClientService(localhost, processor);
			client.init();
			final InetSocketAddress localClient = new InetSocketAddress(localhost, ClientConstants.LOCAL_CLIENT_PORT);
			final InetSocketAddress localHeart = new InetSocketAddress(localhost, ClientConstants.LOCAL_HEART_PORT);
			final InetSocketAddress localUpload = new InetSocketAddress(localhost, ClientConstants.LOCAL_UPLOAD_PORT);
			client.start(localClient, localHeart, localUpload);
		}
		logger.info("Client module started");

		final AbstractServerService server = new SingleServerService();
		server.init();
		logger.info("Single Server module initialized");

		// final GroundService ground = new GroundService(processor);
		// ground.init();
		// logger.info("Ground module initialized");

		final DBStorageService storageService = new DBStorageService();
		storageService.start();

		logger.info("Check the system configuration");
		if (train != null && Utils.validateSetting(train) == 0) {
			LogService.instance().log(LogEvent.ofTrain(train));
			InnerEventBus.getInstance().post(new ConfigEvent(train, null));
		}

		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			logger.info("系统退出");
		}));
	}

}
