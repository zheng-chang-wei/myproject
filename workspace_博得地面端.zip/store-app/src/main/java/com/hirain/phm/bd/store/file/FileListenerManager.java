/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.store.file;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.stereotype.Component;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年5月22日 下午6:12:01
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年5月22日 jianwen.xin@hirain.com 1.0 create file
 */
@Component
public class FileListenerManager {

	private List<IFileListener> listeners = new CopyOnWriteArrayList<>();

	public void add(IFileListener listener) {
		listeners.add(listener);
	}

	public void remove(IFileListener listener) {
		listeners.remove(listener);
	}

	public void fire(SwitchFileEvent event) {
		for (IFileListener l : listeners) {
			l.update(event);
		}
	}
}
