package com.hirain.phm.bd.ground.common.event;

import lombok.Data;

@Data
public class TrainInitEvent {

	private String project;

	private String train;
}
