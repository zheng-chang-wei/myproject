package com.hirain.phm.bode.ui.log.provider;

import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.swt.graphics.Image;

import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.log.model.LogTable;

public class LogTableViewerLabelProvider implements ITableLabelProvider {

	public LogTableViewerLabelProvider() {
	}

	@Override
	public void addListener(ILabelProviderListener listener) {

	}

	@Override
	public void dispose() {

	}

	@Override
	public boolean isLabelProperty(Object element, String property) {
		return false;
	}

	@Override
	public void removeListener(ILabelProviderListener listener) {

	}

	@Override
	public Image getColumnImage(Object element, int columnIndex) {
		return null;
	}

	@Override
	public String getColumnText(Object element, int columnIndex) {
		if (element instanceof LogTable) {

			LogTable log = (LogTable) element;
			switch (columnIndex) {
			case 0:
				return log.getLogTime();
			case 1:
				return log.getLogName();
			default:
				break;
			}
		}
		return StringUtil.EMPTY;
	}

}
