package com.hirain.phm.bd.ground.maintenance.param;

import lombok.Data;

@Data
public class Suggestion {

	private String treatment;

	private String repair;

}