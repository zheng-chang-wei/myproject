package com.hirain.phm.bd.flow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@EnableEurekaClient
@SpringBootApplication
public class FlowAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlowAppApplication.class, args);
	}

}
