package com.hirain.phm.bode.server.client;

import java.net.InetSocketAddress;

import com.hirain.phm.bode.server.TestConstant;

public class ServerClientMock {

	private ClientService client;

	public void start() {
		client = new ClientService(TestConstant.LOCALHOST, null);
		client.init();
		client.start(new InetSocketAddress(TestConstant.LOCALHOST, ClientConstants.LOCAL_CLIENT_PORT),
				new InetSocketAddress(TestConstant.LOCALHOST, ClientConstants.LOCAL_HEART_PORT));
	}

}
