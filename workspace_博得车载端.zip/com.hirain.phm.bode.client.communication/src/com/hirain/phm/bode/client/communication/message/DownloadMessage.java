/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.message;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 16, 2019 3:39:29 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 16, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DownloadMessage extends AbstractMessage {

}
