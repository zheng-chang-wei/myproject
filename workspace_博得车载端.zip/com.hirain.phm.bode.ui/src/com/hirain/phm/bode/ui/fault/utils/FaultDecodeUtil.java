package com.hirain.phm.bode.ui.fault.utils;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import com.hirain.phm.bode.client.communication.message.FaultResultMessage;
import com.hirain.phm.bode.core.fault.Fault;
import com.hirain.phm.bode.core.fault.FaultRecord;
import com.hirain.phm.bode.core.util.FileUtil;
import com.hirain.phm.bode.core.util.StringUtil;

public class FaultDecodeUtil {

	public static List<Fault> getFaults(FaultResultMessage message) {
		List<Fault> faults = new ArrayList<>();
		if (message != null) {
			byte[] data = message.getData();
			ByteBuffer buffer = ByteBuffer.wrap(data);
			buffer.get();
			byte num = buffer.get();
			for (int i = 0; i < num; i++) {
				Fault fault = new Fault();
				fault.setId(Integer.valueOf(buffer.get()));
				byte nameLength = buffer.get();
				byte[] name = new byte[nameLength];
				for (int j = 0; j < nameLength; j++) {
					name[j] = buffer.get();
				}
				try {
					fault.setCname(new String(name, "utf-8"));
				} catch (Exception e) {
					e.printStackTrace();
				}
				faults.add(fault);
			}
		}
		return faults;
	}

	public static List<FaultRecord> getFaultRecord(FaultResultMessage message) {
		List<FaultRecord> records = new ArrayList<>();
		if (message != null) {
			byte[] data = message.getData();
			ByteBuffer buffer = ByteBuffer.wrap(data);
			// 查询结果类型
			buffer.get();
			// 记录数量
			byte num = buffer.get();

			for (int i = 0; i < num; i++) {
				FaultRecord faultRecord = new FaultRecord();
				faultRecord.setFaultId(String.valueOf(buffer.get()));
				String timestamp = getTime(buffer);

				faultRecord.setTimestamp(timestamp);
				String startTime = getTime(buffer);

				faultRecord.setStartTime(startTime);

				String endTime = getTime(buffer);

				faultRecord.setEndTime(endTime);

				faultRecord.setDebug(buffer.get() == 1 ? true : false);
				records.add(faultRecord);
			}
		}
		return records;
	}

	private static String getTime(ByteBuffer buffer) {
		StringBuilder builder = new StringBuilder();
		// 年
		builder.append(buffer.get() + 2000);
		builder.append(StringUtil.MID_LINE);
		// 月
		int month = Byte.toUnsignedInt(buffer.get()) + 1;
		if (month < 10) {
			builder.append("0");
		}
		builder.append(month);
		builder.append(StringUtil.MID_LINE);
		// 日
		int day = Byte.toUnsignedInt(buffer.get());
		if (day < 10) {
			builder.append("0");
		}
		builder.append(day);
		builder.append(" ");
		// 时
		int hour = Byte.toUnsignedInt(buffer.get());
		if (hour < 10) {
			builder.append("0");
		}
		builder.append(hour);
		builder.append(StringUtil.COLON);
		// 分
		int minute = Byte.toUnsignedInt(buffer.get());
		if (minute < 10) {
			builder.append("0");
		}
		builder.append(minute);
		builder.append(StringUtil.COLON);
		// 秒
		int second = Byte.toUnsignedInt(buffer.get());
		if (second < 10) {
			builder.append("0");
		}
		builder.append(second);
		return builder.toString();
	}

	public static void saveFaultMessages(FaultResultMessage message, String filePath) {
		if (message != null) {
			List<String> list = new ArrayList<>();
			byte[] data = message.getData();
			ByteBuffer buffer = ByteBuffer.wrap(data);
			buffer.get();
			int num = Short.toUnsignedInt(buffer.getShort());
			System.out.println(num);
			for (int i = 0; i < num; i++) {
				StringBuffer stringBuffer = new StringBuffer();
				byte[] datas = new byte[32];
				buffer.get(datas);
				for (byte b : datas) {
					String hexString = Integer.toHexString(Byte.toUnsignedInt(b));
					if (hexString.length() == 1) {
						stringBuffer.append(0);
					}
					stringBuffer.append(hexString.toUpperCase());
				}
				buffer.getShort();
				list.add(stringBuffer.toString());
			}
			try {
				FileUtil.appendFile(list, filePath);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public static long getFaultsCount(FaultResultMessage message) {
		if (message.getData() != null) {
			byte[] data = message.getData();
			ByteBuffer buffer = ByteBuffer.wrap(data);
			buffer.get();
			return buffer.getLong();
		}
		return 0;
	}
}
