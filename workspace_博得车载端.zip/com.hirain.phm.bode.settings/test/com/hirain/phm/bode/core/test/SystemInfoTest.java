/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.test;

import java.util.List;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.ICarInfo;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.IMdcu;
import com.hirain.phm.bode.core.IServer;
import com.hirain.phm.bode.core.IServerIp;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.impl.Car;
import com.hirain.phm.bode.core.impl.Door;
import com.hirain.phm.bode.core.impl.Mdcu;
import com.hirain.phm.bode.core.impl.Server;
import com.hirain.phm.bode.core.impl.ServerIp;
import com.hirain.phm.bode.core.impl.ServerIpType;
import com.hirain.phm.bode.core.impl.Train;
import com.hirain.phm.bode.core.util.MarshalUtil;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 11, 2019 10:01:50 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 11, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class SystemInfoTest {

	public static void main(String[] args) {
		ITrain train = new Train();
		train.setCityName("上海");
		train.setLineName(1);
		train.setTrainNo("001");

		ICarInfo carInfo = train.getCarInfo();
		carInfo.setCarNum(10);
		carInfo.setGateNum(6);

		List<IServer> servers = train.getServers();
		IServer server1 = new Server();
		IServer server2 = new Server();

		{
			server1.setGateWay("10.60.1.101");
			List<IServerIp> servesIps = server1.getServesIps();
			IServerIp serverIp_1 = new ServerIp();
			serverIp_1.setType(ServerIpType.Type1);
			serverIp_1.setIp("198.16.0.1");
			IServerIp serverIp_2 = new ServerIp();
			serverIp_2.setType(ServerIpType.Type2);
			serverIp_2.setIp("198.16.0.2");
			servesIps.add(serverIp_1);
			servesIps.add(serverIp_2);
		}
		{
			server2.setGateWay("10.60.1.103");
			List<IServerIp> servesIps = server2.getServesIps();
			IServerIp serverIp_1 = new ServerIp();
			serverIp_1.setType(ServerIpType.Type1);
			serverIp_1.setIp("188.16.0.1");
			IServerIp serverIp_2 = new ServerIp();
			serverIp_2.setType(ServerIpType.Type2);
			serverIp_2.setIp("188.16.0.2");
			servesIps.add(serverIp_1);
			servesIps.add(serverIp_2);
		}
		servers.add(server1);
		servers.add(server2);

		List<ICar> cars = train.getCars();
		ICar car1 = new Car();
		{
			car1.setIndex(1);
			car1.setName("car1");
			car1.setType((byte) 0);
			List<IMdcu> mdcus = car1.getMdcus();
			IMdcu mdcu_1 = new Mdcu();
			IMdcu mdcu_2 = new Mdcu();
			mdcu_1.setIp("10.0.0.1");
			mdcu_2.setIp("10.0.0.8");
			mdcus.add(mdcu_1);
			mdcus.add(mdcu_2);
			List<IDoor> doors1 = car1.getDoors();
			IDoor door1_1 = new Door();
			door1_1.setAddr(5);
			IDoor door1_2 = new Door();
			door1_2.setAddr(6);
			doors1.add(door1_1);
			doors1.add(door1_2);
		}
		ICar car2 = new Car();
		{
			car2.setIndex(1);
			car2.setName("car1");
			car2.setType((byte) 0);
			List<IMdcu> mdcus = car2.getMdcus();
			IMdcu mdcu_1 = new Mdcu();
			IMdcu mdcu_2 = new Mdcu();
			mdcu_1.setIp("10.0.60.1");
			mdcu_2.setIp("10.0.60.2");
			mdcus.add(mdcu_1);
			mdcus.add(mdcu_2);
			List<IDoor> doors2 = car2.getDoors();
			IDoor door2_1 = new Door();
			door2_1.setAddr(7);
			IDoor door2_2 = new Door();
			door2_2.setAddr(8);
			doors2.add(door2_1);
			doors2.add(door2_2);
		}
		cars.add(car1);
		cars.add(car2);

		try {
			MarshalUtil.marshal(train, "C:\\Users\\zepei.tao\\Desktop\\result.xml");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
