package com.hirain.phm.bode.server.client;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.util.SystemInfoUtil;
import com.hirain.phm.bode.server.TestConstant;
import com.hirain.phm.bode.server.config.ConfigurationService;

public class TestClient {

	private static InetSocketAddress serverAddr = new InetSocketAddress(TestConstant.LOCALHOST, 17257);

	private static InetSocketAddress heartAddr = new InetSocketAddress(TestConstant.LOCALHOST, 17258);

	@BeforeClass
	public static void setUp() {
		// final ServerClientMock mock = new ServerClientMock();
		// mock.start();
	}

	@Test
	public void testLogin() throws IOException {
		final DatagramSocket client = new DatagramSocket(17229);
		final String pass = "ADMIN##admin";
		final byte[] bs = pass.getBytes();
		final ByteBuffer buffer = ByteBuffer.allocate(3 + bs.length);
		buffer.put((byte) 0x07);
		buffer.putShort((short) bs.length);
		buffer.put(bs);

		final DatagramPacket send = new DatagramPacket(buffer.array(), 3 + bs.length);
		send.setSocketAddress(serverAddr);
		client.send(send);

		final DatagramPacket receive = new DatagramPacket(new byte[4], 4);
		client.receive(receive);

		assertEquals(4, receive.getLength());
		final byte[] data = receive.getData();
		for (int i = 0; i < data.length; i++) {
			System.out.println(data[i]);
		}
		assertEquals(0x17, data[0]);
		assertEquals(0, data[3]);
		client.close();
	}

	@Test
	public void testLoginError() throws IOException {
		final DatagramSocket client = new DatagramSocket(17229);
		final String pass = "admin##12345";
		final byte[] bs = pass.getBytes();
		final ByteBuffer buffer = ByteBuffer.allocate(3 + bs.length);
		buffer.put((byte) 0x07);
		buffer.putShort((short) bs.length);
		buffer.put(bs);

		final DatagramPacket send = new DatagramPacket(buffer.array(), 3 + bs.length);
		send.setSocketAddress(serverAddr);
		client.send(send);

		final DatagramPacket receive = new DatagramPacket(new byte[4], 4);
		client.receive(receive);

		assertEquals(4, receive.getLength());
		final byte[] data = receive.getData();
		for (int i = 0; i < data.length; i++) {
			System.out.println(data[i]);
		}
		assertEquals(0x17, data[0]);
		assertEquals(1, data[3]);
		client.close();
	}

	@Test
	public void testSetting() throws Exception {
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			login1(client);
			final byte[] bs = new byte[] { 0 };
			final ByteBuffer buffer = ByteBuffer.allocate(3 + bs.length);
			buffer.put((byte) 0x01);
			buffer.putShort((short) bs.length);
			buffer.put(bs);

			final DatagramPacket send = new DatagramPacket(buffer.array(), 3 + bs.length);
			send.setSocketAddress(serverAddr);
			client.send(send);

			final DatagramPacket receive = new DatagramPacket(new byte[65535], 65535);
			client.receive(receive);

			final byte[] data = receive.getData();
			final ByteBuffer bf = ByteBuffer.wrap(data);
			final byte id = bf.get();
			assertEquals(ClientConstants.SYSTEM_CONFIG_RESPONSE, id);
			final int length = Short.toUnsignedInt(bf.getShort());
			assertEquals(0, bf.get());
			final byte[] datas = new byte[length - 1];
			bf.get(datas);
			final ITrain train = SystemInfoUtil.convertXmlBytes2SystemInfo(datas);
			System.out.println(train.getCityName());
			assertEquals("北京", train.getCityName());
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	private void login1(DatagramSocket client) throws IOException {
		final String pass = "admin##admin";
		final byte[] bs = pass.getBytes();
		final ByteBuffer buffer = ByteBuffer.allocate(3 + bs.length);
		buffer.put((byte) 0x07);
		buffer.putShort((short) bs.length);
		buffer.put(bs);

		final DatagramPacket send = new DatagramPacket(buffer.array(), 3 + bs.length);
		send.setSocketAddress(serverAddr);
		client.send(send);
		final DatagramPacket receive1 = new DatagramPacket(new byte[4], 4);
		client.receive(receive1);
	}

	@Test
	public void testSaveSetting() throws Exception {
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			login1(client);
			final ITrain train = ConfigurationService.getInstance().getTrain();
			train.setCityName("北京");
			final byte[] bs = SystemInfoUtil.convertSystemInfo2XmlBytes(train);
			final ByteBuffer buffer = ByteBuffer.allocate(3 + bs.length);
			buffer.put((byte) 0x03);
			buffer.putShort((short) bs.length);
			buffer.put(bs);

			final DatagramPacket send = new DatagramPacket(buffer.array(), 3 + bs.length);
			send.setSocketAddress(serverAddr);
			client.send(send);

			final DatagramPacket receive = new DatagramPacket(new byte[4], 4);
			client.receive(receive);

			final byte[] bs2 = receive.getData();
			assertEquals(0x13, bs2[0]);
			assertEquals(0, bs2[3]);

			final ITrain result = ConfigurationService.getInstance().getTrain();
			assertEquals("北京", result.getCityName());
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	@Test
	public void testStorage() throws IOException {
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			login1(client);
			final ByteBuffer buffer = ByteBuffer.allocate(4);
			buffer.put((byte) 0x02);
			buffer.putShort((short) 1);
			buffer.put((byte) 0);

			final DatagramPacket send = new DatagramPacket(buffer.array(), 4);
			send.setSocketAddress(serverAddr);
			client.send(send);

			final DatagramPacket receive = new DatagramPacket(new byte[20], 20);
			client.receive(receive);

			final ByteBuffer buf = ByteBuffer.wrap(receive.getData());
			assertEquals(0x12, buf.get());
			assertEquals(17, buf.getShort());
			assertEquals(0, buf.get());
			final long total = buf.getLong() / 1024 / 1024 / 1024;
			System.out.println(total);
			final long used = buf.getLong() / 1024 / 1024 / 1024;
			System.out.println(used);
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	@Test
	public void testDebug() throws IOException {
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			login1(client);
			final ByteBuffer buffer = ByteBuffer.allocate(4);
			buffer.put((byte) 0x06);
			buffer.putShort((short) 1);
			buffer.put((byte) 1);

			final DatagramPacket send = new DatagramPacket(buffer.array(), 4);
			send.setSocketAddress(serverAddr);
			client.send(send);

			final DatagramPacket receive = new DatagramPacket(new byte[4], 4);
			client.receive(receive);
			final ByteBuffer buf = ByteBuffer.wrap(receive.getData());

			assertEquals(0x16, buf.get());
			assertEquals(1, buf.getShort());
			assertEquals(0, buf.get());
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	@Test
	@Ignore
	public void testDownload() throws IOException {
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			final ByteBuffer buffer = ByteBuffer.allocate(4);
			buffer.put((byte) 0x05);
			buffer.putShort((short) 1);
			buffer.put((byte) 1);

			final DatagramPacket send = new DatagramPacket(buffer.array(), 4);
			send.setSocketAddress(serverAddr);
			client.send(send);

			final DatagramPacket receive = new DatagramPacket(new byte[4], 4);
			client.receive(receive);
			final ByteBuffer buf = ByteBuffer.wrap(receive.getData());

			assertEquals(0x15, buf.get());
			assertEquals(1, buf.getShort());
			assertEquals(0, buf.get());
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	@Test
	public void testHeart() throws IOException, InterruptedException {
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17255);
			login1(client);
			DatagramPacket packet;
			DatagramPacket receive;
			final byte[] buf = new byte[] { (byte) 0xAA, 0, 1, 0 };
			for (int i = 0; i < 4; i++) {
				packet = new DatagramPacket(buf, 4);
				packet.setSocketAddress(heartAddr);
				client.send(packet);
				receive = new DatagramPacket(new byte[4], 4);
				client.receive(receive);
				final byte[] data = receive.getData();
				assertEquals(0xBB, data[0] & 0xff);
				TimeUnit.SECONDS.sleep(3);
			}
			TimeUnit.SECONDS.sleep(15);

			for (int i = 0; i < 2; i++) {
				packet = new DatagramPacket(buf, 4);
				packet.setSocketAddress(heartAddr);
				client.send(packet);
				receive = new DatagramPacket(new byte[4], 4);
				client.receive(receive);
				final byte[] data = receive.getData();
				assertEquals(0xBB, data[0] & 0xff);
				TimeUnit.SECONDS.sleep(3);
			}
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}
}
