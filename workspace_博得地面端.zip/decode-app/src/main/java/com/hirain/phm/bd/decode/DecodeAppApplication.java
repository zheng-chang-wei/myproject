package com.hirain.phm.bd.decode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DecodeAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DecodeAppApplication.class, args);
	}

}
