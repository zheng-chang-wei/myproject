/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.widget;

import org.eclipse.draw2d.FigureCanvas;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bode.client.communication.parse.DoorInfoParseHandler;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.dataframe.DoorStatus;
import com.hirain.phm.bode.core.dataframe.IDataFrame;
import com.hirain.phm.bode.core.dataframe.RunDataFrame;
import com.hirain.phm.bode.ui.monitor.TrainManager;
import com.hirain.phm.bode.ui.monitor.figure.carriage.TrainFigure;
import com.hirain.phm.bode.ui.monitor.listener.DoorCheckedListener;
import com.hirain.phm.bode.ui.monitor.listener.HandlerDoorDestroyManager;
import com.hirain.phm.bode.ui.monitor.listener.HandlerDoorStateManager;
import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月17日 下午7:49:32
 * @Description
 *              <p>
 *              左侧四个part的父类
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月17日 changwei.zheng@hirain.com 1.0 create file
 */
public class CommonPart implements DoorCheckedListener {

	protected RunDataFrame dataFrame;

	private Composite doorInfoComposite;

	private FigureCanvas topologicalCanvas;

	protected ITrain train;

	protected boolean init = false;

	protected Composite coreComposite;

	protected ScrolledComposite scrolledComposite;

	private Label title;

	public CommonPart() {
		DoorInfoParseHandler.getInstance().getEventBus().register(this);
	}

	public RunDataFrame getDataFrame() {
		return dataFrame;
	}

	public void postConstruct(final Composite parent) {
		scrolledComposite = new ScrolledComposite(parent, SWT.H_SCROLL | SWT.V_SCROLL);
		// scrolledComposite.setBackground(CarriageConstants.commonBackgroundColor);
		scrolledComposite.setLayoutData(new GridData(GridData.FILL_BOTH));
		scrolledComposite.setLayout(new FillLayout());
		coreComposite = new Composite(scrolledComposite, SWT.None);
		// reviewGroup.setBackground(CarriageConstants.commonBackgroundColor);
		coreComposite.setLayout(new GridLayout(1, false));
		final GridData data = new GridData(GridData.FILL_BOTH);
		coreComposite.setLayoutData(data);
		scrolledComposite.setContent(coreComposite);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		createWarningArea(coreComposite);
		Composite titleComposite = new Composite(coreComposite, SWT.NONE);
		titleComposite.setLayout(new GridLayout(2, false));
		titleComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		title = new Label(titleComposite, SWT.NONE);
		setTitle();
		title.setFont(CarriageConstants.title_font);
		title.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, true));
		createRefreshFrequencyArea(titleComposite);
		doorInfoComposite = new Composite(coreComposite, SWT.None);
		doorInfoComposite.setLayout(new GridLayout(2, false));
		doorInfoComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		// doorInfoComposite.setBackground(CarriageConstants.commonBackgroundColor);

		createDoorInfoArea();
		init = true;
	}

	private void setTitle() {
		if (train != null) {
			Integer lineName = train.getLineName();
			String cityName = train.getCityName();
			String trainNo = train.getTrainNo();
			title.setText(cityName + "地铁 " + lineName + "号线 " + trainNo + "号列车");
			title.getParent().layout();
		}
	}

	protected void linkToScroll(final Composite composite) {
		composite.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseDown(MouseEvent e) {
				coreComposite.setFocus();
			}
		});
		composite.addMouseTrackListener(new MouseTrackListener() {

			@Override
			public void mouseHover(MouseEvent e) {
			}

			@Override
			public void mouseExit(MouseEvent e) {
			}

			@Override
			public void mouseEnter(MouseEvent e) {
				coreComposite.setFocus();
			}
		});
	}

	protected void createWarningArea(Composite titleComposite) {
	}

	protected void createRefreshFrequencyArea(Composite titleComposite) {
	}

	private void createDoorInfoArea() {
		train = TrainManager.getInstance().getTrain();
		topologicalCanvas = new FigureCanvas(doorInfoComposite) {

			@Override
			public boolean setFocus() {
				return false;
			}
		};
		linkToScroll(doorInfoComposite);
		linkToScroll(topologicalCanvas);
		refreshFigure();
	}

	public void refreshFigure() {
		if (train != null) {
			setTitle();
			HandlerDoorDestroyManager.getInstatnce().distroy();
			HandlerDoorDestroyManager.getInstatnce().remove();

			TrainFigure trainFigure = new TrainFigure(train, false);
			topologicalCanvas.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, true));
			topologicalCanvas.setContents(trainFigure);
			// topologicalCanvas.setBackground(CarriageConstants.commonBackgroundColor);
			doorInfoComposite.layout();
		}
	}

	public boolean isInit() {
		return init;
	}

	public void setTrain(ITrain train) {
		this.train = train;
	}

	@Override
	public void doorChecked(ICar car, int doorIndex) {
	}

	@Override
	public void mdcuChecked(ICar car) {

	}

	@Override
	public void carChecked(ICar car) {

	}

	protected void refreshDoorState(DoorStatus doorStatus) {
		HandlerDoorStateManager.getInstatnce().refresh(doorStatus);
	}

	/**
	 * 接收解析好的车门状态数据
	 * 
	 * @param doorStatus
	 */
	@Subscribe
	public void receivedDoorStatusData(DoorStatus doorStatus) {
		Display.getDefault().asyncExec(new Runnable() {

			@Override
			public void run() {
				refreshDoorState(doorStatus);
			}
		});
	}

	/**
	 * 接收解析好的实时数据（已经根据车门地址过滤好了）
	 * 
	 * @param dataFrame
	 */
	@Subscribe
	public void receivedRealtimeData(IDataFrame dataFrame) {

	}
}
