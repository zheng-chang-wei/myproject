/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.exception;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 9, 2019 4:20:23 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 9, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class SystemInfoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4628736172124322109L;

	private String description;

	public SystemInfoException(String description) {
		this.description = description;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

}
