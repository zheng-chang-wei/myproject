package com.hirain.phm.bode.ui.monitor.figure.carriage;

import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.monitor.model.CarriageConstants;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created Jan 7, 2019 10:23:49 AM
 * @Description
 *              <p>
 *              车尾
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 7, 2019 changwei.zheng@hirain.com 1.0 create file
 */
public class CarriageEndFigure extends CommonCarriageFigure {

	public CarriageEndFigure(ICar car, boolean isConfig) {
		super(car, isConfig);
		setLayoutManager(new XYLayout());
		add(label, new Rectangle(0, 0, CarriageConstants.carriageHeadWidth, CarriageConstants.carriageHeight));
		DoorFigure doorFigure1 = new DoorFigure("1", isConfig);
		doorFigureMap.put(car.getIndex() + StringUtil.UNDER_LINE + doorFigure1.getName(), doorFigure1);
		DoorFigure doorFigure2 = new DoorFigure("2", isConfig);
		doorFigureMap.put(car.getIndex() + StringUtil.UNDER_LINE + doorFigure2.getName(), doorFigure2);
		add(doorFigure1, new Rectangle(CarriageConstants.carriageHorizontalSpacing, 0, CarriageConstants.doorWidth, CarriageConstants.doorWidth));
		add(doorFigure2, new Rectangle(CarriageConstants.carriageHorizontalSpacing, CarriageConstants.carriageHeight - CarriageConstants.doorWidth,
				CarriageConstants.doorWidth, CarriageConstants.doorWidth));
		addListener();
	}

	@Override
	protected void paintFigure(Graphics g) {
		Rectangle r = bounds;

		g.fillArc(r.x, r.y, r.height - 1, r.height - 1, 270, 180);
		g.fillRectangle(r.x + 1, r.y + 1, r.width / 2 - 2, r.height - 2);
		g.drawLine(r.x, r.y, r.x + r.width / 2, r.y);
		g.drawLine(r.x, r.y + r.height - 1, r.x + r.width / 2, r.y + r.height - 1);
		g.drawLine(r.x, r.y, r.x, r.y + r.height - 1);
		g.drawArc(r.x, r.y, r.height - 1, r.height - 1, 270, 180);

		super.paintFigure(g);
	}

	/**
	 * 获取一节车厢的宽度
	 */
	@Override
	public int getCarriageWidth() {
		return CarriageConstants.carriageHeadWidth;
	}
}
