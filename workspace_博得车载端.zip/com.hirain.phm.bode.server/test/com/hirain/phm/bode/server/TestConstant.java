package com.hirain.phm.bode.server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;
import java.util.List;

import com.hirain.phm.bode.server.query.TestClientCount;

public class TestConstant {

	public static String LOCALHOST = "10.40.30.132";

	static {
		List<String> locahosts = Utils.locahosts();
		LOCALHOST = locahosts.get(0);
	}

	public static void login1(DatagramSocket client) throws IOException {
		String pass = "admin##admin";
		byte[] bs = pass.getBytes();
		ByteBuffer buffer = ByteBuffer.allocate(3 + bs.length);
		buffer.put((byte) 0x07);
		buffer.putShort((short) bs.length);
		buffer.put(bs);
	
		DatagramPacket send = new DatagramPacket(buffer.array(), 3 + bs.length);
		send.setSocketAddress(TestClientCount.address);
		client.send(send);
		DatagramPacket receive1 = new DatagramPacket(new byte[4], 4);
		client.receive(receive1);
	}
}
