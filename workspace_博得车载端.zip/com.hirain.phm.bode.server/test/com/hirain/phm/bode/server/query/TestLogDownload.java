package com.hirain.phm.bode.server.query;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Test;

import com.hirain.phm.bode.server.TestConstant;
import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ServerClientMock;
import com.hirain.phm.bode.server.client.Token;
import com.hirain.phm.bode.server.client.data.LogDataDownloadHandler;

public class TestLogDownload {

	File file = new File("E:\\test\\test_log.txt");

	@Test
	public void test() throws InterruptedException {
		new LogDataDownloadHandler((address, pid, datas) -> {
			System.out.println(Integer.toHexString(pid));
			final ByteBuffer buffer = ByteBuffer.wrap(datas);
			final byte type = buffer.get();
			if (type == 6) {
				System.out.println("EOF");
				return;
			}
			final byte[] bs = new byte[datas.length - 1];
			buffer.get(bs);
			try {
				FileUtils.writeByteArrayToFile(file, bs, true);
			} catch (final IOException e) {
				e.printStackTrace();
			}
		}, "2019-02-15", ClientConstants.LOG_TAG, new Token("", null)).work();
		TimeUnit.SECONDS.sleep(5);
	}

	private static InetSocketAddress address = new InetSocketAddress(TestConstant.LOCALHOST, 17257);

	public static void setUp() {
		final ServerClientMock mock = new ServerClientMock();
		mock.start();
	}

	@Test
	public void testClient() throws IOException {
		setUp();
		DatagramSocket client = null;
		try {
			client = new DatagramSocket(17229);
			TestConstant.login1(client);
			final ByteBuffer buffer = ByteBuffer.allocate(4 + 3);
			buffer.put((byte) 0x0c);
			buffer.putShort((short) 4);
			buffer.put((byte) 0x05);
			buffer.put((byte) 19);
			buffer.put((byte) 2);
			buffer.put((byte) 20);
			send(client, buffer.array(), address);
			while (true) {
				final DatagramPacket packet = new DatagramPacket(new byte[1024], 1024);
				client.receive(packet);
				final byte[] data = packet.getData();
				final ByteBuffer bf = ByteBuffer.wrap(data);
				assertEquals(0x1a, bf.get());
				final int length = Short.toUnsignedInt(bf.getShort());
				final byte type = bf.get();
				if (type == 6) {
					System.out.println("eof");
					break;
				}
				final byte[] bs = new byte[length];
				bf.get(bs);
				FileUtils.writeByteArrayToFile(file, bs, true);
			}
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	public void send(DatagramSocket socket, byte[] data, InetSocketAddress address) throws IOException {
		final DatagramPacket send = new DatagramPacket(data, data.length, address);
		socket.send(send);
	}
}
