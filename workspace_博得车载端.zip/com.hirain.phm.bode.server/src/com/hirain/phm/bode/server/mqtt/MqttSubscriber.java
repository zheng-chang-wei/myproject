package com.hirain.phm.bode.server.mqtt;

import org.eclipse.paho.client.mqttv3.MqttException;

public interface MqttSubscriber {

	public void subscribe(String topic, int qos) throws MqttException;

	public void subscribe(String topic) throws MqttException;
}
