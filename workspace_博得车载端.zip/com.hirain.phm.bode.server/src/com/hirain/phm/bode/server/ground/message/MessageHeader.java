package com.hirain.phm.bode.server.ground.message;

public class MessageHeader {

	public int sid;
}
