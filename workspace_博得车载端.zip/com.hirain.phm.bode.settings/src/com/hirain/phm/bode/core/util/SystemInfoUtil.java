/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.ICarInfo;
import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.core.IMdcu;
import com.hirain.phm.bode.core.IServer;
import com.hirain.phm.bode.core.IServerIp;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.exception.SystemInfoException;
import com.hirain.phm.bode.core.impl.Car;
import com.hirain.phm.bode.core.impl.Door;
import com.hirain.phm.bode.core.impl.Mdcu;
import com.hirain.phm.bode.core.impl.Server;
import com.hirain.phm.bode.core.impl.ServerIp;
import com.hirain.phm.bode.core.impl.ServerIpType;
import com.hirain.phm.bode.core.impl.Train;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 11:25:47 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class SystemInfoUtil {

	private static final int SYSTEMINFO_MESSAGE_BASESIZE = 53;

	/**
	 * 校验系统信息配置文件是否有效
	 * 
	 * @param train
	 */
	public static void vaildModel(ITrain train) throws Exception {
		StringBuilder errorMessage = new StringBuilder(StringUtil.EMPTY);
		int lineName = train.getLineName();
		if (StringUtil.isEmpty(String.valueOf(lineName))) {
			errorMessage.append("线路名称不能为空");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		}
		if (lineName < 1 || lineName > 255) {
			errorMessage.append("线路名称超出范围");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		}
		String trainNo = train.getTrainNo();
		if (StringUtil.isEmpty(trainNo)) {
			errorMessage.append("列车编号不能为空");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		}
		String cityName = train.getCityName();
		if (StringUtil.isEmpty(cityName)) {
			errorMessage.append("城市名称不能为空");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		}
		// 校验服务器信息
		List<IServer> servers = train.getServers();
		if (servers.size() != 2) {// 校验服务器数量是否为2
			errorMessage.append("服务器数量不为2");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		} else if (servers.get(0).getServesIps().size() != 2 || servers.get(1).getServesIps().size() != 2) {// 校验每个服务器下是否对应2个IP地址
			errorMessage.append("服务器对应的IP地址数量不为2");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		} else if (!(verfityIp(servers.get(0).getServesIps().get(0).getIp()) && verfityIp(servers.get(0).getServesIps().get(1).getIp())
				&& verfityIp(servers.get(1).getServesIps().get(0).getIp()) && verfityIp(servers.get(1).getServesIps().get(1).getIp()))) {// 校验IP地址格式是否正确
			errorMessage.append("服务器对应IP地址格式不正确");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		} else if (StringUtil.isEmpty(servers.get(0).getGateWay()) || StringUtil.isEmpty(servers.get(1).getGateWay())) {
			errorMessage.append("服务器无线网关地址不能为空");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		}
		// 校验车厢信息
		ICarInfo carInfo = train.getCarInfo();
		int carNum = carInfo.getCarNum();
		if (StringUtil.isEmpty(String.valueOf(carNum))) {
			errorMessage.append("车厢数量不能为空");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		}
		int gateNum = carInfo.getGateNum();
		if (StringUtil.isEmpty(String.valueOf(gateNum))) {
			errorMessage.append("车门数量不能为空");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		}
		if (gateNum < 0 || gateNum > 12 || gateNum % 2 != 0) {
			errorMessage.append("gateNum值应是[ 2,12 ]之间偶数");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		}

		// 校验车厢内部具体信息
		List<ICar> cars = train.getCars();
		if (cars.size() < 2) {
			errorMessage.append("缺少车头信息");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		}
		if (cars.size() - 2 != carNum) {
			errorMessage.append("carNum值与实际车厢数量不一致");
			errorMessage.append(StringUtil.LINE_SEPARATOR);
		}
		ICar car = null;
		Map<Integer, String> doorAddrMap = new HashMap<Integer, String>();
		Map<String, String> mdcuIpMap = new HashMap<String, String>();
		for (int i = 0; i < 2; i++) {
			doorAddrMap.clear();
			car = cars.get(i);
			for (IDoor door : car.getDoors()) {
				int addr = door.getAddr();
				if (doorAddrMap.get(addr) != null) {
					errorMessage.append(doorAddrMap.get(addr) + " 车厢门地址有重复");
					errorMessage.append(StringUtil.LINE_SEPARATOR);
				}
				doorAddrMap.put(addr, car.getName());
				if (addr < 1 || addr > 12) {
					errorMessage.append("车头门地址超出范围");
					errorMessage.append(StringUtil.LINE_SEPARATOR);
				}
			}
		}
		for (int i = 2; i < cars.size(); i++) {
			doorAddrMap.clear();
			mdcuIpMap.clear();
			car = cars.get(i);
			int mdcuAmount = car.getMdcus().size();
			if (mdcuAmount != 2) {// 校验每个车厢下的mdcu数量是否为2
				errorMessage.append("普通车厢中的mdcu数量有误");
				errorMessage.append(StringUtil.LINE_SEPARATOR);
			}
			for (IMdcu mdcu : car.getMdcus()) {
				if (!verfityIp(mdcu.getIp())) {
					errorMessage.append("车厢mdcu对应IP地址格式不正确");
					errorMessage.append(StringUtil.LINE_SEPARATOR);
				}
				if (mdcuIpMap.get(mdcu.getIp()) != null) {
					errorMessage.append(mdcuIpMap.get(mdcu.getIp()) + " 车厢中mdcu的IP地址重复");
					errorMessage.append(StringUtil.LINE_SEPARATOR);
				}
				mdcuIpMap.put(mdcu.getIp(), car.getName());
			}
			int doorAmount = car.getDoors().size();
			if (doorAmount != gateNum) {// 校验每个车厢下的车门数量是否和carInfo中的gateNum数量一致
				errorMessage.append("普通车厢中的车门数量与gateNum值不一致");
				errorMessage.append(StringUtil.LINE_SEPARATOR);
			}
			for (IDoor door : car.getDoors()) {
				int addr = door.getAddr();
				if (doorAddrMap.get(addr) != null) {
					errorMessage.append(doorAddrMap.get(addr) + " 车厢中门地址有重复");
					errorMessage.append(StringUtil.LINE_SEPARATOR);
				}
				doorAddrMap.put(addr, car.getName());
				if (addr < 1 || addr > 12) {
					errorMessage.append("普通车厢门地址超出范围");
					errorMessage.append(StringUtil.LINE_SEPARATOR);
				}
			}
		}
		if (StringUtil.isNotEmpty(errorMessage.toString())) {
			throw new SystemInfoException(errorMessage.toString());
		}
	}

	/**
	 * 将xml字符串的byte数组转换成系统信息
	 */
	public static ITrain convertXmlBytes2SystemInfo(final byte[] xmlBytes) throws Exception {
		return MarshalUtil.unmarshalXmlstr2SystemInfo(new String(xmlBytes, "UTF-8"));
	}

	/**
	 * 将系统信息转换成xml字符串的byte数组
	 */
	public static byte[] convertSystemInfo2XmlBytes(ITrain train) throws Exception {
		return MarshalUtil.marshalSystemInfo2XmlBytes(train);
	}

	/**
	 * 将报文数据转换成系统信息
	 * 
	 * @param messageBytes
	 */
	public static ITrain convertBytes2SystemInfo(final byte[] messageBytes) {
		if (messageBytes.length == 0) {
			return null;
		}
		final ByteBuffer buffer = ByteBuffer.wrap(messageBytes).order(ByteOrder.LITTLE_ENDIAN);
		byte carNum, doorNum;
		ITrain train = new Train();
		{
			// 城市名称
			final byte[] cityName = new byte[2];
			buffer.get(cityName);
			train.setCityName(new String(cityName).toUpperCase());

			// 线路名称
			byte lineName = buffer.get();
			train.setLineName(Byte.toUnsignedInt(lineName));

			// 列车编号
			byte[] trainNo = new byte[8];
			buffer.get(trainNo);
			train.setTrainNo(new String(trainNo).trim());

			// 车厢数量
			carNum = buffer.get();
			train.getCarInfo().setCarNum(carNum);

			// 每节车厢门数
			doorNum = buffer.get();
			train.getCarInfo().setGateNum(doorNum);
		}
		{
			for (int i = 0; i < 2; i++) {
				// 服务器的无线网关地址
				byte[] gateWay = new byte[4];
				buffer.get(gateWay);
				IServer server = new Server();
				train.getServers().add(server);
				server.setGateWay(convertBytes2Ip(gateWay));

				// 服务器的type1的ip地址
				byte[] ip1 = new byte[4];
				buffer.get(ip1);
				IServerIp serverip_1 = new ServerIp();
				serverip_1.setIp(convertBytes2Ip(ip1));
				serverip_1.setType(ServerIpType.Type1);
				server.getServesIps().add(serverip_1);

				// 服务器的type2的ip地址
				byte[] ip2 = new byte[4];
				buffer.get(ip2);
				IServerIp serverip_2 = new ServerIp();
				serverip_2.setIp(convertBytes2Ip(ip2));
				serverip_2.setType(ServerIpType.Type2);
				server.getServesIps().add(serverip_2);

			}
		}
		{// 车头尾信息
			for (int i = 0; i < 2; i++) {
				ICar car = new Car();
				// 车头尾地址
				byte carAddr = buffer.get();
				car.setIndex(carAddr);
				// 车头尾Type
				byte carType = buffer.get();
				car.setType(carType);
				// 车头尾 Name
				byte[] carName = new byte[4];
				buffer.get(carName);
				car.setName(new String(carName).trim());
				for (int j = 0; j < 2; j++) {
					// 车头尾门地址
					byte doorAddr = buffer.get();
					IDoor door = new Door();
					door.setAddr(doorAddr);
					car.getDoors().add(door);
				}
				train.getCars().add(car);
			}
		}
		{// 车厢具体信息
			for (int i = 0; i < carNum; i++) {
				ICar car = new Car();
				// 地址
				byte carAddr = buffer.get();
				car.setIndex(carAddr);
				// Type
				byte carType = buffer.get();
				car.setType(carType);
				// Name
				byte[] carName = new byte[4];
				buffer.get(carName);
				car.setName(new String(carName).trim());
				// mdcu_1 ip地址
				byte[] ip_mdcu1 = new byte[4];
				buffer.get(ip_mdcu1);
				IMdcu mdcu_1 = new Mdcu();
				mdcu_1.setIp(convertBytes2Ip(ip_mdcu1));
				car.getMdcus().add(mdcu_1);
				// mdcu_2 ip地址
				byte[] ip_mdcu2 = new byte[4];
				buffer.get(ip_mdcu2);
				IMdcu mdcu_2 = new Mdcu();
				mdcu_2.setIp(convertBytes2Ip(ip_mdcu2));
				car.getMdcus().add(mdcu_2);
				// 车门信息
				for (int j = 0; j < doorNum; j++) {
					IDoor door = new Door();
					byte doorAddr = buffer.get();
					door.setAddr(doorAddr);
					car.getDoors().add(door);
				}

				train.getCars().add(car);
			}
		}
		return train;
	}

	/**
	 * 将系统信息转换为报文数据
	 * 
	 * @param train
	 */
	public static byte[] convertSystemInfo2Bytes(ITrain train) {
		String cityName = train.getCityName();
		int lineName = train.getLineName();
		String trainNo = train.getTrainNo();
		int carNum = train.getCarInfo().getCarNum();
		int gateNum = train.getCarInfo().getGateNum();

		int messageSize = SYSTEMINFO_MESSAGE_BASESIZE + carNum * (14 + gateNum * 1);
		final ByteBuffer buffer = ByteBuffer.allocate(messageSize).order(ByteOrder.LITTLE_ENDIAN);

		// 城市名称
		buffer.put(convertString2Bytes(cityName.toUpperCase(), 2));
		// 线路名称
		buffer.put((byte) lineName);
		// 列车编号
		buffer.put(convertString2Bytes(trainNo, 8));

		// 车厢节数
		buffer.put((byte) carNum);
		// 每节车厢门数
		buffer.put((byte) gateNum);
		// 服务器信息
		for (IServer server : train.getServers()) {
			buffer.put(convertIp2Bytes(server.getGateWay()));// 无线网关地址
			buffer.put(convertIp2Bytes(server.getServesIps().get(0).getIp()));// type 1 的IP
			buffer.put(convertIp2Bytes(server.getServesIps().get(1).getIp()));// type 2 的IP
		}
		// 车头尾信息
		for (int i = 0; i < 2; i++) {
			ICar car = train.getCars().get(i);
			buffer.put((byte) car.getIndex());// index/addr
			buffer.put(car.getType());// type
			buffer.put(convertString2Bytes(car.getName(), 4));// name
			for (int j = 0; j < 2; j++) {
				IDoor door = car.getDoors().get(j);
				buffer.put((byte) door.getAddr());// 门地址
			}
		} // 车厢信息
		for (int i = 0; i < carNum; i++) {
			ICar car = train.getCars().get(i + 2);
			buffer.put((byte) car.getIndex());// index/addr
			buffer.put(car.getType());
			buffer.put(convertString2Bytes(car.getName(), 4));// name
			buffer.put(convertIp2Bytes(car.getMdcus().get(0).getIp()));// mdcu1的IP地址
			buffer.put(convertIp2Bytes(car.getMdcus().get(1).getIp()));// mdcu2的IP 地址
			for (int j = 0; j < gateNum; j++) {
				IDoor door = car.getDoors().get(j);
				buffer.put((byte) door.getAddr());// 门地址
			}
		}

		return buffer.array();
	}

	/**
	 * 校验IP地址的格式
	 */
	private static boolean verfityIp(String IPValue) {
		String HOST_IP = "^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])\\." + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
				+ "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\." + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)";
		final Pattern pattern = Pattern.compile(HOST_IP);
		final Matcher matcher = pattern.matcher(IPValue);
		if (!matcher.matches()) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 将字符串转换成指定长度的byte数组
	 * 
	 * @param str
	 * @param length
	 *            byte数组长度
	 * @return
	 */
	private static byte[] convertString2Bytes(String str, int length) {
		final ByteBuffer buffer = ByteBuffer.allocate(length).order(ByteOrder.LITTLE_ENDIAN);
		buffer.put(str.getBytes());
		return buffer.array();
	}

	/**
	 * 将ip地址转成4字节数组
	 * 
	 * @param str
	 * @return
	 */
	private static byte[] convertIp2Bytes(String str) {
		byte[] ip = new byte[4];
		String[] split = str.split("\\" + StringUtil.DOAT);
		if (split.length == 4) {
			for (int i = 0; i < 4; i++) {
				ip[i] = (byte) (int) Integer.valueOf(split[i]);
			}
			return ip;
		}
		return ip;
	}

	/**
	 * 将4字节数组转成ip地址
	 * 
	 * @param bytes
	 * @return
	 */
	private static String convertBytes2Ip(byte[] bytes) {
		if (bytes.length == 4) {
			StringBuilder sb = new StringBuilder();
			sb.append(String.valueOf(Byte.toUnsignedInt(bytes[0])));
			sb.append(StringUtil.DOAT);
			sb.append(String.valueOf(Byte.toUnsignedInt(bytes[1])));
			sb.append(StringUtil.DOAT);
			sb.append(String.valueOf(Byte.toUnsignedInt(bytes[2])));
			sb.append(StringUtil.DOAT);
			sb.append(String.valueOf(Byte.toUnsignedInt(bytes[3])));
			return sb.toString();
		}
		return StringUtil.EMPTY;
	}

}
