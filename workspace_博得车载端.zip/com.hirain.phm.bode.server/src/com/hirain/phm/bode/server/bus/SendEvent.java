package com.hirain.phm.bode.server.bus;

import lombok.ToString;

@ToString
public class SendEvent {

	private byte pid;

	private byte[] datas;

	public SendEvent() {
	}

	public SendEvent(byte pid, byte[] datas) {
		super();
		this.pid = pid;
		this.datas = datas;
	}

	public byte getPid() {
		return pid;
	}

	public void setPid(byte pid) {
		this.pid = pid;
	}

	public byte[] getDatas() {
		return datas;
	}

	public void setDatas(byte[] datas) {
		this.datas = datas;
	}
}
