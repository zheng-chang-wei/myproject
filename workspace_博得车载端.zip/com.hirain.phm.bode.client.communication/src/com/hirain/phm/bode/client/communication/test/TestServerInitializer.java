package com.hirain.phm.bode.client.communication.test;

import com.hirain.phm.bode.client.communication.service.ServiceHandler;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;

public class TestServerInitializer extends ChannelInitializer<SocketChannel> {

	@Override
	protected void initChannel(SocketChannel ch) throws Exception {
		ChannelPipeline pipeline = ch.pipeline();

		pipeline.addLast(TestMessageCodec.class.getName(), new TestMessageCodec());
		pipeline.addLast(ServiceHandler.class.getName(), new TestServiceHandler());
	}
}
