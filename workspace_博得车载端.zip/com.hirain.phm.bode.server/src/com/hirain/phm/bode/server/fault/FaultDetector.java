package com.hirain.phm.bode.server.fault;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.server.message.DoorMessage;

class FaultDetector {

	private final Map<Integer, DoorFaultProcessor> cache = new ConcurrentHashMap<>();

	private final BlockingQueue<List<DoorMessage>> queue = new LinkedBlockingQueue<>();

	private ExecutorService detectExecutor;

	private final AtomicBoolean hadDebug = new AtomicBoolean(false);

	private boolean debug;

	private final int carriageId;

	public FaultDetector(int carriageId, List<IDoor> doors) {
		this.carriageId = carriageId;
		final Date now = new Date();
		for (final IDoor door : doors) {
			final DoorFaultProcessor doorFault = new DoorFaultProcessor(door.getAddr(), carriageId, now);
			cache.put(door.getAddr(), doorFault);
		}
		detectExecutor = Executors.newSingleThreadExecutor(r -> new Thread(r, "fault detactor-" + carriageId));
	}

	public void work() {
		System.out.println("fault detector-" + carriageId);
		detectExecutor.submit(() -> {
			while (true) {
				final List<DoorMessage> list = queue.take();
				// final DoorFaultProcessor doorFault = cache.get(list.get(0).getDoorId());
				for (final DoorMessage message : list) {
					final DoorFaultProcessor doorFault = cache.get(message.getDoorId());
					final byte[] datas = message.getDatas();
					doorFault.updateState(message, debug);
					final int insulateBit = MessageBitDecoder.getInsulateBit(datas);
					if (insulateBit == 0) {
						doorFault.update(message, hadDebug.get());
					}
					final int openBit = MessageBitDecoder.getOpenBit(datas);
					if (doorFault.checkOpen(openBit)) {
						System.out.println(String.format("carriage-%d,door-%d, open", message.getCarriageId(), message.getDoorId()));
						hadDebug.set(debug);
						doorFault.setStartTime2(message.getTimestamp());
						continue;
					}
					final int closeBit = MessageBitDecoder.getCloseBit(datas);
					if (doorFault.checkClosed(closeBit)) {
						System.out.println(String.format("carriage-%d,door-%d, close", message.getCarriageId(), message.getDoorId()));
						doorFault.updateRecord(message.getTimestamp());
					} else if (doorFault.checkIsulated(insulateBit)) {
						System.out.println(String.format("carriage-%d,door-%d, insulate", message.getCarriageId(), message.getDoorId()));
						doorFault.updateRecord(message.getTimestamp());
					}
					cache.put(message.getDoorId(), doorFault);
				}
			}
		});
	}

	public void stop() {
		if (detectExecutor != null) {
			detectExecutor.shutdown();
			detectExecutor = null;
		}
		for (final DoorFaultProcessor processor : cache.values()) {
			processor.updateRecord(new Date());
			processor.stop();
		}
	}

	public void push(List<DoorMessage> messages) {
		try {
			queue.put(messages);
		} catch (final InterruptedException e) {
			DoorFaultProcessor.logger.error(e.getMessage(), e);
		}
	}

	public void setDebug(boolean debug) {
		this.debug = debug;
		if (debug) {
			hadDebug.set(debug);
		}
	}

}
