package com.hirain.phm.bode.ui.fault.provider;

import java.util.List;

import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.swt.graphics.Image;

import com.hirain.phm.bode.core.fault.Fault;
import com.hirain.phm.bode.core.fault.FaultRecord;
import com.hirain.phm.bode.core.util.StringUtil;

public class TableViewerlabelProvider implements ITableLabelProvider {

	private List<Fault> faults;

	public TableViewerlabelProvider(List<Fault> faults) {
		this.faults = faults;
	}

	@Override
	public void addListener(ILabelProviderListener listener) {

	}

	@Override
	public void dispose() {

	}

	@Override
	public boolean isLabelProperty(Object element, String property) {
		return false;
	}

	@Override
	public void removeListener(ILabelProviderListener listener) {

	}

	@Override
	public Image getColumnImage(Object element, int columnIndex) {
		return null;
	}

	@Override
	public String getColumnText(Object element, int columnIndex) {
		if (element instanceof FaultRecord) {

			FaultRecord faultRecord = (FaultRecord) element;
			String timestamp = faultRecord.getTimestamp();
			if (StringUtil.isEmpty(timestamp)) {
				if (columnIndex == 0) {
					return "数据库中没有符合条件的记录";
				}
			} else {

				switch (columnIndex) {
				case 0:
					return timestamp;
				case 1:
					if (faults != null) {
						for (Fault fault : faults) {
							if (fault.getId() == Integer.valueOf(faultRecord.getFaultId())) {
								return fault.getCname();
							}
						}
					}
					return StringUtil.EMPTY;
				case 2:
					return faultRecord.getFaultId();
				case 3:
					return faultRecord.getCarriageId();
				case 4:
					return faultRecord.getDoorId();
				case 5:
					return faultRecord.getDebug() ? "是" : "否";
				default:
					break;
				}
			}
		}
		return StringUtil.EMPTY;
	}

}
