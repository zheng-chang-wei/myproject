package com.hirain.phm.bode.server.message;

import java.util.Date;

public class DoorMessage {

	private Long id;

	private Integer carriageId;

	private Integer doorId;

	private byte[] datas;

	private Date timestamp;

	private int milli;

	public Integer getDoorId() {
		return doorId;
	}

	public void setDoorId(Integer doorId) {
		this.doorId = doorId;
	}

	public Integer getCarriageId() {
		return carriageId;
	}

	public void setCarriageId(Integer carriageId) {
		this.carriageId = carriageId;
	}

	public byte[] getDatas() {
		return datas;
	}

	public void setDatas(byte[] datas) {
		this.datas = datas;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public int getMilli() {
		return milli;
	}

	public void setMilli(int milli) {
		this.milli = milli;
	}
}