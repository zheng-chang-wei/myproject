package com.hirain.phm.bode.ui.monitor.figure.door;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.geometry.Rectangle;

public class BottomFigure extends Figure {

	@Override
	protected void paintFigure(Graphics g) {
		Rectangle r = bounds;

		g.drawLine(r.x, r.y, r.x + r.width, r.y);

		g.drawLine(r.x, r.y + r.height / 2, r.x + r.width, r.y + r.height / 2);

		g.drawLine(r.x, r.y + r.height - 1, r.x + r.width - 1, r.y + r.height - 1);

	}
}
