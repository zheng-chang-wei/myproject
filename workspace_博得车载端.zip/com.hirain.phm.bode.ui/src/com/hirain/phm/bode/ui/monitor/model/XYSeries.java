package com.hirain.phm.bode.ui.monitor.model;

import org.eclipse.swt.graphics.Color;

public class XYSeries {

	private String id;

	private double[] xAxisData;

	private double[] yAxisData;

	private Color color;

	public XYSeries() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(final String id) {
		this.id = id;
	}

	public double[] getxAxisData() {
		return xAxisData;
	}

	public void setxAxisData(double[] xAxisData) {
		this.xAxisData = xAxisData;
	}

	public double[] getyAxisData() {
		return yAxisData;
	}

	public void setyAxisData(double[] yAxisData) {
		this.yAxisData = yAxisData;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

}