package com.hirain.phm.bode.client.communication.service;

import java.nio.ByteBuffer;
import java.util.List;

import com.hirain.phm.bode.client.communication.transport.ITransportPacket;
import com.hirain.phm.bode.client.communication.transport.impl.TransportPacketImpl;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.socket.DatagramPacket;
import io.netty.handler.codec.MessageToMessageCodec;

class MessageCodec extends MessageToMessageCodec<DatagramPacket, ITransportPacket> {

	// 这里的msg是从服务端发送上来的报文信息
	@Override
	protected void decode(ChannelHandlerContext ctx, DatagramPacket msg, List<Object> out) throws Exception {
		if (msg.content().readableBytes() < 3) {
			return;
		}
		ByteBuf buf = msg.content();
		final int pos = buf.readerIndex();
		final int length = buf.getUnsignedShort(pos + 1);
		if (msg.content().readableBytes() < length + 3) {
			return;
		}
		final byte[] bs = new byte[length + 3];
		buf.readBytes(bs);
		// int length = buf.readableBytes();
		// System.out.println(length);
		// byte[] bs = new byte[length];
		// buf.readBytes(bs);
		ITransportPacket packet = new TransportPacketImpl();
		packet.setPid(bs[0]);
		packet.setLength(length + 3);
		byte[] bytes = new byte[length];
		System.arraycopy(bs, 3, bytes, 0, bytes.length);
		packet.setData(bytes);
		out.add(packet);
	}

	@SuppressWarnings("unused")
	private ITransportPacket decode(byte[] bs) {
		final ITransportPacket packet = new TransportPacketImpl();
		final ByteBuffer buffer = ByteBuffer.wrap(bs);
		packet.setPid(buffer.get());
		packet.setLength(Short.toUnsignedInt(buffer.getShort()));
		final byte[] data = new byte[packet.getLength()];
		buffer.get(data);
		packet.setData(data);
		return packet;
	}

	@Override
	protected void encode(ChannelHandlerContext ctx, ITransportPacket packet, List<Object> out) throws Exception {
		ByteBuffer buffer = ByteBuffer.wrap(packet.toByte());
		DatagramPacket datagramPacket = new DatagramPacket(Unpooled.copiedBuffer(buffer.array()), packet.getAddress());
		ctx.writeAndFlush(datagramPacket);
	}

}
