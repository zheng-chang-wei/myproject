package com.hirain.phm.bode.ui.fault.service;

import com.hirain.phm.bode.core.fault.FaultRecord;

public interface FaultMessageService {

	void select(FaultRecord faultMessage);
}
