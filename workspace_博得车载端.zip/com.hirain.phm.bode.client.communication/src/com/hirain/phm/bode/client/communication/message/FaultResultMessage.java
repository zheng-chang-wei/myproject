package com.hirain.phm.bode.client.communication.message;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年2月1日 上午9:24:28
 * @Description
 *              <p>
 *              故障查询回复
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年2月1日 changwei.zheng@hirain.com 1.0 create file
 */
public class FaultResultMessage extends AbstractMessage {

	private byte sid;

	private byte[] data;

	/**
	 * @return the data
	 */
	public byte[] getData() {
		return data;
	}

	/**
	 * @param data
	 *            the data to set
	 */
	public void setData(byte[] data) {
		this.data = data;
	}

	public byte getSid() {
		return sid;
	}

	public void setSid(byte sid) {
		this.sid = sid;
	}

}
