/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.listener;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年3月11日 下午5:03:31
 * @Description
 *              <p>
 *              刷新车厢号和门地址
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年3月11日 changwei.zheng@hirain.com 1.0 create file
 */
public interface IRefreshCarNumAndDoorAddressListener {

	void refreshCarNumAndDoorAddr();
}
