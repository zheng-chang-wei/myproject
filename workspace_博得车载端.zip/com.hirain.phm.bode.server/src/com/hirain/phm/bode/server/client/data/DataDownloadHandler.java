package com.hirain.phm.bode.server.client.data;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.ibatis.session.SqlSession;

import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ISender;
import com.hirain.phm.bode.server.client.Token;
import com.hirain.phm.bode.server.db.DBService;

public class DataDownloadHandler {

	private static final int MAX_MESSAGE_NUM = 2000;

	private final ExecutorService pool;

	private final String sql;

	private final ISender sender;

	private final int type;

	private final Token token;

	public DataDownloadHandler(ISender sender, String sql, int type, Token token) {
		pool = Executors.newSingleThreadExecutor(r -> new Thread(r, "data-download-thread" + type));
		this.sql = sql;
		this.sender = sender;
		this.type = type;
		this.token = token;
	}

	public void work() {
		downloadMessages();
	}

	private void downloadMessages() {
		pool.submit(() -> {
			SqlSession session = null;
			List<Message> lists = new ArrayList<>();
			try {
				session = DBService.getInstance().getSession(false);
				final ClientMapper mapper = DBService.getInstance().getMapper(ClientMapper.class, session);
				lists = mapper.downloadMessage(sql);
				DBService.getInstance().disconnect(session);
			} catch (final Exception e) {
				DBService.getInstance().disconnect(session);
				sender.send(token.getAddress(), ClientConstants.DATA_DOWNLOAD_RESPONSE, new byte[] { (byte) (type + ClientConstants.EOF) });
				return;
			}

			int index = 0;
			while (index < lists.size()) {
				final int length = Math.min(MAX_MESSAGE_NUM, lists.size() - index);
				System.out.println(length);
				final int buffersize = length * (32 + 2) + 3;
				System.out.println(buffersize);
				final ByteBuffer buffer = ByteBuffer.allocate(buffersize);
				buffer.put((byte) type);
				buffer.putShort((short) length);
				final int offset = length + index;
				for (; index < offset; index++) {
					final Message msg = lists.get(index);
					final byte[] bs = new byte[32];
					System.arraycopy(msg.getDatas(), 0, bs, 0, msg.getDatas().length);
					buffer.put(bs);

					final Calendar calendar = Calendar.getInstance();
					calendar.setTime(msg.getTimestamp());
					final int milli = calendar.get(Calendar.MILLISECOND);
					buffer.putShort((short) milli);
				}
				sender.send(token.getAddress(), ClientConstants.DATA_DOWNLOAD_RESPONSE, buffer.array());
			}
			sender.send(token.getAddress(), ClientConstants.DATA_DOWNLOAD_RESPONSE, new byte[] { (byte) (type + ClientConstants.EOF) });
		});
	}

}
