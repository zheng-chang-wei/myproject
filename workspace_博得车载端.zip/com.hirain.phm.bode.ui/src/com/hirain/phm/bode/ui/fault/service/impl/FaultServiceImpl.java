package com.hirain.phm.bode.ui.fault.service.impl;

import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.fault.service.FaultService;

public class FaultServiceImpl implements FaultService {

	private static FaultServiceImpl singleton = null;

	private FaultServiceImpl() {
	}

	public static FaultServiceImpl getInstance() {
		if (singleton == null) {
			singleton = new FaultServiceImpl();
		}
		return singleton;
	}

	@Override
	public void selectAll() {
		String sql = "SELECT * from t_fault";
		try {
			CommunicationService.getInstance().select(ServiceConstant.PID_DATA_QUERY, ServiceConstant.FAULT_SID, sql);
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}
}
