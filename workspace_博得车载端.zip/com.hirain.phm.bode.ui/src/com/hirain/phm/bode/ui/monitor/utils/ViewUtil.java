package com.hirain.phm.bode.ui.monitor.utils;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;

public class ViewUtil {

	public static Color color = new Color(null, 215, 215, 215);

	public static CLabel createCLabel(Composite composite, String text) {
		CLabel cLabel = new CLabel(composite, SWT.PUSH);
		cLabel.setText(text);
		cLabel.setBackground(color);
		cLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, true));
		return cLabel;
	}

	public static void setTableHeight(final Table table, final float n) {
		table.addListener(SWT.MeasureItem, new Listener() {

			public void handleEvent(Event event) {
				event.height = (int) Math.floor(event.gc.getFontMetrics().getHeight() * n);
			}
		});
	}
}
