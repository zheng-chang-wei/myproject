package com.hirain.phm.bode.client.communication.transport.impl;

import java.net.InetSocketAddress;

import com.hirain.phm.bode.client.communication.transport.ITransportPacket;

public class TransportPacketImpl implements ITransportPacket {

	private InetSocketAddress address;

	private int localPort;

	private byte pid;

	private int length;

	private byte[] data;

	@Override
	public InetSocketAddress getAddress() {
		return address;
	}

	@Override
	public void setAddress(InetSocketAddress address) {
		this.address = address;
	}

	@Override
	public byte getPid() {
		return pid;
	}

	@Override
	public void setPid(byte pid) {
		this.pid = pid;
	}

	@Override
	public int getLength() {
		return length;
	}

	@Override
	public void setLength(int length) {
		this.length = length;
	}

	@Override
	public byte[] getData() {
		return data;
	}

	@Override
	public void setData(byte[] data) {
		this.data = data;
	}

	// 注意若自定义的通信协议的结构变了，这里也可能要相应变化
	@Override
	public byte[] toByte() {
		final long totalLength = 3 + data.length;
		final byte[] result = new byte[(int) totalLength];
		result[0] = (byte) getPid();
		byte[] splitShort = ByteUtil.splitShort((short) data.length);
		result[1] = splitShort[1];
		result[2] = splitShort[0];
		System.arraycopy(data, 0, result, 3, data.length);
		return result;
	}

	@Override
	public int localPort() {
		return localPort;
	}

	@Override
	public void setLocalPort(int localPort) {
		this.localPort = localPort;
	}

}
