package com.hirain.phm.bode.server.store.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.hirain.phm.bode.server.message.DoorMessage;
import com.hirain.phm.bode.server.store.MessageRecord;

public interface StoreMapper {

	/**
	 * insert a message record to t_carriage${carriageId}_record table
	 * include properties:startTime,doorId,debug
	 * 
	 * @param record
	 * @return
	 */
	int insert(MessageRecord record);

	/**
	 * update property endTime
	 * 
	 * @param carriageId
	 * @param endTime
	 * @return
	 */
	int updateEndtime(@Param("carriageId") Integer carriageId, @Param("endTime") Date endTime);

	/**
	 * insert doormessage to t_carriage${carriageId}_message table
	 * 
	 * @param map
	 *            key:carriageId,key:list
	 * @return
	 */
	int insertMessage(Map<String, Object> map);

	/**
	 * 从数据库中查询指定时间段内的实时报文数据
	 * 
	 * @author zepei.tao
	 */
	List<DoorMessage> findMessage(@Param("record") MessageRecord record);

	/**
	 * 从数据库中查询结束时间为空的记录中最早插入的一条
	 * 
	 * @author weijia.kong
	 */
	Date findLastRecordInsertTime(@Param("carriageId") Integer carriageId);

}
