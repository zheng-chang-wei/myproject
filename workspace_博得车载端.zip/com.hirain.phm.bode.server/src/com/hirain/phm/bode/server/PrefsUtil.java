package com.hirain.phm.bode.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.hirain.phm.bode.server.ground.GroundConstant;

public class PrefsUtil {

	private static PrefsUtil instance;

	private static final String GROUND_PREFS = System.getProperty("user.dir") + File.separator + "ground.prefs";

	private Properties properties;

	private PrefsUtil() {
		final File file = new File(GROUND_PREFS);
		if (file.exists()) {
			try {
				final FileInputStream stream = new FileInputStream(file);
				properties = new Properties();
				properties.load(stream);
				stream.close();
			} catch (final FileNotFoundException e) {
			} catch (final IOException e) {
			}
		}
	}

	public static PrefsUtil instance() {
		if (instance == null) {
			instance = new PrefsUtil();
		}
		return instance;
	}

	public String[] getMac() {
		if (properties != null) {
			final String mac1 = properties.getProperty("mac1");
			final String mac2 = properties.getProperty("mac2");
			final List<String> macList = new ArrayList<>();
			macList.add(mac1);
			if (mac2 != null) {
				macList.add(mac2);
			}
			return macList.toArray(new String[] {});
		}
		return null;
	}

	public int getState() {
		if (properties != null) {
			final String property = properties.getProperty("state");
			if (property != null) {
				return Integer.parseInt(property);
			}
		}
		return GroundConstant.TRAIN_ACTIVATE;
	}

	public String getPassword() {
		if (properties != null) {
			return properties.getProperty("password");
		}
		return null;
	}

	public String getValue(String key) {
		return properties.getProperty(key);
	}

	public boolean getBooleanValue(String key) {
		return Boolean.parseBoolean(getValue(key));
	}

	public void update(String key, String value) {
		final File file = new File(GROUND_PREFS);
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (final IOException e) {
				e.printStackTrace();
			}
		}
		try {
			properties.setProperty(key, value);
			final FileOutputStream outputStream = new FileOutputStream(file);
			properties.store(outputStream, "");
			outputStream.close();
		} catch (final Exception e) {
		}
	}

}
