/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.dataframe;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 29, 2019 3:21:40 PM
 * @Description
 *              <p>
 *              车门状态，用于界面上方车厢门的刷新
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 29, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DoorStatus {

	private boolean closeCompletely;

	private boolean openCompletely;

	private boolean openProcess;

	private boolean closeProcess;

	private byte malfunction;// 故障

	private boolean emergencyUnlock;// 紧急解锁

	private boolean isolation;// 隔离状态

	private boolean anticrush;// 防挤压

	private int carNo;// 车厢号

	private int doorAddr;// 车门地址

	private boolean existFault;// 存在故障

	private boolean outputShortCircuit;// 输出短路

	private boolean switchTimeOut;// 开关门超时

	private boolean encoder;// 编码器故障

	private boolean lockSwitch;// 锁闭开关故障

	private boolean greenLoop;// 绿色环线

	private boolean doorSwitch;// 门板开关故障

	private boolean motorOverCurrent;// 电机过流

	private boolean motorOpenCircuit;// 电机开路

	/**
	 * 日
	 */
	private int date;

	/**
	 * 时
	 */
	private int hour;

	/**
	 * 分
	 */
	private int minute;

	/**
	 * 秒
	 */
	private int second;

	/**
	 * 毫秒
	 */
	private int millisecond;

	/**
	 * @return the closeCompletely
	 */
	public boolean isCloseCompletely() {
		return closeCompletely;
	}

	/**
	 * @param closeCompletely
	 *            the closeCompletely to set
	 */
	public void setCloseCompletely(boolean closeCompletely) {
		this.closeCompletely = closeCompletely;
	}

	/**
	 * @return the openCompletely
	 */
	public boolean isOpenCompletely() {
		return openCompletely;
	}

	/**
	 * @return the carNo
	 */
	public int getCarNo() {
		return carNo;
	}

	/**
	 * @param carNo
	 *            the carNo to set
	 */
	public void setCarNo(int carNo) {
		this.carNo = carNo;
	}

	/**
	 * @return the doorAddr
	 */
	public int getDoorAddr() {
		return doorAddr;
	}

	/**
	 * @param doorAddr
	 *            the doorAddr to set
	 */
	public void setDoorAddr(int doorAddr) {
		this.doorAddr = doorAddr;
	}

	/**
	 * @param openCompletely
	 *            the openCompletely to set
	 */
	public void setOpenCompletely(boolean openCompletely) {
		this.openCompletely = openCompletely;
	}

	/**
	 * @return the openProcess
	 */
	public boolean isOpenProcess() {
		return openProcess;
	}

	/**
	 * @param openProcess
	 *            the openProcess to set
	 */
	public void setOpenProcess(boolean openProcess) {
		this.openProcess = openProcess;
	}

	/**
	 * @return the closeProcess
	 */
	public boolean isCloseProcess() {
		return closeProcess;
	}

	/**
	 * @param closeProcess
	 *            the closeProcess to set
	 */
	public void setCloseProcess(boolean closeProcess) {
		this.closeProcess = closeProcess;
	}

	/**
	 * @return the malfunction
	 */
	public byte getMalfunction() {
		return malfunction;
	}

	/**
	 * @param malfunction
	 *            the malfunction to set
	 */
	public void setMalfunction(byte malfunction) {
		this.malfunction = malfunction;
	}

	/**
	 * @return the emergencyUnlock
	 */
	public boolean isEmergencyUnlock() {
		return emergencyUnlock;
	}

	/**
	 * @param emergencyUnlock
	 *            the emergencyUnlock to set
	 */
	public void setEmergencyUnlock(boolean emergencyUnlock) {
		this.emergencyUnlock = emergencyUnlock;
	}

	/**
	 * @return the isolation
	 */
	public boolean isIsolation() {
		return isolation;
	}

	/**
	 * @param isolation
	 *            the isolation to set
	 */
	public void setIsolation(boolean isolation) {
		this.isolation = isolation;
	}

	/**
	 * @return the anticrush
	 */
	public boolean isAnticrush() {
		return anticrush;
	}

	/**
	 * @param anticrush
	 *            the anticrush to set
	 */
	public void setAnticrush(boolean anticrush) {
		this.anticrush = anticrush;
	}

	/**
	 * @return the existFault
	 */
	public boolean isExistFault() {
		return existFault;
	}

	/**
	 * @param existFault
	 *            the existFault to set
	 */
	public void setExistFault(boolean existFault) {
		this.existFault = existFault;
	}

	/**
	 * @return the outputShortCircuit
	 */
	public boolean isOutputShortCircuit() {
		return outputShortCircuit;
	}

	/**
	 * @param outputShortCircuit
	 *            the outputShortCircuit to set
	 */
	public void setOutputShortCircuit(boolean outputShortCircuit) {
		this.outputShortCircuit = outputShortCircuit;
	}

	/**
	 * @return the switchTimeOut
	 */
	public boolean isSwitchTimeOut() {
		return switchTimeOut;
	}

	/**
	 * @param switchTimeOut
	 *            the switchTimeOut to set
	 */
	public void setSwitchTimeOut(boolean switchTimeOut) {
		this.switchTimeOut = switchTimeOut;
	}

	/**
	 * @return the encoder
	 */
	public boolean isEncoder() {
		return encoder;
	}

	/**
	 * @param encoder
	 *            the encoder to set
	 */
	public void setEncoder(boolean encoder) {
		this.encoder = encoder;
	}

	/**
	 * @return the lockSwitch
	 */
	public boolean isLockSwitch() {
		return lockSwitch;
	}

	/**
	 * @param lockSwitch
	 *            the lockSwitch to set
	 */
	public void setLockSwitch(boolean lockSwitch) {
		this.lockSwitch = lockSwitch;
	}

	/**
	 * @return the greenLoop
	 */
	public boolean isGreenLoop() {
		return greenLoop;
	}

	/**
	 * @param greenLoop
	 *            the greenLoop to set
	 */
	public void setGreenLoop(boolean greenLoop) {
		this.greenLoop = greenLoop;
	}

	/**
	 * @return the doorSwitch
	 */
	public boolean isDoorSwitch() {
		return doorSwitch;
	}

	/**
	 * @param doorSwitch
	 *            the doorSwitch to set
	 */
	public void setDoorSwitch(boolean doorSwitch) {
		this.doorSwitch = doorSwitch;
	}

	/**
	 * @return the motorOverCurrent
	 */
	public boolean isMotorOverCurrent() {
		return motorOverCurrent;
	}

	/**
	 * @param motorOverCurrent
	 *            the motorOverCurrent to set
	 */
	public void setMotorOverCurrent(boolean motorOverCurrent) {
		this.motorOverCurrent = motorOverCurrent;
	}

	/**
	 * @return the motorOpenCircuit
	 */
	public boolean isMotorOpenCircuit() {
		return motorOpenCircuit;
	}

	/**
	 * @param motorOpenCircuit
	 *            the motorOpenCircuit to set
	 */
	public void setMotorOpenCircuit(boolean motorOpenCircuit) {
		this.motorOpenCircuit = motorOpenCircuit;
	}

	public String getDate() {
		return isSingleDigit(date);
	}

	public void setDate(int date) {
		this.date = date;
	}

	public String getHour() {
		return isSingleDigit(hour);
	}

	public void setHour(int hour) {
		this.hour = hour;
	}

	public String getMinute() {
		return isSingleDigit(minute);
	}

	public void setMinute(int minute) {
		this.minute = minute;
	}

	public String getSecond() {
		return isSingleDigit(second);
	}

	public void setSecond(int second) {
		this.second = second;
	}

	public int getMillisecond() {
		return millisecond;
	}

	public void setMillisecond(int millisecond) {
		this.millisecond = millisecond;
	}

	/**
	 * 判断参数是否为个位数，如果为个位数前面加0
	 * 
	 * @param a
	 * @return
	 */
	private String isSingleDigit(int a) {
		if (a < 10) {
			return "0" + a;
		}
		return String.valueOf(a);
	}
}
