package com.hirain.phm.bd.store.domain;

import java.nio.ByteBuffer;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class StoreBuffer {

	private String filename;

	private ByteBuffer buffer;

	public StoreBuffer(int bufferCapacity) {
		buffer = ByteBuffer.allocate(bufferCapacity);
	}

	public void put(byte[] datas) {
		buffer.put(datas);
	}

	public void flip() {
		buffer.flip();
	}
}