package com.hirain.phm.bode.server.store;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.MDCUMock;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.config.ConfigurationService;

public class TestStore {

	@Test
	public void testStore() throws IOException, InterruptedException {
		ServerStoreMock mock = new ServerStoreMock();
		mock.start();
		MDCUMock mdcuMock = new MDCUMock();
		mdcuMock.start(true);
		try {
			ITrain train = ConfigurationService.getInstance().getTrain();
			if (train != null) {
				InnerEventBus.getInstance().post(new ConfigEvent(train, null));
			} else {
				return;
			}
			TimeUnit.SECONDS.sleep(5);
		} finally {
			mdcuMock.stop();
		}
		ITrain train = ConfigurationService.getInstance().getTrain();
		List<ICar> cars = train.getCars();
		ICar car = cars.remove(2);
		car.setIndex(1);
		cars.add(car);
		train.setCars(cars);
		InnerEventBus.getInstance().post(new ConfigEvent(train, null));
		TimeUnit.SECONDS.sleep(5);
	}
}
