/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.server.life;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.common.eventbus.Subscribe;
import com.hirain.phm.bd.message.train.LifeMessage;
import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.bus.ConfigEvent;
import com.hirain.phm.bode.server.bus.InnerEventBus;
import com.hirain.phm.bode.server.bus.MessageListEvent;
import com.hirain.phm.bode.server.message.DoorMessage;
import com.hirain.phm.bode.server.message.IPreProcessor;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created May 30, 2019 3:20:52 PM
 * @Description
 *              <p>
 *              处理寿命报文的Service
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               May 30, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class LifeService {

	private ITrain train;

	private final IPreProcessor processor;

	private final Map<Integer, LifeDetector> detectorMap = new HashMap<>();

	private final Map<Integer, LifeMessage> lifeMessageMap = new ConcurrentHashMap<>();// key:车门地址

	private ExecutorService executor;

	private final Timer timer = new Timer("lifemessage timer", true);

	public LifeService(IPreProcessor processor) {
		this.processor = processor;
	}

	public void init() {
		InnerEventBus.getInstance().register(this);
		processor.register(this);
		executor = Executors.newFixedThreadPool(2);
		executor.submit(() -> {
			timer.schedule(task, 0, 3600 * 1000);// 每小时执行一次
		});
	}

	@Subscribe
	public void on(ConfigEvent event) {
		executor.submit(() -> {
			processor.unregister(this);
			train = event.getTrain();
			final List<ICar> cars = train.getCars();
			final Set<Integer> idSet = new HashSet<>();
			for (final ICar car : cars) {
				if (car.getType() == 0) {
					continue;
				}
				final int carriageId = car.getIndex();
				LifeDetector detector = detectorMap.get(carriageId);
				if (detector == null) {
					detector = new LifeDetector(carriageId, lifeMessageMap, car.getDoors());
					detector.work();
					detectorMap.put(carriageId, detector);
				}
				idSet.add(carriageId);
			}
			processor.register(this);
			for (final Integer key : detectorMap.keySet()) {
				if (!idSet.contains(key)) {
					LifeDetector detector = detectorMap.get(key);
					detector.stop();
					detector = null;
					detectorMap.remove(key);
				}
			}
		});
	}

	@Subscribe
	public void on(MessageListEvent event) {
		final List<DoorMessage> messages = event.getMessages();
		final Integer carriageId = messages.get(0).getCarriageId();
		final LifeDetector detector = detectorMap.get(carriageId);
		if (detector != null) {
			detector.push(messages);
		}
	}

	private final TimerTask task = new TimerTask() {

		@Override
		public void run() {

			final List<LifeMessage> lifeMessages = new ArrayList<>();
			final LifeMessagePackage messagePackage = new LifeMessagePackage(lifeMessages);
			final Iterator<Map.Entry<Integer, LifeMessage>> entries = lifeMessageMap.entrySet().iterator();
			while (entries.hasNext()) {
				final Map.Entry<Integer, LifeMessage> entry = entries.next();
				final LifeMessage lifeMessage = entry.getValue();
				lifeMessage.setCity(train.getCityName());
				lifeMessage.setLine(train.getLineName().toString());
				lifeMessage.setTrain(train.getTrainNo());
				lifeMessage.setSid(0x0A);
				lifeMessages.add(lifeMessage);
			}
			InnerEventBus.getInstance().post(messagePackage);
		}
	};
}
