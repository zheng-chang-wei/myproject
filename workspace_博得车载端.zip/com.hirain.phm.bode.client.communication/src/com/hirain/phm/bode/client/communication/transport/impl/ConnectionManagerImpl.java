package com.hirain.phm.bode.client.communication.transport.impl;

import java.util.HashMap;
import java.util.Map;

import com.hirain.phm.bode.client.communication.transport.IConnection;
import com.hirain.phm.bode.client.communication.transport.IConnectionFactory;
import com.hirain.phm.bode.client.communication.transport.IConnectionManager;
import com.hirain.phm.bode.client.communication.transport.ITransportPacket;

public class ConnectionManagerImpl implements IConnectionManager {

	private IConnectionFactory factory;

	private Map<Integer, IConnection> connectionMap = new HashMap<>();

	public ConnectionManagerImpl(IConnectionFactory factory) {
		this.factory = factory;
	}

	@Override
	public int bind(int... port) {
		int result = 0;
		for (int p : port) {
			IConnection connection = factory.create(p);
			connectionMap.put(p, connection);
			result = connection.bind();
			if (result != 0) {
				return result;
			}
		}
		return result;
	}

	@Override
	public int stop(int... port) {
		if (port == null) {
			for (Integer key : connectionMap.keySet()) {
				connectionMap.get(key).disconnect();
				connectionMap.remove(key);
			}
		} else {
			for (int p : port) {
				connectionMap.get(p).disconnect();
				connectionMap.remove(p);
			}
		}
		return 0;
	}

	@Override
	public int send(ITransportPacket packet) {
		int port = packet.localPort();
		IConnection connection = connectionMap.get(port);
		return connection.send(packet);
	}

}
