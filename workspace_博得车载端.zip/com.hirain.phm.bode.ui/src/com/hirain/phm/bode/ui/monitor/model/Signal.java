package com.hirain.phm.bode.ui.monitor.model;

public class Signal {

	private String SignalName;

	private SignalState signalState;

	private String value;

	public String getSignalName() {
		return SignalName;
	}

	public void setSignalName(String signalName) {
		SignalName = signalName;
	}

	public SignalState getSignalState() {
		return signalState;
	}

	public void setSignalState(SignalState signalState) {
		this.signalState = signalState;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "Signal [SignalName=" + SignalName + ", signalState=" + signalState + ", value=" + value + "]";
	}

}
