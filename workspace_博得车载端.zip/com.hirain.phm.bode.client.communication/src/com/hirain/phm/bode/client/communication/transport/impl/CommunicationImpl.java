package com.hirain.phm.bode.client.communication.transport.impl;

import java.net.InetSocketAddress;

import com.hirain.phm.bode.client.communication.transport.ICommunication;
import com.hirain.phm.bode.client.communication.transport.IConnectionFactory;
import com.hirain.phm.bode.client.communication.transport.IConnectionManager;
import com.hirain.phm.bode.client.communication.transport.IEncoder;
import com.hirain.phm.bode.client.communication.transport.ITransportPacket;

public class CommunicationImpl implements ICommunication {

	private IConnectionManager connectionManager;

	private IEncoder encoder;

	public CommunicationImpl(IConnectionFactory factory) {
		connectionManager = new ConnectionManagerImpl(factory);
		encoder = new PacketEncoder();
	}

	@Override
	public int bind(int... port) {
		return connectionManager.bind(port);
	}

	@Override
	public void send(InetSocketAddress address, int localport, byte pid, byte[] data) {
		ITransportPacket packet = encoder.encode(pid, data);
		packet.setAddress(address);
		packet.setLocalPort(localport);
		connectionManager.send(packet);
	}

	@Override
	public int stop(int... port) {
		return connectionManager.stop(port);
	}

}
