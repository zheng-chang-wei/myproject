package com.hirain.phm.bode.ui.monitor.figure.door;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.geometry.PointList;
import org.eclipse.draw2d.geometry.Rectangle;

public class ArrowFigure extends Figure {

	public int side;

	public ArrowFigure(int side) {
		this.side = side;
		this.setOpaque(true);
	}

	@Override
	public void paintFigure(Graphics g) {
		Rectangle r = bounds;
		PointList pl = new PointList(7);
		if (side == DoorContent.LEFT) {
			pl.addPoint(r.x, r.y + r.height / 2);
			pl.addPoint(r.x + r.width / 2, r.y + r.height);
			pl.addPoint(r.x + r.width / 2, r.y + r.height * 2 / 3);
			pl.addPoint(r.x + r.width - 2, r.y + r.height * 2 / 3);
			pl.addPoint(r.x + r.width - 2, r.y + r.height / 3);
			pl.addPoint(r.x + r.width / 2, r.y + r.height / 3);
			pl.addPoint(r.x + r.width / 2, r.y);
		} else {
			pl.addPoint(r.x + r.width, r.y + r.height / 2);
			pl.addPoint(r.x + r.width / 2, r.y + r.height);
			pl.addPoint(r.x + r.width / 2, r.y + r.height * 2 / 3);
			pl.addPoint(r.x, r.y + r.height * 2 / 3);
			pl.addPoint(r.x, r.y + r.height / 3);
			pl.addPoint(r.x + r.width / 2, r.y + r.height / 3);
			pl.addPoint(r.x + r.width / 2, r.y);
		}
		g.drawPolygon(pl);
		g.fillPolygon(pl.toIntArray());
	}
}
