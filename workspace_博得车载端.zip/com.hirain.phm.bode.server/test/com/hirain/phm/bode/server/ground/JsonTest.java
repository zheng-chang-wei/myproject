package com.hirain.phm.bode.server.ground;

import com.hirain.phm.bode.server.Utils;

public class JsonTest {

	public static void main(String[] args) {
		final String json = "{a:1;b:2;c:3}";
		final Entity entity = Utils.fromJsonString(json, Entity.class);
		System.out.println(entity.a + ";" + entity.b + ";" + entity.c);

		final Entity1 entity1 = Utils.fromJsonString(json, Entity1.class);
		System.out.println(entity1.a);
	}

	private class Entity {

		int a;

		int b;

		int c;
	}

	private class Entity1 {

		int a;

	}

}
