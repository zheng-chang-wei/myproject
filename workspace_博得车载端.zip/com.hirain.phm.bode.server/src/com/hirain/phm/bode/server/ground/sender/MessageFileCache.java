package com.hirain.phm.bode.server.ground.sender;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class MessageFileCache {

	static Logger logger = Logger.getLogger(MessageFileCache.class);

	public static final int FILE_MAX_SIZE = 1024 * 1024;

	public static final int OFFSET_UPDATE = 200;

	private static final String MESSAGE_ROOT = "cache";

	private static final String INDEX_FILE = MESSAGE_ROOT + File.separator + "index.txt";

	private FileOutputStream fos;

	private FileChannel out;

	private FileInputStream fis;

	private FileChannel in;

	private final AtomicInteger offset = new AtomicInteger();

	private int lastOffset;

	private Queue<String> queue = new ConcurrentLinkedQueue<>();

	private final ExecutorService writeExecutor = Executors.newSingleThreadExecutor(r -> new Thread(r, MessageFileCache.class.getName() + "-write"));

	private final ScheduledExecutorService offsetExecutor = Executors
			.newSingleThreadScheduledExecutor(r -> new Thread(r, MessageFileCache.class.getName() + "-offset"));

	public void init() {
		final File folder = new File(System.getProperty("user.dir"), MESSAGE_ROOT);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		final File[] children = folder.listFiles((FilenameFilter) (dir, name) -> name.endsWith(".cache"));
		if (children != null) {
			final List<File> fileList = Arrays.asList(children);
			Collections.sort(fileList);
			fileList.stream().forEach(f -> {
				queue.add(f.getAbsolutePath());
			});
		}
		initInChannel();
		initOutChannel();
		offsetExecutor.scheduleAtFixedRate(() -> {
			updateOffset();
		}, OFFSET_UPDATE, OFFSET_UPDATE, TimeUnit.MILLISECONDS);
	}

	public void close() {
		offsetExecutor.shutdown();
		updateOffset();
		try {
			fis.close();
			in.close();
			fos.close();
			out.close();
		} catch (IOException e) {
		}
	}

	public void write(byte[] payload) {
		writeExecutor.submit(() -> {
			final ByteBuffer buffer = ByteBuffer.allocate(2 + payload.length);
			buffer.putShort((short) payload.length);
			buffer.put(payload);
			buffer.flip();
			try {
				out.write(buffer);
			} catch (final IOException e) {
				logger.error(e.getMessage(), e);
			}
			checkAndCreate();
		});
	}

	public byte[] read() {
		final FileChannel channel = getInChannel();
		try {
			if (channel != null) {
				final ByteBuffer buffer = ByteBuffer.allocate(2);
				channel.read(buffer);
				buffer.flip();
				final int length = Short.toUnsignedInt(buffer.getShort());
				final ByteBuffer dataBuffer = ByteBuffer.allocate(length);
				channel.read(dataBuffer);
				dataBuffer.flip();
				final byte[] result = dataBuffer.array();
				offset.addAndGet(2 + length);
				return result;
			}
		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}

	private void initInChannel() {
		String filepath = queue.peek();
		if (filepath != null) {
			try {
				fis = new FileInputStream(filepath);
				in = fis.getChannel();
				offset.set(getOffset());
				in.position(offset.get());
			} catch (final IOException e) {
				logger.error(e.getMessage(), e);
			}
		} else {
			final File file = createNewFile();
			try {
				fis = new FileInputStream(file);
				in = fis.getChannel();
				offset.set(getOffset());
				in.position(offset.get());
			} catch (final IOException e) {
				logger.error(e.getMessage(), e);
			}
		}
		lastOffset = offset.get();
	}

	private void initOutChannel() {
		String filepath = queue.peek();
		Iterator<String> iterator = queue.iterator();
		while (iterator.hasNext()) {
			filepath = iterator.next();
		}
		System.out.println(filepath);
		try {
			fos = new FileOutputStream(filepath, true);
			out = fos.getChannel();
		} catch (final FileNotFoundException e) {
			logger.error(e.getMessage(), e);
		}
	}

	private int getOffset() {
		final File indexFile = new File(System.getProperty("user.dir") + File.separator + INDEX_FILE);
		if (indexFile.exists()) {
			try {
				final String value = FileUtils.readFileToString(indexFile, "utf-8");
				return Integer.parseInt(value);
			} catch (final IOException e) {
				logger.error(e.getMessage(), e);
			}
		} else {
			try {
				indexFile.createNewFile();
				FileUtils.writeStringToFile(indexFile, "0", Charset.forName("utf-8"));
			} catch (final IOException e) {
				logger.error(e.getMessage(), e);
			}
		}
		return 0;
	}

	private void checkAndCreate() {
		try {
			if (out.size() > FILE_MAX_SIZE) {
				out.close();
				fos.close();
				final File file = createNewFile();
				file.createNewFile();
				fos = new FileOutputStream(file, true);
				out = fos.getChannel();
			}
		} catch (final IOException e) {
			logger.error(e.getMessage(), e);
		}
	}

	private File createNewFile() {
		String filepath = System.getProperty("user.dir") + File.separator + MESSAGE_ROOT + File.separator;
		filepath += LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".cache";
		final File file = new File(filepath);
		try {
			file.createNewFile();
			queue.add(file.getAbsolutePath());
		} catch (final IOException e) {
			logger.error(e.getMessage(), e);
		}
		return file;
	}

	private void updateOffset() {
		lastOffset = offset.get();
		try {
			FileUtils.writeStringToFile(new File(System.getProperty("user.dir") + File.separator + INDEX_FILE), String.valueOf(lastOffset), "utf-8");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private FileChannel getInChannel() {
		try {
			if (in.size() == in.position()) {
				if (queue.size() >= 2) {
					in.close();
					fis.close();
					final String oldPath = queue.remove();
					final File oldFile = new File(oldPath);
					oldFile.delete();
					final String filepath = queue.peek();
					final File file = new File(filepath);
					fis = new FileInputStream(file);
					in = fis.getChannel();
					offset.set(0);
					if (in.size() == in.position()) {
						return null;
					}
					return in;
				}
			} else {
				return in;
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
