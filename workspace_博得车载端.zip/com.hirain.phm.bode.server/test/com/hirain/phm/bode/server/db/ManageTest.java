package com.hirain.phm.bode.server.db;

import static org.junit.Assert.assertEquals;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.server.config.ConfigurationService;
import com.hirain.phm.bode.server.db.dao.ManageMapper;

public class ManageTest extends DBTestCase {

	@Test
	public void testExist() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		int result = mapper.existRecordTable(100);
		assertEquals(0, result);

		result = mapper.existMessageTable(100);
		assertEquals(0, result);

		result = mapper.existTable("t_carriage12_record");
		assertEquals(0, result);
	}

	@Test
	public void testCreateMessage() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		final HashMap<String, Object> map = new HashMap<>();
		map.put("carriageId", 2);
		map.put("list", partitions());
		mapper.createMessageTable(map);

		final int count = mapper.existMessageTable(2);
		assertEquals(1, count);
	}

	@Test
	public void testAddPartition() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		final HashMap<String, Object> map = new HashMap<>();
		map.put("carriageId", 2);
		map.put("list", Arrays.asList("20190209"));
		mapper.addPartitionsToMessage(map);
	}

	@Test
	public void testDropPartition() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		mapper.dropPartitionFromMessage("t_carriage2_message", "20190129");
	}

	@Test
	public void testCreateRecord() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		final HashMap<String, Object> map = new HashMap<>();
		map.put("carriageId", 2);
		map.put("list", years());
		mapper.createRecordTable(map);
		final int count = mapper.existRecordTable(2);
		assertEquals(1, count);
	}

	@Test
	public void testAddPartitionToRecord() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		final HashMap<String, Object> map = new HashMap<>();
		map.put("carriageId", 2);
		map.put("list", Arrays.asList(2021));
		mapper.addPartitionsToRecord(map);
	}

	@Test
	public void testDeleteRecords() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		mapper.deleteRecords("t_carriage2_record", "20190129");
		session.commit();
	}

	@Test
	public void testFaultCreatePartition() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		mapper.createPartitions(getFaultPartitions(1));
	}

	@Test
	public void testFaultAddPartition() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		mapper.addPartitionsToFaultRecord(Arrays.asList(40000l));
	}

	@Test
	public void testFaultMessageAddPartition() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		mapper.addPartitionsToFaultMessage(getFaultPartitions(0));
	}

	@Test
	public void testFaultCount() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		final long count = mapper.countFaultRecord();
		System.out.println(count);
	}

	@Test
	public void testQueryPartition() {
		final ManageMapper mapper = session.getMapper(ManageMapper.class);
		final String partition = mapper.lastPartition("t_fault_message");
		System.out.println(partition);
	}

	@Test
	public void testPartition() {
		final ITrain train = ConfigurationService.getInstance().getTrain();
		DBManageService.getInstance().init(train.getCars());
		DBManageService.getInstance().part(train.getCars());
	}

	@Test
	public void testSpace() {
		final ManageMapper mapper = getMapper(ManageMapper.class);
		final double space = mapper.selectSpace();
		System.out.println(space);

		List<String> tables = mapper.selectTables(DBConstant.MESSAGE_TABLE_SUFFIX);
		for (final String table : tables) {
			System.out.println(table);
		}
		tables = mapper.selectTables(DBConstant.RECORD_TABLE_SUFFIX);
		for (final String table : tables) {
			System.out.println(table);
		}
	}

	@Test
	public void testSelectPartition() {
		final ManageMapper mapper = getMapper(ManageMapper.class);
		final String tableName = "t_carriage2_message";
		final long count = mapper.countPartitions(tableName);
		System.out.println(count);
		final String first = mapper.firstPartition(tableName);
		System.out.println(first);
		final String last = mapper.lastPartition(tableName);
		System.out.println(last);
	}

	@Test
	public void testDeletePartition() {
		final ManageMapper mapper = getMapper(ManageMapper.class);
		final String tableName = "t_carriage2_message";
		final long count = mapper.countPartitions(tableName);
		if (count > 1) {
			String first = mapper.firstPartition(tableName);
			if (first.startsWith("p")) {
				first = first.substring(1);
			}
			int res = mapper.dropPartitionFromMessage(tableName, first);
			System.out.println("drop result" + res);
			String recordName = tableName.substring(0, tableName.length() - 7);
			recordName += "record";
			mapper.deleteRecords(recordName, first);
		}
	}

	@Test
	public void testDeleteByDate() {
		final ManageMapper mapper = getMapper(ManageMapper.class);
		DateTimeFormatter DATETIME_PATTERN = DateTimeFormatter.ofPattern("yyyyMMdd");
		LocalDate cutDate = LocalDate.parse("20190805", DATETIME_PATTERN);
		LocalDate dropDate = LocalDate.parse("20190725", DATETIME_PATTERN);
		String table = "t_carriage1_message";
		while (mapper.countPartitions(table) > 1) {
			String first = mapper.firstPartition(table);
			if (first.startsWith("p")) {
				first = first.substring(1);
			}
			LocalDate partitionDate = LocalDate.parse(first, DATETIME_PATTERN);
			if (partitionDate.compareTo(dropDate) < 0) {
				int res = mapper.dropPartitionFromMessage(table, first);
				System.out.println("drop result:" + res);
			} else {
				break;
			}
		}
		try {
			int res = mapper.deleteMessagesBeforeDay(table, cutDate.format(DATETIME_PATTERN));
			System.out.println("delete result:" + res);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testDateToLocalDateTime() {
		DateTimeFormatter DATETIME_PATTERN = DateTimeFormatter.ofPattern("yyyyMMdd");
		java.util.Date date = new java.util.Date();
		System.out.println(date);
		Instant instant = date.toInstant();
		System.out.println(instant);
		ZoneId zone = ZoneId.systemDefault();
		System.out.println(zone);
		LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, zone);
		System.out.println(localDateTime);
		LocalDate t1 = LocalDate.parse("20190101", DATETIME_PATTERN),
				t2 = LocalDate.parse("20181221", DATETIME_PATTERN);
		int res = t1.compareTo(t2);
		System.out.println(res);
	}

	private List<String> getFaultPartitions(int start) {
		final List<String> partitions = new ArrayList<>();
		final LocalDate now = LocalDate.now();
		for (int i = start; i < 12; i++) {
			final LocalDate date = now.plusMonths(i);
			partitions.add(date.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
		}
		return partitions;
	}

	private List<Integer> years() {
		final List<Integer> years = new ArrayList<>();
		final int year = LocalDate.now().getYear();
		for (int i = 0; i < 2; i++) {
			years.add(year + i);
		}
		return years;
	}

	public List<String> partitions() {
		final List<String> partitions = new ArrayList<>();
		final LocalDate date = LocalDate.now();
		for (int i = 0; i <= 30; i++) {
			final LocalDate day = date.plusDays(i);
			final String time = day.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
			partitions.add(time);
		}
		return partitions;
	}

}
