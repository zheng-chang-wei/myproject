package com.hirain.phm.bode.server.store;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.ibatis.session.SqlSession;

import com.hirain.phm.bode.core.IDoor;
import com.hirain.phm.bode.server.db.DBService;
import com.hirain.phm.bode.server.message.DoorMessage;
import com.hirain.phm.bode.server.store.dao.StoreMapper;

class MessageStorager {

	private final AtomicBoolean debug = new AtomicBoolean(false);

	private final ReentrantLock lock = new ReentrantLock();

	/**
	 * store message thread pool
	 */
	private ExecutorService storeExecutors;

	/**
	 * insert message record thread pool
	 */
	private ExecutorService insertExecutors;

	/**
	 * insert a message record per hour
	 */
	private ScheduledExecutorService timerExecutor;

	private final List<MessageRecord> records;

	/**
	 * the queue to store
	 */
	private final BlockingQueue<List<DoorMessage>> queue = new LinkedBlockingQueue<>();

	private final int carriageId;

	private Date startTime;

	private Date endTime;

	private final Map<Integer, Boolean> hasMsg = new ConcurrentHashMap<>();

	private final Runnable insertRunnable = () -> {
		updateRecord();
	};

	public MessageStorager(int carriageId, List<IDoor> doors) {
		this.carriageId = carriageId;
		records = new CopyOnWriteArrayList<>();
		for (final IDoor door : doors) {
			final MessageRecord record = new MessageRecord();
			record.setCarriageId(carriageId);
			record.setDoorId(door.getAddr());
			record.setDebug(debug.get());
			records.add(record);
		}
		storeExecutors = Executors.newSingleThreadExecutor(r -> new Thread(r, "message store-" + carriageId));
		insertExecutors = Executors.newFixedThreadPool(1, r -> new Thread(r, "record insert-" + carriageId));
	}

	/**
	 * start to store message
	 */
	public void work() {
		System.out.println("message storager-" + carriageId);
		fixRecord();
		storeExecutors.submit(() -> {
			while (true) {
				final List<DoorMessage> list = queue.take();
				if (list.size() > 0) {
					final Integer doorId = list.get(0).getDoorId();
					if (hasMsg.putIfAbsent(doorId, true) == null) {
						startTime = list.get(0).getTimestamp();
						insertRecord(doorId, new Date(startTime.getTime()));
					} else {
						endTime = list.get(0).getTimestamp();
					}
				}
				insertMessage(list);
			}
		});
		timerExecutor = Executors.newSingleThreadScheduledExecutor(r -> new Thread(r, "insert timer" + carriageId));
		timerExecutor.scheduleAtFixedRate(insertRunnable, 0, 1, TimeUnit.HOURS);
	}

	/**
	 * stop message storage
	 */
	public void stop() {
		updateRecord();
		if (storeExecutors != null) {
			storeExecutors.shutdown();
			storeExecutors = null;
		}
		if (insertExecutors != null) {
			insertExecutors.shutdown();
			insertExecutors = null;
		}
		if (timerExecutor != null) {
			timerExecutor.shutdown();
			timerExecutor = null;
		}
	}

	public void push(List<DoorMessage> messages) {
		try {
			queue.put(messages);
		} catch (final InterruptedException e) {
			StoreService.logger.error(e.getMessage(), e);
		}
	}

	public void setDebug(boolean debug) {
		timerExecutor.shutdownNow();
		this.debug.set(debug);
		timerExecutor = Executors.newSingleThreadScheduledExecutor(r -> new Thread(r, "insert timer" + carriageId));
		timerExecutor.scheduleAtFixedRate(insertRunnable, 0, 1, TimeUnit.HOURS);
	}

	private void insertMessage(List<DoorMessage> list) {
		final SqlSession session = DBService.getInstance().getSession(true);
		try {
			final StoreMapper mapper = DBService.getInstance().getMapper(StoreMapper.class, session);
			final Map<String, Object> map = new HashMap<String, Object>();
			map.put("carriageId", carriageId);
			map.put("list", list);
			mapper.insertMessage(map);
		} finally {
			DBService.getInstance().disconnect(session);
		}
//		System.out.println(String.format("[%tT] store-carriagedId:%d", new Date(), carriageId));
	}

	private void insertRecord(Integer doorId, Date startTime) {
		insertExecutors.submit(() -> {
			final SqlSession session = DBService.getInstance().getSession(false);
			try {
				lock.tryLock();
				insertNewRecord(doorId, startTime, session);
				session.commit();
			} finally {
				DBService.getInstance().disconnect(session);
				lock.unlock();
			}
			System.out.println("insert-carriageId: " + carriageId + " : " + doorId);
		});
	}

	private void fixRecord() {
		final SqlSession session = DBService.getInstance().getSession(false);
		try {
			lock.tryLock();
			Date lastInsert = getLastInsertTime(session);
			if (lastInsert != null) {
				final Date now = new Date();
				if ((now.getTime() - lastInsert.getTime()) > 60 * 60 * 1000) {
					Date endTime = new Date(lastInsert.getTime() + 60 * 60 * 1000);
					updateEndTime(endTime, session);
				} else {
					updateEndTime(now, session);
				}
				session.commit();
			}
		} finally {
			DBService.getInstance().disconnect(session);
			lock.unlock();
		}
		System.out.println("fix-carriageId:" + carriageId);
	}

	private void updateRecord() {
		insertExecutors.submit(() -> {
			final SqlSession session = DBService.getInstance().getSession(false);
			try {
				lock.tryLock();
				updateEndTime(endTime, session);
				session.commit();
			} finally {
				DBService.getInstance().disconnect(session);
				lock.unlock();
			}
			System.out.println("complete-carriageId:" + carriageId);
		});
	}

	private void insertNewRecord(Integer doorId, Date startTime, SqlSession session) {
		final StoreMapper mapper = DBService.getInstance().getMapper(StoreMapper.class, session);
		MessageRecord record = new MessageRecord();
		record.setId(null);
		record.setCarriageId(carriageId);
		record.setDoorId(doorId);
		record.setStartTime(startTime);
		record.setEndTime(null);
		record.setDebug(debug.get());
		mapper.insert(record);
	}

	private void updateEndTime(Date now, SqlSession session) {
		final StoreMapper mapper = DBService.getInstance().getMapper(StoreMapper.class, session);
		mapper.updateEndtime(carriageId, now);
		hasMsg.clear();
	}

	private Date getLastInsertTime(SqlSession session) {
		final StoreMapper mapper = DBService.getInstance().getMapper(StoreMapper.class, session);
		return mapper.findLastRecordInsertTime(carriageId);
	}

}
