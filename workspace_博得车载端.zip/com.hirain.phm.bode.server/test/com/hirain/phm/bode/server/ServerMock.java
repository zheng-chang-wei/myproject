package com.hirain.phm.bode.server;

import java.net.InetSocketAddress;

import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ClientService;
import com.hirain.phm.bode.server.server.ServerService;

public class ServerMock {

	private ClientService client;

	private ServerService server;

	public void start() {
		String localhost = TestConstant.LOCALHOST;
		client = new ClientService(localhost, null);
		client.init();
		InetSocketAddress localClient = new InetSocketAddress(localhost, ClientConstants.LOCAL_CLIENT_PORT);
		InetSocketAddress localHeart = new InetSocketAddress(localhost, ClientConstants.LOCAL_HEART_PORT);
		InetSocketAddress localUpload = new InetSocketAddress(localhost, ClientConstants.LOCAL_UPLOAD_PORT);
		client.start(localClient, localHeart, localUpload);
		server = new ServerService();
		server.init();
	}
}
