/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.util;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 22, 2019 1:27:16 PM
 * @Description
 *              <p>
 *              调试模式的两种状态：开始调试、停止调试
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 22, 2019 zepei.tao@hirain.com 1.0 create file
 */
public enum DebugeEnum {

	start((byte) 0x01), stop((byte) 0x02);

	private byte state;

	DebugeEnum(byte state) {
		this.state = state;
	}

	public byte getState() {
		return state;
	}

	public void setState(byte state) {
		this.state = state;
	}

}
