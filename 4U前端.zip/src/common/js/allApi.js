const appApi = {
  // 用户管理
  logIn: '/login', // 登入
  logOut: '/logout', // 登出
  list_all_protocols: '/setting/all', // 获取所有配置
  get_setting_by_id: '/setting/select', // 获取所有配置
  upload_protocol: '/setting/upload/protocol', // 上传数据流文件
  upload_script: '/setting//upload/script', // 上传脚本文件
  save_protocol: '/setting/update', // 保存配置
  activate_protocol: '/setting/activate', // 激活配置

  delete_protocol: '/setting/delete', // 删除配置
  select_all_subsystems: '/setting/selectAllSubsystems', // 查询所有子系统

  board_list: '/board/list',
  board_abstract: '/board/count',
  board_history: '/board/history',

  algorithm_list: '/algorithm/list',
  algorithm_abstract: '/algorithm/count',
  algorithm_history: '/algorithm/history'

}

export default appApi
