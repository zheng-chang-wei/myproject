package com.hirain.phm.bode.ui.monitor.figure.carriage;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.geometry.Rectangle;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created Jan 7, 2019 5:34:58 PM
 * @Description
 *              <p>
 *              隔离
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 7, 2019 changwei.zheng@hirain.com 1.0 create file
 */
public class IsolationFigure extends Figure {

	@Override
	protected void paintFigure(Graphics g) {
		Rectangle r = bounds;
		g.setLineWidth(3);
		g.fillRectangle(r.x, r.y, r.width, r.height);
		// |
		g.drawLine(r.x, r.y, r.x, r.y + r.height);
		// ——
		g.drawLine(r.x, r.y, r.x + r.width, r.y);
		// |
		g.drawLine(r.x + r.width - 1, r.y, r.x + r.width - 1, r.y + r.height);
		// ——
		g.drawLine(r.x, r.y + r.height - 1, r.x + r.width, r.y + r.height - 1);
		// \
		g.drawLine(r.x, r.y, r.x + r.width, r.y + r.height);
		// /
		g.drawLine(r.x, r.y + r.height, r.x + r.width, r.y);
		setBackgroundColor(ColorConstants.green);

	}
}
