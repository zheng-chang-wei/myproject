package com.hirain.phm.bode.server.server;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MDCULiveHandler {

	private final Map<String, Boolean> mdcus = new ConcurrentHashMap<>();

	private ScheduledExecutorService heartExecutor;

	private final AbstractServerService server;

	public MDCULiveHandler(AbstractServerService server) {
		heartExecutor = Executors.newSingleThreadScheduledExecutor(r -> new Thread(r, "mdcu-live-handler"));
		this.server = server;
	}

	public void addMdcu(String ip) {
		mdcus.put(ip, false);
	}

	public void update(String ip) {
		mdcus.put(ip, true);
	}

	public void start() {
		heartExecutor.scheduleAtFixedRate(() -> {
			for (final String ip : mdcus.keySet()) {
				if (!mdcus.get(ip)) {
					server.sendOk(ip);
				}
				mdcus.put(ip, false);
			}
		}, 1, 1, TimeUnit.SECONDS);
	}

	public void stop() {
		heartExecutor.shutdown();
		heartExecutor = null;
	}
}
