package com.hirain.qsy.shaft.common.model;

public class CoreConstant {

	/**
	 * 0表示所有车型
	 */
	public static String allCarType = "0";

	/**
	 * 测点个数
	 */
	public static int pointCount = 6;

	/**
	 * 轴个数
	 */
	public static int axleCount = 6;
}
