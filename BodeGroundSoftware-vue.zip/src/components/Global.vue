<script>
const serverIpAndPort = 'http://localhost:8082/'

export default {
  serverIpAndPort // 服务端IP
}

</script>
