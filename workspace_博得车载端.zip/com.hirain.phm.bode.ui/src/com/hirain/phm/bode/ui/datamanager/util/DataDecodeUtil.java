package com.hirain.phm.bode.ui.datamanager.util;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import com.hirain.phm.bode.client.communication.message.DataResultMessage;
import com.hirain.phm.bode.core.message.DataMessage;
import com.hirain.phm.bode.core.message.MessageRecord;
import com.hirain.phm.bode.core.util.StringUtil;

public class DataDecodeUtil {

	public static List<DataMessage> getDataMessages(DataResultMessage message) {
		List<DataMessage> dataMessages = new ArrayList<>();
		if (message != null) {
			byte[] data = message.getData();
			ByteBuffer buffer = ByteBuffer.wrap(data);
			buffer.get();
			int num = Short.toUnsignedInt(buffer.getShort());
			for (int i = 0; i < num; i++) {
				DataMessage dateMessage = new DataMessage();
				byte[] datas = new byte[32];
				buffer.get(datas);
				dateMessage.setData(datas);
				dataMessages.add(dateMessage);
			}
		}
		return dataMessages;
	}

	public static List<MessageRecord> getMessageRecord(DataResultMessage message) {
		List<MessageRecord> records = new ArrayList<>();
		if (message != null) {
			byte[] data = message.getData();
			ByteBuffer buffer = ByteBuffer.wrap(data);
			// 查询结果类型
			buffer.get();
			// 记录数量
			byte num = buffer.get();

			for (int i = 0; i < num; i++) {
				MessageRecord messageRecord = new MessageRecord();

				String startTime = getTime(buffer);

				messageRecord.setStartTime(startTime);

				String endTime = getTime(buffer);

				messageRecord.setEndTime(endTime);

				messageRecord.setDebug(buffer.get() == 1 ? "是" : "否");
				records.add(messageRecord);
			}
		}
		return records;
	}

	public static List<String> getDownloadMessage(DataResultMessage message) {
		List<String> list = new ArrayList<>();
		byte[] data = message.getData();
		ByteBuffer buffer = ByteBuffer.wrap(data);
		buffer.get();
		int num = Short.toUnsignedInt(buffer.getShort());
		for (int i = 0; i < num; i++) {
			StringBuffer stringBuffer = new StringBuffer();
			byte[] datas = new byte[32];
			buffer.get(datas);
			for (byte b : datas) {
				String hexString = Integer.toHexString(Byte.toUnsignedInt(b));
				if (hexString.length() == 1) {
					stringBuffer.append(0);
				}
				stringBuffer.append(hexString.toUpperCase());
			}
			list.add(stringBuffer.toString());
			buffer.getShort();
		}
		return list;
	}

	private static String getTime(ByteBuffer buffer) {
		StringBuilder builder = new StringBuilder();
		// 年
		builder.append(buffer.get() + 2000);
		builder.append(StringUtil.MID_LINE);
		// 月
		builder.append(Byte.toUnsignedInt(buffer.get()) + 1);
		builder.append(StringUtil.MID_LINE);
		// 日
		builder.append(Byte.toUnsignedInt(buffer.get()));
		builder.append(" ");
		// 时
		builder.append(Byte.toUnsignedInt(buffer.get()));
		builder.append(StringUtil.COLON);
		// 分
		builder.append(Byte.toUnsignedInt(buffer.get()));
		builder.append(StringUtil.COLON);
		// 秒
		builder.append(Byte.toUnsignedInt(buffer.get()));
		return builder.toString();
	}
}
