package com.hirain.phm.bode.server.ground;

import java.io.File;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.hirain.phm.bode.server.ground.sender.MessageFileCache;

public class MessageFileCacheTest {

	@Test
	public void test() {
		final File folder = new File("E:\\workIDE\\runtime-com.hirain.autotcn.ui.basic.product\\MVB Monitor");
		final File[] files = folder.listFiles();

		final List<File> fileList = Arrays.asList(files);
		Collections.sort(fileList);
		fileList.forEach(f -> System.out.println(f.getName()));
	}

	@Test
	public void testSeque() {
		final MessageFileCache cache = new MessageFileCache();
		cache.init();
		CountDownLatch latch = new CountDownLatch(2);
		ExecutorService executor = Executors.newFixedThreadPool(2);
		executor.submit(() -> {
			for (int i = 0; i < 50; i++) {
				try {
					TimeUnit.MILLISECONDS.sleep(200);
				} catch (InterruptedException e) {
				}
				String time = LocalDateTime.now().toString();
				final byte[] datas = time.getBytes();
				cache.write(datas);
				// System.out.println("write:" + time);
			}
			latch.countDown();
		});
		executor.submit(() -> {
			for (int i = 0; i < 100;) {
				final byte[] bs = cache.read();
				if (bs == null) {
					try {
						TimeUnit.MILLISECONDS.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					continue;
				}
				i++;
				String value = new String(bs);
				System.out.println("read:" + value);
			}
			latch.countDown();
		});

		try {
			latch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
