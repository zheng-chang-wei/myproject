package com.hirain.phm.bode.server.comm;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 */
public interface IEncoder {

	ITransportPacket encode(int sid, byte[] data);
}
