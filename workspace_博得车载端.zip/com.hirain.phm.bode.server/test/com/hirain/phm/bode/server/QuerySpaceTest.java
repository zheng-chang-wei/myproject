package com.hirain.phm.bode.server;

import java.io.File;

public class QuerySpaceTest {

	public static void main(String[] args) {
		final File[] roots = File.listRoots();
		for (final File root : roots) {
			System.out.println(root.getPath() + ":" + root.getFreeSpace() / 1024 / 1024 + "/" + root.getTotalSpace() / 1024 / 1024);
		}
	}
}
