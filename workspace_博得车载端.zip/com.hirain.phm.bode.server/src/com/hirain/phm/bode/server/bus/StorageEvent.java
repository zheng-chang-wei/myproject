package com.hirain.phm.bode.server.bus;

public class StorageEvent {

	private double total;

	private double used;

	private double faultSpace;

	private String faultStart;

	private String commonStart;

	private String faultUpdate;

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public double getUsed() {
		return used;
	}

	public void setUsed(double used) {
		this.used = used;
	}

	public double getFaultSpace() {
		return faultSpace;
	}

	public void setFaultSpace(double faultSpace) {
		this.faultSpace = faultSpace;
	}

	public String getFaultStart() {
		return faultStart;
	}

	public void setFaultStart(String faultStart) {
		this.faultStart = faultStart;
	}

	public String getFaultUpdate() {
		return faultUpdate;
	}

	public void setFaultUpdate(String faultUpdate) {
		this.faultUpdate = faultUpdate;
	}

	public String getCommonStart() {
		return commonStart;
	}

	public void setCommonStart(String commonStart) {
		this.commonStart = commonStart;
	}
}
