package com.hirain.phm.bode.server.bus;

public class DebugEvent {

	private final boolean debug;

	private final Object from;

	public DebugEvent(boolean debug, Object from) {
		this.debug = debug;
		this.from = from;
	}

	public Object getFrom() {
		return from;
	}

	public boolean isDebug() {
		return debug;
	}

}
