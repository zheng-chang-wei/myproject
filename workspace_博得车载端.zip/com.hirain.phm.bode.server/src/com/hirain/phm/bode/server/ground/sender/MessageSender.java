package com.hirain.phm.bode.server.ground.sender;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import com.hirain.phm.bd.message.CarriagePacket;
import com.hirain.phm.bd.message.CommonMessage;
import com.hirain.phm.bd.message.DoorPacket;
import com.hirain.phm.bd.message.TrainPacket;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.message.DoorMessage;
import com.hirain.phm.bode.server.message.DoorMessageDecoder;
import com.hirain.phm.bode.server.mqtt.MqttPublisher;

public class MessageSender {

	private static int SEND_THREAD_COUNT = 10;

	private final DoorMessageDecoder decoder = new DoorMessageDecoder();

	private MqttPublisher publisher;

	private ScheduledExecutorService executor;

	private final Map<Integer, CarriageCache> realtimeMap = new ConcurrentHashMap<>();

	private String topic;

	private boolean stopped = false;

	private int index = 0;

	private String city;

	private String line;

	private String train;

	private final AtomicBoolean groundOn = new AtomicBoolean(true);

	private Future<?> reconnectfuture;

	private final ExecutorService executorService;

	private static AtomicInteger count = new AtomicInteger(0);

	private final ExecutorService sendPool;

	public MessageSender() {
		executorService = Executors.newSingleThreadExecutor();
		sendPool = Executors.newFixedThreadPool(SEND_THREAD_COUNT);
	}

	public void start() {
		if (executor != null && !executor.isShutdown()) {
			return;
		}
		stopped = false;
		executor = Executors.newSingleThreadScheduledExecutor(r -> new Thread(r, "message send to ground"));
		executor.scheduleAtFixedRate(() -> {
			final List<CarriagePacket> packets = new ArrayList<>();
			for (final Integer key : realtimeMap.keySet()) {
				final CarriageCache carriageCache = realtimeMap.get(key);
				final List<DoorPacket> list = carriageCache.get(16);
				if (!list.isEmpty()) {
					packets.add(new CarriagePacket(key, list));
				}
			}
			if (packets.isEmpty()) {
				return;
			}
			final TrainPacket packet = new TrainPacket(index, packets);
			packet.set(city, line, train);
			sendPool.submit(() -> {
				if ((publisher == null || !publisher.isConnected()) && !groundOn.get()) {
				} else {
					final String string = Utils.toJsonString(packet);
					boolean flag = false;
					try {
						publisher.send(topic, string.getBytes(), 1, false);
						System.out.println(count.incrementAndGet());
						flag = true;
					} catch (final Exception e) {
						e.printStackTrace();
					}
					if (!flag) {
						try {
							publisher.send(topic, string.getBytes(), 1, false);
							System.out.println(count.incrementAndGet());
						} catch (final Exception e) {
						}
					}
				}
			});
		}, 800, 800, TimeUnit.MILLISECONDS);
	}

	public void add(CommonMessage message) {
		final byte[] datas = message.getDatas();
		final DoorMessage doorMessage = decoder.decode(datas);
		CarriageCache carriageCache = realtimeMap.get(doorMessage.getCarriageId());
		if (carriageCache == null) {
			carriageCache = new CarriageCache();
			realtimeMap.put(doorMessage.getCarriageId(), carriageCache);
		}
		carriageCache.add(doorMessage.getDoorId(), message);
	}

	public void add(List<DoorMessage> messages, boolean debug) {
		final Integer carriageId = messages.get(0).getCarriageId();
		CarriageCache carriageCache = realtimeMap.get(carriageId);
		if (carriageCache == null) {
			carriageCache = new CarriageCache();
			realtimeMap.put(carriageId, carriageCache);
		}
		carriageCache.add(messages.get(0).getDoorId(), messages, debug);
	}

	public void reconnected() {
		if (stopped) {
			return;
		}
		if (reconnectfuture != null && !reconnectfuture.isDone()) {
			return;
		}
		reconnectfuture = executorService.submit(() -> {
		});
	}

	public void stop() {
		executor.shutdown();
		executor = null;
		stopped = true;
	}

	public void setPublisher(MqttPublisher publisher) {
		this.publisher = publisher;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public void setTrain(String train) {
		this.train = train;
	}

	public void set(String city, String line, String train) {
		setCity(city);
		setLine(line);
		setTrain(train);
	}

	public void setGroundOn(boolean on) {
		if (!groundOn.get() && on) {
			reconnected();
		}
		groundOn.set(on);
	}
}
