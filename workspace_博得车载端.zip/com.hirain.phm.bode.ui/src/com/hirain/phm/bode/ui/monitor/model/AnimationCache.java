package com.hirain.phm.bode.ui.monitor.model;

import java.util.List;

public class AnimationCache {

	private int a;

	private boolean processOpenDoor;

	private boolean processCloseDoor;

	private boolean doorClose;

	private boolean doorOpen;

	private long time;

	private List<Object> dataFrameList;

	public List<Object> getDataFrameList() {
		return dataFrameList;
	}

	public void setDataFrameList(List<Object> dataFrameList) {
		this.dataFrameList = dataFrameList;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public boolean isProcessOpenDoor() {
		return processOpenDoor;
	}

	public void setProcessOpenDoor(boolean processOpenDoor) {
		this.processOpenDoor = processOpenDoor;
	}

	public boolean isProcessCloseDoor() {
		return processCloseDoor;
	}

	public void setProcessCloseDoor(boolean processCloseDoor) {
		this.processCloseDoor = processCloseDoor;
	}

	public boolean isDoorClose() {
		return doorClose;
	}

	public void setDoorClose(boolean doorClose) {
		this.doorClose = doorClose;
	}

	public boolean isDoorOpen() {
		return doorOpen;
	}

	public void setDoorOpen(boolean doorOpen) {
		this.doorOpen = doorOpen;
	}
}
