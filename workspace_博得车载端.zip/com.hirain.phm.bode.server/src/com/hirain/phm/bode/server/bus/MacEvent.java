package com.hirain.phm.bode.server.bus;

public class MacEvent {

	String mac;

	public MacEvent(byte[] mac) {
		this.mac = new String(mac);
	}

	public String getMac() {
		return mac;
	}

}
