package com.hirain.phm.bode.server.client.data;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.io.FileUtils;
import org.apache.ibatis.session.SqlSession;

import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.ClientService;
import com.hirain.phm.bode.server.client.ISender;
import com.hirain.phm.bode.server.client.Token;
import com.hirain.phm.bode.server.db.DBService;
import com.hirain.phm.bode.server.log.LogRecord;
import com.hirain.phm.bode.server.log.LogRecordMapper;
import com.hirain.phm.bode.server.log.LogService;

public class LogDataDownloadHandler {

	private static final int MAX_SIZE = 65000;

	private final ExecutorService pool;

	private final String day;

	private final ISender sender;

	private final Token token;

	public LogDataDownloadHandler(ISender sender, String day, int type, Token token) {
		pool = Executors.newSingleThreadExecutor();
		this.day = day;
		this.sender = sender;
		this.token = token;
	}

	public void work() {
		pool.submit(() -> {
			SqlSession session = null;
			String filepath = null;
			try {
				session = DBService.getInstance().getSession(false);
				final LogRecordMapper mapper = session.getMapper(LogRecordMapper.class);
				final LogRecord record = mapper.selectByPrimaryKey(day);
				if (record != null) {
					filepath = record.getFilepath();
				}
			} catch (final Exception e) {
				ClientService.logger.error(e.getMessage(), e);
				DBService.getInstance().disconnect(session);
			}
			if (filepath != null) {
				final String path = LogService.instance().LOG_ROOT + filepath;
				final File file = new File(path);
				if (file.exists()) {
					try {
						final byte[] bs = FileUtils.readFileToByteArray(file);
						final ByteBuffer buffer = ByteBuffer.wrap(bs);
						while (buffer.hasRemaining()) {
							final int size = Math.min(MAX_SIZE, buffer.remaining());
							final byte[] send = new byte[size + 1];
							send[0] = ClientConstants.LOG_TAG;
							buffer.get(send, 1, size);
							sender.send(token.getAddress(), ClientConstants.DATA_DOWNLOAD_RESPONSE, send);
						}
					} catch (final IOException e) {
						ClientService.logger.error(e.getMessage(), e);
					}
				}
			}
			sender.send(token.getAddress(), ClientConstants.DATA_DOWNLOAD_RESPONSE, new byte[] { ClientConstants.LOG_TAG + 1 });
		});
	}
}
