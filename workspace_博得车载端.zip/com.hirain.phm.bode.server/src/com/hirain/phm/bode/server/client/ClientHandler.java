package com.hirain.phm.bode.server.client;

import com.hirain.phm.bode.server.comm.IPost;
import com.hirain.phm.bode.server.comm.ITransportPacket;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

class ClientHandler extends ChannelInboundHandlerAdapter {

	private final IPost poster;

	public ClientHandler(IPost poster) {
		this.poster = poster;
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		if (msg instanceof ITransportPacket) {
			poster.post((ITransportPacket) msg);
		}
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		ClientService.logger.error(cause.getMessage(), cause);
	}
}
