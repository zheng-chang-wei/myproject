package com.hirain.phm.bode.server.ground;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.hirain.phm.bode.server.PrefsUtil;
import com.hirain.phm.bode.server.mqtt.SslUtil;

public class GroundUtils {

	public static <T> String object2XmlStr(T t) throws JAXBException {
		final JAXBContext context = JAXBContext.newInstance(t.getClass());
		final Marshaller marshaller = context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
		marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
		final StringWriter sw = new StringWriter();
		marshaller.marshal(t, sw);
		return sw.toString();
	}

	public static boolean validateSSLCondition() {
		if (!validateCertFile(SslUtil.SSL_ROOT + "ca.crt")) {
			return false;
		}
		if (!validateCertFile(SslUtil.SSL_ROOT + "client.crt")) {
			return false;
		}
		final File file = new File(SslUtil.SSL_ROOT + "client.key");
		if (!file.exists()) {
			return false;
		}
		final String password = PrefsUtil.instance().getPassword();
		if (password == null) {
			return false;
		}
		return true;
	}

	public static boolean validateCertFile(final String caCert) {
		System.out.println(caCert);
		final File file = new File(caCert);
		if (!file.exists()) {
			return false;
		}
		try {
			if (SslUtil.overtime(caCert)) {
				return false;
			}
		} catch (final IOException e) {
			return false;
		}
		return true;
	}
}
