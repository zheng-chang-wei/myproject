package com.hirain.phm.bode.core.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class FileUtil {

	/**
	 * 以行为单位读取文件，常用于读面向行的格式化文件
	 * 
	 * @throws IOException
	 */
	public static List<String> readFileByLines(String filePath) throws IOException {
		File file = new File(filePath);
		BufferedReader reader = null;
		List<String> list = new ArrayList<String>();
		try {
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;

			while ((tempString = reader.readLine()) != null) {
				String trim = tempString.trim();
				if (!trim.isEmpty()) {
					list.add(tempString);
				}
			}
		} catch (IOException e) {
			throw e;
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					throw e;
				}
			}
		}
		return list;
	}

	/**
	 * 以行为单位写文件
	 * 
	 * @throws IOException
	 */
	public static void writeFileByLines(List<String> list, String filePath) throws IOException {
		File file = new File(filePath);
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(file));
			for (String string : list) {
				writer.write(string + "\r\n");
			}
		} catch (IOException e) {
			throw e;
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					throw e;
				}
			}
		}
	}

	/**
	 * 以追加的方式写文件
	 * 
	 * @param filePath
	 * @param content
	 */
	public static void appendFile(String content, String filePath) {
		FileWriter fw = null;
		PrintWriter pw = null;
		try {
			// 如果文件存在，则追加内容；如果文件不存在，则创建文件
			File f = new File(filePath);
			fw = new FileWriter(f, true);
			pw = new PrintWriter(fw);
			pw.println(content);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pw != null) {
					pw.close();
					pw = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (fw != null) {
					fw.close();
					fw = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 以追加的方式写文件
	 * 
	 * @param filePath
	 * @param content
	 */
	public static void appendFile(List<String> contents, String filePath) {
		FileWriter fw = null;
		PrintWriter pw = null;
		try {
			// 如果文件存在，则追加内容；如果文件不存在，则创建文件
			File f = new File(filePath);
			fw = new FileWriter(f, true);
			pw = new PrintWriter(fw);
			for (String content : contents) {
				pw.println(content);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pw != null) {
					pw.close();
					pw = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (fw != null) {
					fw.close();
					fw = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}
