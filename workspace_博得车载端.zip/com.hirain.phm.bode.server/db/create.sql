use phm_bd;

create table t_user(
username varchar(20) not null,
password varchar(20) not null,
primary key(username)
)ENGINE=InnoDB default charset=utf8;

create table t_fault(
id int not null,
cname varchar(255)not null,
primary key(id)
)ENGINE=InnoDB default charset=utf8;

create table t_fault_record(
id bigint not null auto_increment,
fault_id int not null,
carriage_id int not null,
door_id int not null,
timestamp datetime(6) not null,
start_time datetime not null,
end_time datetime not null,
debug boolean default false,
primary key(id)
)ENGINE=InnoDB default charset=utf8
partition by range(id)
(
partition p10000 values less than(10000),
partition p20000 values less than(20000),
partition p30000 values less than(30000)
);

create table t_fault_message(
id bigint not null auto_increment,
carriage_id int not null,
door_id int not null,
timestamp datetime not null,
datas blob not null,
primary key(id,timestamp)
)ENGINE=InnoDB default charset=utf8;

create table t_log(
day varchar(20) not null,
filepath varchar(255) not null,
primary key(day)
)ENGINE=InnoDB default charset=utf8;