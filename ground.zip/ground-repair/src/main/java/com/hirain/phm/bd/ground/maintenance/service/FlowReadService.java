/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.ground.maintenance.service;

import java.util.List;

import com.hirain.phm.bd.ground.maintenance.domain.WorkStep;
import com.hirain.phm.bd.ground.maintenance.param.SheetCountResponse;
import com.hirain.phm.bd.ground.maintenance.param.WorkSheetRecord;
import com.hirain.phm.bd.ground.maintenance.param.WorksheetPacket;
import com.hirain.phm.bd.ground.train.param.TrainParamHeader;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年6月3日 下午2:40:00
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年6月3日 jianwen.xin@hirain.com 1.0 create file
 */
public interface FlowReadService {

	WorkStep findLastSameStep(Long sheetId, String state);

	List<WorkSheetRecord> listWorkSheets(TrainParamHeader trainParam);

	WorksheetPacket getWorksheet(Long sheetId);

	/**
	 * @return
	 */
	SheetCountResponse countSheets();
}
