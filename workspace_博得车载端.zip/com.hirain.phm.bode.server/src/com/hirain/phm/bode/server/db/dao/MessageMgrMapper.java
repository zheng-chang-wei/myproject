package com.hirain.phm.bode.server.db.dao;

import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface MessageMgrMapper {

	/**
	 * create message data table, the format of table name is
	 * 't_carriage{carriageId}_message'<br/>
	 * <code>
	 * create table `t_carriage${carriageId}_message`(
	 * 		id bigint not null auto_increment,
	 * 		door_id int not null, 
	 * 		timestamp datetime not null,
	 * 		datas binary(32) not null,
	 * 		primary key(id,timestamp)
	 * )ENGINE=InnoDB default charset=utf8
	 * PARTITION by range(to_days(timestamp))
	 * (
	 * 		partition p${time} values less than(to_days(time)+1),
	 * 		......
	 * )
	 * </code>
	 * 
	 * @param map
	 *            key:carriageId value:int key:list value:List<String>
	 * @return
	 */
	int createMessageTable(Map<String, Object> map);

	/**
	 * check if table 't_carriage{carriageId}_message' exists
	 * 
	 * @param carriageId
	 * @return
	 */
	int existMessageTable(@Param("carriageId") int carriageId);

	/**
	 * add partitions to message table
	 * 
	 * @param map
	 *            key:carriageId value:int key:list value:List<String>
	 * @return
	 */
	int addPartitionsToMessage(Map<String, Object> map);

	/**
	 * remove partitions from message table
	 * 
	 * @return
	 */
	int dropPartitionFromMessage(@Param("tableName") String tableName, @Param("day") String day);

	/**
	 * delete messages from message table before given date
	 * 
	 * @return
	 */
	int deleteMessagesBeforeDay(@Param("tableName") String tableName, @Param("day") String day);

}
