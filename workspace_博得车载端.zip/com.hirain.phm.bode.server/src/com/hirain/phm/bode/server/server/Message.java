package com.hirain.phm.bode.server.server;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年1月7日 上午10:17:59
 * @Description
 *              <p>
 *              The original message from mdcu
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月7日 jianwen.xin@hirain.com 1.0 create file
 */
public class Message {

	/**
	 * original datas
	 */
	private final byte[] datas;

	public Message(byte[] datas) {
		this.datas = datas;
	}

	public byte[] getDatas() {
		return datas;
	}

}
