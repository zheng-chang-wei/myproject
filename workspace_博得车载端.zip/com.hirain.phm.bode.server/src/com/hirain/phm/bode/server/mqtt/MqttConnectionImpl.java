package com.hirain.phm.bode.server.mqtt;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import com.hirain.phm.bode.server.ground.GroundConstant;

public class MqttConnectionImpl implements MqttConnection {

	private final String host;

	private final String clientId;

	private final MqttCallback callback;

	private MqttClient client;

	private byte[] will;

	private final Map<String, Integer> topicCache = new HashMap<>();

	public MqttConnectionImpl(String host, String clientId, MqttCallback callback) {
		this.host = host;
		this.clientId = clientId;
		this.callback = callback;
	}

	@Override
	public void connect() throws Exception {
		connect(getOptions());
	}

	@Override
	public void connect(final String caCrtFile, final String crtFile, final String keyFile, final String password) throws Exception {
		final MqttConnectOptions options = getOptions();
		options.setSocketFactory(SslUtil.getSocketFactory(caCrtFile, crtFile, keyFile, password));
		connect(options);
	}

	@Override
	public void disconnect() throws MqttException {
		getClient().disconnect();
		getClient().close();
	}

	@Override
	public void send(String topic, byte[] payload) throws Exception {
		send(topic, payload, 1, false);
	}

	@Override
	public void send(String topic, byte[] payload, int qos, boolean retained) throws Exception {
		getClient().publish(topic, payload, qos, retained);
	}

	@Override
	public void sendAsync(String topic, byte[] payload) {
		try {
			getClient().getTopic(topic).publish(payload, 0, false);
		} catch (final MqttException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void subscribe(String topic, int qos) throws MqttException {
		topicCache.put(topic, qos);
		getClient().subscribe(topic, qos);
	}

	@Override
	public void subscribe(String topic) throws MqttException {
		topicCache.put(topic, -1);
		getClient().subscribe(topic);
	}

	@Override
	public boolean isConnected() {
		return client != null && client.isConnected();
	}

	public MqttClient getClient() {
		return client;
	}

	private void connect(final MqttConnectOptions options) throws Exception {
		client = new MqttClient(host, clientId, new MemoryPersistence());
		client.setCallback(callback);
		client.connect(options);
	}

	protected MqttConnectOptions getOptions() {
		final MqttConnectOptions options = new MqttConnectOptions();
		options.setCleanSession(false);
		options.setConnectionTimeout(20);
		options.setKeepAliveInterval(10);
		options.setAutomaticReconnect(true);
		if (will != null) {
			options.setWill(GroundConstant.TRAIN_TO_GROUND, will, 1, false);
		}
		return options;
	}

	public void setWill(byte[] will) {
		this.will = will;
	}

}
