/*******************************************************************************
 * Copyright (c) 2018, 2018 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.client.communication.message;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2018年11月8日 上午9:46:00
 * @Description
 *              <p>
 *              心跳查询回复
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2018年11月8日 jianwen.xin@hirain.com 1.0 create file
 */
public class HeartMessage extends AbstractMessage {

}
