package com.hirain.phm.bode.server.comm.impl;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;

import com.hirain.phm.bode.server.comm.IConnection;
import com.hirain.phm.bode.server.comm.IConnectionFactory;
import com.hirain.phm.bode.server.comm.IConnectionManager;
import com.hirain.phm.bode.server.comm.ITransportPacket;

public class ConnectionManagerImpl implements IConnectionManager {

	private final IConnectionFactory factory;

	private final Map<Integer, IConnection> connectionMap = new HashMap<>();

	public ConnectionManagerImpl(IConnectionFactory factory) {
		this.factory = factory;
	}

	@Override
	public int bind(InetSocketAddress... addrs) {
		for (InetSocketAddress addr : addrs) {
			IConnection connection = factory.create(addr);
			connectionMap.put(addr.getPort(), connection);
			connection.bind();
		}
		return 0;
	}

	@Override
	public int stop(InetSocketAddress... address) {
		if (address == null || address.length == 0) {
			for (Integer key : connectionMap.keySet()) {
				connectionMap.get(key).disconnect();
				connectionMap.remove(key);
			}
		} else {
			for (InetSocketAddress addr : address) {
				connectionMap.get(addr.getPort()).disconnect();
				connectionMap.remove(addr.getPort());
			}
		}
		return 0;
	}

	@Override
	public int send(ITransportPacket packet) {
		int port = packet.localPort();
		IConnection connection = connectionMap.get(port);
		if (connection != null) {
			return connection.send(packet);
		}
		System.out.println("null port");
		return -1;
	}

}
