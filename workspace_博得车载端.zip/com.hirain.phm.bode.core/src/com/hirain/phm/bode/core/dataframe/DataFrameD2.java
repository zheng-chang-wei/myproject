/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.dataframe;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 10, 2019 4:58:52 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 10, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DataFrameD2 {

	/**
	 * 门开
	 */
	private boolean door_Open;

	/**
	 * 开门过程
	 */
	private boolean process_openDoor;

	/**
	 * 关门过程
	 */
	private boolean process_closeDoor;

	/**
	 * 门关
	 */
	private boolean door_Close;

	/**
	 * 防挤压过程中
	 */
	private boolean process_PreventExtrusion;

	/**
	 * 防挤压停
	 */
	private boolean PreventExtrusionStop;

	/**
	 * 电机电压
	 */
	private byte motorVoltage;

	/**
	 * 电机电流
	 */
	private double motorCurrent;

	/**
	 * 车厢号
	 */
	private int carNo;

	/**
	 * 门地址
	 */
	private int doorAddr;

	/**
	 * 车号
	 */
	private int trainNo;

	/**
	 * 开门时间
	 */
	private short openDoorTime;

	/**
	 * @return the door_Open
	 */
	public boolean isDoor_Open() {
		return door_Open;
	}

	/**
	 * @param door_Open
	 *            the door_Open to set
	 */
	public void setDoor_Open(boolean door_Open) {
		this.door_Open = door_Open;
	}

	/**
	 * @return the process_openDoor
	 */
	public boolean isProcess_openDoor() {
		return process_openDoor;
	}

	/**
	 * @param process_openDoor
	 *            the process_openDoor to set
	 */
	public void setProcess_openDoor(boolean process_openDoor) {
		this.process_openDoor = process_openDoor;
	}

	/**
	 * @return the process_closeDoor
	 */
	public boolean isProcess_closeDoor() {
		return process_closeDoor;
	}

	/**
	 * @param process_closeDoor
	 *            the process_closeDoor to set
	 */
	public void setProcess_closeDoor(boolean process_closeDoor) {
		this.process_closeDoor = process_closeDoor;
	}

	/**
	 * @return the door_Close
	 */
	public boolean isDoor_Close() {
		return door_Close;
	}

	/**
	 * @param door_Close
	 *            the door_Close to set
	 */
	public void setDoor_Close(boolean door_Close) {
		this.door_Close = door_Close;
	}

	/**
	 * @return the process_PreventExtrusion
	 */
	public boolean isProcess_PreventExtrusion() {
		return process_PreventExtrusion;
	}

	/**
	 * @param process_PreventExtrusion
	 *            the process_PreventExtrusion to set
	 */
	public void setProcess_PreventExtrusion(boolean process_PreventExtrusion) {
		this.process_PreventExtrusion = process_PreventExtrusion;
	}

	/**
	 * @return the preventExtrusionStop
	 */
	public boolean isPreventExtrusionStop() {
		return PreventExtrusionStop;
	}

	/**
	 * @param preventExtrusionStop
	 *            the preventExtrusionStop to set
	 */
	public void setPreventExtrusionStop(boolean preventExtrusionStop) {
		PreventExtrusionStop = preventExtrusionStop;
	}

	/**
	 * @return the motorVoltage
	 */
	public byte getMotorVoltage() {
		return motorVoltage;
	}

	/**
	 * @param motorVoltage
	 *            the motorVoltage to set
	 */
	public void setMotorVoltage(byte motorVoltage) {
		this.motorVoltage = motorVoltage;
	}

	/**
	 * @return the motorCurrent
	 */
	public double getMotorCurrent() {
		return motorCurrent;
	}

	/**
	 * @param motorCurrent
	 *            the motorCurrent to set
	 */
	public void setMotorCurrent(double motorCurrent) {
		this.motorCurrent = motorCurrent;
	}

	/**
	 * @return the carNo
	 */
	public int getCarNo() {
		return carNo;
	}

	/**
	 * @param carNo
	 *            the carNo to set
	 */
	public void setCarNo(int carNo) {
		this.carNo = carNo;
	}

	/**
	 * @return the doorAddr
	 */
	public int getDoorAddr() {
		return doorAddr;
	}

	/**
	 * @param doorAddr
	 *            the doorAddr to set
	 */
	public void setDoorAddr(int doorAddr) {
		this.doorAddr = doorAddr;
	}

	/**
	 * @return the trainNo
	 */
	public int getTrainNo() {
		return trainNo;
	}

	/**
	 * @param trainNo
	 *            the trainNo to set
	 */
	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}

	/**
	 * @return the openDoorTime
	 */
	public short getOpenDoorTime() {
		return openDoorTime;
	}

	/**
	 * @param openDoorTime
	 *            the openDoorTime to set
	 */
	public void setOpenDoorTime(short openDoorTime) {
		this.openDoorTime = openDoorTime;
	}

}
