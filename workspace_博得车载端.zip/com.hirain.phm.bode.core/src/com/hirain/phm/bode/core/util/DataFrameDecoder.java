/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Map;

import com.hirain.phm.bode.core.dataframe.DataFrameD1;
import com.hirain.phm.bode.core.dataframe.DataFrameD2;
import com.hirain.phm.bode.core.dataframe.DataFrameD3;
import com.hirain.phm.bode.core.dataframe.DataFrameD4;
import com.hirain.phm.bode.core.dataframe.DoorStatus;
import com.hirain.phm.bode.core.dataframe.IDataFrame;
import com.hirain.phm.bode.core.dataframe.RunDataFrame;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 16, 2019 4:47:24 PM
 * @Description
 *              <p>
 *              车门信息数据帧的解码器
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 16, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DataFrameDecoder {

	/**
	 * 获取每条报文中的帧数据信息对象和车门状态对象
	 * 
	 * @param dataByte
	 * @return
	 */
	public Map<IDataFrame, DoorStatus> convertBytes2DataFrame(byte[] dataByte) {
		if (dataByte.length != 32) {
			throw new IllegalArgumentException("message length error! ");
		}
		Map<IDataFrame, DoorStatus> map = new HashMap<IDataFrame, DoorStatus>();
		final ByteBuffer buffer = ByteBuffer.wrap(dataByte);
		RunDataFrame dataFrame = new RunDataFrame();
		DoorStatus doorStatus = new DoorStatus();
		byte b0 = buffer.get();
		dataFrame.setID(b0);
		byte b1 = buffer.get();
		dataFrame.setType(b1);

		DataFrameD1 d1 = new DataFrameD1();
		dataFrame.setDataFrameD1(d1);
		{
			byte b2 = buffer.get();
			boolean result = (b2 & 0x01) == 1 ? true : false;
			d1.setDoor_PreventExtrusion(result);
			doorStatus.setAnticrush(result);

			result = (b2 >> 1 & 0x01) == 1 ? true : false;
			d1.setDoor_Isolation(result);
			doorStatus.setIsolation(result);

			result = (b2 >> 2 & 0x01) == 1 ? true : false;
			d1.setDoor_EmergencyUnlock(result);
			doorStatus.setEmergencyUnlock(result);

			result = (b2 >> 3 & 0x01) == 1 ? true : false;
			d1.setDoor_Open(result);
			doorStatus.setOpenCompletely(result);

			result = (b2 >> 4 & 0x01) == 1 ? true : false;
			d1.setDoor_Close(result);
			doorStatus.setCloseCompletely(result);

			d1.setDoor_Action((b2 >> 5 & 0x01) == 1 ? true : false);
			d1.setDoor_NoSpeed((b2 >> 6 & 0x01) == 1 ? true : false);
			d1.setDoor_Enable((b2 >> 7 & 0x01) == 1 ? true : false);

		}
		{
			byte b3 = buffer.get();
			d1.setDoor_ControlChoose((b3 >> 2 & 0x01) == 1 ? true : false);
			d1.setFeedback_SwitchAgain((b3 >> 3 & 0x01) == 1 ? true : false);
			d1.setDetectObstacles((b3 >> 4 & 0x01) == 1 ? true : false);
			d1.setFeedback_doorClose((b3 >> 5 & 0x01) == 1 ? true : false);
			d1.setFeedback_doorOpen((b3 >> 6 & 0x01) == 1 ? true : false);
			boolean faultExisted = (b3 >> 7 & 0x01) == 1 ? true : false;
			d1.setFault_DoorExist(faultExisted);
			doorStatus.setExistFault(faultExisted);
		}
		{
			byte b4 = buffer.get();
			doorStatus.setMalfunction(b4);
			boolean result = (b4 & 0x01) == 1 ? true : false;
			d1.setFault_OutputShortCircuit(result);
			doorStatus.setOutputShortCircuit(result);
			result = (b4 >> 1 & 0x01) == 1 ? true : false;
			d1.setDoor_SwitchTimeOut(result);
			doorStatus.setSwitchTimeOut(result);
			result = (b4 >> 2 & 0x01) == 1 ? true : false;
			d1.setFault_Encoder(result);
			doorStatus.setEncoder(result);
			result = (b4 >> 3 & 0x01) == 1 ? true : false;
			d1.setFault_LockSwitch(result);
			doorStatus.setLockSwitch(result);
			result = (b4 >> 4 & 0x01) == 1 ? true : false;
			d1.setFault_GreenLoop(result);
			doorStatus.setGreenLoop(result);
			result = (b4 >> 5 & 0x01) == 1 ? true : false;
			d1.setFault_doorSwitch(result);
			doorStatus.setDoorSwitch(result);
			result = (b4 >> 6 & 0x01) == 1 ? true : false;
			d1.setFault_MotorOverCurrent(result);
			doorStatus.setMotorOverCurrent(result);
			result = (b4 >> 7 & 0x01) == 1 ? true : false;
			d1.setFault_MotorOpenCircuit(result);
			doorStatus.setMotorOpenCircuit(result);
		}
		{
			byte b5 = buffer.get();
			d1.setSignal_ServiceButton((b5 & 0x01) == 1 ? true : false);
			d1.setSignal_SwitchDoorCentralControl((b5 >> 1 & 0x01) == 1 ? true : false);
			d1.setSignal_CloseDoorCentralControl((b5 >> 2 & 0x01) == 1 ? true : false);
			d1.setSignal_OpenCloseAgain((b5 >> 3 & 0x01) == 1 ? true : false);
			d1.setSignal_ZeroSpeed((b5 >> 4 & 0x01) == 1 ? true : false);
			d1.setSignal_Isolation((b5 >> 5 & 0x01) == 1 ? true : false);
			d1.setSignal_EmergencyUnlock((b5 >> 6 & 0x01) == 1 ? true : false);
			d1.setSignal_UnlockSwitch((b5 >> 7 & 0x01) == 1 ? true : false);
		}
		{
			byte b6 = buffer.get();
			d1.setSignal_leftDoorOpenClose((b6 & 0x01) == 1 ? true : false);
			d1.setSignal_rightDoorOpenClose((b6 >> 1 & 0x01) == 1 ? true : false);
			d1.setDoor_CodeAddr1((b6 >> 2 & 0x01) == 1 ? true : false);
			d1.setDoor_CodeAddr2((b6 >> 3 & 0x01) == 1 ? true : false);
			d1.setDoor_CodeAddr3((b6 >> 4 & 0x01) == 1 ? true : false);
			d1.setDoor_CodeAddr4((b6 >> 5 & 0x01) == 1 ? true : false);
			d1.setSignal_SafetyInterlockInput((b6 >> 6 & 0x01) == 1 ? true : false);
			d1.setSignal_SafetyInterlockOutput((b6 >> 7 & 0x01) == 1 ? true : false);
		}
		{
			byte b7 = buffer.get();
			d1.setOpenDoorLightOutput((b7 & 0x01) == 1 ? true : false);
			d1.setEmergencyUnlockElectromagnetOutput((b7 >> 1 & 0x01) == 1 ? true : false);
			d1.setBuzzerOutput((b7 >> 2 & 0x01) == 1 ? true : false);
		}
		@SuppressWarnings("unused")
		byte b8 = buffer.get();
		DataFrameD2 d2 = new DataFrameD2();
		dataFrame.setDataFrameD2(d2);
		{
			byte b9 = buffer.get();
			d2.setDoor_Open((b9 & 0x01) == 1 ? true : false);

			boolean result = (b9 >> 1 & 0x01) == 1 ? true : false;
			d2.setProcess_openDoor(result);
			doorStatus.setOpenProcess(result);

			result = (b9 >> 2 & 0x01) == 1 ? true : false;
			d2.setProcess_closeDoor(result);
			doorStatus.setCloseProcess(result);

			d2.setDoor_Close((b9 >> 3 & 0x01) == 1 ? true : false);
			d2.setProcess_PreventExtrusion((b9 >> 4 & 0x01) == 1 ? true : false);
			d2.setPreventExtrusionStop((b9 >> 5 & 0x01) == 1 ? true : false);
		}
		{
			byte b10 = buffer.get();
			d2.setMotorVoltage(b10);
		}
		{
			byte b11 = buffer.get();
			int decimal = b11 & 0x0f;
			int integer = (b11 & 0xf0) >> 4;
			String current = String.valueOf(integer) + "." + String.valueOf(decimal);
			d2.setMotorCurrent(Double.valueOf(current));
		}
		{
			byte b12 = buffer.get();
			int carNo = b12 >> 4 & 0x0F;
			d2.setCarNo(carNo);
			doorStatus.setCarNo(carNo);
			int doorAddr = b12 & 0x0F;
			d2.setDoorAddr(doorAddr);
			doorStatus.setDoorAddr(doorAddr);
		}
		{
			byte b13 = buffer.get();
			d2.setTrainNo(b13 & 0xFF);
		}
		{// 开门时间
			byte b14 = buffer.get();
			byte b15 = buffer.get();
			short openDoorTime = (short) (b15 << 8 | b14 & 0xFF);
			d2.setOpenDoorTime(openDoorTime);

		}
		@SuppressWarnings("unused")
		byte b16 = buffer.get();
		DataFrameD3 d3 = new DataFrameD3();
		dataFrame.setDataFrameD3(d3);
		{// 关门时间
			byte b17 = buffer.get();
			byte b18 = buffer.get();
			short closeDoorTime = (short) (b18 << 8 | b17 & 0xFF);
			d3.setCloseDoorTime(closeDoorTime);
		}
		{// 编码器
			byte b19 = buffer.get();
			byte b20 = buffer.get();
			short encoder = (short) (b20 << 8 | b19 & 0xFF);
			d3.setEncoder(encoder);
		}
		{// 日
			byte b21 = buffer.get();
			d3.setDate(b21 & 0xFF);
			doorStatus.setDate(b21 & 0xFF);

		}
		{// 时
			byte b22 = buffer.get();
			d3.setHour(b22 & 0xFF);
			doorStatus.setHour(b22 & 0xFF);

		}
		{// 分
			byte b23 = buffer.get();
			d3.setMinute(b23 & 0xFF);
			doorStatus.setMinute(b23 & 0xFF);

		}
		@SuppressWarnings("unused")
		byte b24 = buffer.get();
		DataFrameD4 d4 = new DataFrameD4();
		dataFrame.setDataFrameD4(d4);
		{// 秒
			byte b25 = buffer.get();
			d4.setSecond(b25 & 0xFF);
			doorStatus.setSecond(b25 & 0xFF);
		}
		{// 毫秒
			int millisecond = Short.toUnsignedInt(buffer.order(ByteOrder.LITTLE_ENDIAN).getShort());
			d4.setMillisecond(millisecond);
			doorStatus.setMillisecond(millisecond);

		}
		{// 温度
			byte b28 = buffer.get();
			d4.setTemperature(b28 & 0XFF);
		}
		@SuppressWarnings("unused")
		byte b29 = buffer.get();
		{// CRC校验
			byte b30 = buffer.get();
			byte b31 = buffer.get();
			short verifyCRC = (short) (b31 << 8 | b30 & 0xFF);
			d4.setVerifyCRC(verifyCRC);
		}
		map.put(dataFrame, doorStatus);
		return map;
	}

	/**
	 * 获得车门及车厢地址
	 * 
	 * @return 车厢和车门地址组成的一个byte值，高四位车厢号，低四位门地址
	 */
	public static byte convertBytes2DoorAddr(byte[] dataByte) {
		if (dataByte.length != 32) {
			throw new IllegalArgumentException("message length error! ");
		}
		final ByteBuffer buffer = ByteBuffer.wrap(dataByte);
		byte b12 = buffer.get(12);
		return b12;
	}

}
