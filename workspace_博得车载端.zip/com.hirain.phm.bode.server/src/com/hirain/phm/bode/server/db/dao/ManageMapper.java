package com.hirain.phm.bode.server.db.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface ManageMapper extends MessageMgrMapper, RecordMgrMapper, FaultMgrMapper {

	String lastPartition(@Param("tableName") String tableName);

	String firstPartition(@Param("tableName") String tableName);

	long countPartitions(@Param("tableName") String tableName);

	double selectSpace();

	double selectFaultSpace();

	/**
	 * 根据后缀判断选择消息表或者记录表
	 */
	List<String> selectTables(@Param("suffix") String suffix);

	int existTable(@Param("tableName") String tableName);

	Date faultStartTime();

	Date faultUpdateTime();

	int deleteAll(@Param("tableName") String tableName);

}
