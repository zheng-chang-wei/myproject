package com.hirain.phm.bode.server.rbac;

import java.util.List;

import com.hirain.phm.bode.server.rbac.impl.UserOperation;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年1月4日 下午2:49:30
 * @Description
 *              <p>
 *              User Management
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月4日 jianwen.xin@hirain.com 1.0 create file
 */
public interface IUserService {

	/**
	 * validate username and password, set current user
	 * 
	 * @param username
	 * @param password
	 * @return
	 */
	boolean login(String username, String password);

	/**
	 * validate username, set null user
	 * 
	 * @param username
	 * @return
	 */
	boolean logout(String username);

	int update(List<UserOperation> operations);
}
