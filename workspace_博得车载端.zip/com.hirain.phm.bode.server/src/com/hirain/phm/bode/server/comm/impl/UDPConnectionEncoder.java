package com.hirain.phm.bode.server.comm.impl;

import java.nio.ByteBuffer;
import java.util.List;

import com.hirain.phm.bode.server.comm.ITransportPacket;

import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.socket.DatagramPacket;
import io.netty.handler.codec.MessageToMessageEncoder;

public class UDPConnectionEncoder extends MessageToMessageEncoder<ITransportPacket> {

	@Override
	protected void encode(ChannelHandlerContext ctx, ITransportPacket packet, List<Object> out) throws Exception {
		ByteBuffer buffer = ByteBuffer.wrap(packet.toByte());
		DatagramPacket datagramPacket = new DatagramPacket(Unpooled.copiedBuffer(buffer.array()), packet.getAddress());
		ctx.writeAndFlush(datagramPacket);
	}

}
