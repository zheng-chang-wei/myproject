package com.hirain.phm.bode.server.bus;

import java.nio.ByteBuffer;

import com.hirain.phm.bode.server.Utils;

public class ResultEvent {

	private int result;

	private int state;

	private SSLEntity entity;

	public ResultEvent(byte[] datas) {
		final ByteBuffer buffer = ByteBuffer.wrap(datas);
		result = buffer.get();
		state = buffer.get();
		if (result == 0) {
			final byte[] jsonbs = new byte[buffer.remaining()];
			buffer.get(jsonbs);
			entity = Utils.fromJsonString(new String(jsonbs), SSLEntity.class);
		}
	}

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public SSLEntity getEntity() {
		return entity;
	}

	public void setEntity(SSLEntity entity) {
		this.entity = entity;
	}
}
