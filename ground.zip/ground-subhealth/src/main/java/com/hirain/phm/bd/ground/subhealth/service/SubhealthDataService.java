/*******************************************************************************
 * Copyright (c) 2020, 2020 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.ground.subhealth.service;

import com.hirain.phm.bd.ground.subhealth.param.SubhealthDataResponse;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created Jan 6, 2020 2:04:48 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 6, 2020 jianwen.xin@hirain.com 1.0 create file
 */
public interface SubhealthDataService {

	/**
	 * @param id
	 * @param state
	 * @param keys
	 * @param datas
	 */
	void saveData(Integer id, int state, String keys, String datas);

	/**
	 * @param i
	 */
	SubhealthDataResponse getSubhealthData(int detailId);

}
