/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.hirain.phm.bode.core.IMdcu;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 8, 2019 4:32:53 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 8, 2019 zepei.tao@hirain.com 1.0 create file
 */
@XmlRootElement(name = "Mdcu")
@XmlType(propOrder = { "ip" })
@XmlAccessorType(XmlAccessType.FIELD)
public class Mdcu implements IMdcu {

	@XmlAttribute(name = "ip", required = true)
	private String ip;

	@Override
	public void setIp(String ip) {
		this.ip = ip;
	}

	@Override
	public String getIp() {
		return ip;
	}

}
