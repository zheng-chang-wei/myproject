package com.hirain.phm.bd.message.ground;

import lombok.Data;

@Data
public class TrainUser {

	private String username;

	private String password;
}
