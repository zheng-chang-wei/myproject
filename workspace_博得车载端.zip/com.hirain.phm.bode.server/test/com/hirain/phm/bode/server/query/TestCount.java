package com.hirain.phm.bode.server.query;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.hirain.phm.bode.server.client.ClientConstants;
import com.hirain.phm.bode.server.client.Token;
import com.hirain.phm.bode.server.client.data.DataStatisticeHandler;

public class TestCount {

	@Test
	public void test() throws InterruptedException {
		final String sql = "select count(id) from t_fault_record";
		new DataStatisticeHandler((address, pid, datas) -> {
			final ByteBuffer buffer = ByteBuffer.wrap(datas);
			final byte type = buffer.get();
			System.out.println(type);
			final long count = buffer.getLong();
			System.out.println(count);
		}, ClientConstants.FAULT_TAG, sql, new Token("123", new InetSocketAddress(122))).work();
		TimeUnit.SECONDS.sleep(1);
	}
}
