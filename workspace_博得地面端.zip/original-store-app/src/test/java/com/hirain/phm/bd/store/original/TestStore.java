/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.store.original;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.hirain.phm.bd.common.ZipUtil;
import com.hirain.phm.bd.common.serialize.JsonUtil;
import com.hirain.phm.bd.message.CarriagePacket;
import com.hirain.phm.bd.message.CommonMessage;
import com.hirain.phm.bd.message.DoorPacket;
import com.hirain.phm.bd.message.TrainPacket;
import com.hirain.phm.bd.message.train.RegisterMessage;
import com.hirain.phm.bd.store.kafka.KafkaConsumerProperties;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年11月11日 上午11:04:18
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年11月11日 jianwen.xin@hirain.com 1.0 create file
 */
@SpringBootTest(classes = OriginalStoreAppApplication.class)
@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@EmbeddedKafka(count = 1, ports = { 9092 })
public class TestStore {

	@Autowired
	private KafkaConsumerProperties properties;

	@Autowired
	EmbeddedKafkaBroker broker;

	@Test
	public void test() throws InterruptedException, Exception {
		TimeUnit.SECONDS.sleep(1);
		KafkaProducer<String, Object> producer = producer();
		sendRegister(producer);

		TimeUnit.SECONDS.sleep(20);

		sendMessage(producer);

		TimeUnit.SECONDS.sleep(60);
		File file = new File("D:\\data\\rt\\北京地铁1号线\\10");
		assertTrue(file.exists());
	}

	/**
	 * @param producer
	 */
	public void sendMessage(KafkaProducer<String, Object> producer) {
		ProducerRecord<String, Object> record = new ProducerRecord<>("message-beijing-1", "北京地铁1号线-10", messages());
		producer.send(record);
	}

	private void sendRegister(KafkaProducer<String, Object> producer) throws InterruptedException, ExecutionException {
		RegisterMessage message = getMessage();
		String json = JsonUtil.toString(message);
		ProducerRecord<String, Object> producerRecord = new ProducerRecord<>("train-ground", message.getProject() + "-" + message.getTrain(),
				json.getBytes(Charset.forName("utf-8")));
		Future<RecordMetadata> future = producer.send(producerRecord);
		RecordMetadata metadata = future.get();
		System.err.println("send:" + metadata.topic() + "," + metadata.offset());
	}

	KafkaProducer<String, Object> producer() {
		Map<String, Object> props = new HashMap<>();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, properties.getServers());
		props.put(ProducerConfig.BATCH_SIZE_CONFIG, 4096);
		props.put(ProducerConfig.LINGER_MS_CONFIG, 1);
		props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, 40960);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class);
		return new KafkaProducer<>(props);
	}

	KafkaConsumer<String, Object> consumer() {
		Map<String, Object> map = new HashMap<>();
		map.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, properties.getServers());
		map.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, properties.isEnableAutoCommit());
		map.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, properties.getAutoCommitInterval());
		map.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, properties.getSessionTimeout());
		map.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, properties.getKeyDeserializer());
		map.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, properties.getValueDeserializer());
		map.put(ConsumerConfig.GROUP_ID_CONFIG, "store-test");
		map.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, properties.getAutoOffsetReset());
		return new KafkaConsumer<>(map);
	}

	private RegisterMessage getMessage() {
		RegisterMessage message = new RegisterMessage();
		message.setSid(0x01);
		message.setProject("北京地铁1号线");
		message.setCity("北京");
		message.setLine("1");
		message.setTrain("10");
		message.setMac1("ff-ff-ff-ff-ff-ff");
		message.setMac2("ff-ff-ff-ff-ff-ff");
		message.setSsl(false);
		message.setState(0);
		return message;
	}

	private byte[] messages() {
		TrainPacket packet = new TrainPacket();
		packet.setProject("北京地铁1号线");
		packet.setTrain("10");
		CarriagePacket cp = new CarriagePacket();
		cp.setCarriageId(1);
		DoorPacket dp = new DoorPacket();
		dp.setDoorId(1);
		CommonMessage message = new CommonMessage();
		message.setDatas(datas());
		message.setMilli(0);
		message.setMonth(11);
		message.setYear(2019);
		dp.setMessages(Arrays.asList(message));
		cp.setPackets(Arrays.asList(dp));
		packet.setPackets(Arrays.asList(cp));

		String json = JsonUtil.toString(packet);
		byte[] bs = json.getBytes(Charset.forName("utf-8"));
		return ZipUtil.compress(bs);
	}

	public static void main(String[] args) {
		byte[] bs = new TestStore().messages();
		System.err.println(bs.length);
	}

	private byte[] datas() {
		byte[] bs = new byte[32];
		for (int i = 0; i < 32; i++) {
			bs[i] = (byte) i;
		}
		bs[21] = 11;
		bs[22] = 11;
		bs[23] = 24;
		bs[25] = 0;
		return bs;
	}
}
