const apiDomain = {
  ip: 'localhost:8082'
}
export default apiDomain
