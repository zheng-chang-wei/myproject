/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.listener;

import java.util.List;
import java.util.Vector;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 21, 2019 11:05:44 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 21, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class HeartbeatListenerManager {

	private final List<IHeartbeatListener> listeners = new Vector<IHeartbeatListener>();

	private HeartbeatListenerManager() {
	}

	public static HeartbeatListenerManager getInstance() {
		return HeartbeatListenerManagerClazz.instance;
	}

	private final static class HeartbeatListenerManagerClazz {

		private final static HeartbeatListenerManager instance = new HeartbeatListenerManager();
	}

	public void addListener(final IHeartbeatListener listener) {
		listeners.add(listener);
	}

	public void removeListener(final IHeartbeatListener listener) {
		if (listeners.contains(listener)) {
			listeners.remove(listener);
		}
	}

	public void notifyChanged(boolean enable) {
		for (final IHeartbeatListener listener : listeners) {
			listener.updateEnable(enable);
		}
	}

}
