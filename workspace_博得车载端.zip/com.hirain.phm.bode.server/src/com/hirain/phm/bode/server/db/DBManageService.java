package com.hirain.phm.bode.server.db;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.binding.BindingException;
import org.apache.ibatis.session.SqlSession;

import com.hirain.phm.bode.core.ICar;
import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.db.dao.ManageMapper;

public class DBManageService {

	private static DateTimeFormatter DATETIME_PATTERN = DateTimeFormatter.ofPattern("yyyyMMdd");

	private static DateTimeFormatter DATETIME_PATTERN1 = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

	private static DBManageService instance = new DBManageService();

	private DBManageService() {
	}

	public static DBManageService getInstance() {
		return instance;
	}

	public void init(List<ICar> list) {
		SqlSession session = null;
		try {
			session = DBService.getInstance().getSession(true);
			final ManageMapper mapper = session.getMapper(ManageMapper.class);
			for (final ICar car : list) {
				if (car.getType() == 0) {
					continue;
				}
				final int carriageId = car.getIndex();
				final int exist = mapper.existRecordTable(carriageId);
				if (exist == 0) {
					createRecordTable(carriageId, mapper);
				}
				final int exist1 = mapper.existMessageTable(carriageId);
				if (exist1 == 0) {
					createMessageTable(carriageId, mapper);
				}
			}
		} catch (final Exception e) {
			DBService.logger.error(e.getMessage(), e);
			e.printStackTrace();
		} finally {
			DBService.getInstance().disconnect(session);
		}
	}

	public void part(List<ICar> cars) {
		SqlSession session = null;
		try {
			session = DBService.getInstance().getSession(true);
			final ManageMapper mapper = session.getMapper(ManageMapper.class);
			for (final ICar car : cars) {
				if (car.getType() == 0) {
					continue;
				}
				final int carriageId = car.getIndex();
				addRecordPartition(carriageId, mapper);
				addMessagePartition(carriageId, mapper);
			}
		} catch (final Exception e) {
			DBService.logger.error(e.getMessage(), e);
		} finally {
			DBService.getInstance().disconnect(session);
		}
	}

	public void partFaultTable() {
		SqlSession session = null;
		try {
			session = DBService.getInstance().getSession(true);
			final ManageMapper mapper = session.getMapper(ManageMapper.class);
			addFaultPartition(mapper);
		} catch (final Exception e) {
			DBService.logger.error(e.getMessage(), e);
		} finally {
			DBService.getInstance().disconnect(session);
		}
	}

	public void checkSpace() {
		final double total = Utils.getTotalSpace();
		SqlSession session = null;
		try {
			session = DBService.getInstance().getSession(true);
			final ManageMapper mapper = session.getMapper(ManageMapper.class);
			final double used = mapper.selectSpace();
			final double ratio = used / total;
			System.out.println(ratio);
			if (ratio > 0.9) {
				deletePartitions(mapper);
			}
		} catch (final Exception e) {
			DBService.logger.error(e.getMessage(), e);
		} finally {
			DBService.getInstance().disconnect(session);
		}
	}

	public void deleteDataBeforeDay(Date date) {
		SqlSession session = null;
		try {
			session = DBService.getInstance().getSession(true);
			final ManageMapper mapper = session.getMapper(ManageMapper.class);
			if (date == null) {
				deleteAllMessages(mapper);
				deleteAllRecords(mapper);
				deleteAllFaultMessages(mapper);
				deleteAllFaultRecords(mapper);
			} else {
				deleteMessagesBeforeDay(mapper, date);
				deleteRecordsBeforeDay(mapper, date);
				deleteFaultMessagesBeforeDay(mapper, date);
				deleteFaultRecordsBeforeDay(mapper, date);
			}
		} catch (final Exception e) {
			DBService.logger.error(e.getMessage(), e);
		} finally {
			DBService.getInstance().disconnect(session);
		}
		new DBStorageService().checkSpaceAndPost();
	}

	public void deleteCommonDataBeforeDay(Date date) {
		SqlSession session = null;
		try {
			session = DBService.getInstance().getSession(true);
			final ManageMapper mapper = session.getMapper(ManageMapper.class);
			if (date == null) {
				deleteAllMessages(mapper);
				deleteAllRecords(mapper);
			} else {
				deleteMessagesBeforeDay(mapper, date);
				deleteRecordsBeforeDay(mapper, date);
			}
		} catch (final Exception e) {
			DBService.logger.error(e.getMessage(), e);
		} finally {
			DBService.getInstance().disconnect(session);
		}
		new DBStorageService().checkSpaceAndPost();
	}

	public void deleteFaultDataBeforDay(Date date) {
		SqlSession session = null;
		try {
			session = DBService.getInstance().getSession(true);
			final ManageMapper mapper = session.getMapper(ManageMapper.class);
			if (date == null) {
				deleteAllFaultMessages(mapper);
				deleteAllFaultRecords(mapper);
			} else {
				deleteFaultMessagesBeforeDay(mapper, date);
				deleteFaultRecordsBeforeDay(mapper, date);
			}
		} catch (final Exception e) {
			DBService.logger.error(e.getMessage(), e);
		} finally {
			DBService.getInstance().disconnect(session);
		}
		new DBStorageService().checkSpaceAndPost();
	}

	/**
	 * partition by day, drop all partition before min(cutDate,nowDate), then delete
	 * messages before cutDate
	 */
	private void deleteMessagesBeforeDay(ManageMapper mapper, Date date) {
		LocalDate cutDate = LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()).toLocalDate();
		LocalDate dropDate = getDropDate(cutDate);
		List<String> tables = mapper.selectTables(DBConstant.MESSAGE_TABLE_SUFFIX);
		for (String table: tables) {
			while (mapper.countPartitions(table) > 1) {
				String first = mapper.firstPartition(table);
				if (first.startsWith("p")) {
					first = first.substring(1);
				}
				LocalDate partitionDate = LocalDate.parse(first, DATETIME_PATTERN);
				if (partitionDate.compareTo(dropDate) < 0) {
					mapper.dropPartitionFromMessage(table, first);
				} else {
					break;
				}
			}
			mapper.deleteMessagesBeforeDay(table, cutDate.format(DATETIME_PATTERN));
		}
	}

	private void deleteAllMessages(ManageMapper mapper) {
		List<String> tables = mapper.selectTables(DBConstant.MESSAGE_TABLE_SUFFIX);
		for (String table : tables) {
			mapper.deleteAll(table);
		}
	}

	/**
	 * partition by year, drop all partition before year of given date, then delete
	 * records in given year before given date
	 */
	private void deleteRecordsBeforeDay(ManageMapper mapper, Date date) {
		LocalDate cutDate = LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()).toLocalDate();
		LocalDate dropDate = getDropDate(cutDate);
		int year = dropDate.getYear();
		List<String> tables = mapper.selectTables(DBConstant.RECORD_TABLE_SUFFIX);
		for (String table : tables) {
			while (mapper.countPartitions(table) > 1) {
				String first = mapper.firstPartition(table);
				if (first.startsWith("p")) {
					first = first.substring(1);
				}
				int partitionYear = Integer.parseInt(first);
				if (partitionYear < year) {
					mapper.dropPartitionFromMessage(table, first);
				} else {
					break;
				}
			}
			mapper.deleteRecordsBeforeDay(table, cutDate.format(DATETIME_PATTERN));
		}
	}

	private void deleteAllRecords(ManageMapper mapper) {
		List<String> tables = mapper.selectTables(DBConstant.RECORD_TABLE_SUFFIX);
		for (String table : tables) {
			mapper.deleteAll(table);
		}
	}

	/**
	 * partition by month, drop all partition before month of given date, then
	 * delete records before given date
	 */
	private void deleteFaultMessagesBeforeDay(ManageMapper mapper, Date date) {
		LocalDate cutDate = LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()).toLocalDate();
		LocalDate dropDate = getDropDate(cutDate);
		String table = DBConstant.FAULT_MESSAGE_TABLE;
		while (mapper.countPartitions(table) > 1) {
			String first = mapper.firstPartition(table);
			if (first.startsWith("p")) {
				first = first.substring(1);
			}
			LocalDate partitionDate = LocalDate.parse(first, DATETIME_PATTERN);
			if (partitionDate.compareTo(dropDate) < 0) {
				mapper.dropPartitionFromMessage(table, first);
			} else {
				break;
			}
		}
		mapper.deleteFaultMessagesBeforeDay(cutDate.format(DATETIME_PATTERN));
	}

	private void deleteAllFaultMessages(ManageMapper mapper) {
		mapper.deleteAll(DBConstant.FAULT_MESSAGE_TABLE);
	}

	private void deleteFaultRecordsBeforeDay(ManageMapper mapper, Date date) {
		LocalDate cutDate = LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()).toLocalDate();
		mapper.deleteFaultRecordsBeforeDay(cutDate.format(DATETIME_PATTERN));
	}

	private void deleteAllFaultRecords(ManageMapper mapper) {
		mapper.deleteAll(DBConstant.FAULT_RECORD_TABLE);
	}

	private LocalDate getDropDate(LocalDate cutDate) {
		LocalDate nowDate = LocalDateTime.ofInstant(new Date().toInstant(), ZoneId.systemDefault()).toLocalDate();
		if (cutDate.compareTo(nowDate) < 0) {
			return cutDate;
		} else {
			return nowDate;
		}
	}

	private void deletePartitions(ManageMapper mapper) {
		final List<String> tables = mapper.selectTables(DBConstant.MESSAGE_TABLE_SUFFIX);
		for (final String table : tables) {
			final long count = mapper.countPartitions(table);
			if (count > 1) {
				String first = mapper.firstPartition(table);
				if (first.startsWith("p")) {
					first = first.substring(1);
				}
				mapper.dropPartitionFromMessage(table, first);
				final String recordTable = table.substring(0, table.length() - 7) + "record";
				if (mapper.existTable(recordTable) == 1) {
					mapper.deleteRecords(table, first);
				}
			}
		}
	}

	private void createMessageTable(int carriageId, ManageMapper mapper) {
		final Map<String, Object> map = new HashMap<>();
		map.put("carriageId", carriageId);
		map.put("list", partitions());
		mapper.createMessageTable(map);
	}

	private void createRecordTable(int carriageId, ManageMapper mapper) {
		final Map<String, Object> map = new HashMap<>();
		map.put("carriageId", carriageId);
		map.put("list", years());
		mapper.createRecordTable(map);
	}

	private List<String> partitions() {
		final List<String> partitions = new ArrayList<>();
		final LocalDate date = LocalDate.now();
		for (int i = 0; i <= 30; i++) {
			final LocalDate day = date.plusDays(i);
			final String time = day.format(DATETIME_PATTERN);
			partitions.add(time);
		}
		return partitions;
	}

	private List<Integer> years() {
		final List<Integer> years = new ArrayList<>();
		final int year = LocalDate.now().getYear();
		for (int i = 0; i < 2; i++) {
			years.add(year + i);
		}
		return years;
	}

	private void addRecordPartition(int carriageId, ManageMapper mapper) {
		final int year = queryRecordPartition(carriageId, mapper);
		final int now = LocalDate.now().getYear();
		if (year - now <= 1) {
			final Map<String, Object> map = new HashMap<>();
			map.put("carriageId", carriageId);
			map.put("list", addYears(year));
			mapper.addPartitionsToRecord(map);
		}
	}

	private int queryRecordPartition(int carriageId, ManageMapper mapper) {
		String partition = mapper.lastPartition("t_carriage" + carriageId + "_record");
		if (partition.startsWith("p")) {
			partition = partition.substring(1);
		}
		return Integer.parseInt(partition);
	}

	private List<Integer> addYears(int year) {
		final List<Integer> years = new ArrayList<>();
		for (int i = 1; i < 3; i++) {
			years.add(year + i);
		}
		return years;
	}

	private void addMessagePartition(int carriageId, ManageMapper mapper) {
		String partition = mapper.lastPartition("t_carriage" + carriageId + "_message");
		if (partition.startsWith("p")) {
			partition = partition.substring(1);
		}
		final LocalDateTime date = LocalDateTime.parse(partition + "000000", DATETIME_PATTERN1);
		final LocalDateTime now = LocalDateTime.now();
		final Duration duration = Duration.between(now, date);
		final long days = duration.toDays();
		if (days <= 30) {
			final Map<String, Object> map = new HashMap<>();
			map.put("carriageId", carriageId);
			map.put("list", addPartitions(date, days));
			mapper.addPartitionsToMessage(map);
		}
	}

	private List<String> addPartitions(LocalDateTime date, long days) {
		final List<String> partitions = new ArrayList<>();
		long duration = 30;
		if (days < 0) {
			duration = duration - days;
		}
		for (int i = 1; i < duration; i++) {
			final LocalDateTime day = date.plusDays(i);
			final String time = day.format(DATETIME_PATTERN);
			partitions.add(time);
		}
		return partitions;
	}

	private void addFaultPartition(ManageMapper mapper) {
		addFaultRecordPartitions(mapper);
		addFaultMessagePartition(mapper);
	}

	private void addFaultMessagePartition(ManageMapper mapper) {
		String partition = mapper.lastPartition("t_fault_message");
		if (partition == null) {
			mapper.createPartitions(getFaultPartitions(LocalDateTime.now()));
		} else {
			if (partition.startsWith("p")) {
				partition = partition.substring(1);
			}
			final LocalDateTime date = LocalDateTime.parse(partition + "000000", DATETIME_PATTERN1);
			final LocalDateTime now = LocalDateTime.now();
			final Duration duration = Duration.between(now, date);
			final long days = duration.toDays();
			if (days < 365) {
				if (days < 0) {
					mapper.addPartitionsToFaultMessage(getFaultPartitions(now));
				} else {
					mapper.addPartitionsToFaultMessage(getFaultPartitions(date));
				}
			}
		}
	}

	private List<String> getFaultPartitions(LocalDateTime start) {
		final List<String> partitions = new ArrayList<>();
		for (int i = 1; i <= 12; i++) {
			final LocalDateTime date = start.plusMonths(i);
			partitions.add(date.format(DATETIME_PATTERN));
		}
		return partitions;
	}

	private void addFaultRecordPartitions(ManageMapper mapper) {
		String partition = mapper.lastPartition("t_fault_record");
		if (partition.startsWith("p")) {
			partition = partition.substring(1);
		}
		final long value = Long.parseLong(partition);
		try {
			final long maxId = mapper.countFaultRecord();
			if (value - maxId < 10000) {
				final List<Long> partitions = new ArrayList<>();
				partitions.add(value + 10000);
				partitions.add(value + 20000);
				mapper.addPartitionsToFaultRecord(partitions);
			}
		} catch (final BindingException e) {
		} catch (final Exception e) {
			DBService.logger.error(e.getMessage(), e);
		}
	}
}
