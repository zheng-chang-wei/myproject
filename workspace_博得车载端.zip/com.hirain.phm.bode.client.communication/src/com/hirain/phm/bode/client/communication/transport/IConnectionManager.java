package com.hirain.phm.bode.client.communication.transport;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 */
public interface IConnectionManager {

	int bind(int... port);

	int stop(int... port);

	int send(ITransportPacket packet);
}
