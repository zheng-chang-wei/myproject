package com.hirain.phm.bode.ui.monitor.listener;

import com.hirain.phm.bode.core.ICar;

/**
 * @Version 1.0
 * @Author changwei.zheng@hirain.com
 * @Created 2019年1月17日 下午7:49:45
 * @Description
 *              <p>
 *              车门，车厢，mdcu点击事件监听器
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月17日 changwei.zheng@hirain.com 1.0 create file
 */
public interface DoorCheckedListener {

	void doorChecked(ICar car, int doorIndex);

	void mdcuChecked(ICar car);

	void carChecked(ICar car);
}
