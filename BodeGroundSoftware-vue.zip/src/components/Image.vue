<template>
  <el-col style="position:relative;">
    <img src="./isolation.png" style="width: 100%;height:100%">
    <div style="position:absolute; z-index:2; vertical-align: middle">1
    </div>
  </el-col>
</template>
<script>
export default {
  props: {
  },
  data() {
    return {
    }
  },
  mounted() {
  },
  methods: {
  }
}
</script>

<style >
</style>
