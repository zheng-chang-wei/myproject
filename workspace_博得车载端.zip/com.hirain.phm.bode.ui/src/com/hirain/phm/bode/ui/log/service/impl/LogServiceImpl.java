package com.hirain.phm.bode.ui.log.service.impl;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.client.communication.service.ServiceConstant;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.log.model.LogQueryCondition;
import com.hirain.phm.bode.ui.log.model.LogTable;
import com.hirain.phm.bode.ui.log.service.LogService;

public class LogServiceImpl implements LogService {

	private static LogServiceImpl singleton = null;

	private LogServiceImpl() {
	}

	public static LogServiceImpl getInstance() {
		if (singleton == null) {
			singleton = new LogServiceImpl();
		}
		return singleton;
	}

	@Override
	public void selectByPage(LogQueryCondition queryCondition, int pageNum, int pageSize) {
		StringBuilder sql = new StringBuilder("select * from t_log where true");
		String start = queryCondition.getStartTime();
		if (start != null) {
			sql.append(" and to_days (day)>=to_days('" + start + "')");
		}
		String end = queryCondition.getEndTime();
		if (end != null) {
			sql.append(" and to_days (day)<=to_days('" + end + "')");
		}
		sql.append(" order by day desc limit " + (pageNum - 1) * pageSize + "," + pageSize);
		System.err.println(sql);

		try {
			CommunicationService.getInstance().select(ServiceConstant.PID_DATA_QUERY, ServiceConstant.LOG_SID, sql.toString());
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}

	@Override
	public void selectCount(LogQueryCondition queryCondition) {
		StringBuilder sql = new StringBuilder("select count(day) from t_log where true");
		String start = queryCondition.getStartTime();
		if (start != null) {
			sql.append(" and to_days(day)>=to_days('" + start + "')");
		}
		String end = queryCondition.getEndTime();
		if (end != null) {
			sql.append(" and to_days(day)<=to_days('" + end + "')");
		}
		System.err.println(sql);
		try {
			CommunicationService.getInstance().select(ServiceConstant.PID_DATA_COUNT, ServiceConstant.LOG_SID, sql.toString());
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}

	@Override
	public void download(LogTable logTable) {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date date = dateFormat.parse(logTable.getLogTime());
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			ByteBuffer buffer = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
			buffer.put(ServiceConstant.LOG_SID);

			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.YEAR) - 2000)));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.MONTH) + 1)));
			buffer.put(Byte.parseByte(String.valueOf(calendar.get(Calendar.DATE))));
			CommunicationService.getInstance().download(buffer.array());
		} catch (Exception e) {
			BodeUIPlugin.log(e);
		}
	}
}
