/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bd.ground.life;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;

import com.hirain.phm.bd.ground.common.event.StatisticsEvent;
import com.hirain.phm.bd.ground.common.event.TrainInitEvent;
import com.hirain.phm.bd.ground.life.domain.LifeDoorItem;
import com.hirain.phm.bd.ground.life.domain.LifeProjectInfo;
import com.hirain.phm.bd.ground.life.domain.LifeTrainInfo;
import com.hirain.phm.bd.ground.life.domain.LifeWarning;
import com.hirain.phm.bd.ground.life.service.LifeDoorItemService;
import com.hirain.phm.bd.ground.life.service.LifeProjectInfoService;
import com.hirain.phm.bd.ground.life.service.LifeTrainInfoService;
import com.hirain.phm.bd.ground.life.service.LifeWarningService;
import com.hirain.phm.bd.ground.train.controller.TrainGateWay;
import com.hirain.phm.bd.ground.train.domain.Project;
import com.hirain.phm.bd.ground.train.domain.Train;
import com.hirain.phm.bd.message.train.LifeMessage;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created May 28, 2019 9:57:22 AM
 * @Description
 *              <p>
 *              处理寿命信息报文
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               May 28, 2019 zepei.tao@hirain.com 1.0 create file
 */
@Configuration
public class LifeEventHandler {

	@Autowired
	private LifeDoorItemService doorItemLifeService;

	@Autowired
	private LifeProjectInfoService lineProjectInfoService;

	@Autowired
	private TrainGateWay trainGW;

	@Autowired
	private LifeTrainInfoService lifeTrainInfoService;

	@Autowired
	private LifeWarningService lifeWarningService;

	@EventListener
	@Async
	public void handleTrainInit(TrainInitEvent event) {
		insertLifeTrainInfo(event);
	}

	/**
	 * 向t_life_traininfo数据表中插入新注册列车对应的寿命项点数据
	 */
	private void insertLifeTrainInfo(TrainInitEvent message) {
		// 根据lineID从t_linelife_info表中找到对应的数据集合
		Project project = trainGW.selectProjectByName(message.getProject());
		List<LifeProjectInfo> lineLifeInfos = lineProjectInfoService.findLifeInfos(project.getId());
		for (LifeProjectInfo lineLifeInfo : lineLifeInfos) {
			Integer lifeitemId = lineLifeInfo.getLifeitemId();
			LifeTrainInfo trainLifeInfo = new LifeTrainInfo();
			Train train = trainGW.selectTrain(message.getProject(), message.getTrain());
			trainLifeInfo.setTrainId(train.getId());
			trainLifeInfo.setLifeitemId(lifeitemId);
			lifeTrainInfoService.insertTrainLifeInfo(trainLifeInfo);
		}
	}

	@EventListener
	@Async
	public void handleLifeMessage(LifeMessage message) {
		handle(message);
	}

	/**
	 * @see com.hirain.phm.bd.ground.train.ILifeHandler#handle(com.hirain.phm.bd.message.train.LifeMessage)
	 */
	private void handle(LifeMessage message) {
		Integer doorOpenFrequency = message.getDoorOpenFrequency();
		Integer doorCloseFrequency = message.getDoorCloseFrequency();
		Integer doorOpenTime = message.getDoorOpenTime();
		Integer doorCloseTime = message.getDoorCloseTime();
		Integer communicationTime = message.getCommunicationTime();
		Integer emergencyUnlockFrequency = message.getEmergencyUnlockFrequency();
		Integer doorIsolationFrequency = message.getDoorIsolationFrequency();
		Integer lockSwitchFrenquency = message.getLockSwitchFrenquency();

		Train train = trainGW.selectTrain(message.getProject(), message.getTrain());
		Project project = trainGW.selectProjectByName(message.getProject());

		List<LifeDoorItem> doorItemLifes = doorItemLifeService.findDoorItemLifeInfos(train.getId(), message.getCarNo(), message.getDoorAddr());
		if (doorItemLifes == null || doorItemLifes.size() == 0) {// 数据表中暂没有该车门的寿命数据
			List<LifeProjectInfo> lineLifeInfos = lineProjectInfoService.findLifeInfos(project.getId());
			for (LifeProjectInfo lineLifeInfo : lineLifeInfos) {
				LifeDoorItem doorItemLife = new LifeDoorItem();
				doorItemLife.setTrainId(train.getId());
				doorItemLife.setCarNo(message.getCarNo());
				doorItemLife.setDoorAddr(message.getDoorAddr());
				Integer lifeitemId = lineLifeInfo.getLifeitemId();
				doorItemLife.setLifeitemId(lifeitemId);
				doorItemLife.setValue(getDoorItemValue(lifeitemId, doorOpenFrequency, doorCloseFrequency, doorOpenTime, doorCloseTime,
						communicationTime, emergencyUnlockFrequency, doorIsolationFrequency, lockSwitchFrenquency, doorItemLife));

				doorItemLifeService.insertDoorItemLifeData(doorItemLife);
			}
		} else {// 已存在该车门寿命数据
			for (LifeDoorItem doorItemLife : doorItemLifes) {
				Integer doorItemValue = getDoorItemValue(doorItemLife.getLifeitemId(), doorOpenFrequency, doorCloseFrequency, doorOpenTime,
						doorCloseTime, communicationTime, emergencyUnlockFrequency, doorIsolationFrequency, lockSwitchFrenquency, doorItemLife);
				doorItemLife.setValue(doorItemValue);
				doorItemLifeService.updateDoorItemLifeInfo(doorItemLife);

				saveOrUpdateLifeWearning(doorItemLife, doorItemValue);
			}
		}
	}

	private void saveOrUpdateLifeWearning(LifeDoorItem doorItemLife, Integer doorItemValue) {
		Integer trainId = doorItemLife.getTrainId();
		Integer lifeitemId = doorItemLife.getLifeitemId();
		LifeTrainInfo info = lifeTrainInfoService.findTrainLifeInfoByTrainIDItemId(trainId, lifeitemId);
		Integer referenceValue = info.getReferenceValue();
		double remainderLife = 1 - (double) doorItemValue / referenceValue;
		// 如果剩余寿命小于20%,开始预警
		if (remainderLife <= 0.2) {
			// 如果剩余寿命小于0，将剩余寿命等于0
			if (remainderLife < 0) {
				remainderLife = 0;
			}
			LifeWarning lifeWarning = lifeWarningService.findLifeWarningByTrainIDItemId(trainId, lifeitemId);
			if (lifeWarning == null) {
				lifeWarning = new LifeWarning();
				lifeWarning.setCarNo(doorItemLife.getCarNo());
				lifeWarning.setDoorAddr(doorItemLife.getDoorAddr());
				lifeWarning.setLifeitemId(lifeitemId);
				lifeWarning.setRemainderLife(remainderLife);
				lifeWarning.setTrainId(trainId);
				lifeWarning.setWarningTime(new Date());
				// lifeWarning.setStatistics(statistics);
				// lifeWarning.setDebugMode(debugMode);
				lifeWarningService.save(lifeWarning);
			} else {
				lifeWarning.setRemainderLife(remainderLife);
				lifeWarningService.updateNotNull(lifeWarning);
			}
		}
	}

	/**
	 * 计算DoorItemLife的value值
	 * 
	 * @param doorOpenFrequency
	 *            开门次数
	 * @param doorCloseFrequency
	 *            关门次数
	 * @param doorOpenTime
	 *            开门总时间
	 * @param doorCloseTime
	 *            关门总时间
	 * @param communicationTime
	 *            通信总时间
	 * @param emergencyUnlockFrequency
	 *            紧急解锁次数
	 * @param doorIsolationFrequency
	 *            门隔离状态次数
	 */
	private Integer getDoorItemValue(Integer lifeItemID, Integer doorOpenFrequency, Integer doorCloseFrequency, Integer doorOpenTime,
			Integer doorCloseTime, Integer communicationTime, Integer emergencyUnlockFrequency, Integer doorIsolationFrequency,
			Integer lockSwitchFrenquency, LifeDoorItem doorItemLife) {
		switch (lifeItemID) {
		case 1:// 到位开关
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		case 2:// 紧急解锁开关
			return doorItemLife.getValue() + emergencyUnlockFrequency;
		case 3:// 隔离开关
			return doorItemLife.getValue() + doorIsolationFrequency;
		case 4:// 锁闭开关
			return doorItemLife.getValue() + lockSwitchFrenquency;
		case 5:// 控制器CPU
			return doorItemLife.getValue() + communicationTime;
		case 6:// 上部导轨
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		case 7:// 电机
			return doorItemLife.getValue() + doorOpenTime + doorCloseTime;
		case 8:// 电磁铁
			return doorItemLife.getValue() + emergencyUnlockFrequency;
		case 9:// 辊式滑车组成
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		case 10:// 解锁旋转架组成
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		case 11:// 齿带
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		case 12:// 旋转立柱滚轮
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		case 13:// 蜂鸣器
			return doorItemLife.getValue() + doorOpenFrequency * 3 + doorCloseFrequency * 2;
		case 14:// 锁闭转杆组成
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		case 15:// 拉杆组成
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		case 16:// 解锁拉杆组成
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		case 17:// 锁闭弯连杆组成
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		case 18:// 电机摆动轮体组成
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		case 19:// 同步带轮
			return doorItemLife.getValue() + doorOpenFrequency + doorCloseFrequency;
		default:
			return 0;
		}
	}

	@EventListener
	@Async
	public void onStatisticsEvent(StatisticsEvent event) {
		if (event.getTopCode() == 2) {
			LifeWarning warning = new LifeWarning();
			warning.setId(Integer.valueOf((int) event.getFaultId()));
			warning.setStatistics(event.isStatistics());
			lifeWarningService.updateNotNull(warning);
		}
	}

}
