package com.hirain.phm.bode.server.config;

import java.io.File;

import org.apache.log4j.Logger;

import com.hirain.phm.bode.core.ITrain;
import com.hirain.phm.bode.core.util.MarshalUtil;

public class ConfigurationService {

	private static String xmlPath = System.getProperty("user.dir") + "//system.xml";

	private ITrain train;

	private static ConfigurationService instance = new ConfigurationService();

	static Logger logger = Logger.getLogger(ConfigurationService.class);

	private ConfigurationService() {
		final File file = new File(xmlPath);
		if (file.exists()) {
			try {
				train = MarshalUtil.unmarshalToSystemInfo(xmlPath);
			} catch (final Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	public static ConfigurationService getInstance() {
		return instance;
	}

	public ITrain getTrain() {
		return train;
	}

	public void save(ITrain train) {
		this.train = train;
		try {
			MarshalUtil.marshalToXml(getTrain(), xmlPath);
		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

}
