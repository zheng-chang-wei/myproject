package com.hirain.phm.bode.server.mqtt;

import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.hirain.phm.bode.server.Utils;
import com.hirain.phm.bode.server.bus.SSLEntity;

public class TestConnection {

	public static final String HOST = "tcp://10.40.2.34:1883";

	public static final String TOPIC = "hello1";

	@Test
	public void test() throws Exception {
		final MqttConnection client = new MqttConnectionImpl(HOST, "subscribe", new MqttHandler("subscribe"));
		client.connect();
		client.subscribe(TOPIC);
		final SSLEntity entity = new SSLEntity();
		entity.setCaCrt("cacert");
		entity.setCrt("crt");
		entity.setKey("key");
		entity.setPassword("password");
		final String json = Utils.toJsonString(entity);
		client.send(TOPIC, json.getBytes(), 1, false);
		System.out.println("send");

		TimeUnit.SECONDS.sleep(2);
	}

	@Test
	public void testSsl() throws Exception {
		// final MqttSubscriber subscriber = new MqttSubscriber(HOST, "subscribe", new MqttHandler("subcribe"));
		// subscriber.connect("F:\\apache-apollo-1.7.1-windows-distro\\apache-apollo-1.7.1\\ca.crt",
		// "F:\\apache-apollo-1.7.1-windows-distro\\apache-apollo-1.7.1\\client.crt",
		// "F:\\apache-apollo-1.7.1-windows-distro\\apache-apollo-1.7.1\\client.key", "password");
		// subscriber.subscribe(SSL_TOPIC);
		//
		// final MqttPublisher publisher = new MqttPublisher(SSL_HOST, "publish", new MqttHandler("publish"));
		// publisher.connect("F:\\apache-apollo-1.7.1-windows-distro\\apache-apollo-1.7.1\\ca.crt",
		// "F:\\apache-apollo-1.7.1-windows-distro\\apache-apollo-1.7.1\\client.crt",
		// "F:\\apache-apollo-1.7.1-windows-distro\\apache-apollo-1.7.1\\client.key", "password");
		// publisher.send(SSL_TOPIC, "Hello World".getBytes(), 1, false);
		// System.out.println("send");

		TimeUnit.SECONDS.sleep(2);
	}

}
