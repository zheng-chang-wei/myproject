/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core.dataframe;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 10, 2019 4:59:00 PM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 10, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class DataFrameD3 {

	/**
	 * 关门时间
	 */
	private short closeDoorTime;

	/**
	 * 编码器
	 */
	private short Encoder;

	/**
	 * 日
	 */
	private int date;

	/**
	 * 时
	 */
	private int hour;

	/**
	 * 分
	 */
	private int minute;

	/**
	 * @return the closeDoorTime
	 */
	public short getCloseDoorTime() {
		return closeDoorTime;
	}

	/**
	 * @param closeDoorTime
	 *            the closeDoorTime to set
	 */
	public void setCloseDoorTime(short closeDoorTime) {
		this.closeDoorTime = closeDoorTime;
	}

	/**
	 * @return the encoder
	 */
	public short getEncoder() {
		return Encoder;
	}

	/**
	 * @param encoder
	 *            the encoder to set
	 */
	public void setEncoder(short encoder) {
		Encoder = encoder;
	}

	/**
	 * @return the date
	 */
	public int getDate() {
		return date;
	}

	/**
	 * @param date
	 *            the date to set
	 */
	public void setDate(int date) {
		this.date = date;
	}

	/**
	 * @return the hour
	 */
	public int getHour() {
		return hour;
	}

	/**
	 * @param hour
	 *            the hour to set
	 */
	public void setHour(int hour) {
		this.hour = hour;
	}

	/**
	 * @return the minute
	 */
	public int getMinute() {
		return minute;
	}

	/**
	 * @param minute
	 *            the minute to set
	 */
	public void setMinute(int minute) {
		this.minute = minute;
	}

}
