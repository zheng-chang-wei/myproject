package com.hirain.phm.bode.server.rbac.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.hirain.phm.bode.server.db.DBService;
import com.hirain.phm.bode.server.rbac.IUser;
import com.hirain.phm.bode.server.rbac.IUserService;
import com.hirain.phm.bode.server.rbac.dao.UserMapper;

public class UserService implements IUserService {

	private static IUserService instance = new UserService();

	private UserService() {

	}

	public static IUserService getInstance() {
		return instance;
	}

	@Override
	public boolean login(String username, String password) {
		final SqlSession session = DBService.getInstance().getSession(true);
		try {
			final UserMapper mapper = DBService.getInstance().getMapper(UserMapper.class, session);
			final UserImpl user = mapper.get(username);
			if (user != null) {
				if (!username.equals(user.getUsername())) {
					return false;
				}
				if (user.getPassword().equals(password)) {
					return true;
				}
			}
			return false;
		} finally {
			DBService.getInstance().disconnect(session);
		}
	}

	@Override
	public boolean logout(String username) {
		return true;
	}

	public int update(IUser user) {
		final SqlSession session = DBService.getInstance().getSession(true);
		try {
			final UserMapper mapper = DBService.getInstance().getMapper(UserMapper.class, session);
			mapper.update((UserImpl) user);
		} finally {
			DBService.getInstance().disconnect(session);
		}
		return 0;
	}

	@Override
	public int update(List<UserOperation> operations) {
		SqlSession session = null;
		try {
			session = DBService.getInstance().getSession(false);
			final UserMapper mapper = DBService.getInstance().getMapper(UserMapper.class, session);
			for (final UserOperation operation : operations) {
				if (operation.getOperation().equals("add")) {
					final UserImpl userImpl = mapper.get(operation.getUsername());
					if (userImpl != null) {
						mapper.update(userImpl);
					} else {
						mapper.insert(new UserImpl(operation.getUsername(), operation.getPassword()));
					}
				} else if (operation.getOperation().equals("update")) {
					final UserImpl userImpl = mapper.get(operation.getUsername());
					if (userImpl == null) {
						mapper.insert(userImpl);
					} else {
						mapper.update(new UserImpl(operation.getUsername(), operation.getPassword()));
					}
				} else if (operation.getOperation().equals("delete")) {
					final UserImpl userImpl = mapper.get(operation.getUsername());
					if (userImpl != null) {
						mapper.deleteByPrimaryKey(operation.getUsername());
					}
				}
			}
			session.commit();
		} finally {
			DBService.getInstance().disconnect(session);
		}
		return 0;
	}

}
