/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.core;

import com.hirain.phm.bode.core.impl.ServerIpType;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 9, 2019 11:34:57 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 9, 2019 zepei.tao@hirain.com 1.0 create file
 */
public interface IServerIp {

	void setType(ServerIpType type);

	ServerIpType getType();

	void setIp(String ip);

	String getIp();

}
