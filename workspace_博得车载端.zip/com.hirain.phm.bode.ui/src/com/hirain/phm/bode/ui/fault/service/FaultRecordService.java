package com.hirain.phm.bode.ui.fault.service;

import com.hirain.phm.bode.core.fault.FaultRecord;

public interface FaultRecordService {

	void selectByPage(FaultRecord faultQuery, int pageNum, int pageSize);

	void selectCount(FaultRecord faultQuery);
}
