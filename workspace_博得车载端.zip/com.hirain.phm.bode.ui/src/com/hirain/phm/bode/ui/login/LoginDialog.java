/*******************************************************************************
 * Copyright (c) 2019, 2019 Hirain Technologies Corporation.
 ******************************************************************************/
package com.hirain.phm.bode.ui.login;

import java.util.TimerTask;

import javax.inject.Inject;

import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.InstanceScope;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseTrackListener;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.wb.swt.SWTResourceManager;
import org.osgi.service.prefs.BackingStoreException;

import com.hirain.phm.bode.client.communication.message.SystemInfoMessage;
import com.hirain.phm.bode.client.communication.service.CommunicationService;
import com.hirain.phm.bode.client.communication.transport.ICommunication;
import com.hirain.phm.bode.core.util.StringUtil;
import com.hirain.phm.bode.ui.BodeUIPlugin;
import com.hirain.phm.bode.ui.listener.HeartbeatListenerManager;
import com.hirain.phm.bode.ui.util.UIConstants;
import com.hirain.phm.bode.ui.util.UIUtilMethod;
import com.hirain.phm.bode.ui.widget.MainPart;

/**
 * @Version 1.0
 * @Author zepei.tao@hirain.com
 * @Created Jan 24, 2019 10:43:27 AM
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               Jan 24, 2019 zepei.tao@hirain.com 1.0 create file
 */
public class LoginDialog extends AbstractDialog {

	@Inject
	Shell shell;

	private TimerTask task;

	private static String OFFLINE_MESSAGE = "与服务端通信异常";

	private static String ONLINE_MESSAGE = "通信正常，请登录";

	private static String LOGIN_ERRORMESSAGE = "用户名或密码错误";

	private static String NOHOST_ERRORMESSAGE = "无目标服务器地址,请配置";

	private static String CONNECTING_MESSAGE = "连接服务器中……";

	private static Font DEFAULT_FONT = SWTResourceManager.getFont("Malgun Gothic Semilight", 12, SWT.BOLD);

	private static LoginDialog dialog;

	private static String serverIp;

	private boolean online = false;

	private Composite serverIpCom;

	private Text serverIpText;

	private Text userNameText;

	private Text passWordText;

	private Label passwordEye;

	private Button connectButton;

	private Button loginButton;

	/**
	 * Create the dialog.
	 * 
	 * @param parentShell
	 */
	private LoginDialog(Shell parentShell) {
		super(parentShell);
	}

	public static LoginDialog getInstance() {
		if (dialog == null) {
			dialog = new LoginDialog(Display.getDefault().getActiveShell());
		}
		dialog.addHeartbeatListener();
		IEclipsePreferences node = InstanceScope.INSTANCE.getNode(BodeUIPlugin.PLUGIN_ID);
		serverIp = node.get(UIConstants.PREFERENCE_SERVERIP, StringUtil.EMPTY);
		return dialog;
	}

	@Override
	protected Control createContents(Composite parent) {
		Composite composite = new Composite(parent, 0);
		GridLayout layout = new GridLayout();
		layout.marginHeight = 0;
		layout.marginWidth = 0;
		layout.verticalSpacing = 0;
		composite.setLayout(layout);
		composite.setLayoutData(new GridData(GridData.FILL_BOTH));
		applyDialogFont(composite);
		// initialize the dialog units
		initializeDialogUnits(composite);
		// create the dialog area and button bar
		dialogArea = createDialogArea(composite);

		return composite;
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		Composite main = new Composite(parent, SWT.NONE);
		GridLayout gl_main = new GridLayout(1, false);
		gl_main.marginLeft = 250;
		gl_main.marginTop = 300;
		main.setLayout(gl_main);
		main.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		main.setBackgroundImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/LoginBackground.png"));
		main.setBackgroundMode(SWT.INHERIT_DEFAULT);

		{
			serverIpCom = new Composite(main, SWT.NONE);
			GridData gd_serverIpCom = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
			gd_serverIpCom.widthHint = 351;
			serverIpCom.setLayoutData(gd_serverIpCom);
			serverIpCom.setLayout(new GridLayout(3, false));

			Label serverIPLb = new Label(serverIpCom, SWT.NONE);
			serverIPLb.setFont(DEFAULT_FONT);
			serverIPLb.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			serverIPLb.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
			serverIPLb.setText("服务端 IP：");

			serverIpText = new Text(serverIpCom, SWT.BORDER);
			serverIpText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
			serverIpText.setToolTipText("请输入服务端IP");
			serverIpText.setText(serverIp);
			serverIpText.setSelection(serverIp.length());
			serverIpText.setEnabled(false);

			connectButton = new Button(serverIpCom, SWT.NONE);
			connectButton.setText("建立连接");
			connectButton.setLayoutData(new GridData(SWT.RIGHT, SWT.FILL, false, false, 1, 1));
			connectButton.setEnabled(false);
		}

		Composite composite_1 = new Composite(main, SWT.NONE);
		GridData gd_composite_1 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_composite_1.widthHint = 351;
		composite_1.setLayoutData(gd_composite_1);
		composite_1.setLayout(new GridLayout(3, false));
		composite_1.setBackgroundMode(SWT.INHERIT_DEFAULT);

		Label userNameLb = new Label(composite_1, SWT.NONE);
		userNameLb.setFont(DEFAULT_FONT);
		userNameLb.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		userNameLb.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		userNameLb.setText("用户名：");

		userNameText = new Text(composite_1, SWT.BORDER);
		userNameText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		userNameText.setEnabled(online);

		Label passwordLb = new Label(composite_1, SWT.NONE);
		passwordLb.setFont(DEFAULT_FONT);
		passwordLb.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		passwordLb.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		passwordLb.setText("密  码：");

		passWordText = new Text(composite_1, SWT.BORDER | SWT.PASSWORD);
		passWordText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		passWordText.setEnabled(online);

		passwordEye = new Label(composite_1, SWT.NONE);
		passwordEye.setLayoutData(new GridData(SWT.RIGHT, SWT.FILL, false, false, 1, 1));
		passwordEye.setImage(ResourceManager.getPluginImage(BodeUIPlugin.PLUGIN_ID, "icons/password_eye.ico"));

		loginButton = new Button(composite_1, SWT.NONE);
		loginButton.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 3, 1));
		loginButton.setText("              登录             ");
		loginButton.setEnabled(false);

		messageLab = new Label(composite_1, SWT.NONE);
		messageLab.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		messageLab.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		UIUtilMethod.setCommonMessage(messageLab, CONNECTING_MESSAGE);

		initListener();

		verfityHeartbeat();

		return parent;
	}

	/**
	 * 发送心跳校验
	 */
	private void verfityHeartbeat() {
		if (StringUtil.isEmpty(serverIp)) {
			UIUtilMethod.setErrorMessage(messageLab, NOHOST_ERRORMESSAGE);
			serverIpText.setEnabled(true);
			connectButton.setEnabled(false);
		} else {
			int startServices = CommunicationService.getInstance().start(serverIp);
			if (startServices == 0) {
				startHeartBeat();
			} else {
				HeartbeatListenerManager.getInstance().notifyChanged(false);
			}
		}
	}

	private void initListener() {
		connectButton.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			UIUtilMethod.setCommonMessage(messageLab, CONNECTING_MESSAGE);
			serverIpText.setEnabled(false);
			connectButton.setEnabled(false);
			String serverIp = serverIpText.getText().trim();
			try {// 将IP地址存入首选项中
				IEclipsePreferences node = InstanceScope.INSTANCE.getNode(BodeUIPlugin.PLUGIN_ID);
				node.put(UIConstants.PREFERENCE_SERVERIP, serverIp);
				node.flush();
			} catch (BackingStoreException e1) {
				e1.printStackTrace();
			}

			ICommunication communication = ((CommunicationService) CommunicationService.getInstance()).getCommunication();
			if (communication != null) {
				CommunicationService.getInstance().stop();
			}
			int startServices = CommunicationService.getInstance().start(serverIp);
			if (startServices == 0) {
				startHeartBeat();
			}
		}));
		serverIpText.addModifyListener(e -> {
			connectButton.setEnabled(UIUtilMethod.verfityIp(serverIpText.getText().trim()));
		});

		userNameText.addModifyListener(e -> {
			updateLoginBtnStatus();
		});

		passWordText.addModifyListener(e -> {
			updateLoginBtnStatus();
		});

		passWordText.addKeyListener(KeyListener.keyPressedAdapter(e -> {
			if (!loginButton.isEnabled()) {
				return;
			}
			if (e.keyCode == 13) {// 键盘回车事件
				Event event = new Event();
				event.widget = loginButton;
				loginButton.notifyListeners(SWT.Selection, event);
			}
		}));
		loginButton.addSelectionListener(SelectionListener.widgetSelectedAdapter(t -> {
			// 校验用户名密码是否正确
			if (validLogin(compose())) {
				close();
				// 校验服务器是否有初始化过
				if (!isInitialization()) {// 未初始化
					InitializationConfirmDialog initializationDialog = new InitializationConfirmDialog(shell);
					if (initializationDialog.open() != Window.OK) {
						System.exit(0);
					} else {
						initializationDialog.close();
						showMainShell();
					}
				} else {// 已初始化
					okPressed();
					showMainShell();
				}
			} else {
				UIUtilMethod.setErrorMessage(messageLab, LOGIN_ERRORMESSAGE);
			}
		}));
		passwordEye.addMouseTrackListener(MouseTrackListener.mouseExitAdapter(t -> {
			Display.getDefault().getActiveShell().setCursor(null);
		}));
		passwordEye.addMouseTrackListener(MouseTrackListener.mouseEnterAdapter(t -> {
			Display.getDefault().getActiveShell().setCursor(Display.getDefault().getSystemCursor(SWT.CURSOR_HAND));
		}));
		passwordEye.addMouseListener(MouseListener.mouseDownAdapter(t -> {
			if (StringUtil.isEmpty(passWordText.getText())) {
				return;
			}
			boolean isPasswordStyle = (passWordText.getEchoChar() == UIConstants.PASSWORD_SHOWSTYLE);
			if (isPasswordStyle) {
				passWordText.setEchoChar((char) 0);
			} else {
				passWordText.setEchoChar(UIConstants.PASSWORD_SHOWSTYLE);
			}
			passWordText.redraw();
		}));
	}

	private void updateLoginBtnStatus() {
		loginButton.setEnabled(!StringUtil.isEmpty(userNameText.getText()) && !StringUtil.isEmpty(passWordText.getText()));
	}

	@Override
	public void updateEnable(boolean enable) {
		Display.getDefault().asyncExec(() -> {
			if (!userNameText.isDisposed() && !passWordText.isDisposed() && !loginButton.isDisposed()) {
				if (!serverIpCom.isDisposed()) {
					serverIpCom.setVisible(!enable);
					serverIpText.setEnabled(!online);
					connectButton.setEnabled(!online && UIUtilMethod.verfityIp(serverIpText.getText().trim()));
					if (online || enable) {
						UIUtilMethod.setCommonMessage(messageLab, ONLINE_MESSAGE);
					} else {
						UIUtilMethod.setErrorMessage(messageLab, OFFLINE_MESSAGE);
					}
				}
				userNameText.setEnabled(enable);
				passWordText.setEnabled(enable);
				loginButton.setEnabled(
						enable && StringUtil.isNotEmpty(userNameText.getText().trim()) && StringUtil.isNotEmpty(passWordText.getText().trim()));
			}
		});
	}

	@Override
	protected boolean isResizable() {
		return false;
	}

	@Override
	protected Point getInitialSize() {
		return new Point(1400, 700);
	}

	/**
	 * 将用户名和密码组合成一个字符串，中间用特殊符号"##"隔开
	 * 
	 * @return
	 */
	private String compose() {
		return userNameText.getText() + UIConstants.LOGIN_COMPOSE + passWordText.getText();
	}

	/**
	 * 验证用户名和密码
	 */
	private boolean validLogin(String str) {
		try {// 将登录信息（即用户名和密码）存入首选项中
			IEclipsePreferences node = InstanceScope.INSTANCE.getNode(BodeUIPlugin.PLUGIN_ID);
			node.put(UIConstants.PREFERENCE_LOGININFO, str);
			node.flush();
		} catch (BackingStoreException e1) {
			e1.printStackTrace();
		}
		return CommunicationService.getInstance().login(str);
	}

	/**
	 * 检测是否有初始化
	 */
	private boolean isInitialization() {
		// 向服务端发送系统信息查询指令,收到的回复报文
		// 错误码 0，则表示配置完整；错误码 1，则表示配置不完整
		SystemInfoMessage systemInfoMessage = CommunicationService.getInstance().inquireSystemInfo();
		return systemInfoMessage.getErrorCode() == (byte) 0;// 0表示服务端配置信息网完整；1表示服务端配置信息不完整
	}

	private void startHeartBeat() {
		task = new TimerTask() {

			@Override
			public void run() {
				online = CommunicationService.getInstance().inquireHeartBeat();
				HeartbeatListenerManager.getInstance().notifyChanged(online);
			}
		};
		HeartBeatTimer.getInstance().start(task);
	}

	/**
	 * 登出后再重新登录时，将MainPart显示出来
	 */
	private void showMainShell() {
		Shell mainShell = MainPart.getShell();
		if (mainShell != null) {
			mainShell.setVisible(true);
			mainShell.setActive();
		}
	}
}
