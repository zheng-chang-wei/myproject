package com.hirain.phm.bode.server.server;

public class ServerConstant {

	public static final int TO_MDCU_PORT = 10001;

	public static final int LOCAL_MDCU_PORT = 17228;

	public static final int TO_OTHER_PORT = 17227;

	public static final int TO_LOSTDATA_PORT = 17226;// 发送对端服务器丢失数据的端口

	public static final int DOOR_MESSAGE_PID = 1;

	public static final int SERVER_HEARTBEAT_PID = 0x02;

	public static final int SETTING_COMMAND_ID = 0x03;

	public static final int SERVER_LOSTMESSAGEDATA_ID = 0x04;//

	public static final int SERVER_LOSTFAULTRECORD_ID = 0x05;//

	public static final int DEBUG_COMMAND_ID = 0x06;

	public static final int HEARTBEAT_RESPONSE_PID = 0x12;

	public static final int SETTING_RESPONCE_ID = 0x13;

	public static final int LOSTDATA_RESPONSE_ID = 0x14;

	public static final int FAULTRECORD_RESPONSE_ID = 0x15;

	public static final int DEBUG_RESPONCE_ID = 0x16;

	public static final int REPLY_MAC_ID = 0x53;

	public static final int ASK_MAC_ID = 0x23;
}
