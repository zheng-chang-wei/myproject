package com.hirain.phm.bode.server.rbac;

/**
 * @Version 1.0
 * @Author jianwen.xin@hirain.com
 * @Created 2019年1月7日 上午10:08:38
 * @Description
 *              <p>
 * @Modification
 *               <p>
 *               Date Author Version Description
 *               <p>
 *               2019年1月7日 jianwen.xin@hirain.com 1.0 create file
 */
public interface IUser {

	/**
	 * @return username
	 */
	String getUsername();

	/**
	 * @return password
	 */
	String getPassword();
}
